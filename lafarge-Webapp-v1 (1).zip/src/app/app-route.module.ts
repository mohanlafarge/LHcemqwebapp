import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ArisRouteAuthorizationService } from './aris-core-ui-ng/src/app/common/services/aris-route-authorization.service';
import { LoginComponent } from './aris-core-ui-ng/src/app/pages/login-module/login.component';
import { PostLoginComponent } from './aris-core-ui-ng/src/app/pages/login-module/post-login.component';
import { PreLoginComponent } from './aris-core-ui-ng/src/app/pages/login-module/pre-login.component';
import { ArisZoomInChartComponent } from './aris-core-ui-ng/src/app/pages/zoom-in-module/aris-zoom-in-chart.component';
import { ArisZoomInInforcardChartComponent } from './aris-core-ui-ng/src/app/pages/zoom-in-module/aris-zoom-in-inforcard-chart.component';
import { AppLoginFailedComponent } from './pages/app-login-failed/app-login-failed.component';




console.log("Loading visRoutes");

const appRoutes: Routes = [

  /******************** APP Routes Start ***************/
  // ADD here all the routes to your application pages

  //{ path: 'page/home', loadChildren: './pages/app-landing/app-landing.module#AppLandingModule', canActivate: [ArisRouteAuthorizationService] },
  { path: 'page/detail', loadChildren: './pages/strength-prediction-details/strength-prediction-details.module#StrengthPredictionDetailsModule', canActivate: [ArisRouteAuthorizationService] },
  { path: 'page/overview', loadChildren: './pages/app-overview/app-overview.module#AppOverviewModule', canActivate: [ArisRouteAuthorizationService] },
  { path: 'page/home', loadChildren: './pages/app-landing/app-landing.module#AppLandingModule', canActivate: [ArisRouteAuthorizationService] },
  //{ path: 'page/uc2', loadChildren: './pages/todo-module/todo.module#TodoModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'PERM_VIEW_UC2' } },
  //{ path: 'page/uc3', loadChildren: './pages/todo-module/todo.module#TodoModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'PERM_VIEW_UC3' } },

  /********************* APP Routes End ****************/

  /******************** ARIS Routes Start ***********************/
  /******** ARIS - CORE & ADMINISTRATION PAGES ********/
  { path: 'login/pre', component: PreLoginComponent },
  { path: 'login/post', component: PostLoginComponent },
  { path: 'login/:errormessage', component: LoginComponent},
  { path: 'login', component: LoginComponent },
  { path: "loginfailed", component: AppLoginFailedComponent},
  { path: 'forgotpassword', loadChildren: './aris-core-ui-ng/src/app/pages/forgot-password-module/forgot-password.module#ForgotPasswordModule' },
  { path: 'resetpassword/:email/:token', loadChildren: './aris-core-ui-ng/src/app/pages/reset-password-module/reset-password.module#ResetPasswordModule' },
  { path: 'page/changePassword', loadChildren: './aris-core-ui-ng/src/app/pages/change-password-module/change-password.module#ChangePasswordModule', canActivate: [ArisRouteAuthorizationService] },
  { path: 'browsernotsupported', loadChildren: './aris-core-ui-ng/src/app/pages/browser-not-supported-module/browser-not-supported.module#BrowserNotSupportedModule' },
  { path: 'page/uc3', loadChildren: './aris-core-ui-ng/src/app/pages/todo-module/todo.module#TodoModule', canActivate: [ArisRouteAuthorizationService] },
  { path: 'page/legalTerms', loadChildren: './aris-core-ui-ng/src/app/pages/legalterms-module/legalterms.module#LegalTermsModule', canActivate: [ArisRouteAuthorizationService] },
  { path: 'page/geopage', loadChildren: './aris-core-ui-ng/src/app/common/ui-page-models/geo-module/aris-geo.module#ArisGeoModule', canActivate: [ArisRouteAuthorizationService] },
  { path: 'page/schematicdiag', loadChildren: './aris-core-ui-ng/src/app/common/ui-page-models/schematic-module/aris-schematic.module#ArisSchematicModule', canActivate: [ArisRouteAuthorizationService] },
  { path: 'page/chartgallery', loadChildren: './aris-core-ui-ng/src/app/prototypes/chart-gallery-module/chart-gallery.module#ChartGalleryModule', canActivate: [ArisRouteAuthorizationService] },
  { path: 'page/useraccessmanagement', loadChildren: './aris-core-ui-ng/src/app/pages/user-access-management-module/user-access-management.module#UserAccessManagementModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_ADMIN' } },
  { path: 'page/usergroupmanagement', loadChildren: './aris-core-ui-ng/src/app/pages/usergroup-module/aris-usergroup.module#ArisUsergroupModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_ADMIN' } },
  { path: 'page/preferences/usergroup', loadChildren: './aris-core-ui-ng/src/app/pages/preferences-module/aris-preferences.module#ArisPrefrencesModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_ADMIN' } },
  { path: 'page/preferences/user', loadChildren: './aris-core-ui-ng/src/app/pages/preferences-module/aris-preferences.module#ArisPrefrencesModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_ADMIN' } },
  { path: 'page/globalparameters', loadChildren: './aris-core-ui-ng/src/app/pages/globalparameter-module/globalparameter.module#GlobalParameterModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_ADMIN' } },
  { path: 'page/emaillist', loadChildren: './aris-core-ui-ng/src/app/pages/emaillist-module/aris-emaillist.module#ArisEmaillistModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_ADMIN' } },
  { path: 'page/assetconfigdata', loadChildren: './aris-core-ui-ng/src/app/pages/asset-config-module/asset-config.module#AssetConfigModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_ADMIN' } },
  { path: 'page/auditlog', loadChildren: './aris-core-ui-ng/src/app/pages/audit-module/audit.module#AuditModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_ADMIN' } },
  { path: 'page/logginginformation', loadChildren: './aris-core-ui-ng/src/app/pages/logging-module/logging.module#LoggingModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_ADMIN' } },
  { path: 'page/fileupload', loadChildren: './aris-core-ui-ng/src/app/pages/file-upload-module/aris-file-upload.module#ArisFileUploadModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_ADMIN' } },
  { path: 'page/notificationmanagement', loadChildren: './aris-core-ui-ng/src/app/pages/notification-management-module/aris-notification-management.module#ArisNotificationManagementModule', canActivate: [ArisRouteAuthorizationService] },

  { path: 'zoomInChart/:id', component: ArisZoomInChartComponent, canActivate: [ArisRouteAuthorizationService] },
  { path: 'zoomInInfocardChart/:id', component: ArisZoomInInforcardChartComponent, canActivate: [ArisRouteAuthorizationService] },

  /******** ARIS - DIGITAL TWIN PAGES *****************/
  { path: 'page/dt/predictivemodel/upload', loadChildren: './aris-core-ui-ng/src/app/pages/digital-twin-module/predictive-model-upload/aris-dt-predictive-model-upload.module#ArisDtPredictiveModelUploadModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_SUPERUSER' } },
  { path: 'page/dt/predictivemodelconfiguration', loadChildren: './aris-core-ui-ng/src/app/pages/digital-twin-module/predictive-model-configuration/aris-dt-predictive-model-configuration.module#ArisDtPredictiveModelConfigurationModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_SUPERUSER' } },
  { path: 'page/dt/setting', loadChildren: './aris-core-ui-ng/src/app/pages/digital-twin-module/configure-settings/aris-dt-configure-settings.module#ArisDtConfigureSettingsModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_SUPERUSER' } },
  { path: 'page/dt/agent/management', loadChildren: './aris-core-ui-ng/src/app/pages/digital-twin-module/agent-management/aris-dt-agent-management.module#ArisDtAgentManagementModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_SUPERUSER' } },
  { path: 'page/dt/agent/configuration', loadChildren: './aris-core-ui-ng/src/app/pages/digital-twin-module/agent-configuration/aris-dt-agent-configuration.module#ArisDtAgentConfigurationModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_SUPERUSER' } },
  { path: 'page/dt/processflow/configuration', loadChildren: './aris-core-ui-ng/src/app/pages/digital-twin-module/process-flow-configuration/aris-dt-process-flow-configuration.module#ArisDtProcessFlowConfigurationModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_SUPERUSER' } },
  { path: 'page/dt/processflow/management', loadChildren: './aris-core-ui-ng/src/app/pages/digital-twin-module/process-flow-management/aris-dt-process-flow-management.module#ArisDtProcessFlowManagementModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_SUPERUSER' } },
  { path: 'page/dt/simulation/management', loadChildren: './aris-core-ui-ng/src/app/pages/digital-twin-module/simulation-management/aris-dt-simulation-management.module#ArisDtSimulationManagementModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_SUPERUSER' } },
  { path: 'page/dt/simulation/run', loadChildren: './aris-core-ui-ng/src/app/pages/digital-twin-module/simulation-run/aris-dt-simulation-run.module#ArisDtSimulationRunModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_SUPERUSER' } },
  { path: 'page/dt/simulation/progress', loadChildren: './aris-core-ui-ng/src/app/pages/digital-twin-module/simulation-progress/aris-dt-simulation-progress.module#ArisDtSimulationProgressModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_SUPERUSER' } },
  { path: 'page/dt/simulation/results', loadChildren: './aris-core-ui-ng/src/app/pages/digital-twin-module/simulation-results/aris-dt-simulation-results.module#ArisDtSimulationResultsModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_SUPERUSER' } },
  { path: 'page/dt/simulation/3dview/:id', loadChildren: './aris-core-ui-ng/src/app/pages/digital-twin-module/simulation-3d-view-module/simulation-3d-view.module#Simulation3dViewModule', canActivate: [ArisRouteAuthorizationService], data: { authority: 'ROLE_SUPERUSER' } },

  /******** ARIS - PAGE UNDER-CONSTRUCTION ********************/
  { path: 'page/underconstruction', loadChildren: './aris-core-ui-ng/src/app/pages/todo-module/todo.module#TodoModule', canActivate: [ArisRouteAuthorizationService] },

  /******** ARIS - PAGE NOT FOUND ********************/
  { path: '', redirectTo: 'login/pre', pathMatch: 'full' }

  /******************** ARIS Routes End ***********************/
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes, { useHash: true }),
  ],
  exports: [
    RouterModule,
  ],
  providers: [ArisRouteAuthorizationService]
})

export class AppRoutingModule {




}
