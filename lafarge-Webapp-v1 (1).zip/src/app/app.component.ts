import { Component, ViewContainerRef, Inject, HostListener } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent } from '@angular/router';
import { DOCUMENT } from '@angular/platform-browser';

// ARIS Services
import { ArisThemeService } from './aris-core-ui-ng/src/app/common/services/aris-theme.service';
import { ArisUserOperationService } from './aris-core-ui-ng/src/app/common/services/aris-user-operation.service';
import { ArisRouteInterceptor } from './aris-core-ui-ng/src/app/common/interceptors/aris-route.interceptor';

// ARIS&VIS Configuration: ARIS Must be overrited in case of VIS implementations
import { getAppLocalConfiguration } from './../app/config/configApp';



declare global {
    interface Window { app: any; selectMarker: any; }
}
window.app = window.app || { config: { } };

getAppLocalConfiguration();

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [],
  providers: [ArisThemeService]
})
export class AppComponent {

  title = 'CemQ';

  constructor(private router: Router,
              vRef: ViewContainerRef,
              @Inject(DOCUMENT) private document,
              private arisThemeService: ArisThemeService,
              private arisRouteInterceptor: ArisRouteInterceptor) {
    this.arisThemeService.changeTheme(window.app.config.application.theme);
  }

  @HostListener('document:click', ['$event'])
  onClickHandler (event: MouseEvent) {
    ArisUserOperationService.getInstance().setUserOperation(true);
  }

  @HostListener('document:keypress', ['$event'])
  onKeypressHandler (event: KeyboardEvent) {
    ArisUserOperationService.getInstance().setUserOperation(true);
  }

}
