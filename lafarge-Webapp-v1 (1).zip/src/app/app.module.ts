// ANGULAR & PLUGINS MODULES
// Angular Core
// Http
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
// Route
import {RouteReuseStrategy} from '@angular/router';
// EXTERNAL MODULES
import {ToastrModule} from 'ngx-toastr';
// APP Routing & Component
import {AppRoutingModule} from './app-route.module';
import {AppComponent} from './app.component';
// ARIS Interceptors
import {ArisHttpInterceptor} from './aris-core-ui-ng/src/app/common/interceptors/aris-http.interceptor';
import {ArisRouteInterceptor} from './aris-core-ui-ng/src/app/common/interceptors/aris-route.interceptor';
import {ArisPipesModule} from './aris-core-ui-ng/src/app/common/pipes/aris-pipes.module';
import {ArisConfigService} from './aris-core-ui-ng/src/app/common/services/aris-config.service';
import {ArisFilterService} from './aris-core-ui-ng/src/app/common/services/aris-filter.service';
import {ArisLastLoginInfoService} from './aris-core-ui-ng/src/app/common/services/aris-last-login-info.service';
import {ArisNotificationService} from './aris-core-ui-ng/src/app/common/services/aris-notification.service';
import {ArisPageRefreshService} from './aris-core-ui-ng/src/app/common/services/aris-page-refresh.service';
import {ArisPermissionService} from './aris-core-ui-ng/src/app/common/services/aris-permission.service';
import {ArisRouteReuseStrategy} from './aris-core-ui-ng/src/app/common/services/aris-route-reuse-strategy.service';
// ARIS Services
import {ArisSessionService} from './aris-core-ui-ng/src/app/common/services/aris-session.service';
import {ArisUserOperationService} from './aris-core-ui-ng/src/app/common/services/aris-user-operation.service';
import {ArisWebSocketService} from './aris-core-ui-ng/src/app/common/services/aris-websocket.service';
import {ArisUiComponentsModule} from './aris-core-ui-ng/src/app/common/ui-components/aris-ui-components.module';
import {ArisPageModule} from './aris-core-ui-ng/src/app/common/ui-page-models/page-module/aris-page.module';
import {ArisBreadCrumbModule} from './aris-core-ui-ng/src/app/common/ui-page-sections/aris-bread-crumb/aris-bread-cumb-components.module';
import {ArisCookieModalModule} from './aris-core-ui-ng/src/app/common/ui-page-sections/cookie-module/aris-cookie-modal.module';
import {ArisErrorService} from './aris-core-ui-ng/src/app/common/ui-page-sections/error-module/services/aris-error.service';
import {ArisFooterModule} from './aris-core-ui-ng/src/app/common/ui-page-sections/footer-module/aris-footer.module';
//import {ArisHeaderModule} from './aris-core-ui-ng/src/app/common/ui-page-sections/header-module/aris-header.module';
//import {ArisHeaderService} from './aris-core-ui-ng/src/app/common/ui-page-sections/header-module/services/aris-header-service';
import {ArisLanguageService} from './aris-core-ui-ng/src/app/common/ui-page-sections/language-selector-module/services/aris-language.service';
import {ArisPopUpModule} from './aris-core-ui-ng/src/app/common/ui-page-sections/pop-up-module/aris-popup.module';
import {ArisPageSectionObservableEventService} from './aris-core-ui-ng/src/app/common/ui-page-sections/services/aris-page-section-observable-event.service';
// ARIS Modules & Components
import {LoginModule} from './aris-core-ui-ng/src/app/pages/login-module/login.module';
import {ArisZoomInModule} from './aris-core-ui-ng/src/app/pages/zoom-in-module/aris-zoom-in.module';
import {ChartGalleryModule} from './aris-core-ui-ng/src/app/prototypes/chart-gallery-module/chart-gallery.module';
import {CementCommonModule} from './common/services/cement-common.module';
import { AppOverviewModule } from './pages/app-overview/app-overview.module';
import { AppLandingModule } from './pages/app-landing/app-landing.module';
import {StrengthPredictionDetailsModule} from './pages/strength-prediction-details/strength-prediction-details.module';
// I18n global configuration
import {AppI18nModule} from './translation/app-i18n.module';
import {LafargeHolclimMultiLineChartService} from "./common/services/lafarge-multi-line-chart.service";
import { ArisC3BarLineChartService } from "./common/services/aris-c3-chart-bar-line.service";
import { LhHeaderModule } from './common/ui-page-sections/lh-header-module/lh-header.module';
import { LhHeaderService } from './common/ui-page-sections/lh-header-module/services/lh-header-service';
import { AppLoginFailedModule } from './pages/app-login-failed/app-login-failed.module';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    /****** ARIS CORE MODULES *******/
    BrowserModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    HttpClientModule,
    LoginModule,
    ArisPageModule,
    LhHeaderModule,
    ArisFooterModule,
    ArisBreadCrumbModule,
    ArisZoomInModule,
    ArisPopUpModule,
    ArisUiComponentsModule,
    ArisCookieModalModule,
    CementCommonModule,
    AppOverviewModule,
    AppLoginFailedModule,
    StrengthPredictionDetailsModule,
    AppLandingModule,

    /******* APP BASIC MODULE *******/
    AppI18nModule,
    AppRoutingModule,
    ArisPipesModule,
    ChartGalleryModule,
    CementCommonModule.forRoot()
  ],
  providers: [
    /****** ARIS CORE PROVIDERS *******/
    ArisSessionService,
    ArisErrorService,
    LafargeHolclimMultiLineChartService,
    ArisC3BarLineChartService,
    ArisPermissionService,
    {
      provide: RouteReuseStrategy,
      useClass: ArisRouteReuseStrategy
    },
    ArisConfigService,
    ArisLanguageService,
    ArisUserOperationService,
    ArisPageRefreshService,
    ArisLastLoginInfoService,
    ArisFilterService,
    ArisPageSectionObservableEventService,
    // This line borke the AOT compilation: don´t uncomment   { provide: Window, useValue: window }
    {provide: HTTP_INTERCEPTORS, useClass: ArisHttpInterceptor, multi: true},
    ArisRouteInterceptor,
    LhHeaderService,
    ArisWebSocketService,
    ArisNotificationService
    /****** APP CORE PROVIDERS *******/

    /****** END-APP CORE PROVIDERS *******/
  ],
  bootstrap: [AppComponent],
})
export class AppModule {
}
