# ARIS-CORE-UI

ARIS (Accenture Resource Industry Solutions) is an application that provide a set of functionality/services/components..., that are reusables by all the 'Resource Industry' solutions.

ARIS provides reusable elements at different layers (Web Layer, Server Application Layer, Persistent Layer, Processing Layer)

ARIS-CORE-UI centralize the elements reusables at Web Layer.   

# GETTING STARTED

**To install the dependences libraries:**
1. "cd" into the root directory of the project.
2. Execute "npm install"

**To Execute the application:**
1. Execute "npm start"
2. Open a browser and put "http://localhost:4200"

**To Access:**
The application will display a Login Page.
Use the following information:
- User: daniel.cazares
- Password: p@ssword

After execute the Login, the application will display a Home page with a Navigation bar. This navigation bar will include a Logo, some static information and Links/Menu that will give access to other Pages.


# PRECONFIGURED TASKS
This project was generated with [Angular CLI](https://github.com/angular/angular-cli) .
The tasks preconfigured were genereated automatically by Angular CLI.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).
Before running the tests make sure you are serving the app via `ng serve`.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
