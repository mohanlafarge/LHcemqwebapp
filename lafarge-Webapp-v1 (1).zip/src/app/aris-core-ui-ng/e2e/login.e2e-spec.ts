import { LoginPage } from './login.po';

describe('poc-from-scratch App', () => {
  let loginPage: LoginPage;

  beforeEach(() => {
    loginPage = new LoginPage();
  });

  it('Should display Login title', () => {
    loginPage.navigateTo();
    expect(loginPage.getLoginAppText()).toEqual('ARIS ANALYTICS DASHBOARD');
  });

  it('Should display username input', () => {
    loginPage.navigateTo();
    expect(loginPage.getUserName().isPresent()).toBeTruthy();
  });

  it('Should display password input', () => {
    loginPage.navigateTo();
    expect(loginPage.getPassword().isPresent()).toBeTruthy();
  });

  it('Should display Login button', () => {
    loginPage.navigateTo();
    expect(loginPage.getLoginButton().isPresent()).toBeTruthy();
  });

  it('Should login when password and username are valid', () => {
    loginPage.navigateTo();
    loginPage.setUserNameValue('daniel.cazares');
    expect(loginPage.getUserNameValue()).toEqual('daniel.cazares');
    loginPage.setPassword('p@ssword');
    expect(loginPage.getPasswordValue()).toEqual('p@ssword');
    loginPage.getLoginButton().click();
    loginPage.waitForURLContain('page/home', 1000);
  });

});
