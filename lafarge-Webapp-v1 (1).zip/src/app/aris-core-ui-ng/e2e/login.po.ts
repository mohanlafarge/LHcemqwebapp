import { browser, by, element } from 'protractor';

export class LoginPage {
  navigateTo() {
    return browser.get('/');
  }

  getLoginAppText() {
    return element(by.css('.login-title')).getText();
  }

  getUserName() {
    return element(by.id('username'));
  }

  getUserNameValue() {
    return this.getUserName().getAttribute('value');
  }

  setUserNameValue(value) {
    let username = this.getUserName();
    username.clear();
    username.sendKeys(value);
  }

  getPassword() {
    return element(by.id('password'));
  }

  getPasswordValue() {
    return this.getPassword().getAttribute('value');
  }

  setPassword(value) {
    let password = this.getPassword();
    password.clear();
    password.sendKeys(value);
  }

  getLoginButton() {
    return element(by.css('.btn'));
  }

  waitForURLContain(urlExpected: string, timeout: number) {
    try {
      const condition = browser.ExpectedConditions;
      browser.wait(condition.urlContains(urlExpected), timeout);
    } catch (e) {
      console.error('URL not contain text.', e);
    }
  }
}
