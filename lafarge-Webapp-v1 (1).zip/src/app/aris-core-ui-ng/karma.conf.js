// Karma configuration file, see link for more information
// https://karma-runner.github.io/1.0/config/configuration-file.html

module.exports = function (config) {
  process.env.CHROME_BIN = require('puppeteer').executablePath()
  config.set({
    basePath: '',
    frameworks: ['jasmine', '@angular/cli'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('karma-firefox-launcher'),
      require('karma-jasmine-html-reporter'),
      require('karma-html-reporter'),
      require('karma-coverage-istanbul-reporter'),
      require('@angular/cli/plugins/karma')
    ],
    client:{
      clearContext: false // leave Jasmine Spec Runner output visible in browser
    },
    coverageIstanbulReporter: {
      reports: [ 'html', 'lcovonly' ],
      fixWebpackSourcePaths: true
    },
    angularCli: {
      environment: 'dev',
      sourcemaps: false
    },
    reporters: ['progress', 'kjhtml', 'html'],
    port: 9876,

  	htmlReporter: {
      outputDir: 'karma_html', // where to put the reports  
      reportName: 'report-summary-filename', // report summary filename; browser info by default 
    },
	
    proxies: {
      'geoserver/*': {
        'target': 'http://172.48.102.108:30000',
      }
    },
    files: [
      'src/app/mocks/tests/google-api-mock.js'
    ],
    colors: true,
    logLevel: config.LOG_INFO,
    autoWatch: true,    
    browserNoActivityTimeout : 300000,
    captureTimeout: 300000,
    // browsers: ['Firefox'],
   // browsers: ['FirefoxHeadless'],
    // browsers: ['Chrome'],
    customLaunchers: {
      ChromeHeadless: {
        base: 'Chrome',
        flags: [
          '--headless',
          '--disable-gpu',
          '--no-sandbox',
          '--remote-debugging-port=9222',
        ]
      }
    },
    browsers: ['ChromeHeadless'],
    // singleRun: false
    singleRun: true
  });
};
