/**
 * Entry point for all public APIs of the package.
 */
export * from './src/app/aris-core-ui-ng';
