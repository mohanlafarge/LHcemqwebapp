import { Component, ViewContainerRef, Inject, HostListener } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, Event as NavigationEvent } from '@angular/router';
import { DOCUMENT } from '@angular/platform-browser';

// ARIS Services
import { ArisThemeService } from './common/services/aris-theme.service';
import { ArisUserOperationService } from './common/services/aris-user-operation.service';
import { ArisRouteInterceptor } from './common/interceptors/aris-route.interceptor';

// ARIS&VIS Configuration: ARIS Must be overrited in case of VIS implementations
import { getArisLocalConfiguration } from './../app/config/configAris';



declare global {
  interface Window { app: any; selectMarker: any; }
}
window.app = window.app || { config: { } };

getArisLocalConfiguration();

@Component({
  selector: 'aris-root',
  templateUrl: './aris.component.html',
  styleUrls: [],
  providers: [ArisThemeService]
})
export class ArisComponent {

  title = 'aris';

  constructor(private router: Router,
              vRef: ViewContainerRef,
              @Inject(DOCUMENT) private document,
              private arisThemeService: ArisThemeService,
              private arisRouteInterceptor: ArisRouteInterceptor) {
  }

  @HostListener('document:click', ['$event'])
  onClickHandler (event: MouseEvent) {
    ArisUserOperationService.getInstance().setUserOperation(true);
  }

  @HostListener('document:keypress', ['$event'])
  onKeypressHandler (event: KeyboardEvent) {
    ArisUserOperationService.getInstance().setUserOperation(true);
  }

}
