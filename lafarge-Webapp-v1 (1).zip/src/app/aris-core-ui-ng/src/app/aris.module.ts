// ANGULAR & PLUGINS MODULES
// Angular Core
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// Http
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
// Route
import { RouteReuseStrategy } from '@angular/router';

// EXTERNAL MODULES
import { ToastrModule } from 'ngx-toastr';

// ARIS Interceptors
import { ArisHttpInterceptor } from './common/interceptors/aris-http.interceptor';

// ARIS Modules & Components
import { LoginModule } from './pages/login-module/login.module';
import { ArisPageModule } from './common/ui-page-models/page-module/aris-page.module';
import { ArisHeaderModule } from './common/ui-page-sections/header-module/aris-header.module';
import { ArisFooterModule } from './common/ui-page-sections/footer-module/aris-footer.module';
import { ArisUiComponentsModule } from './common/ui-components/aris-ui-components.module';
import { ArisZoomInModule } from './pages/zoom-in-module/aris-zoom-in.module';
import { ArisCookieModalModule } from './common/ui-page-sections/cookie-module/aris-cookie-modal.module';
import { ArisPopUpModule } from './common/ui-page-sections/pop-up-module/aris-popup.module';
import { ArisBreadCrumbModule } from './common/ui-page-sections/aris-bread-crumb/aris-bread-cumb-components.module';

// ARIS Services
import { ArisSessionService } from './common/services/aris-session.service';
import { ArisPermissionService } from './common/services/aris-permission.service';
import { ArisPageRefreshService } from './common/services/aris-page-refresh.service';
import { ArisErrorService } from './common/ui-page-sections/error-module/services/aris-error.service';
import { ArisConfigService } from './common/services/aris-config.service';
import { ArisLanguageService } from './common/ui-page-sections/language-selector-module/services/aris-language.service';
import { ArisLastLoginInfoService } from './common/services/aris-last-login-info.service';
import { ArisUserOperationService } from './common/services/aris-user-operation.service';
import { ArisFilterService } from './common/services/aris-filter.service';
import { ArisHeaderService } from './common/ui-page-sections/header-module/services/aris-header-service';
import { ArisRouteReuseStrategy } from './common/services/aris-route-reuse-strategy.service';
import { ArisPageSectionObservableEventService } from './common/ui-page-sections/services/aris-page-section-observable-event.service';
import { ArisRouteInterceptor } from './common/interceptors/aris-route.interceptor';
import { ArisWebSocketService } from './common/services/aris-websocket.service';
import { ArisNotificationService } from './common/services/aris-notification.service';

// ARIS Routing & Component
import { ArisRoutingModule } from './aris-route.module';
import { ArisComponent } from './aris.component';
// I18n global configuration
import { ArisI18nModule } from './translation/aris-i18n.module';



@NgModule({
  declarations: [
    ArisComponent
  ],
  imports: [
    /****** ARIS CORE MODULES *******/
    BrowserModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    HttpClientModule,
    LoginModule,
    ArisPageModule,
    ArisHeaderModule,
    ArisFooterModule,
    ArisBreadCrumbModule,
    ArisZoomInModule,
    ArisPopUpModule,
    ArisUiComponentsModule,
    ArisCookieModalModule,

    /******* APP ARIS BASIC MODULE *******/
    ArisI18nModule,
    ArisRoutingModule
  ],
  providers:    [
    /****** ARIS CORE PROVIDERS *******/
    ArisSessionService,
    ArisErrorService,
    ArisPermissionService,
    {provide: RouteReuseStrategy,
      useClass: ArisRouteReuseStrategy},
    ArisConfigService,
    ArisLanguageService,
    ArisUserOperationService,
    ArisPageRefreshService,
    ArisLastLoginInfoService,
    ArisFilterService,
    ArisPageSectionObservableEventService,
    // This line borke the AOT compilation: don´t uncomment   { provide: Window, useValue: window }
    { provide: HTTP_INTERCEPTORS, useClass: ArisHttpInterceptor, multi: true },
    ArisRouteInterceptor,
    ArisHeaderService,
    ArisWebSocketService,
    ArisNotificationService
  ],
  bootstrap: [ArisComponent],
})
export class ArisModule { }
