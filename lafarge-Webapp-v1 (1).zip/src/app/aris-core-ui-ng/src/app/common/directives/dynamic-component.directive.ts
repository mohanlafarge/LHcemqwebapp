import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[arisDynamicDirective]',
})
export class DynamicComponentDirective {
  constructor(public viewContainerRef: ViewContainerRef) { }
}
