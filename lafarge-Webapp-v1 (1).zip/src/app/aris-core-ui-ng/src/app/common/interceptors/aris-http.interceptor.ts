import { Injectable } from '@angular/core';
import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpResponse,
  HttpXsrfTokenExtractor,
  HttpErrorResponse
} from '@angular/common/http';
import { Router } from '@angular/router';

import { Observable } from 'rxjs/Observable';

import { ArisUserOperationService } from '../services/aris-user-operation.service';
import { ArisNotificationBoxService } from '../ui-page-sections/error-module/services/aris-notification-box.service';
import { ArisSessionService } from '../services/aris-session.service';
import { ArisErrorService } from '../ui-page-sections/error-module/services/aris-error.service';
import { ArisWebSocketService } from '../services/aris-websocket.service';

@Injectable()
export class ArisHttpInterceptor implements HttpInterceptor {

  result: {
    status: number,
    title: string,
    message: string
  };

  constructor(private router: Router,
    private notificationService: ArisNotificationBoxService,
    private arisWebSocketService: ArisWebSocketService,
    private arisSessionService: ArisSessionService,
    private arisErrorService: ArisErrorService,
    private tokenExtractor: HttpXsrfTokenExtractor) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    const isGet = req.method === 'GET';
    const isPreLogin = req.url === 'rest/authenticationinfo/prelogin';
    const isLogin = req.url === 'rest/j_spring_security_check';
    const isLogout = req.url === 'rest/logout';

    return next.handle(this.updateHeader(req))
      .do((response: HttpEvent<any>) => {
        if (response instanceof HttpResponse && !isGet && !isLogin && !isLogout && !isPreLogin) {
          this.result = {
            status: response.status,
            title: response.statusText,
            message: null,
          };
        }
      })
      .catch((response) => {
        if (response instanceof HttpErrorResponse) {
          this.manageResponseError(response);
        }

        // In case of Expiration time (401 been logged) the popup dialog asking by the user/password
        // must not be displayed. To avoid this we have to avoid send the 'req' to the next handle of request
        if (response.status !== 401 && !this.arisSessionService.isLoggedIn()) {
          return next.handle(req);
        }
      });
  }

  private updateHeader(request: any) {
    const headerName = 'X-XSRF-TOKEN';
    let token = this.tokenExtractor.getToken() as string;
    console.log("TTTTTTTTTT", token)
//    this.arisConfigService.setParameter({ assetAttributeName: "X-XSRF-TOKEN", assetAttributeValue: token });
    this.arisSessionService.set_x_xsrf_Token(token);
    // Added Cache Control and Pragma to headers with No-Cache;
    // With CORS let reqWithCacheControl = request.clone({ headers: request.headers.set('cache-control', 'no-cache').set('Pragma', 'no-cache'), withCredentials: true });
    let reqWithCacheControl = request.clone({ headers: request.headers.set('cache-control', 'no-cache').set('Pragma', 'no-cache'), withCredentials: true });
    let reqWithXRequested = reqWithCacheControl.clone({ headers: reqWithCacheControl.headers.set('X-Requested-With', 'XMLHttpRequest') });
    let reqWithXUserOperation = reqWithXRequested.clone({ headers: reqWithXRequested.headers.set('x-user-operation', ArisUserOperationService.getInstance().isUserOperation() + '') });
    let reqWithAuthorization: any;
    if (token !== null) {
      let reqWithXsrfToken = reqWithXUserOperation.clone({ headers: reqWithXUserOperation.headers.set(headerName, token) });
      reqWithAuthorization = reqWithXsrfToken.clone({ headers: reqWithXsrfToken.headers.set('Authorization', '') });
    } else {
      reqWithAuthorization = reqWithXUserOperation.clone({ headers: reqWithXUserOperation.headers.set('Authorization', '') });
    }

    if (window.app.config.application.timeout !== undefined) {
      reqWithAuthorization.timeout = window.app.config.application.timeout;
    } else {
      reqWithAuthorization.timeout = 60000;
    }
    return reqWithAuthorization;
  }

  private manageResponseError(response) {
    let commError: any = {};

    console.log(response);
    // Session has expired
    if ((response.status === 401 && this.arisSessionService.isLoggedIn()) ||
      (this.arisSessionService.isExpired())) {
      this.arisWebSocketService.disconnectAll();
      this.arisSessionService.setExpired(true);
      commError.status = response.status;
      commError.title = 'CLI_ERR_TIT_ACCES_DENIED';
      commError.message = 'CLI_ERR_DESC_SESSION_EXPIRED';
      if ((localStorage !== undefined) &&
        (localStorage.arisLocalConfig !== undefined) &&
        (JSON.parse(localStorage.arisLocalConfig)['AUTHENTICATION_PROVIDER_TYPE'] === 'SAML')) {
          let landingPageData = { "statusCode": 407, "message":"Your session has expired. Please go to PACT to log in.", "errorTitle":  "CLI_ERR_TIT_ACCES_DENIED"};
          this.router.navigate(["loginfailed"], { queryParams: landingPageData });
          // window.open( 'saml/logout', '_self');
      } else {
        this.router.navigate(['login', JSON.stringify(commError)]);
      }
    } else if (response.status !== 200 && response.status !== 404) {
      if ((response.status === 503) ||
        (response.status === -1 && response.data === null)) {
        commError.title = 'LOGIN_ERR_TIT_001';
        commError.message = 'LOGIN_ERR_COD_001';
        commError.status = '503';
      } else if (response.status === 500) {
        commError.status = response.status;
        commError.title = 'APP_ERR_TIT_CONNECTION_ERROR';
        commError.message = 'APP_ERR_CONNECTION_ERROR';

        if (response.error !== null && response.error.message !== null && response.error.message !== undefined) {
          if (response.error.message.indexOf(response.status + ' null') !== -1 && response.message !== null) {
            commError.title = 'APP_ERR_TIT_INTERNAL_SERVER_ERROR';
            commError.message = response.message;
          } else {
            commError.title = 'CLI_MSG_TIT_OPERATION_NO_SUCCESS';
            const position = response.error.message.indexOf('Exception');
            if (position !== -1) {
              commError.message = response.error.message.substring(position + 10);
            } else {
              commError.message = response.error.message;
            }
          }
        }

      } else if (response.status === 504) {
        commError = {
          status: response.status,
          title: 'APP_ERR_TIT_CONNECTION_ERROR',
          message: 'APP_ERR_CONNECTION_ERROR'
        };
      } else if (response instanceof HttpErrorResponse &&
        ((response.error.text !== undefined) ||
          (response.error.message !== undefined && response.error.message.indexOf('CSRF') === -1))) {
        commError = {
          status: response.status,
          title: response.statusText,
          message: response.message
        };
      } else {
        commError.status = response.status;
        commError.title = response.error.statusText;
        commError.message = response.error.message;
      }

      // This interceptor only must display the errors in case of be logged in
      // In other case, the error will be managed by login Service/Controller
      if (this.arisSessionService.isLoggedIn()) {
        // The errors testing "temporal datasources" must not be displayed here
        if ((response.error == null) ||
          (response.error !== null &&
            (response.error.path === undefined ||
              (response.error.path !== null &&
                response.error.path.indexOf('tempDatasource') === -1)))) {
          if (response.status !== '0' && response.status !== 0) {
            this.notificationService.showNotification(commError, 'right', 'error');
          }
        }
      } else if (response != null && response !== undefined) {
        // CSRF-TOKEN/XSRF-TOKEN no created
        if (response.error !== undefined && response.error.message !== undefined &&
          response.error.message.indexOf('CSRF') !== -1) {
          // Don´t display message error
          // The CSRF error is managed and displayed by the login component
        } else {
          this.arisErrorService.showArisError.next(response.error);
        }
      } else {
        this.arisErrorService.showArisError.next(response);
      }
    }
  }
}
