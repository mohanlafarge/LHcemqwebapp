import { Injectable } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ArisPageService } from '../services/aris-page-service';


@Injectable()
export class ArisRouteInterceptor {
  lastUrl = '';
  constructor(private router: Router,
    private toastr: ToastrService,
    private arisPageService: ArisPageService) {
    this.router.events
      .map(event => event instanceof NavigationStart)
      .subscribe((e) => {
        if (document.URL.indexOf(document.baseURI) === -1) {
          window.open(document.baseURI, "_self");
          return;
        }
        if (this.lastUrl !== this.router.url) {
          this.arisPageService.initPage(this.router.url, undefined);
          this.lastUrl = this.router.url;
          this.toastr.clear();
        }
      });
  }
}

