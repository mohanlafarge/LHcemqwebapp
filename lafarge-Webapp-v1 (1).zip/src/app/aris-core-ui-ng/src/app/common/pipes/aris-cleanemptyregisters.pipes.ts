/**
  * The filter 'ariscleanemptyregisters' allows remove from an array the empty entries
  */
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'ariscleanemptyregisters',
})
export class ArisCleanEmptyRegistersPipe implements PipeTransform {
  constructor() { }
  transform(value: any) {
    if (value !== undefined) {
      var filteredValue = value.filter(function (el) {
        return el[Object.keys(el)[0]] != null;
      });
    }
    return filteredValue;
  }
}
