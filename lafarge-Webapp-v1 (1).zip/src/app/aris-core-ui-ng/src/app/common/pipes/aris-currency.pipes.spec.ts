import { HttpClient, HttpHandler } from '@angular/common/http';
import { CurrencyPipe } from '@angular/common';
import {
  TranslationService,
  LocaleService,
  TranslationHandler,
  TranslationConfig,
  TranslationProvider,
  LocaleStorage,
  LocaleConfig,
} from 'angular-l10n';

import { ArisCurrencyPipe } from './aris-currency.pipes';
import { ArisPermissionService } from '../services/aris-permission.service';
import { ArisConfigService } from '../services/aris-config.service';
import { ArisLanguageService } from '../ui-page-sections/language-selector-module/services/aris-language.service';

describe('Test Pipe: ArisCurrencyPipe', () => {
  const mockDataUSD = {
    arisConfig: [{
      assetAttributeName: 'Currency',
      value: 'USD',
    }, {
      assetAttributeName: 'Currency Symbol',
      value: '$',
    }],
  };

  const mockDataEUR = {
    arisConfig: [{
      assetAttributeName: 'Currency',
      value: 'EUR',
    }, {
      assetAttributeName: 'Currency Symbol',
      value: '€',
    }],
  };
  let httpHandler: HttpHandler;
  const httpClient = new HttpClient(httpHandler);
  const languageservice = new ArisLanguageService();
  const configService = new ArisConfigService(httpClient, languageservice);
  const currencyPipe = new CurrencyPipe('en-gb');
  let arisCurrencyPipe: ArisCurrencyPipe;

  beforeEach(() => {
    arisCurrencyPipe = new ArisCurrencyPipe(configService, currencyPipe);
  });

  afterEach(() => {
    arisCurrencyPipe = null;
  });

  it('Received 100, the pipe should return the Currency Symbol (USD) configured plus the "ammount" ==> $100.00', () => {
    configService.setArisConfig(mockDataUSD.arisConfig);
    const result = arisCurrencyPipe.transform(100, true);
    expect(result).toBe('$100.00');
  });

  it('Received 10000000, the pipe should return the Currency Symbol (USD) configured plus the "ammount/1000" plus "M" ==> $10.00M', () => {
    configService.setArisConfig(mockDataUSD.arisConfig);
    const result = arisCurrencyPipe.transform(10000000, true);
    expect(result).toBe('$10.00M');
  });

  it('Received 100, the pipe should return the Currency Symbol (EUR) configured plus the "ammount" ==> €100.00', () => {
    configService.setArisConfig(mockDataEUR.arisConfig);
    const result = arisCurrencyPipe.transform(100, true);
    expect(result).toBe('€100.00');
  });

  it('Received 10000000, the pipe should return the Currency Symbol (EUR) configured plus the "ammount/1000" plus "M" ==> €10.00M', () => {
    configService.setArisConfig(mockDataEUR.arisConfig);
    const result = arisCurrencyPipe.transform(10000000, true);
    expect(result).toBe('€10.00M');
  });

  it('Amount null scenario', () => {
    const result = arisCurrencyPipe.transform(null, true);
    expect(result).toBe('');
  });
});
