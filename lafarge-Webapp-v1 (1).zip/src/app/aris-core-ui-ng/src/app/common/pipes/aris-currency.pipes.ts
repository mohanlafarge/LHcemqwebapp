/**
  * The filter 'ariscurrency' allows format an amount following
  * the specifications defined in the locale
  * The symbol used as currency symbol will be the defined in the DB table 'GLOBAL_PARAMETERS'
  * param amount  -->  money amount
  * param millon  -->  boolean used to specify if we wish display a 'M' to represent millons
  */
import { Pipe, PipeTransform } from '@angular/core';
import { CurrencyPipe } from '@angular/common';

import { ArisConfigService } from '../services/aris-config.service';

@Pipe({
  name: 'ariscurrency'
})
export class ArisCurrencyPipe implements PipeTransform {
  constructor(private arisConfigService: ArisConfigService, private currencyPipe: CurrencyPipe) { }
  transform(amount: any, millon: any) {
    const symbol = this.arisConfigService.getCurrencySymbol();
    let result = '';
    if (amount !== null && amount !== undefined) {
      if (millon !== undefined && amount > 1000000) {
        const milionAmount = amount / 1000000;
        result = this.currencyPipe.transform(milionAmount, symbol);
        result = result + 'M';
      } else {
        result = this.currencyPipe.transform(amount, symbol);
      }
    }
    return result;
  }
}
