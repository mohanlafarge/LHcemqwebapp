import { ArisDateTimePipe } from './aris-datetime.pipes';
import { DatePipe } from '@angular/common';


describe('Test Pipe: ArisDateTimePipe', () => {
  const locale = 'en';
  const date = new DatePipe(locale);
  let arisdatetime: ArisDateTimePipe;

  beforeEach(() => {
    arisdatetime = new ArisDateTimePipe(date);
  });

  afterEach(() => {
    arisdatetime = null;
  });

  it('Received an undefined date, it should return "undefined"', () => {
    const value = undefined;
    const datetime = arisdatetime.transform(value);
    expect(datetime).toMatch('undefined');
  });

  it('Received a valid date in milisecond, it should return a date in format (yyyy-mm-dd hh:mm:ss a) ==> 2010-10-28 23:40:23 EDT', () => {
    const value = 1288323623006;
    const datetime = arisdatetime.transform(value);
    expect(datetime).toMatch('2010-10-28');
  });

  it('Received a valid date in milisecond (1434254400000 --> 2015-06-14 00:00:00) without time, it should return only the date (yyyy-mm-dd) ==> 2015-06-14', () => {
    const value = 1434254400000;
    const datetime = arisdatetime.transform(value);
    expect(datetime).toMatch('2015-06-14');
  });

});
