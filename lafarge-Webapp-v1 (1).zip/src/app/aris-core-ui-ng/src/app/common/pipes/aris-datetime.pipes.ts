 /**
 * Filter to convert timestamp format.
 * If no time componentnt is present, remove it from date string.
 */
import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'arisdatetime',
})
export class ArisDateTimePipe implements PipeTransform {
  constructor(private datePipe: DatePipe) { }
  transform(value: any) {
    let result;
    if (!value) {
      return value;
    }
    let date = this.datePipe.transform(value, 'yyyy-MM-dd', 'EDT');
    // date = date + ' EDT';
    // if no time, then remove time component from string.
    const index = date.indexOf(' 00:00:00');
    if (index === -1) {
      result = date;
    } else {
      result = date.substring(0, index);
    }
    return result;
  }
}
