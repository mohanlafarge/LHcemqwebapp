/**
 * Filter to update the date received to local date and convert timestamp format.
 * If no time componentnt is present, remove it from date string.
 */
import { Pipe, PipeTransform } from '@angular/core';
import { ArisThemeService } from '../services/aris-theme.service';

@Pipe({
  name: 'arisimagechange',
  pure: false
})
export class ArisImagePipe implements PipeTransform {  
  themeConfig: any; 
  constructor(private arisThemeService: ArisThemeService) { }
  transform(imageIcon: string) {      
    this.themeConfig = this.arisThemeService.getThemeConfig();   
    return this.themeAndLogoSelection(imageIcon);
  }

  private themeAndLogoSelection(imageIcon: string) {
    for (let i = 0; i < this.themeConfig.themeList.length; i += 1) {
      if (this.themeConfig.themeList[i].class === this.themeConfig.defaultType) {
        return this.changeLogoOnThemeChange(i, imageIcon);
      }
    }     
  }

  private changeLogoOnThemeChange(i: number, imageIcon: string) {    
    for (let j = 0; j < this.themeConfig.themeList[i].colorList.length; j += 1) {
      if (this.themeConfig.themeList[i].colorList[j].class === this.themeConfig.defaultColor) {
        return imageIcon.replace("*", this.themeConfig.themeList[i].colorList[j].name.toLowerCase());                        
      }
    }    
  }  
}


