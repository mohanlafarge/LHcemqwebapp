import { DatePipe } from '@angular/common';

import { ArisLocalDateTimePipe } from './aris-local-datetime.pipes';

describe('Test Pipe: ArisLocaldatetime ', () => {
  const locale = 'en';
  const datePipe = new DatePipe(locale);
  let arisLocalDateTimePipe: ArisLocalDateTimePipe;

  beforeEach(() => {
    arisLocalDateTimePipe = new ArisLocalDateTimePipe(datePipe);
  });

  afterEach(() => {
    arisLocalDateTimePipe = null;
  });

  it('Received an "undefined" date, the pipe should return "undefined"', () => {
    const value = 1288323623006;
    const datetime = arisLocalDateTimePipe.transform(undefined);
    expect(datetime).toBeUndefined();
  });

  it('Received a valid date in milisecond, the pipe should return something in format "MMM d, y, h:mm:ss a" ==> /Oct 2\\d, 2010, \\d{1,2}:\\d{2}:\\d{2} AM|PM/', () => {
    const value = 1288323623006; // Oct 29, 2010, 9:10:23 AM
    const datatime = arisLocalDateTimePipe.transform(value);
    expect(datatime).toMatch(/Oct 2\d, 2010, \d{1,2}:\d{2}:\d{2} AM|PM/);
  });

  it('Received a valid date in milisecond, the pipe should transformed it correctly ==> Oct 29, 2010, 9:10:23 AM', () => {
    const value = 1288323623006; // +0530 --> Oct 29, 2010, 9:10:23 AM
    const datatime = arisLocalDateTimePipe.transform(value, '+0530');
    expect(datatime).toMatch('Oct 29, 2010, 9:10:23 AM');
  });
});
