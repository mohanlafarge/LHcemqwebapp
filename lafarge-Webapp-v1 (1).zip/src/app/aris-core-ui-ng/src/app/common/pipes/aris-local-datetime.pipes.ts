/**
 * Filter to update the date received to local date and convert timestamp format.
 * If no time componentnt is present, remove it from date string.
 */
import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'arislocaldatetime',
})
export class ArisLocalDateTimePipe implements PipeTransform {
  constructor(private datePipe: DatePipe) { }
  transform(value: any, timeZone?: string) {
    if (!value) {
      return value;
    }

    return this.datePipe.transform(value, 'medium', timeZone);
  }
}
