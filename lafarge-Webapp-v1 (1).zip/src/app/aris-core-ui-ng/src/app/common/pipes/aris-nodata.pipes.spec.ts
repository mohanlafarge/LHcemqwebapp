import { ArisNoDataPipe } from './aris-nodata.pipes';
import {
    TranslationService,
    LocaleService,
    TranslationHandler,
    TranslationConfig,
    TranslationProvider,
    LocaleStorage,
    LocaleConfig,
} from 'angular-l10n';
import { ArisModule } from '../../aris.module';
import { Language } from 'angular-l10n/src/decorators/language.decorator';

describe('Test Pipe: ArisNoDataPipe', () => {
  beforeEach(() => {
    const arisModule = new ArisModule();
  });

    // abstract classes
  let translationhandler: TranslationHandler;
  let storage: LocaleStorage;
  let translationprovider: TranslationProvider;
  let configservice: any;
  let localconfig: any;
  const localservice = new LocaleService(localconfig, storage);
  const aristranslation = new TranslationService(configservice, localservice, translationprovider, translationhandler);
  let arisnodata: ArisNoDataPipe;

  beforeEach(() => {
    arisnodata = new ArisNoDataPipe(aristranslation);
  });

  afterEach(() => {
    arisnodata = null;
  });

  it('Received empty value "", the pipe should return No Data ==> "No Data"', () => {
    const value = '';
    const type = undefined;
    const translatedText = aristranslation.translate('CLI_ERR_DESC_NO_DATA');
    const result = arisnodata.transform(value, type);
    expect(result).toBe(translatedText);
  });

  it('Received an undefined, the pipe should return No Data ==> "No Data"', () => {
    const value = undefined;
    const type = undefined;
    const translatedText = aristranslation.translate('CLI_ERR_DESC_NO_DATA');
    const result = arisnodata.transform(value, type);
    expect(result).toBe(translatedText);
  });

  it('Received a value like "10/04/1987" and type "dtv", it should return the date between paranthesis ==> "(10/04/1987)"', () => {
    const value = '10/04/1987';
    const type = 'dtv';
    const result = arisnodata.transform(value, type);
    expect(result).toBe('(10/04/1987)');
  });

  it('Received a value like "test" and undefined type, it should return No Data ==> "No Data"', () => {
    const value = 'test';
    const type = undefined;
    const result = arisnodata.transform(value, type);
    expect(result).toBe('test');
  });

  it('Received an undefined value, the pipe should return No Data ==> ""', () => {
    const value = undefined;
    const type = 'dtv';
    const result = arisnodata.transform(value, type);
    expect(result).toBe('');
  });

  it('Received a "" value, the pipe should return translated value ==> "CLI_ERR_DESC_NO_DATA"', () => {
    const value = '';
    const type = 'dtv';
    const translatedText = aristranslation.translate('CLI_ERR_DESC_NO_DATA');
    const result = arisnodata.transform(value, type);
    expect(result).toBe(translatedText);
  });
});
