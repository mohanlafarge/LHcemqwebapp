/**
 * Filter to check empty value and replace it with 'No Data'.
 * If it is dtv type value, check if is 'undefined', if yes ignore it.
 * If not, then return '(<value/"No Data">)'.
 */
import { Pipe, PipeTransform } from '@angular/core';
import { TranslationService } from 'angular-l10n';


@Pipe({
  name: 'arisnodata',
})
export class ArisNoDataPipe implements PipeTransform {
  constructor(private translation: TranslationService) { }
  transform(value: any, type: any) {
    let result;
    if (type === 'dtv') {
      if (typeof value === 'undefined') {
        result = '';
      } else if (value === '') {
        result = this.translation.translate('CLI_ERR_DESC_NO_DATA');
      } else {
        result = '(' + (value ? value : this.translation.translate('CLI_ERR_DESC_NO_DATA')) + ')';
      }
    } else {
      result =  value !== undefined && value !== null && value !== '' ?
      value : this.translation.translate('CLI_ERR_DESC_NO_DATA');
    }
    return result;
  }
}
