import { ArisPermissionPipe } from './aris-permission.pipes';
import { ArisPermissionService } from '../services/aris-permission.service';

describe('Test Pipe: ArisPermissionPipe', () => {
  const data = [{
    id: 26,
    name: 'PERM_VIEW_WW',
    moduleName: 'AWA_WW',
    authority: 'PERM_VIEW_WW',
  }, {
    id: 25,
    name: 'PERM_VIEW_CW',
    moduleName: 'AWA_CW',
    authority: 'PERM_VIEW_CW',
  }, {
    id: 24,
    name: 'PERM_VIEW_CIP',
    moduleName: 'AWA_CIP',
    authority: 'PERM_VIEW_CIP',
  }];

  const arisPermissionService = new ArisPermissionService();
  arisPermissionService.setPermissions(data);
  let arisPermissionPipe: ArisPermissionPipe;

  beforeEach(() => {
    arisPermissionPipe = new ArisPermissionPipe(arisPermissionService);
  });

  afterEach(() => {
    arisPermissionPipe = null;
  });

  it('Received a permission, The pipe should return "true" if user has this permission ==> "true"', () => {
    expect(arisPermissionPipe.transform('PERM_VIEW_WW')).toMatch(/true/);
  });

  it('Received a permission, The pipe should return "false" if user has this permission ==> "false"', () => {
    expect(arisPermissionPipe.transform('PERM_VIEW_Test')).toMatch(/false/);
  });

  it('Received an undefined, The pipe should return "true" if user has this permission ==> "true"', () => {
    expect(arisPermissionPipe.transform(undefined)).toMatch(/true/);
  });

});

