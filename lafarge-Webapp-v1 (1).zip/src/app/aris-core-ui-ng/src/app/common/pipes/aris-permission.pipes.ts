/**
  * The filter 'arispermission' allows verify if the current user has a specific permission
  * param value  -->  permission to verify, example: 'PERM_VIEW_CIP'
  */
import { Pipe, PipeTransform } from '@angular/core';
import { ArisPermissionService } from '../services/aris-permission.service';

@Pipe({
  name: 'arispermission',
})
export class ArisPermissionPipe implements PipeTransform {
  constructor(private arisPermissionService: ArisPermissionService) { }
  transform(value: any) {
    return this.arisPermissionService.hasPermission(value);
  }
}
