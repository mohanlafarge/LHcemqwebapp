import { NgModule } from '@angular/core';
import { DecimalPipe } from '@angular/common/src/pipes'; // aris number format pipe

import { ArisCurrencyPipe } from './aris-currency.pipes'; // for custom currency pipe core file
import { ArisLocalDateTimePipe } from './aris-local-datetime.pipes'; // for local Date
import { ArisDateTimePipe } from './aris-datetime.pipes'; // aris Normal data
import { ArisImagePipe } from './aris-image.pipes';

import { ArisNoDataPipe } from './aris-nodata.pipes'; // aris no data
import { ArisUomPipe } from './aris-uom.pipes'; // aris unit of meaasurement pipe
import { ArisPermissionPipe } from './aris-permission.pipes'; // aris number format pipe
import { ArisSafePipe } from './aris-safe.pipe';
import { ArisValueTypeCheckPipe } from './aris-value-type-check-pipe';
import { ArisCleanEmptyRegistersPipe } from './aris-cleanemptyregisters.pipes';

@NgModule({
  declarations: [
    ArisCurrencyPipe,
    ArisDateTimePipe,
    ArisImagePipe,
    ArisLocalDateTimePipe,
    ArisNoDataPipe,
    ArisPermissionPipe,
    ArisSafePipe,
    ArisUomPipe,
    ArisValueTypeCheckPipe,
    ArisCleanEmptyRegistersPipe
  ],
  imports: [],
  providers: [],
  exports: [
    ArisCurrencyPipe,
    ArisDateTimePipe,
    ArisImagePipe,
    ArisLocalDateTimePipe,
    ArisNoDataPipe,
    ArisPermissionPipe,
    ArisSafePipe,
    ArisUomPipe,
    ArisValueTypeCheckPipe,
    ArisCleanEmptyRegistersPipe
  ],
})

export class ArisPipesModule { }
