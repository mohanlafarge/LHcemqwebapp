import { HttpHandler, HttpClient } from '@angular/common/http';
import { DecimalPipe } from '@angular/common';

import { ArisUomPipe } from './aris-uom.pipes';
import { ArisConfigService } from '../services/aris-config.service';
import { ArisLanguageService } from '../ui-page-sections/language-selector-module/services/aris-language.service';
import { ArisSafePipe } from './aris-safe.pipe';
import { DomSanitizer, SafeValue } from '@angular/platform-browser';
import { TestBed } from '@angular/core/testing';
import { SecurityContext } from '@angular/platform-browser/src/security/dom_sanitization_service';

export class MockDomSanitizer extends DomSanitizer {
  sanitize(context: SecurityContext, value: SafeValue | string | null) {
    return '';
  }
  bypassSecurityTrustHtml(value: any) {
    return value;
  }
  bypassSecurityTrustResourceUrl(value: any) {
    return value;
  }
  bypassSecurityTrustScript(value: any) {
    return value;
  }
  bypassSecurityTrustStyle(value: any) {
    return value;
  }
  bypassSecurityTrustUrl(value: any) {
    return value;
  }

}

describe('Test Pipe: ArisSafePipe', () => {

  let domSanitizer = new MockDomSanitizer();
  let arisSafePipe: ArisSafePipe;

  beforeEach(() => {
    arisSafePipe = new ArisSafePipe(domSanitizer);
  });

  afterEach(() => {
    arisSafePipe = null;
  });

  it('Pass trustHtml and receive html', () => {
    let value = 'html';
    let type = "trustHtml";
    const result = arisSafePipe.transform(value, type);
    expect(result).toBe(value);
  });

  it('Pass trustResourceUrl and receive ResourceUrl', () => {
    let value = 'ResourceUrl';
    let type = "trustResourceUrl";
    const result = arisSafePipe.transform(value, type);
    expect(result).toBe(value);
  });

  it('Pass trustScript and receive Script', () => {
    let value = 'Script';
    let type = "trustScript";
    const result = arisSafePipe.transform(value, type);
    expect(result).toBe(value);
  });

  it('Pass trustStyle and receive Style', () => {
    let value = 'Style';
    let type = "trustStyle";
    const result = arisSafePipe.transform(value, type);
    expect(result).toBe(value);
  });

  it('Pass trustUrl and receive Url', () => {
    let value = 'Url';
    let type = "trustUrl";
    const result = arisSafePipe.transform(value, type);
    expect(result).toBe(value);
  });

  it('Pass trustUrl and receive Url', () => {
    let value = 'Url1';
    let type = "trustUrl1";
    const result = arisSafePipe.transform(value, type);
    expect(result).toBeUndefined();
  });
});
