import { PipeTransform, Pipe } from "@angular/core";
import { DomSanitizer} from '@angular/platform-browser';

@Pipe({
  name: 'arisSafe'})
  export class ArisSafePipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) {}
  transform(value: any, type: any) {
    let sanitizedReturnedValue;
    if (type === "trustHtml") {
      sanitizedReturnedValue =  this.sanitizer.bypassSecurityTrustHtml(value);
    } else if (type === 'trustResourceUrl') {
      sanitizedReturnedValue = this.sanitizer.bypassSecurityTrustResourceUrl(value);
    } else if (type === 'trustScript') {
      sanitizedReturnedValue = this.sanitizer.bypassSecurityTrustScript(value);
    } else if (type === 'trustStyle') {
      sanitizedReturnedValue =  this.sanitizer.bypassSecurityTrustStyle(value);
    } else if (type === 'trustUrl') {
      sanitizedReturnedValue = this.sanitizer.bypassSecurityTrustUrl(value);
    }
    return sanitizedReturnedValue;
  }

}