import { HttpHandler, HttpClient } from '@angular/common/http';
import { DecimalPipe } from '@angular/common';

import { ArisUomPipe } from './aris-uom.pipes';
import { ArisConfigService } from '../services/aris-config.service';
import { ArisLanguageService } from '../ui-page-sections/language-selector-module/services/aris-language.service';

describe('Test Pipe: ArisUomPipe', () => {
  const data = {
    arisConfig: [
      {
        assetAttributeName: 'Locale',
        value: 'en-gb',
      }, {
        assetAttributeName: 'Currency',
        value: 'USD',
      }, {
        assetAttributeName: 'Currency Symbol',
        value: '$',
      }, {
        assetAttributeName: 'Flow',
        value: 'litres/sec',
      }, {
        assetAttributeName: 'Conductivity',
        value: 'micro siemens per metre (?S/m)',
      }, {
        assetAttributeName: 'Max Speed',
        value: 'Km/h',
      }, {
        assetAttributeName: 'Odometer',
        value: 'Km',
      }],
  };

  const locale = 'en-gb';
  let httpHandler: HttpHandler;
  const httpClient = new HttpClient(httpHandler);
  const languageservice = new ArisLanguageService();
  const configService = new ArisConfigService(httpClient, languageservice);
  const decimalpipe = new DecimalPipe(locale);
  let arisuom: ArisUomPipe;

  beforeEach(() => {
    arisuom = new ArisUomPipe(configService, decimalpipe);
  });

  afterEach(() => {
    arisuom = null;
  });

  it('Received (units="", assetAttributeName=Currency, fractionSize=0, parenthesis=true), the pipe should return the UOM with parantesis ==> (USD)', () => {
    const units = '';
    const assetAttributeName = 'Currency';
    const fractionSize = 0;
    const parenthesis = true;
    configService.setArisConfig(data.arisConfig);
    const result = arisuom.transform(units, assetAttributeName, fractionSize, parenthesis);
    expect(result.toString()).toBe(' (USD)');
  });
  it('Received (units="", assetAttributeName=Flow, fractionSize=0, parenthesis=false), The pipe should return UOM without parantesis ==> litres/sec', () => {
    const units = '';
    const assetAttributeName = 'Flow';
    const fractionSize = 0;
    const parenthesis = false;
    configService.setArisConfig(data.arisConfig);
    const result = arisuom.transform(units, assetAttributeName, fractionSize, parenthesis);
    expect(result.toString()).toBe('litres/sec');
  });
  it('Received (units=1000, assetAttributeName=Currency, fractionSize=0, parenthesis=false), The pipe should return the Units plus the Uom without parantesis ==> 10,00USD', () => {
    const units = 1000;
    const assetAttributeName = 'Currency';
    const fractionSize = 0;
    const parenthesis = false;
    configService.setArisConfig(data.arisConfig);
    const result = arisuom.transform(units, assetAttributeName, fractionSize, parenthesis);
    expect(result.toString()).toBe('1,000USD');
  });
  it('Received (units=1000, assetAttributeName=Flow, fractionSize=0, parenthesis=true), The pipe should return the Units plus the Uom with parantesis ==> 10,00 (litres/sec)', () => {
    const units = 1000;
    const assetAttributeName = 'Flow';
    const fractionSize = 0;
    const parenthesis = true;
    configService.setArisConfig(data.arisConfig);
    const result = arisuom.transform(units, assetAttributeName, fractionSize, parenthesis);
    expect(result.toString()).toBe('1,000 (litres/sec)');
  });

  it('Received (units=1000, assetAttributeName=?, fractionSize=0, parenthesis=true), The pipe should return the Units plus the Uom with parantesis ==> 10,00 (?)', () => {
    const units = 1000;
    const assetAttributeName = '?';
    const fractionSize = 0;
    const parenthesis = true;
    configService.setArisConfig(data.arisConfig);
    const result = arisuom.transform(units, assetAttributeName, fractionSize, parenthesis);
    expect(result.toString()).toBe('1,000 (?)');
  });

  it('Received (units=1000, assetAttributeName=undefined, fractionSize=0, parenthesis=true), The pipe should return the Units plus the Uom with parantesis ==> 10,00 ()', () => {
    const units = 1000;
    const assetAttributeName = undefined;
    const fractionSize = 0;
    const parenthesis = true;
    configService.setArisConfig(data.arisConfig);
    const result = arisuom.transform(units, assetAttributeName, fractionSize, parenthesis);
    expect(result.toString()).toBe('1,000 ()');
  });

  it('getFractionSize null scenario', () => {
    const result = arisuom.getFractionSize(null);
    expect(result.toString()).toBe('2');
  });

  it('transform null scenario', () => {
    const result = arisuom.transform(null, null, null, null);
    expect(result).toBe('');
  });
});
