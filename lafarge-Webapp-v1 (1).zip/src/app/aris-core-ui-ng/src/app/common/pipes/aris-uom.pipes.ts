/**
  * The filter 'arisuom' allows display a number followed by its unit of measurement associated
  * The association between 'asset attribute'/'uom' is defined in the DB table 'META_UNIT_MEASUREMENT'
  * The uom depends of the standard used (imperial or international).
  * param units  -->  number of units
  * param fractionSize -->  (optional) by default 0. Number of decimals
  * param assetAttributeName  -->  asset attribute name, any defined in the table META_UNIT_MEASUREMENT
  * param parenthesis --> boolean used to specify if the unit should be displayed between parethensis
  */
import { Pipe, PipeTransform } from '@angular/core';
import { ArisConfigService } from '../services/aris-config.service';
import { DecimalPipe } from '@angular/common';

@Pipe({
  name: 'arisuom',
})
export class ArisUomPipe implements PipeTransform {
  constructor(private arisConfigService: ArisConfigService, private number: DecimalPipe) { }
  transform(units: any, assetAttributeName: any, fractionSize: any, parenthesis: any) {
    let result = '';
    if (units !== null && units !== undefined) {
      if (units === '') {
        result = units;
      } else {
        const finalFractionSize = this.getFractionSize(fractionSize);
        result = this.number.transform(units, finalFractionSize);
      }
      if (parenthesis === true || parenthesis === 'true') {
        result = result + ' (' + this.getUom(assetAttributeName) + ')';
      } else {
        result = result + this.getUom(assetAttributeName) + '';
      }
    }
    return result;
  }

  getUom(assetAttributeName) {
    let uom = this.arisConfigService.getParameter(assetAttributeName);
    if (assetAttributeName !== undefined) {
      if (uom === '?') {
        uom = assetAttributeName;
      }
    } else {
      uom = '';
    }
    if (uom.toUpperCase().indexOf('{CURRENCY}') !== -1) {
      const symbol = this.arisConfigService.getCurrencySymbol();
      uom = uom.replace('{Currency}', symbol);
    }
    return uom;
  }

  getFractionSize(fractionSize) {
    let finaleFranctionSize = fractionSize;
    if (fractionSize === null || fractionSize === undefined || fractionSize.length === 0) {
      finaleFranctionSize = 2;
    }
    return finaleFranctionSize;
  }
}
