/**
 * Filter to return type of value
 */
import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'arisvaluetype',
})
export class ArisValueTypeCheckPipe implements PipeTransform {
  transform(value: any) {
    if (!value) {
      return value;
    }
    if (/^[0-9]+$/.test(value) || !isNaN(value)){
      return "number";
    }
    return "string";
  }
}