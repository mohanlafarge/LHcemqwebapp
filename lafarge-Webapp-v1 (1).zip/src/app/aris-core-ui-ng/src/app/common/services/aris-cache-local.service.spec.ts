import { TestBed, async, fakeAsync, tick } from '@angular/core/testing';
import { ArisCacheLocalService } from './aris-cache-local.service';

describe('Test: Aris Cache Local Service', () => {
  const arisCacheLocalService = new ArisCacheLocalService();
  const testData = 'Hola';

  it('Aris Cache Local Service test : Storing data in local cache', () => {
    arisCacheLocalService.setItem('key', testData);
    expect(arisCacheLocalService.keyInCache(testData)).toBeDefined(true);
  });

  it('Aris Cache Local Service test : Storing data in local cache defining expiration time 1 milliseconds', () => {
    arisCacheLocalService.setItem('key', testData, 1);
    setTimeout(expect(arisCacheLocalService.keyInCache(testData)).toBeDefined(false), 2);
  });

  it('Aris Cache Local Service test : remove data from local cache', () => {
    arisCacheLocalService.setItem('key', testData);
    arisCacheLocalService.removeItem('key');
    expect(arisCacheLocalService.keyInCache(testData)).toBeDefined(false);
  });

  it('Aris Cache Local Service test : clear the local cache', () => {
    arisCacheLocalService.setItem('key', testData);
    arisCacheLocalService.clear();
    expect(arisCacheLocalService.keyInCache(testData)).toBeDefined(false);
  });

  it('Aris Cache Local Service test : Getting information from local cache - success result', () => {
    arisCacheLocalService.setItem('key', testData);
    expect(arisCacheLocalService.getItem('key')).toBeDefined(testData);
  });

  it('Aris Cache Local Service test : Getting information from local cache - success result', () => {
    arisCacheLocalService._localCacheAvailable = false;
    let result = arisCacheLocalService.setItem('key', testData);
    expect(result).toBeFalsy();
  });

  it('Aris Cache Local Service test : getItem first if scenario', () => {
    expect(arisCacheLocalService.getItem('key')).toEqual(testData);
  });

  it('Aris Cache Local Service test : getItem second if scenario', () => {
    ArisCacheLocalService._data = { key: { expirationCacheTime: 101, time: 10 } };
    expect(arisCacheLocalService.getItem('key')).toBeUndefined();
  });
});

