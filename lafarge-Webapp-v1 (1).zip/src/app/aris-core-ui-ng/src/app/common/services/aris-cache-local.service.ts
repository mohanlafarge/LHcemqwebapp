import { Injectable } from '@angular/core';

import { ArisConfigService } from '../../common/services/aris-config.service';

@Injectable()
export class ArisCacheLocalService {
  public static _data: {[key: string]: any} = {};
  private _expirationCacheTime: number = window.app.config.application.localCache.expirationTime;
  public _localCacheAvailable: boolean = window.app.config.application.localCache.available;

  public getItem(key: string) {
    if (ArisCacheLocalService._data[key] === undefined) {
      return undefined;
    }
    const expiration = ArisCacheLocalService._data[key].expirationCacheTime !== undefined ? ArisCacheLocalService._data[key].expirationCacheTime : this._expirationCacheTime;
    if (Math.abs((new Date()).getMilliseconds() - ArisCacheLocalService._data[key].time) > expiration) {
      this.removeItem(key);
      return undefined;
    }

    return ArisCacheLocalService._data[key].value;
  }

  public setItem(key: string, newValue: any, newExpirationCacheTime?: number) {
    if (this._localCacheAvailable === false) {
      return false;
    }
    const valueWithTime = { value: newValue, time: (new Date()).getMilliseconds(), expirationCacheTime: newExpirationCacheTime };
    ArisCacheLocalService._data[key] = valueWithTime;
    return true;
  }

  public keyInCache(key: string) {
    return this.getItem(key) !== undefined ? true : false;
  }

  public removeItem(key: string) {
    delete ArisCacheLocalService._data[key];
  }

  public clear() {
    ArisCacheLocalService._data = [];
  }
}
