import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ArisConfigService } from './aris-config.service';
import { ArisLanguageService } from '../ui-page-sections/language-selector-module/services/aris-language.service';

export class MockHttp extends HttpClient {

}

describe('Test: ArisConfigService', () => {
  let arisConfigService: ArisConfigService;
  let http: HttpClient;
  let item = { assetAttributeName: "item" };
  let item1 = [{ assetAttributeName: "item" }];

  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [
      ],
      imports: [
        HttpClientModule,
        HttpClientTestingModule
      ],
      providers: [
        ArisConfigService, ArisLanguageService,
        { provide: HttpClient,
          useClass: MockHttp },
      ]
    }).compileComponents();

    afterAll(() => {
      arisConfigService = null;
        });

    arisConfigService = TestBed.get(ArisConfigService);
    http = TestBed.get(HttpClient);
  });


  it('ArisConfigService test: checking if reloadArisConfig executed', () => {
    spyOn(http, 'get').and.callThrough();
    arisConfigService.reloadArisConfig();
    expect(http.get).toHaveBeenCalled();
  });

  it('ArisConfigService test: checking if resetConfig executed', () => {
    arisConfigService.resetConfig();
    expect(sessionStorage.arisSessionConfig).toEqual('{}');
  });

  it('ArisConfigService test: checking if setLocale executed', () => {
    arisConfigService.setLocale('en-gb');
    expect(ArisConfigService.arisLocalConfig['LOCALE']).toEqual('en-gb');
  });

  it('ArisConfigService test: checking if getLocale executed', () => {
    ArisConfigService.arisSessionConfig = undefined;
    ArisConfigService.arisLocalConfig = undefined;
    let result = arisConfigService.getLocale();
    expect(result).toEqual('?');
  });

  it('ArisConfigService test: checking if getLocale second if executed', () => {
    ArisConfigService.arisSessionConfig['LOCALE'] = 'en-gb';
    ArisConfigService.arisLocalConfig = undefined;
    arisConfigService.getLocale();
    expect(ArisConfigService.arisSessionConfig['LOCALE']).toEqual('en-gb');
  });

  it('ArisConfigService test: checking if getParameter executed', () => {
    let result = arisConfigService.getParameter('value');
    expect(result).toEqual("?");
  });

  it('ArisConfigService test: checking if getParameter else scenario executed', () => {
    let result = arisConfigService.getParameter(undefined);
    expect(result).toEqual("?");
  });

  it('ArisConfigService test: checking if setParameter executed', () => {
    arisConfigService.setParameter(item);
    expect(sessionStorage.getItem('arisSessionConfig')).toEqual('{}');
  });

  it('ArisConfigService test: checking if setParameter else scenario executed', () => {
    arisConfigService.setParameter(undefined);
    expect(sessionStorage.getItem('arisSessionConfig')).toEqual('{}');
  });

  it('ArisConfigService test: checking if getLocale executed', () => {
    let result = arisConfigService.getLocale();
    expect(result).toEqual('en-gb');
  });

  it('ArisConfigService test: checking if getCurrency executed', () => {
    arisConfigService.getCurrency();
    expect(arisConfigService).toBeTruthy();
  });

  it('ArisConfigService test: checking if getCurrency else executed', () => {
    ArisConfigService.arisSessionConfig = undefined;
    let expected = arisConfigService.getCurrency();
    expect(expected).toEqual('?');
  });

  it('ArisConfigService test: checking if getCurrencySymbol executed', () => {
    arisConfigService.getCurrencySymbol();
    expect(sessionStorage.getItem('arisSessionConfig')).toEqual('{}');
  });

  it('ArisConfigService test: checking if getCurrencySymbol else executed', () => {
    ArisConfigService.arisSessionConfig = undefined;
    let expected = arisConfigService.getCurrencySymbol();
    expect(expected).toEqual('?');
  });

  it('ArisConfigService test: checking if getWeekendDefinition executed', () => {
    arisConfigService.getWeekendDefinition();
    expect(sessionStorage.getItem('arisSessionConfig')).toEqual('{}');
  });

  it('ArisConfigService test: checking if getWeekendDefinition else executed', () => {
    ArisConfigService.arisSessionConfig = undefined;
    let expected = arisConfigService.getWeekendDefinition();
    expect(expected).toEqual('standard');
  });

  it('ArisConfigService test: checking if getDabaseDateFormat executed', () => {
    arisConfigService.getDabaseDateFormat();
    expect(sessionStorage.getItem('arisSessionConfig')).toEqual('{}');
  });

  it('ArisConfigService test: checking if getDabaseDateFormat else executed', () => {
    ArisConfigService.arisSessionConfig = undefined;
    let expected = arisConfigService.getDabaseDateFormat();
    expect(expected).toEqual('yyyy-MM-dd');
  });

  it('ArisConfigService test: checking if getRefreshFrontendTimer executed', () => {
    let result = arisConfigService.getRefreshFrontendTimer();
    expect(result).toEqual(60000);
  });

  it('ArisConfigService test: checking if getRefreshFrontendTimer else executed', () => {
    ArisConfigService.arisSessionConfig = undefined;
    let result = arisConfigService.getRefreshFrontendTimer();
    expect(result).toEqual(60000);
  });

  it('ArisConfigService test: checking if setArisConfig executed', () => {
    arisConfigService.setArisConfig(item1);
    expect(sessionStorage.getItem('arisSessionConfig')).toEqual('{}');
  });

  it('ArisConfigService test: checking if setArisConfig else scnario executed', () => {
    arisConfigService.setArisConfig('');
    expect(sessionStorage.getItem('arisSessionConfig')).toEqual('{}');
  });

});
