import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';

import { ArisLanguageService } from '../ui-page-sections/language-selector-module/services/aris-language.service';

@Injectable()
export class ArisConfigService {
  public static arisSessionConfig = {};
  public static arisLocalConfig = {};
  private arisConfigUrl = 'rest/config';

  private changedLang = '';

  private localeSource = new BehaviorSubject<string>('');
  locale = this.localeSource.asObservable();

  constructor(
    private http: HttpClient, private arisLanguageService: ArisLanguageService
   ) {
    if (typeof(Storage) !== 'undefined') {
      if (sessionStorage.arisSessionConfig === undefined) {
        sessionStorage.setItem('arisSessionConfig', JSON.stringify({}));
      } else {
        ArisConfigService.arisSessionConfig = JSON.parse(sessionStorage.arisSessionConfig);
      }
      if (localStorage.arisLocalConfig === undefined) {
        localStorage.setItem('arisLocalConfig', JSON.stringify({}));
      } else {
        ArisConfigService.arisLocalConfig = JSON.parse(localStorage.arisLocalConfig);
      }
    }
  }

  setArisConfig(data: any) {
    console.log(ArisConfigService.arisSessionConfig);
    this.resetConfig();
    if (data.length > 0) {
      ArisConfigService.arisSessionConfig = {};
      for (let i = 0; i < data.length; i++) {
        ArisConfigService.arisSessionConfig[data[i].assetAttributeName.toUpperCase()] = data[i].value;
      }
      if (typeof(Storage) !== 'undefined') {
        sessionStorage.setItem('arisSessionConfig', JSON.stringify(ArisConfigService.arisSessionConfig));
      }
      ArisConfigService.arisLocalConfig['LOCALE'] = ArisConfigService.arisSessionConfig['LOCALE'];
      this.setLocale(ArisConfigService.arisLocalConfig['LOCALE']);
    }
  }

  reloadArisConfig() {
    let authenticationProviderType = ArisConfigService.arisLocalConfig['AUTHENTICATION_PROVIDER_TYPE'];
    return new Promise((resolve, reject) => {
      this.http.get(this.arisConfigUrl)
        .toPromise()
        .then((result: any) => {
          this.setArisConfig(result);
          this.setAuthenticationProviderType(authenticationProviderType);
          resolve(result);
        })
        .catch((err) => {
          console.log(err);
          reject(err);
        });
    });
  }

  resetConfig() {
    ArisConfigService.arisSessionConfig = {};
    sessionStorage.arisSessionConfig = JSON.stringify({});
    ArisConfigService.arisLocalConfig = {};
    sessionStorage.arisLocalConfig = JSON.stringify({});
  }

  getParameter(param: any) {
    let result = '?';
    if (ArisConfigService.arisSessionConfig !== undefined && param !== undefined) {
      const aux = ArisConfigService.arisSessionConfig[param.toUpperCase()];
      if (aux !== undefined) {
        result = aux;
      }
    }
    return result;
  }

  setParameter(item: any) {
    if (ArisConfigService.arisSessionConfig !== undefined && item !== undefined) {
      ArisConfigService.arisSessionConfig[item.assetAttributeName.toUpperCase()] = item.assetAttributeValue;
    }
    if (typeof(Storage) !== 'undefined') {
      sessionStorage.setItem('arisSessionConfig', JSON.stringify(ArisConfigService.arisSessionConfig));
    }
  }

  getAuthenticationProviderType(): string {
    if (ArisConfigService.arisLocalConfig !== undefined && ArisConfigService.arisLocalConfig !== {} && ArisConfigService.arisLocalConfig['AUTHENTICATION_PROVIDER_TYPE'] !== undefined) {
      return ArisConfigService.arisLocalConfig['AUTHENTICATION_PROVIDER_TYPE'];
    }
    if (ArisConfigService.arisSessionConfig !== undefined && ArisConfigService.arisSessionConfig !== {} &&
      ArisConfigService.arisSessionConfig['AUTHENTICATION_PROVIDER_TYPE'] !== undefined) {
      return ArisConfigService.arisSessionConfig['AUTHENTICATION_PROVIDER_TYPE'];
    }
    return '?';
  }

  setAuthenticationProviderType(authenticationProviderType: string) {
    ArisConfigService.arisLocalConfig['AUTHENTICATION_PROVIDER_TYPE'] = authenticationProviderType;
    localStorage.setItem('arisLocalConfig', JSON.stringify(ArisConfigService.arisLocalConfig));
  }

  getLocale(): string {
    if (ArisConfigService.arisLocalConfig !== undefined && ArisConfigService.arisLocalConfig !== {} && ArisConfigService.arisLocalConfig['LOCALE'] !== undefined) {
      return ArisConfigService.arisLocalConfig['LOCALE'];
    }
    if (ArisConfigService.arisSessionConfig !== undefined && ArisConfigService.arisSessionConfig !== {} &&
      ArisConfigService.arisSessionConfig['LOCALE'] !== undefined) {
      return ArisConfigService.arisSessionConfig['LOCALE'];
    }
    return '?';
  }

  setLocale(locale: string) {
    ArisConfigService.arisLocalConfig['LOCALE'] = locale;
    localStorage.setItem('arisLocalConfig', JSON.stringify(ArisConfigService.arisLocalConfig));
    this.arisLanguageService.languageChange.next(locale);
    this.localeSource.next(locale);
  }

  getCurrency() {
    if (ArisConfigService.arisSessionConfig !== undefined) {
      return ArisConfigService.arisSessionConfig['CURRENCY'];
    }
    return '?';
  }

  getCurrencySymbol() {
    if (ArisConfigService.arisSessionConfig !== undefined) {
      return ArisConfigService.arisSessionConfig['CURRENCY SYMBOL'];
    }
    return '?';
  }

  getWeekendDefinition() {
    if (ArisConfigService.arisSessionConfig !== undefined) {
      return ArisConfigService.arisSessionConfig['WEEKEND DEFINITION'];
    }
    return 'standard';
  }

  getDabaseDateFormat() {
    if (ArisConfigService.arisSessionConfig !== undefined) {
      return ArisConfigService.arisSessionConfig['DATABASE DATE FORMAT'];
    }
    return 'yyyy-MM-dd';
  }

  getRefreshFrontendTimer() {
    if (ArisConfigService.arisSessionConfig !== undefined) {
      const time = Number(ArisConfigService.arisSessionConfig['REFRESH FRONT-END']);
      if (!isNaN(time)) {
        return time;
      }
    }
    return 60000;
  }
}

