import { ArisFilterService } from './aris-filter.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ArisDataSourceService } from './aris-datasource.service';

export class MockHttp extends HttpClient {

}

describe('Test: ArisDataSourceService', () => {
  let dataSourceName: any;
  let showLoaders = {};
  let dateRange = ['one', 'two'];
  let filterField = { op: 'data' };
  let loading = { status: "loading", key: "" };
  let name = "name";
  let values = "values";
  let op = "op";
  let input = { name, values, op };
  let arisDataSourceService: ArisDataSourceService;
  let http: HttpClient;
  let filterDatasources: any = [];
  let data = {criterias:
               [{ name: 'five' }, { type: 'textfield', val: 'val' }]
  };

  let data3 = {criterias:
    [{ name: 'five' }, { type: 'textfield', val: undefined }]
  };

  let data1 = {criterias:
    [{ name: 'four' }, { type: 'autocompletefield', val: 'val' }]
  };
  let data4 = {criterias:
    [{ name: 'four' }, { type: 'autocompletefield', val: undefined }]
  };
  let data2 = {criterias:
    [{ name: 'four' }, { type: 'checkbox', val: ['val'] }]
  };
  let data5 = {criterias:
    [{ name: 'four' }, { type: 'checkbox', val: undefined }]
  };

  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [
      ],
      imports: [
        HttpClientModule,
        HttpClientTestingModule
      ],
      providers: [
        ArisDataSourceService,
        { provide: HttpClient,
          useClass: MockHttp },
      ]
    }).compileComponents();

    afterAll(() => {
      arisDataSourceService = null;
        });

    arisDataSourceService = TestBed.get(ArisDataSourceService);
    http = TestBed.get(HttpClient);
  });

  it('ArisDataSourceService test: checking if deleteFilterData is executed', () => {
    let result = arisDataSourceService.getLoaders();
    expect(result).toEqual(showLoaders);
  });

  it('ArisDataSourceService test: checking if getOp is executed', () => {
    let result = arisDataSourceService.getOp(filterField);
    expect(result).toEqual("data");
  });

  it('ArisDataSourceService test: checking if filterCriteria is executed', () => {
    let result = arisDataSourceService.filterCriteria("name", "values", "op");
    expect(result).toEqual(input);
  });

  it('ArisDataSourceService test: checking if setLoaders is executed', () => {
    let expected = arisDataSourceService.setLoaders(data);
    expect(expected).toBeDefined();
  });

  it('ArisDataSourceService test: checking if hideLoaders status is false scenario executed', () => {
    let expected = arisDataSourceService.hideLoaders(data, false);
    expect(expected).toBeDefined();
  });

  it('ArisDataSourceService test: checking if hideLoaders status is empty scenario executed', () => {
    let expected = arisDataSourceService.hideLoaders(data, 'empty');
    expect(expected).toBeDefined();
  });

  it('ArisDataSourceService test: checking if hideLoaders status is error scenario executed', () => {
    let expected = arisDataSourceService.hideLoaders(data, 'error');
    expect(expected).toBeDefined();
  });

  it('ArisDataSourceService test: checking if hideLoaders status is error1 scenario executed', () => {
    let expected = arisDataSourceService.hideLoaders(data, 'error1');
    expect(expected).toBeDefined();
  });

  it('ArisDataSourceService test: checking if getFromDataSource executed', () => {
    spyOn(arisDataSourceService, 'toJsonFilterData').and.callThrough();
    arisDataSourceService.getFromDataSource(dataSourceName, data, dateRange, 2, 1, 'waste', 'refreshCache');
    expect(arisDataSourceService.toJsonFilterData).toHaveBeenCalled();
  });

  it('ArisDataSourceService test: checking if getFromDataSource filterFields.val is empty executed', () => {
    spyOn(arisDataSourceService, 'toJsonFilterData').and.callThrough();
    arisDataSourceService.getFromDataSource(dataSourceName, data3, dateRange, 2, 1, 'waste', 'refreshCache');
    expect(arisDataSourceService.toJsonFilterData).toHaveBeenCalled();
  });

  it('ArisDataSourceService test: checking if getFromDataSource  autoComplete executed', () => {
    spyOn(arisDataSourceService, 'toJsonFilterData').and.callThrough();
    arisDataSourceService.getFromDataSource(dataSourceName, data1, dateRange, 2, 1, 'waste', 'refreshCache');
    expect(arisDataSourceService.toJsonFilterData).toHaveBeenCalled();
  });
  it('ArisDataSourceService test: checking if getFromDataSource filterFields.val is undefined  autoComplete executed', () => {
    spyOn(arisDataSourceService, 'toJsonFilterData').and.callThrough();
    arisDataSourceService.getFromDataSource(dataSourceName, data4, dateRange, 2, 1, 'waste', 'refreshCache');
    expect(arisDataSourceService.toJsonFilterData).toHaveBeenCalled();
  });

  it('ArisDataSourceService test: checking if getFromDataSource  CheckBox executed', () => {
    spyOn(arisDataSourceService, 'toJsonFilterData').and.callThrough();
    arisDataSourceService.getFromDataSource(dataSourceName, data2, dateRange, 2, 1, 'waste', 'refreshCache');
    expect(arisDataSourceService.toJsonFilterData).toHaveBeenCalled();
  });

  it('ArisDataSourceService test: checking if getFromDataSource filterFields.val is empty CheckBox executed', () => {
    spyOn(arisDataSourceService, 'toJsonFilterData').and.callThrough();
    arisDataSourceService.getFromDataSource(dataSourceName, data5, dateRange, 2, 1, 'waste', 'refreshCache');
    expect(arisDataSourceService.toJsonFilterData).toHaveBeenCalled();
  });

  it('ArisDataSourceService test: checking if getFromDataSource  all else scenario executed', () => {
    spyOn(http, 'post').and.callThrough();
    arisDataSourceService.getFromDataSource(dataSourceName, null, dateRange, 2, 1, undefined, undefined);
    expect(http.post).toHaveBeenCalled();
  });

  it('ArisDataSourceService test: checking if toJsonFilterData executed', () => {
    let result = arisDataSourceService.toJsonFilterData(null, undefined);
    expect(result).toEqual('[]');
  });

});
