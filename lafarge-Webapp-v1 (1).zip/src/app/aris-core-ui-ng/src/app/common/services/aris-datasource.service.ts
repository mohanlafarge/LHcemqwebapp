import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class ArisDataSourceService {
  showLoaders = {};
  public CHECKBOX_FIELD = 'checkbox';
  public TEXT_FIELD = 'textfield';
  public AUTOCOMPLETE_FIELD = 'autocompletefield';
  constructor(private http: HttpClient) { }

  /**
   * get post query for given given dataSource based on selected filter options.
   * @param dataSourceName dataSource end point.
   * @param filterData filter data object.
   * @param dateRange date range [from, to].
   * @param page
   * @param pageSize
   * @param mapbounds
   * @param refreshCache
   * @returns
   */
  getFromDataSource(dataSourceName, filterData, dateRange?: any, offset?: any, limit?: any, mapbounds?: any, refreshCache?: any, restPrefix?: any) {
    let filterDataJson: any = [];
    if (filterData) {
      filterDataJson = this.toJsonFilterData(filterData, dateRange);
    }
    let httpRefreshCache: any = '';
    let httpMapBounds = '';
    if (refreshCache !== undefined) {
      httpRefreshCache = '&refreshCache=' + refreshCache;
    }
    if (mapbounds !== undefined) {
      httpMapBounds = '&' + mapbounds;
    }
    return this.http.post ('rest/' + (restPrefix ? restPrefix + '/' : '') + 'getFromDataSource/' + dataSourceName + '?offset=0&limit=1000' + httpMapBounds + httpRefreshCache, filterDataJson,
      {
        headers: new HttpHeaders().set('Content-Type', 'application/json; charset=utf-8'),
      }).toPromise();
  }

  setLoaders(dataSourceName) {
    this.showLoaders[dataSourceName] = {};
    this.showLoaders[dataSourceName].status = 'loading';
    this.showLoaders[dataSourceName].key = '';
    return this.showLoaders;
  }
  getLoaders() {
    return this.showLoaders;
  }
  hideLoaders(dataSourceName, status) {
    this.showLoaders[dataSourceName] = {};
    if (!status) {
      this.showLoaders[dataSourceName].status = 'showChart';
      this.showLoaders[dataSourceName].key = '';
    } else if (status === 'empty') {
      this.showLoaders[dataSourceName].status = 'empty';
      this.showLoaders[dataSourceName].key = 'No Data Found';
    } else if (status === 'error') {
      this.showLoaders[dataSourceName].status = 'error';
      this.showLoaders[dataSourceName].key = 'Error Occurred';
    }
    return this.showLoaders;
  }


 // ----------- Internal functions ---------------

 /*
  * Convert filterData to post query json.
  *
  * param filterData all filter data.
  * param dateRange  [from, to] date array.
  */
  toJsonFilterData(filterData, dateRange) {     // NOSONAR
    let filterArray = [];
    // let that = this;
    // Convert filter data object to json string.
    if (filterData) {
      filterData.criterias.forEach((filterCriteria) => {
        // Get values for given filter criteria.
        let values = this.getValues(filterCriteria);
        // If values, then add to json else ignore it.
        if (values.length > 0) {
          let filterCriteriaObj = this.filterCriteria(filterCriteria.name, values,
          this.getOp(filterCriteria));
          filterArray.push(filterCriteriaObj);
        }
      });
    }
    // if both dates available, add to json else ignore.
    if (dateRange && dateRange.length === 2) {
      let filterCriteriaObj = this.filterCriteria('date', dateRange, 'between');
      filterArray.push(filterCriteriaObj);
    }
    return JSON.stringify(filterArray);
  }


  /*
   * get values for given filter field.
   *
   * param filterFields filter fields of criteria.
   */
  getValues(filterFields) {
    let values = [];
    switch (filterFields.type) {
      case this.CHECKBOX_FIELD: {
        if (filterFields.val) {
          for (let key in filterFields.val) {
            if (filterFields.val[key]) {
              values.push(key);
            }
          }
        }
        break;
      }
      case this.TEXT_FIELD: {
        if (filterFields.val) {
          values = filterFields.val;
        }
        break;
      }
      case this.AUTOCOMPLETE_FIELD: {
        if (filterFields.val) {
          values = filterFields.val;
        }
        break;
      }
      default: {
        break;
      }
    }
    return values;
  }

  /*
   * Class for filter criteria.that
   * param name name of criteria.
   * param values values array of criteria.
   * param op query operation of criteria.
   * returns filter criteria object.
   */
  filterCriteria(name, values, op) {
    return { name, values, op };
  }

  /*
   * Get operation from filter field.
   * @param filterField filter field object
   * @returns operation string.
   */
  getOp(filterField) {
    return filterField.op;
  }
}


