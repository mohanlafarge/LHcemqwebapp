import { ArisFilterService } from './aris-filter.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Subject } from 'rxjs';

export class MockHttp extends HttpClient {

}

describe('Test: ArisFilterService', () => {
  let pageName = 'wasteWater';
  let dataSource = 'wasteWater/';
  let arisFilterService: ArisFilterService;
  let http: HttpClient;
  let filterDatasources: any = [];
  let data = [
    {criterias:
               [{ type: 'four' }]
    }
  ];
  let data1 = [
    {criterias: undefined
    }
  ];
  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [
      ],
      imports: [
        HttpClientModule,
        HttpClientTestingModule
      ],
      providers: [
        ArisFilterService,
        { provide: HttpClient,
          useClass: MockHttp },
      ]
    }).compileComponents();

    afterAll(() => {
      arisFilterService = null;
        });

    arisFilterService = TestBed.get(ArisFilterService);
    http = TestBed.get(HttpClient);
  });

  it('ArisFilterService test: checking if deleteFilterData is executed', () => {
    spyOn(http, 'post').and.callThrough();
    arisFilterService.deleteFilterData(pageName);
    expect(http.post).toHaveBeenCalled();
  });

  it('ArisFilterService test: checking if saveFilterData is called or not', () => {
    spyOn(http, 'post').and.callThrough();
    arisFilterService.saveFilterData(pageName, dataSource);
    expect(http.post).toHaveBeenCalled();
  });

  it('ArisFilterService test: checking if getDatasourceData is executed', () => {
    spyOn(http, 'post').and.callThrough();
    arisFilterService.getDatasourceData(dataSource);
    expect(http.post).toHaveBeenCalled();
  });

  it('ArisFilterService test: checking if getFilter is executed', () => {
    spyOn(http, 'get').and.callThrough();
    arisFilterService.getFilter(pageName);
    expect(http.get).toHaveBeenCalled();
  });

  it('ArisFilterService test: checking if getFilterByPageName is executed', () => {
    spyOn(http, 'get').and.callThrough();
    arisFilterService.getFilterByPageName(pageName);
    expect(http.get).toHaveBeenCalled();
  });

  it('ArisFilterService test: checking if getFilterConfig is executed', () => {
    let result = arisFilterService.getFilterConfig();
    expect(result).toEqual(filterDatasources);
  });

  it('ArisFilterService test: checking if getOpenFilterPanelSubject is executed', () => {
    let expected = arisFilterService.getOpenFilterPanelSubject();
    expect(expected).toBeDefined();
  });

  it('ArisFilterService test: checking if getClearAutoCompleteSubject is executed', () => {
    let expected = arisFilterService.getClearAutoCompleteSubject();
    expect(expected).toBeDefined();
  });

  it('ArisFilterService test: checking if setFilterConfig is executed', () => {
    arisFilterService.setFilterConfig(data);
    expect(arisFilterService).toBeTruthy();
  });

  it('ArisFilterService test: checking if getDatasourcesFromConfig is executed', () => {
    const result = arisFilterService.getDatasourcesFromConfig();
    expect(result.length).toEqual(0);
  });

  it('ArisFilterService test: checking if getDatasourcesFromConfig else is executed', () => {
    ArisFilterService.filterDatasources = undefined;
    const result = arisFilterService.getDatasourcesFromConfig();
    expect(result).toEqual(null);
  });
});
