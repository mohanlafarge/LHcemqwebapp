import { Subject } from 'rxjs/Subject';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
// import * as $ from 'jquery';
import { ArisAutoComplete } from '../ui-components/aris-autocomplete.component';

@Injectable()
export class ArisFilterService {
  // Define Variables
  public static filterDatasources: any = []; // varibale to save datasource
  private static sample: Observable<any> = undefined; // varible to call broadcast

  private static openFilterPanel = new Subject(); // for use of broadcast
  private static clearAutoComplete = new Subject(); // for use of broadcast

  constructor(private http: HttpClient) {
  }

  getFilterByPageName(pageName) {
    let url = 'rest/userpagefilter/bypagename/' + pageName;
    return this.http.get(url, { responseType: 'text' }).toPromise();
  }
  // get configuration
  getFilterConfig() {
    return ArisFilterService.filterDatasources;
  }
  // set filter configuration
  setFilterConfig(ds: any) {
    ArisFilterService.filterDatasources = ds;
  }
  getOpenFilterPanelSubject() {
    return ArisFilterService.openFilterPanel;
  }
  getClearAutoCompleteSubject() {
    return ArisFilterService.clearAutoComplete;
  }
  // get Filter by Page Name
  getFilter(pageName) {
    let url = 'rest/pagefilters/' + pageName;
    return this.http.get(url, { responseType: 'text' }).toPromise();
  }

  getDatasourcesFromConfig() {
    let dsList = [];
    if (ArisFilterService.filterDatasources) {
        console.log("Data Soorrrrrrrrrrrrrrrrrrrr", ArisFilterService.filterDatasources)
      ArisFilterService.filterDatasources.forEach((obj, keys) => {
        if (obj.criterias) {
          obj.criterias.forEach((cObj) => {
            if (cObj.type === 'autocompletefield' && cObj.dsname) {
              dsList.push(cObj.dsname);
            }
          });
        }
      });
    } else {
      dsList = null;
    }
    return dsList;
  }

  // get data for DataSource
  getDatasourceData(datasource) {
    console.log("Data SSSS", datasource)
    let url = 'rest/getFromDataSource/' + datasource + '?offset=0&limit=1000';
    return this.http.post(url, []).toPromise();
  }
  // Api for delete data from database
  deleteFilterData(pageName) {
    let url = 'rest/userpagefilter/delete/' + pageName;
    return this.http.post(url, {}).toPromise();
  }
  // Api for save filter data
  saveFilterData(pageName, data) {
    let url = 'rest/userpagefilter/save/' + pageName;
    return this.http.post(url, data, { headers: new HttpHeaders().set('Content-Type', 'application/json') }).toPromise();
  }
}
