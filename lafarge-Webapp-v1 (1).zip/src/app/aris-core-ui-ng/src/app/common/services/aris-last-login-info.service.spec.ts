import { TestBed, async, fakeAsync, tick } from '@angular/core/testing';
import { ArisSessionService } from './aris-session.service';
import { ArisLastLoginInfoService } from './aris-last-login-info.service';

describe('Test: Last Login Info Service', () => {
  const arisLastLoginInfoService = new ArisLastLoginInfoService();

  const lastLoginInfoUndefined = undefined;
  const lastLoginInfoSuccess = [
    [1511782819000, 1511783280000],
    [1511776255000, undefined]
  ];
  const lastLoginInfoFailure = [
    [1511790768000, 1511790793000],
    [1511790802000, undefined]
  ];

  it('lastLoginInfoService test : "getLastLoginInfo" manage successfully a "undefined" lastLoginInfo result', () => {
    arisLastLoginInfoService.setLastLoginInfo('paula.cazares', undefined);
    expect(arisLastLoginInfoService.getLastLoginInfo().username).toEqual('paula.cazares');
    expect(arisLastLoginInfoService.getLastLoginInfo().lastLoginStatus).toEqual(undefined);
  });

  it('lastLoginInfoService test : "getLastLoginInfo" manage a "Success" lastLoginInfo result', () => {
    arisLastLoginInfoService.setLastLoginInfo('paula.cazares', lastLoginInfoSuccess);
    expect(arisLastLoginInfoService.getLastLoginInfo().username).toEqual('paula.cazares');
    expect(arisLastLoginInfoService.getLastLoginInfo().lastLoginStatus).toEqual('Success');
  });

  it('lastLoginInfoService test : "getLastLoginInfo" manage a "Failure" lastLoginInfo result', () => {
    arisLastLoginInfoService.setLastLoginInfo('paula.cazares', lastLoginInfoFailure);
    expect(arisLastLoginInfoService.getLastLoginInfo().username).toEqual('paula.cazares');
    expect(arisLastLoginInfoService.getLastLoginInfo().lastLoginStatus).toEqual('Failure');
  });

});
