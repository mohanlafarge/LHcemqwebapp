import { Injectable } from '@angular/core';

@Injectable()
export class ArisLastLoginInfoService {
  private static lastLoginInfo: any = undefined;

  constructor() {
  }

  setLastLoginInfo(newUsername: string , newLastLoginInfo) {
    ArisLastLoginInfoService.lastLoginInfo = undefined;

    if (newLastLoginInfo === undefined || newLastLoginInfo.length === 0) {
      ArisLastLoginInfoService.lastLoginInfo = {
        username: newUsername,
        lastLoggedIn: undefined,
        lastLoggedOutTIme: undefined,
        lastLoginStatus: undefined
      };
    } else if (newLastLoginInfo[1] === undefined || newLastLoginInfo[0][0] > newLastLoginInfo[1][0]) {
      ArisLastLoginInfoService.lastLoginInfo = {
        username: newUsername,
        lastLoggedIn: newLastLoginInfo[0][0],
        lastLoggedOutTIme: newLastLoginInfo[0][1],
        lastLoginStatus: 'Success'
      };
    } else {
      ArisLastLoginInfoService.lastLoginInfo = {
        username: newUsername,
        lastLoggedIn: newLastLoginInfo[1][0],
        lastLoggedOutTIme: newLastLoginInfo[1][1],
        lastLoginStatus: 'Failure'
      };
    }

    sessionStorage.setItem('lastLoginInfo',
      JSON.stringify(ArisLastLoginInfoService.lastLoginInfo));
  }

  getLastLoginInfo() {
    if (ArisLastLoginInfoService.lastLoginInfo === undefined && sessionStorage.getItem('lastLoginInfo')) {
      ArisLastLoginInfoService.lastLoginInfo = JSON.parse(sessionStorage.getItem('lastLoginInfo'));
    }
    return ArisLastLoginInfoService.lastLoginInfo;
  }
}
