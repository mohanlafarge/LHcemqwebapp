import { Injectable } from '@angular/core';
import { get } from 'scriptjs';       // Load Libraries Dynamically, like Google Maps
import { ArisConfigService } from './aris-config.service';

// DECLARE THE FOLLOWING VARIABLE WHERE WILL BE USED THE GOOGLE MAP LIBRARY
// declare var google: any;


@Injectable()
export class ArisLibraryLoadService {

  constructor(private arisConfigService: ArisConfigService) {
  }

  getGoogleMapLibrary(callbackFunction) {
    if (this.arisConfigService.getParameter("Google License Key") !== undefined &&
        this.arisConfigService.getParameter("Google License Key").length > 0) {
      get("https://maps.googleapis.com/maps/api/js?key=" + this.arisConfigService.getParameter("Google License Key") + "&libraries=places", () => {
        callbackFunction();
      });
    }
  }
}

