import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

import 'rxjs/add/operator/toPromise';
import { ArisSessionService } from './aris-session.service';
import { ArisConfigService } from './aris-config.service';
import { ArisWebSocketService } from './aris-websocket.service';

@Injectable()
export class ArisLoginService {
  // loggedIn = false;
  private arisConfigLocaleUrl = 'rest/config/locale';
  private loginUrl = 'rest/j_spring_security_check';
  private preLoginUrl = 'rest/authenticationinfo/prelogin';
  private postLoginUrl = 'rest/authenticationinfo/postlogin';
  private logoutUrl = 'rest/logout';
  private passwordUrl = window.app.config.application.urlForPasswordReset;

  constructor(private http: HttpClient ,
    private arisSessionService: ArisSessionService,
    private arisConfigService: ArisConfigService,
    private arisWebSocketService: ArisWebSocketService,
    private router: Router) {}

  // Execute the Login
  login(username: string, password: string): Promise<any> {
    this.arisSessionService.setExpired(false);
    const form = `j_username=${username}&j_password=${password}`;
    return this.http.post(this.loginUrl, form, {
      headers: new HttpHeaders()
        .set('Content-Type', 'application/x-www-form-urlencoded'),
    }).toPromise();
  }

  preLogin() {
    this.arisSessionService.setExpired(false);
    return this.http.get(this.preLoginUrl, { headers: new HttpHeaders().set('Content-Type', 'application/json') }).toPromise().then((response)=>{
      return({authenticationProviderType: "DB", locale: "en-gb"});
    });
  }

  postLogin() {
    return this.http.get(this.postLoginUrl, { headers: new HttpHeaders().set('Content-Type', 'application/json') }).toPromise();
  }

  // Execute the Logout
  logout() {
    this.arisWebSocketService.disconnectAll();
    if (this.arisConfigService.getAuthenticationProviderType().toUpperCase() === 'SAML') {
      this.arisSessionService.setLoggedOut();
      //window.open('saml/logout', '_self');
      this.router.navigate(['login', 'pre']);
    } else {
      this.arisSessionService.setLoggedOut();
      localStorage.clear();
      return this.http.post(this.logoutUrl, undefined, {
        headers: new HttpHeaders().set('Content-Type', 'application/json'),
        responseType: 'text',
      }).toPromise().then((data) => {
        this.router.navigate(['login', 'pre']);
      }, (error) => {
        console.log(error);
        this.router.navigate(['login', 'pre']);
      });
    }

  }

  getLocale() {
    return this.http.get(this.arisConfigLocaleUrl, { headers: new HttpHeaders().set('Content-Type', 'application/json'),
      responseType: 'text' }).toPromise();
  }

  // Return the 'url' used to change/reset the password
  // If it is defined empty, it will be used the default page '/forgetpassword'
  getChangePasswordToolUrl() {
    return this.passwordUrl;
  }
}
