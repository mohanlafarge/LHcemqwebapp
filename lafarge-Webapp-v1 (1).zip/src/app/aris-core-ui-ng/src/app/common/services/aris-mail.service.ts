import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';

import { ArisNotificationBoxService } from '../ui-page-sections/error-module/services/aris-notification-box.service';

import 'rxjs/add/operator/toPromise';


@Injectable()
export class ArisMailService {

  constructor(private http: HttpClient,
              private arisNotificationBox: ArisNotificationBoxService) {
  }

  /*
    * Send a Plain Text Email
    *  @param data
    *     - emailTo : destination email
    *     - emailSubject : email subject
    *     - emailMessage : email content message
    *  returns
    */
  sendPlainTextEmail(emailTo: string, emailSubject: string, emailMessage: string) {
    this.http.get('rest/email/plaintext/' + encodeURIComponent(emailTo) + '/' + encodeURIComponent(emailSubject) + '/' + encodeURIComponent(emailMessage))
    .toPromise().then((data) => {
      const successMessage = { status: '200', title: 'CLI_MSG_TIT_OPERATION_SUCCESS', message: 'CLI_MSG_DESC_OPERATION_SUCCESS' };
      this.arisNotificationBox.showNotification(successMessage, 'right', 'success');
    }, (err) => {
      this.arisNotificationBox.showNotification(err, 'right', 'error');
    });
  }
}