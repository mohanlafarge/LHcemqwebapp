import { TestBed, getTestBed } from "@angular/core/testing";
import { HttpClient } from "@angular/common/http";
import { ArisSessionService } from "./aris-session.service";
import { ArisConfigService } from "./aris-config.service";
import { ArisWebSocketService } from "./aris-websocket.service";
import { ArisNotificationBoxService } from "../ui-page-sections/error-module/services/aris-notification-box.service";
import { ArisNotificationService } from "./aris-notification.service";
import { HttpTestingController, HttpClientTestingModule } from "@angular/common/http/testing";
import { ArisConfigServiceMock } from "../../mocks/services/mock-aris-config.service";
import { ArisWebSocketServiceMock } from "../../mocks/services/mock-aris-web-socket.service";
import { ArisSessionServiceMock } from "../../mocks/services/mock-aris-session.service";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { ArisNotificationBoxServiceMock } from "../../mocks/services/mock-aris-notification-box.services";

describe('Test: ArisNotificationService', () => {
  let arisNotificationService: ArisNotificationService;
  let http: HttpClient;
  let injector: TestBed;
  let httpMock: HttpTestingController;
  let dummyResponse: any;
  let arisSessionServiceMock: ArisSessionService;
  let arisConfigServiceMock: ArisConfigService;
  let arisWebSocketServiceMock: ArisWebSocketService;
  let arisNotificationBoxServiceMock: ArisNotificationBoxService;

  beforeEach(() => {
    arisSessionServiceMock = new ArisSessionServiceMock();
    arisConfigServiceMock = new ArisConfigServiceMock();
    arisWebSocketServiceMock = new ArisWebSocketServiceMock();
    arisNotificationBoxServiceMock = new ArisNotificationBoxServiceMock();
    TestBed.configureTestingModule({
      declarations: [],
      imports: [
        HttpClientTestingModule
      ],
      providers: [
        ArisNotificationService,
        { provide: ArisSessionService, useValue: arisSessionServiceMock },
        { provide: ArisConfigService, useValue: arisConfigServiceMock },
        { provide: ArisWebSocketService, useValue: arisWebSocketServiceMock },
        { provide: ArisNotificationBoxService, useValue: arisNotificationBoxServiceMock },
      ],
      schemas: [NO_ERRORS_SCHEMA]
    });
    injector = getTestBed();
    arisNotificationService = injector.get(ArisNotificationService);
    httpMock = injector.get(HttpTestingController);
    dummyResponse = {
      status: 'Ok'
    };
  });

  it('ArisNotificationService test: checking if ArisNotificationService is defined', () => {
    expect(arisNotificationService).toBeDefined();
  });

  describe('ArisNotificationService test: initNotificationSubscription', () => {
    beforeEach(() => {
      spyOn(arisSessionServiceMock, 'isLoggedIn').and.returnValue(true);
      spyOn(arisWebSocketServiceMock, 'connect');
    });

    it('ArisNotificationService test: initNotificationSubscription is defined', () => {
      arisNotificationService.initNotificationSubscription();
      expect(arisWebSocketServiceMock.connect).toHaveBeenCalled();
    });
  });

  describe("verify upgradeCounterOfAlerts method", () => {
    it("should return Promise<any>", () => {
      arisNotificationService.upgradeCounterOfAlerts();
    });
  });

  describe("verify getNotifications method", () => {
    it("should return Promise<any>", () => {
      arisNotificationService.getNotifications().then((res) => {
        expect(res).toBeDefined();
        expect(res).toEqual(dummyResponse);
      });
      const req = httpMock.expectOne('rest/notifications/self');
      expect(req.request.method).toBe("GET");
      req.flush(dummyResponse);
    });
  });

  describe("verify changeAllUserNotificationStatusToAcknowledged method", () => {
    it("should return Promise<any>", () => {
      arisNotificationService.changeAllUserNotificationStatusToAcknowledged().then((res) => {
        expect(res).toBeDefined();
        expect(res).toEqual(dummyResponse);
      });
      const req = httpMock.expectOne('rest/notifications/self/update/toacknowledged/all');
      expect(req.request.method).toBe("GET");
      req.flush(dummyResponse);
    });
  });

  describe("verify changeUserNotificationStatusByIdToAcknowledged method", () => {
    it("should return Promise<any>", () => {
      arisNotificationService.changeUserNotificationStatusByIdToAcknowledged(1).then((res) => {
        expect(res).toBeDefined();
        expect(res).toEqual(dummyResponse);
      });
      const req = httpMock.expectOne('rest/notifications/self/update/toacknowledged/byid/1');
      expect(req.request.method).toBe("GET");
      req.flush(dummyResponse);
    });
  });

  describe("verify removeAll method", () => {
    it("should return Promise<any>", () => {
      arisNotificationService.removeAll().then((res) => {
        expect(res).toBeDefined();
        expect(res).toEqual(dummyResponse);
      });
      const req = httpMock.expectOne('rest/notifications/self/remove/all');
      expect(req.request.method).toBe("DELETE");
      req.flush(dummyResponse);
    });
  });

  describe("verify removeNotification method", () => {
    it("should return Promise<any>", () => {
      arisNotificationService.removeNotification(1).then((res) => {
        expect(res).toBeDefined();
        expect(res).toEqual(dummyResponse);
      });
      const req = httpMock.expectOne('rest/notifications/self/remove/byid/1');
      expect(req.request.method).toBe("DELETE");
      req.flush(dummyResponse);
    });
  });
});
