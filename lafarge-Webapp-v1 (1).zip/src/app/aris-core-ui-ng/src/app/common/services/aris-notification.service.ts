import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from "rxjs/Subject";
import { Observable } from 'rxjs/Observable';

import { ArisSessionService } from './aris-session.service';
import { ArisConfigService } from './aris-config.service';
import { ArisWebSocketService } from './aris-websocket.service';
import { ArisNotificationBoxService } from '../ui-page-sections/error-module/services/aris-notification-box.service';

@Injectable()
export class ArisNotificationService {
  public static arisLocalNotifications = [];
  notificationSubject = new Subject();
  notificationPopupClose = new Subject();

  constructor(private arisSessionService: ArisSessionService,
              private arisConfigService: ArisConfigService,
              private arisWebSocketService: ArisWebSocketService,
              private arisNotificationBoxService: ArisNotificationBoxService,
              private http: HttpClient) {
   // this.initNotificationSubscription();
  }

  initNotificationSubscription(callback?) {
    this.arisWebSocketService.disconnectAll();
    if (this.arisSessionService.isLoggedIn()) {
      /* Connect the WebSockets */
      this.arisWebSocketService.connect((frame) => {
        let subscriptions = this.arisConfigService.getParameter('Topics Subscribed');
        if (subscriptions && subscriptions !== "?") {
          let subScriptionList = JSON.parse(subscriptions).subscriptions;
          for (let i = 0; i < subScriptionList.length; i = i + 1) {
            if ((subScriptionList[i].notification !== undefined) &&
                (subScriptionList[i].notification.toString().toLowerCase().indexOf('dashboard') !== -1 ||
                 subScriptionList[i].notification.toString().toLowerCase().indexOf('desktop') !== -1)
                ) {
              this.arisWebSocketService.subscribe("/topic/" + subScriptionList[i].type + "/" + subScriptionList[i].name,
              (message: any) => {
                if (message && message.body) {
                  let adminMessage = JSON.parse(message.body);
                  let messagePopped = { title: adminMessage.alertTitle, message: adminMessage.alertShortDesc, status: adminMessage.code };
                  this.arisNotificationBoxService.showNotification(messagePopped, 'right', adminMessage.alertSeverity);
                }
              });
            }

            // The subscriptions without notification defined never will be increase the Notification Bell Counter
            if (subScriptionList[i].notification !== null && subScriptionList[i].notification.length > 0) {
              this.arisWebSocketService.subscribe("/topic/" + subScriptionList[i].type + "/" + subScriptionList[i].name + "_Counter",
                (message: any) => {
                  if (message && message.body) {
                    this.upgradeCounterOfAlerts(parseInt(message.body, 10));
                  }
                }
              );
            }
          }
        }

        /*** Subscription to Administrator messages ***/
        this.arisWebSocketService.subscribe("/topic/administrator_alert/message",
        (message: any) => {
          if (message && message.body) {
            let adminMessage = JSON.parse(message.body);
            let messagePopped = { title: adminMessage.alertTitle, message: adminMessage.alertShortDesc, status: adminMessage.code };
            this.arisNotificationBoxService.showNotification(messagePopped, 'right', adminMessage.alertSeverity);
          }
        });

        return typeof callback === "function" ? callback(frame) : void 0;
      });
    }
  }

  upgradeCounterOfAlerts(data?: any) {
    this.notificationSubject.next(data);
  }

  getNotifications() {
    return this.http.get("rest/notifications/self").toPromise();
  }

  changeAllUserNotificationStatusToAcknowledged() {
    return this.http.get("rest/notifications/self/update/toacknowledged/all").toPromise();
  }

  changeUserNotificationStatusByIdToAcknowledged(notificationId: number) {
    let url = "rest/notifications/self/update/toacknowledged/byid/" + notificationId;
    return this.http.get(url).toPromise();
  }

  removeAll() {
    return this.http.delete("rest/notifications/self/remove/all").toPromise();
  }
  removeNotification(notificationId: number) {
    return this.http.delete("rest/notifications/self/remove/byid/" + notificationId).toPromise();
  }
}
