import { ArisPageRefreshService } from './aris-page-refresh.service';
import { ArisConfigService } from './aris-config.service';

import { ArisLanguageService } from '../ui-page-sections/language-selector-module/services/aris-language.service';
import { HttpHandler, HttpClient } from '@angular/common/http';

describe('Refresh Page Service Unit Test', () => {
  let handler: HttpHandler;
  let http = new HttpClient(handler);
  let arisLanguageService = new ArisLanguageService();
  let arisConfigService = new ArisConfigService(http, arisLanguageService);
  let arisPageRefreshService = new ArisPageRefreshService(arisConfigService);
  it('check for setPageRefreshInExecution', () => {
    arisPageRefreshService.setPageRefreshInExecution(true);
    expect(arisPageRefreshService.getPageRefreshInExecution()).toBe(true);
  });
  it('check for enable', () => {
    arisPageRefreshService.enable(false);
    expect(arisPageRefreshService.isEnable()).toBe(false);
  });
  it('check for isEnable', () => {
    arisPageRefreshService.enable(window.app.config.application.autorefresh.defaultValue);
    expect(arisPageRefreshService.isEnable()).toBe(window.app.config.application.autorefresh.defaultValue);
  });
  it('check for getPageRefreshInExecution', () => {
    arisPageRefreshService.setPageRefreshInExecution(true);
    arisPageRefreshService.getPageRefreshInExecution();
    expect(arisPageRefreshService.getPageRefreshInExecution()).toBe(true);
  });
  it('check for subscribePageRefresh', () => {
    arisPageRefreshService.enable(true);
    arisPageRefreshService.isEnable();
    arisPageRefreshService.subscribePageRefresh(arisPageRefreshService.isEnable());
    // spyOn(arisPageRefreshService, 'upgradeSubscription').and.callThrough();
    // expect(arisPageRefreshService.upgradeSubscription).not.toHaveBeenCalled();
  });
  it('check for subscribePageRefresh failure scenario', () => {
    ArisPageRefreshService.pageRefreshAvailable = false ;
    arisPageRefreshService.subscribePageRefresh(arisPageRefreshService.isEnable());
    expect(ArisPageRefreshService.pageRefreshAvailable).toBeFalsy();
  });
});
