import { ArisConfigService } from './aris-config.service';
import { ArisUserOperationService } from './aris-user-operation.service';
import { Injectable } from '@angular/core';

@Injectable()
export class ArisPageRefreshService {
  public static pageRefreshEnable = true;
  public static pageRefreshAvailable = true;
  public static lastinterval = {};
  public static pageRefreshInExecution = false;

  constructor(private configService: ArisConfigService) {

    if (window.app.config.application.autorefresh !== undefined) {
      if (window.app.config.application.autorefresh.defaultValue !== undefined) {
        ArisPageRefreshService.pageRefreshEnable = window.app.config.application.autorefresh.defaultValue;
      }
      if (window.app.config.application.autorefresh.available !== undefined) {
        ArisPageRefreshService.pageRefreshAvailable = window.app.config.application.autorefresh.available;
      }
    }
  }

  resetPageRefresh() {
    if (Object.keys(ArisPageRefreshService.lastinterval).length !== 0) {
      for (let index in ArisPageRefreshService.lastinterval) {
        if (ArisPageRefreshService.lastinterval.hasOwnProperty(index) &&
           index.indexOf('refreshTimer') === -1) {
          clearInterval(ArisPageRefreshService.lastinterval[index]);
        }
      }
    }
  }

  private upgradeSubscription(inputCallBack, refreshPeriod) {
    (() => {
      ArisPageRefreshService.lastinterval[inputCallBack] = setInterval(() => {
        if (ArisPageRefreshService.pageRefreshEnable === true) {
          this.setPageRefreshInExecution(true);
          if (inputCallBack !== undefined) {
            ArisUserOperationService.getInstance().setUserOperation(false);
            inputCallBack();
          }
        }
      }, refreshPeriod);
    })();
  }

  setPageRefreshInExecution(refreshing: boolean) {
    return ArisPageRefreshService.pageRefreshInExecution = refreshing;
  }

  subscribePageRefresh(inputCallBack: any, refreshPeriod?) {
    if (ArisPageRefreshService.pageRefreshAvailable) {
      if (refreshPeriod) {
        return this.upgradeSubscription(inputCallBack,  refreshPeriod);
      }
      return this.upgradeSubscription(inputCallBack,  this.configService.getRefreshFrontendTimer());
    }
  }

  enable(option): boolean {
    return ArisPageRefreshService.pageRefreshEnable = option;
  }

  isEnable(): boolean {
    return ArisPageRefreshService.pageRefreshEnable;
  }

  getPageRefreshInExecution() {
    return ArisPageRefreshService.pageRefreshInExecution;
  }

  isPageRefreshAvailable() {
    return ArisPageRefreshService.pageRefreshAvailable;
  }
}
