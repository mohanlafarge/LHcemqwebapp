import { ArisFilterService } from './aris-filter.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ArisDataSourceService } from './aris-datasource.service';
import { ArisHeaderService } from '../ui-page-sections/header-module/services/aris-header-service';
import { ArisFooterService } from '../ui-page-sections/footer-module/services/aris-footer-service';
import { ArisPageRefreshService } from './aris-page-refresh.service';
import { ArisNotificationBoxService } from '../ui-page-sections/error-module/services/aris-notification-box.service';
import { ArisPageService } from './aris-page-service';
import { ArisPageSectionObservableEventService } from '../ui-page-sections/services/aris-page-section-observable-event.service';
import { ArisConfigService } from './aris-config.service';
import { ArisLanguageService } from '../ui-page-sections/language-selector-module/services/aris-language.service';

export class MockHttp extends HttpClient {

}

describe('Test: ArisPageService', () => {
  let arisPageService: ArisPageService;
  let http: HttpClient;

  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [
      ],
      imports: [
        HttpClientModule,
        HttpClientTestingModule
      ],
      providers: [
        ArisHeaderService,
        ArisFooterService,
        ArisPageSectionObservableEventService,
        ArisPageRefreshService,
        { provide: ArisNotificationBoxService },
        ArisFilterService,
        ArisConfigService,
        ArisLanguageService,
        ArisPageService,
        { provide: HttpClient,
          useClass: MockHttp },
      ]
    }).compileComponents();

    afterAll(() => {
      arisPageService = null;
        });

    arisPageService = TestBed.get(ArisPageService);
    http = TestBed.get(HttpClient);
  });


  it('ArisPageService test: checking if setPageLayout is executed', () => {
    arisPageService.setPageLayout('refreshCache');
    expect(arisPageService.pageLayout).toEqual('refreshCache');
  });

  it('ArisPageService test: checking if getPageLayout is executed', () => {
    let result = arisPageService.getPageLayout();
    expect(result).toEqual('refreshCache');
  });

  it('ArisPageService test: checking if setPageName  is executed', () => {
    arisPageService.setPageName ('refreshCache');
    expect(arisPageService.pageName).toEqual('refreshCache');
  });

  it('ArisPageService test: checking if getPageName is executed', () => {
    let result = arisPageService.getPageName();
    expect(result).toEqual('"refreshCache"');
  });

  it('ArisPageService test: checking if capitalize  is executed', () => {
    let expected = arisPageService.capitalize ('refreshCache');
    expect(expected).toEqual('RefreshCache');
  });

  it('ArisPageService test: checking if initPage is executed', () => {
    let arisFilterService = TestBed.get(ArisFilterService);
    spyOn(arisFilterService, 'setFilterConfig').and.callThrough();
    arisPageService.initPage('path', 'refreshCache', 'headerType', 'footerType');
    expect(arisFilterService.setFilterConfig).toHaveBeenCalled();
  });

  it('ArisPageService test: checking if initPage else scenario is executed', () => {
    let arisFilterService = TestBed.get(ArisFilterService);
    spyOn(arisFilterService, 'setFilterConfig').and.callThrough();
    arisPageService.initPage('path', undefined);
    expect(arisFilterService.setFilterConfig).toHaveBeenCalled();
  });

});
