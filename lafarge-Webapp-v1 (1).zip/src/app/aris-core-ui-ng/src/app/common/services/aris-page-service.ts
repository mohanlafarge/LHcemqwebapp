import { DOCUMENT } from '@angular/platform-browser';
import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { ArisNotificationBoxService } from '../ui-page-sections/error-module/services/aris-notification-box.service';
import { ArisConfigService } from './aris-config.service';
import { ArisUserOperationService } from './aris-user-operation.service';
import { ArisHeaderService } from '../ui-page-sections/header-module/services/aris-header-service';
import { ArisFooterService } from '../ui-page-sections/footer-module/services/aris-footer-service';
import { ArisPageRefreshService } from './aris-page-refresh.service';
import { ArisFilterService } from './aris-filter.service';


@Injectable()
export class ArisPageService {
  public pageLayout = '';
  public pageName = '';

  constructor(@Inject(DOCUMENT) private document,
              private arisHeaderService: ArisHeaderService,
              private arisFooterService: ArisFooterService,
              private arisPageRefreshService: ArisPageRefreshService,
              private arisNotificationBox: ArisNotificationBoxService,
              private arisFilterService: ArisFilterService,
              public http: HttpClient) {
    if (typeof (Storage) !== 'undefined') {
      if (sessionStorage.pageLayout === undefined) {
        this.pageLayout = '';
      } else {
        this.pageLayout = JSON.parse(sessionStorage.pageLayout);
      }
      if (sessionStorage.pageName === undefined) {
        this.pageName = '';
      } else {
        this.pageName = sessionStorage.pageName;
      }
    }
  }

  initPage (path, title, headerType?, footerType?) {
    // TO DO : this.arisNotificationBox.closeAll();
    window.scrollTo(0, 0);
    this.arisFilterService.setFilterConfig(undefined);
    this.arisPageRefreshService.resetPageRefresh();
    // Configure Header
    if (headerType) {
      this.arisHeaderService.setHeaderInfo(headerType);
    } else {
      this.arisHeaderService.setHeaderMap(window.app.config.application.headerConfig);
    }
    // Configure Footer
    if (footerType) {
      this.arisFooterService.setFooterInfo(footerType);
    } else {
      this.arisFooterService.setFooterInfo(window.app.config.application.footerConfig);
    }

    // Title displayed on browser tab and in Google Analytics
    // if (title !== undefined) {
    //   this.document.title = title;
    // } else {
    //   this.document.title = this.capitalize(path.replace(/\//g, ' '));
    // }
  }

  setPageLayout (newPageLayout) {
    this.pageLayout = newPageLayout;
    sessionStorage.setItem('pageLayout', JSON.stringify(newPageLayout));
  }

  getPageLayout () {
    return this.pageLayout;
  }

  setPageName (newPageName) {
    this.pageName = newPageName;
    sessionStorage.setItem('pageName', JSON.stringify(newPageName));
  }

  getPageName () {
    return this.pageName;
  }

    /**  convert all word's first letter in to Capital */
  capitalize(originalTitle) {
    return originalTitle.replace(/(^|\s)([a-z])/g, function (m, p1, p2) {
      return p1 + p2.toUpperCase();
    });
  }
}
