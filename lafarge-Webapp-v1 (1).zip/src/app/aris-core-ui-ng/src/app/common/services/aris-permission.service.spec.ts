import { TestBed, async, fakeAsync, tick } from '@angular/core/testing';
import { ArisPermissionService } from './aris-permission.service';

describe('Test: Aris Permission Service', () => {
  const arisPermissionService = new ArisPermissionService();
  const permissions = [{
    id: 26,
    name: 'PERM_VIEW_WW',
    moduleName: 'AWA_WW',
    authority: 'PERM_VIEW_WW',
  }, {
    id: 25,
    name: 'PERM_VIEW_CW',
    moduleName: 'AWA_CW',
    authority: 'PERM_VIEW_CW',
  }, {
    id: 24,
    name: 'PERM_VIEW_CIP',
    moduleName: 'AWA_CIP',
    authority: 'PERM_VIEW_CIP',
  }];

  it('Aris Permission Service test: checking user permissions in session', () => {
    arisPermissionService.setPermissions(permissions);
    expect(sessionStorage.getItem('permissions')).toBeDefined(permissions);
  });

  it('Aris Permission Service test: checking user getpermissions()', () => {
    arisPermissionService.setPermissions(permissions);
    expect(arisPermissionService.getPermissions()).toBeDefined(permissions);
  });

  it('Aris Permission Service test: user have permission it should return true', () => {
    arisPermissionService.setPermissions(permissions);
    expect(arisPermissionService.hasPermission('PERM_VIEW_CW')).toMatch(/true/);
  });

  it('Aris Permission Service test: user dont have permission it should return false', () => {
    arisPermissionService.setPermissions(permissions);
    expect(arisPermissionService.hasPermission('PERM_VIEW_Test')).toMatch(/false/);
  });

  it('Aris Permission Service test: user permission undefined it should return true', () => {
    arisPermissionService.setPermissions(permissions);
    expect(arisPermissionService.hasPermission(undefined)).toMatch(/true/);
  });

});

