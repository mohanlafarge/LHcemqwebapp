export class ArisPermissionService {
  private permissions: any = {};

  constructor() {
    if (typeof (Storage) !== 'undefined') {
      if (sessionStorage.permissions === undefined) {
        sessionStorage.setItem('permissions', JSON.stringify({}));
      } else {
        this.permissions = JSON.parse(sessionStorage.permissions);
      }
    }
  }

  private checkPermission(perm) {
    const aux = this.permissions.reduce(
      function (prev, curr) {
        return (curr.name === perm) ? curr : prev;
      }, null);

    if (perm === undefined || aux !== null) {
      return true;
    }
    return false;
  }

  resetPermissionsn() {
    console.log(this.permissions);
    if (typeof (Storage) !== 'undefined') {
      sessionStorage.setItem('permissions', JSON.stringify({}));
    }
  }

  hasPermission(perm: any) {
    if (this.permissions === undefined || Object.keys(this.permissions).length === 0) {
      return false;
    }

    if (perm === undefined) {
      return true;
    }

    if (perm === 'true' || perm === true) {
      return true;
    }
    if (perm === 'false' || perm === false) {
      return false;
    }

    let result = false;
    if (perm.indexOf('hasPermission') !== -1) {
      result = perm; // NOSONAR
    } else {
      result = this.checkPermission(perm);
    }
    return result;
  }

  getPermissions() {
    return this.permissions;
  }

  setPermissions(data) {
    this.permissions = data;
    if (typeof (Storage) !== 'undefined') {
      sessionStorage.setItem('permissions', JSON.stringify(data));
    }
  }

}
