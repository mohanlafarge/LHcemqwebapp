// import { TestBed } from '@angular/core/testing';
// import { ArisRouteAuthorizationService } from './aris-route-authorization.service';
// import { ArisSessionService } from './aris-session.service';
// import { ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
// import { ArisPermissionService } from './aris-permission.service';
// import { ArisLoginService } from './aris-login.service';
// import { HttpClient } from '@angular/common/http';
// import { HttpClientTestingModule } from '@angular/common/http/testing';
// import { ArisConfigService } from './aris-config.service';
// import { ArisLanguageService } from '../ui-page-sections/language-selector-module/services/aris-language.service';

// class MockActivatedRouteSnapshot {
//   private _data: any;
//   get data() {
//     return this._data;
//   }
// }
// let mockRouter = {
//   navigate: jasmine.createSpy('navigate')
// };

// export class MockHttpClient extends HttpClient {
// }

// describe('Test: ArisRouteAuthorizationService', () => {
//   let arisRouteAuthorizationService: ArisRouteAuthorizationService;
//   let route: ActivatedRouteSnapshot;
//   let state: RouterStateSnapshot;

//   beforeEach(() => {

//     TestBed.configureTestingModule({
//       declarations: [
//       ],
//       imports: [
//         HttpClientTestingModule
//       ],
//       providers: [
//         ArisPermissionService, ArisConfigService, ArisLanguageService,
//         ArisRouteAuthorizationService, ArisLoginService, { provide: HttpClient, useClass: MockHttpClient },
//         ArisSessionService, { provide: ActivatedRouteSnapshot,
//           useClass: MockActivatedRouteSnapshot },
//         { provide: Router, useValue: mockRouter }
//       ]
//     }).compileComponents();

//     afterAll(() => {
//       arisRouteAuthorizationService = null;
//         });
//     arisRouteAuthorizationService = TestBed.get(ArisRouteAuthorizationService);
//     state = TestBed.get(ActivatedRouteSnapshot);
//   });

//   it('canActivateChild executed', () => {
//     spyOn(arisRouteAuthorizationService, 'isBrowserSupported').and.callThrough();
//     arisRouteAuthorizationService.canActivateChild(route, state);
//     expect(arisRouteAuthorizationService.isBrowserSupported).toHaveBeenCalled();
//   });


// });
