import { Injectable } from '@angular/core';
import {
  CanActivate,
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  CanActivateChild,
} from '@angular/router';
import { ArisSessionService } from './aris-session.service';
import { ArisPermissionService } from './aris-permission.service';
import { ArisLoginService } from './aris-login.service';
import { ArisNotificationBoxService } from '../ui-page-sections/error-module/services/aris-notification-box.service';

@Injectable()
export class ArisRouteAuthorizationService implements CanActivate, CanActivateChild {
  constructor(private arisSessionService: ArisSessionService,
              private router: Router,
              private arisNotificationBoxService: ArisNotificationBoxService,
              private arisPermissionService: ArisPermissionService,
              private arisLoginService: ArisLoginService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    let isBrowserSupported = this.isBrowserSupported();
    if (!isBrowserSupported) {
      this.router.navigate(['./browsernotsupported']);
      return false;
    }
    if (state.url.indexOf("/login") !== -1) {
      return true;
    }

    if (this.arisSessionService.isLoggedIn() &&
        (route.data === null || (route.data !== null && this.arisPermissionService.hasPermission(route.data.authority)))) {
      return true;
    }

    if (this.router.url !== "/login") {
      let resultMessage = {
        status: '403',
        title: 'CLI_ERR_TIT_ACCES_DENIED',
        message: 'CLI_ERR_DESC_PERMISSION_AREA_DENIED'
      };
      this.arisNotificationBoxService.showNotification(resultMessage, 'right', 'error');
    }
    return false;
  }

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    return this.canActivate(route, state);
  }

  isBrowserSupported() {
    return navigator.appName === 'Microsoft Internet Explorer' ? false : true;
  }
}
