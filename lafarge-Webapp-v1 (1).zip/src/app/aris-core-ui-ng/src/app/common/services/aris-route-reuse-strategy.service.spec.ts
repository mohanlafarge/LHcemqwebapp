import { ArisRouteReuseStrategy } from './aris-route-reuse-strategy.service';
import { ActivatedRouteSnapshot } from '@angular/router';


describe('Test: ArisRouteReuseStrategy', () => {
  let arisRouteReuseStrategy = new ArisRouteReuseStrategy();
  let route:  ActivatedRouteSnapshot;
  let handle:  {};
  let curr:  ActivatedRouteSnapshot;

  it('shouldDetach executed', () => {
    let value = arisRouteReuseStrategy.shouldDetach(route);
    expect(value).toBeFalsy();
  });

  it('store executed', () => {
    arisRouteReuseStrategy.store(route, handle);
    expect(arisRouteReuseStrategy).toBeTruthy();
  });

  it('shouldAttach executed', () => {
    let value = arisRouteReuseStrategy.shouldAttach(route);
    expect(value).toBeFalsy();
  });

  it('retrieve executed', () => {
    let value = arisRouteReuseStrategy.retrieve(route);
    expect(value).toBeNull();
  });

  it('shouldReuseRoute executed', () => {
    let value = arisRouteReuseStrategy.shouldReuseRoute(route, curr);
    expect(value).toBeFalsy();
  });

});
