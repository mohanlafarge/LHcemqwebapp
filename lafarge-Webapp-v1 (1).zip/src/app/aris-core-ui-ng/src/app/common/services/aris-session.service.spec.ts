import { TestBed, async, fakeAsync, tick } from '@angular/core/testing';
import { ArisSessionService } from './aris-session.service';

describe('Test: Aris Session Service', () => {

  beforeEach(() => TestBed.configureTestingModule({
    providers: [ArisSessionService]
  }));

  it('Aris Session Service test : checking user loggedIn', () => {
    const arisSessionService = TestBed.get(ArisSessionService);
    arisSessionService.setLoggedIn('daniel.cazares');
    expect(arisSessionService.getConnectedUser()).toContain('daniel.cazares');
    expect(arisSessionService.isLoggedIn()).toMatch(/true/);
  });

  it('Aris Session Service test : checking user logout', () => {
    const arisSessionService = TestBed.get(ArisSessionService);
    arisSessionService.setLoggedIn('daniel.cazares');
    arisSessionService.setLoggedOut();
    expect(arisSessionService.isLoggedIn()).toMatch(/false/);
  });

});
