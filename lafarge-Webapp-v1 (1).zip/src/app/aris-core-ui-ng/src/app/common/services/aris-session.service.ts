import { Injectable } from '@angular/core';

import 'rxjs/add/operator/toPromise';

@Injectable()
export class ArisSessionService {
  private static loggedIn = false;
  private static expired = false;
  private static x_xsrf_Token = "";
  private loginUrl = 'rest/j_spring_security_check';
  private logoutUrl = 'rest/logout';

  constructor() {
    if (typeof (Storage) !== 'undefined') {
      if (sessionStorage.loggedIn === undefined) {
        ArisSessionService.loggedIn = false;
      } else {
        ArisSessionService.loggedIn = JSON.parse(sessionStorage.loggedIn);
      }
    }
  }

  set_x_xsrf_Token(new_x_xsrf_Token) {
    ArisSessionService.x_xsrf_Token = new_x_xsrf_Token;
  }
  get_x_xsrf_Token() {
    return ArisSessionService.x_xsrf_Token;
  }
  // Change the session status to LoggedIn
  // This function must be called after executing the login process successfully
  setLoggedIn(user: string) {
    ArisSessionService.loggedIn = true;
    if (typeof (Storage) !== 'undefined') {
      sessionStorage.setItem('username', user);
      sessionStorage.setItem('loggedIn', JSON.stringify(true));
    }
  }

  // Change the session status to LoggedOut
  // This function must be called after executing the logout process successfully
  setLoggedOut() {
    ArisSessionService.loggedIn = false;
    if (typeof (Storage) !== 'undefined') {
      sessionStorage.clear();
    }
  }

  // Return true if the Login was executed successfully
  isLoggedIn(): boolean {
    return this.getConnectedUser() != null;
  }

  // Return the 'Username' associated to the session
  getConnectedUser(): string {
    return sessionStorage.getItem('username');
  }

  setExpired(newExpired) {
    if (newExpired === true) {
      this.setLoggedOut();
    }
    ArisSessionService.expired = newExpired;
  }

  isExpired() {
    return ArisSessionService.expired;
  }
}
