import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { ArisNotificationBoxService } from '../ui-page-sections/error-module/services/aris-notification-box.service';

import 'rxjs/add/operator/toPromise';


@Injectable()
export class ArisSmsService {

  constructor(private http: HttpClient,
              private arisNotificationBox: ArisNotificationBoxService) {
  }

  /*
    * Send a Plain Text Sms
    *  @param data
    *     - smsTo : destination sms
    *     - smsMessage : sms content message
    *  returns
    */
  sendPlainTextSms(smsTo: string, smsMessage: string) {
    this.http.get('rest/sms/plaintext/' + encodeURIComponent(smsTo) + '/' + encodeURIComponent(smsMessage))
    .toPromise().then((data) => {
      const successMessage = { status: '200', title: 'CLI_MSG_TIT_OPERATION_SUCCESS', message: 'CLI_MSG_DESC_OPERATION_SUCCESS' };
      this.arisNotificationBox.showNotification(successMessage, 'right', 'success');
    }, (err) => {
      this.arisNotificationBox.showNotification(err, 'right', 'error');
    });
  }
}