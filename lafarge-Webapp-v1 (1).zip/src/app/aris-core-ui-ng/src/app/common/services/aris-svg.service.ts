import { Injectable, Inject} from '@angular/core';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class ArisSvgService {

  closeOpenDialog: any = new Subject();
}
