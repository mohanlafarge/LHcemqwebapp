import { ArisThemeService } from './aris-theme.service';

describe('ArisThemeService', () => {
  let arisThemeService :  ArisThemeService;

  beforeEach(() => {    
    arisThemeService = new ArisThemeService();
  });

  afterEach(() => {
    arisThemeService = null;
  });

  it('Test service should be created.', () => {
    expect(arisThemeService).toBeTruthy();
  });

  it('Test changeTheme should set blank className if classList is not assiciated with body element.', () => {
    arisThemeService.changeTheme('orange');
    expect(document.getElementsByTagName('body')[0].className).toEqual("");
  });

  it('Test changeTheme should not change className if existing classlist doesnot have o-arisTheme class.', () => {
    document.getElementsByTagName('body')[0].classList.add("o-arisBackground");
    arisThemeService.changeTheme('orange');
    expect(document.getElementsByTagName('body')[0].className).toEqual(" o-arisBackground");
  });

  it('Test changeTheme should change className according to theme selected if existing classlist has arisTheme class.', () => {
    document.getElementsByTagName('body')[0].classList.add("o-arisThemeBlue");
    arisThemeService.changeTheme('orange');
    expect(document.getElementsByTagName('body')[0].className).toBeDefined();
  });
});
