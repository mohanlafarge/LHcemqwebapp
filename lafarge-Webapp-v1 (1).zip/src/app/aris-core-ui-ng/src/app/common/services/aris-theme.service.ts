import { Injectable, Inject } from '@angular/core';
import { Subject } from 'rxjs';

declare var $: any;

@Injectable()
export class ArisThemeService {

  private static arisThemeConfig: any;
  public static themeChange: Subject<String> = new Subject<String>();
  constructor() {
    if (typeof(Storage) !== 'undefined') {
      if (localStorage.arisThemeConfig === undefined) {
        ArisThemeService.arisThemeConfig = window.app.config.application.theme;
        localStorage.setItem('arisThemeConfig', JSON.stringify(ArisThemeService.arisThemeConfig));
      } else {
        ArisThemeService.arisThemeConfig = window.app.config.application.theme;
        let defaultThemeData = JSON.parse(localStorage.arisThemeConfig);
        ArisThemeService.arisThemeConfig.defaultType = defaultThemeData.defaultType;
        ArisThemeService.arisThemeConfig.defaultColor = defaultThemeData.defaultColor;
      }
      this.changeTheme(ArisThemeService.arisThemeConfig);
    }
  }

  changeTheme(theme: any) {
    let bodyAux = $("body")[0];
    let finalClassList = '';
    let classlist = [];
    for (let i = 0; i < bodyAux.classList.length; i++) {
      classlist.push(bodyAux.classList[i]);
    }
    for (let element in classlist) {
      if (element !== 'length') {
        if (classlist[element].indexOf('o-arisTheme') !== -1) {
          finalClassList = finalClassList + ' ' + theme.defaultType + ' ' + theme.defaultColor;
        } else {
          finalClassList = finalClassList + ' ' + classlist[element];
        }
        localStorage.setItem('arisThemeConfig', JSON.stringify(theme));
      }
    }
    ArisThemeService.arisThemeConfig.defaultType = theme.defaultType;
    ArisThemeService.arisThemeConfig.defaultColor = theme.defaultColor;
    window.app.config.application.theme = ArisThemeService.arisThemeConfig;
    bodyAux.className = finalClassList;
  }

  getThemeConfig(): any {
    return ArisThemeService.arisThemeConfig;
  }
}
