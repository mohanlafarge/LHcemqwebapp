import { Injectable } from '@angular/core';

@Injectable()
export class ArisUserOperationService {
  private static instance: ArisUserOperationService = null;
  private static userOperation = true;

  // Return the instance of the service
  public static getInstance(): ArisUserOperationService {
    if (ArisUserOperationService.instance === null) {
      ArisUserOperationService.instance = new ArisUserOperationService();
    }
    return ArisUserOperationService.instance;
  }

  constructor() {}

  setUserOperation (newUserOperation) {
    ArisUserOperationService.userOperation = newUserOperation;
  }
  isUserOperation () {
    return ArisUserOperationService.userOperation;
  }


}

