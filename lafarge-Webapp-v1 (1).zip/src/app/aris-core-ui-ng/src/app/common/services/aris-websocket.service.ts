import { Injectable } from '@angular/core';
import {PlatformLocation } from '@angular/common';
import * as SockJS from 'sockjs-client';
import * as Stomp from 'stompjs';

import { ArisNotificationBoxService } from '../ui-page-sections/error-module/services/aris-notification-box.service';
import { ArisSessionService } from './aris-session.service';

@Injectable()
export class ArisWebSocketService {
  private static callbackList;
  private static stompClient;
  private static process;
  private static subscriptions = [];
  private serverUrl = '/ws';
  private headers = {};



  constructor(private platformLocation: PlatformLocation,
              private arisNotificationBoxService: ArisNotificationBoxService,
              private arisSessionService: ArisSessionService) {
  }

  connect(callback?, errorCallback?) {
    if (this.arisSessionService.isLoggedIn() && !this.arisSessionService.isExpired()) {
      ArisWebSocketService.process = "connecting";
      let token = this.arisSessionService.get_x_xsrf_Token();
      if (token === undefined || token === null || token === '') {
        this.reconnect(callback, errorCallback);
      } else {
        this.headers = { 'X-XSRF-TOKEN' : token };
        let finalWsUrl = ('/' + this.platformLocation.pathname + this.serverUrl).replace(/\/\//g, '/').replace(/\/\//g, '/');
        let ws = new SockJS(finalWsUrl);
        ArisWebSocketService.stompClient = Stomp.over(ws);
        ArisWebSocketService.stompClient.debug = () => {};

        ArisWebSocketService.stompClient.connect(this.headers,  (frame) => {

          switch (frame.command) {
            case "CONNECTED":
              console.log("Socket was open. Setting connected to true!");
              ArisWebSocketService.process = "";
              return typeof callback === "function" ? callback(frame) : void 0;
            case "ERROR":
              console.log("Error Message Received!");
              return typeof errorCallback === "function" ? errorCallback(frame) : void 0;
          }

        }, (error) => {
          let that = this;
          if (ArisWebSocketService.process === "connecting") {
            console.log("Error in Socket connection!!!");
            this.reconnect(callback, errorCallback);
          } else  if (ArisWebSocketService.process === "disconnecting") {
            console.log("Error in Socket disconnection!!!");
          } else {
            console.log("Error in Socket - " + ArisWebSocketService.process);
          }

          if ((error.headers !== undefined) &&
              (error.headers.message !== undefined) &&
              (error.headers.message.indexOf("Access is denied") !== -1)) {
            let resultMessage = {
              status: '403',
              title: 'CLI_ERR_TIT_ACCES_DENIED',
              message: 'CLI_ERR_DESC_USER_WITHOUT_ENOUGH_PERMISSION'
            };
            this.arisNotificationBoxService.showNotification(resultMessage, 'right', 'error');
          }

        });

        ArisWebSocketService.stompClient.onWebsocketClose = function () {
          console.log("Socket was closed!");
        };
      // });
      }
    }
  }

  private reconnect(callback?, errorCallback?) {
    if (this.arisSessionService.isLoggedIn() && !this.arisSessionService.isExpired()) {
      setTimeout(() => {
        this.connect(callback, errorCallback);
      } , 5000);
    }
  }

  disconnectAll() {
    ArisWebSocketService.process = "disconnecting all";
    if (ArisWebSocketService.stompClient) {
      for (let i = 0; i < ArisWebSocketService.stompClient.counter; i = i + 1) {
        try {
          if (ArisWebSocketService.stompClient.subscriptions !== null) {
            // ArisWebSocketService.stompClient.subscriptions['sub-' + i].unsubscribe();
            this.unsubscribe(ArisWebSocketService.subscriptions['sub-' + i]);
          }
        } catch (exception) {
          console.log("Error unsubscribing during disconnection!!!");
        }
      }
      this.disconnect();
    }
  }

  private disconnect() {
    ArisWebSocketService.process = "disconnecting";
    if (ArisWebSocketService.stompClient) {
      try {
        ArisWebSocketService.stompClient.disconnect();
      } catch (exception) {
        console.log("Error disconnecting Websocket!");
      }
    }
  }

  isConnected() {
    if (ArisWebSocketService.stompClient && ArisWebSocketService.stompClient.connected === true) {
      return true;
    }

    return false;
  }

  sendMessage(controllerEndPoint: String, headers: {}, message: any) {
    ArisWebSocketService.process = "sending message";
    if (ArisWebSocketService.stompClient) {
      ArisWebSocketService.stompClient.send(controllerEndPoint , headers, message);
    }
  }

  subscribe(topicEndPoint: String, callback: any, headers?) {
    ArisWebSocketService.process = "subscribing";
    if (ArisWebSocketService.stompClient) {
      console.log("Starting subscription");
      let aux = ArisWebSocketService.stompClient.subscribe(topicEndPoint, callback);
      aux.topicEndPoint = topicEndPoint;
      console.log("Subscription to topic '" + aux.topicEndPoint + "' executed succesfully");
      ArisWebSocketService.subscriptions[aux.id] = aux;
      return aux;
    }
  }

  unsubscribe(subscribeObject: any) {
    ArisWebSocketService.process = "unsubscribing";
    if (subscribeObject) {
      console.log("Starting unsubscription");
      subscribeObject.unsubscribe();
      delete ArisWebSocketService.subscriptions[subscribeObject.id];
      console.log("UnSubscription to process '" + subscribeObject.topicEndPoint + "' executed succesfully");
    }
  }
}
