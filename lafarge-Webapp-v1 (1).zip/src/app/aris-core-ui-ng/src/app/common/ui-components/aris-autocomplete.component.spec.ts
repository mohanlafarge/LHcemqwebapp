import { TestBed, ComponentFixture } from '@angular/core/testing';
import { DebugElement, ChangeDetectorRef } from '@angular/core';
import { HttpClientModule  } from '@angular/common/http';
import { ReactiveFormsModule, FormControl, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';

import { NgSelectModule } from '@ng-select/ng-select';

import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';

import { ArisI18nModule } from '../../translation/aris-i18n.module';
import { ArisAutoComplete } from './aris-autocomplete.component';
import { ArisFormComponentError } from './aris-form-component-error.component';
import { ArisFilterService } from '../services/aris-filter.service';

describe('Test: Aris Autocomplete Component', () => {

  let component: ArisAutoComplete;
  let fixture: ComponentFixture<ArisAutoComplete>;

  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [ArisAutoComplete, ArisFormComponentError],
      imports: [ReactiveFormsModule, HttpClientModule, NgSelectModule, CommonModule, ArisI18nModule, LocalizationModule],
      providers: [ArisFilterService, TranslationService, InjectorRef]
    }).compileComponents();

    // create component and test fixture
    fixture = TestBed.createComponent(ArisAutoComplete);

    // get test component from the fixture
    component = fixture.componentInstance;
    component.arisId = ArisAutoComplete.name;
    component.arisLabel = ArisAutoComplete.name + ' Label';
    component.arisData = [{ distColumn: 'Taste and Odour' }, { distColumn: 'Metering' }, { distColumn: 'Leakage' }];
    component.arisValue = 'Taste and Odour';
    component.arisDisplay = 'distColumn';
    component.arisHidden = false;
    component.arisDisabled = false;

    const formControl = new FormControl('', Validators.compose([
      Validators.required,
    ])
    );

    component.arisFormControl = formControl;

    component.ngOnInit();

    componentEl = fixture.debugElement.query(By.css('ng-select'));
    componentDiv = fixture.debugElement.query(By.css('.form-group'));
  });

  it('Component Id must be the expected one', () => {
    expect(componentEl.nativeElement.id).toBe('autocomplete_ArisAutoComplete');
  });


  it('Setting disabled to true, disables the component', () => {
    component.arisDisabled = true;
    fixture.detectChanges();
    expect(componentEl.nativeElement.classList.contains('disabled')).toBeTruthy();
  });

  it('Setting hidden to true, hides the component', () => {
    component.arisHidden = true;

    fixture.detectChanges();
    expect(componentDiv.nativeElement.hidden).toBeTruthy();
  });

  it('Setting value to undefined, component becomes invalid', () => {
    component.arisValue = '';

    fixture.detectChanges();

    expect(componentEl.nativeElement.classList.contains('ng-invalid')).toBeTruthy();
    expect(component.arisFormControl.hasError('required')).toBeTruthy();
  });


  it('Allow multiple values', () => {
    component.arisAllowMultipleValues = true;
    component.arisValue = ['Taste and Odour', 'Metering'];

    fixture.detectChanges();

    expect(componentEl.nativeElement.classList.contains('ng-multiple')).toBeTruthy();
  });

  it('test case to check if deleteSimulation method is working', () => {
    component.subscription = undefined;
    component.ngOnDestroy();
    expect(component).toBeTruthy();
  });
});
