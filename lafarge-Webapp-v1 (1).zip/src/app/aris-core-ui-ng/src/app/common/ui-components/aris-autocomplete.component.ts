import { Component, Input, Output, EventEmitter, OnInit, ChangeDetectorRef, OnDestroy, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { FormControl } from '@angular/forms';

import { ArisFormComponent } from './aris-form-component.component';
import { ArisFilterService } from '../services/aris-filter.service';
import { Language } from 'angular-l10n';


@Component({
  selector: 'aris-autocomplete',
  templateUrl: './aris-autocomplete.component.html',
})

export class ArisAutoComplete extends ArisFormComponent implements OnInit, OnDestroy, AfterViewInit {

  @Input() arisLabel: string;
  @Input() arisValue: any;
  @Input() arisData: any;
  @Input() arisDisplay: string;
  @Input() arisAllowMultipleValues: boolean;
  subscription: any;

  @Output() onChangeValue: EventEmitter<any> = new EventEmitter<any>();

  model: any;
  @ViewChild('arisAutoComplete') private arisAutoComplete: ElementRef;

  @Language() lang: string;
  constructor(private cdRef: ChangeDetectorRef,
    private arisFilterService: ArisFilterService) {
    super();
    this.subscription = this.arisFilterService.getClearAutoCompleteSubject().subscribe(
      (data) => {
        this.model = [];
      }
    );
  }

  ngOnInit(): void {
    this.createArisFormControl();
    this.model = this.arisValue;
    this.cdRef.detectChanges();
  }

  componentValueChanged(value: any) {
    this.onChangeValue.emit(value);
  }

  ngAfterViewInit() {
    $(this.arisAutoComplete.nativeElement.querySelector('ng-select')).css("z-index", "");
  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
