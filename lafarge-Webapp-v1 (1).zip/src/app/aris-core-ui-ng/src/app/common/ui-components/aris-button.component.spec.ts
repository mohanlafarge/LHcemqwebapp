import { TestBed, ComponentFixture } from '@angular/core/testing';
import { DebugElement, ChangeDetectorRef } from '@angular/core';
import { HttpClientModule  } from '@angular/common/http';
import { ReactiveFormsModule, FormControl, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';

import { NgSelectModule } from '@ng-select/ng-select';

import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';

import { ArisI18nModule } from '../../translation/aris-i18n.module';
import { ArisAutoComplete } from './aris-autocomplete.component';
import { ArisFormComponentError } from './aris-form-component-error.component';
import { ArisFilterService } from '../services/aris-filter.service';
import { ArisButtonComponent } from './aris-button.component';
import { ArisCorneredComponent } from './aris-cornered-module/aris-cornered.component';




describe('Test: ArisButtonComponent', () => {

  let component: ArisButtonComponent;
  let fixture: ComponentFixture<ArisButtonComponent>;


  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [ArisButtonComponent, ArisFormComponentError, ArisCorneredComponent],
      imports: [ReactiveFormsModule, HttpClientModule, NgSelectModule, CommonModule, ArisI18nModule, LocalizationModule],
      providers: [ArisFilterService, TranslationService, InjectorRef]
    }).compileComponents();

    // create component and test fixture
    fixture = TestBed.createComponent(ArisButtonComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    const formControl = new FormControl('', Validators.compose([
      Validators.required,
    ])
    );

    component.ngOnInit();

  });


  it('onClick if executed', () => {
    component.disabled = 'val';

    component.onClick();

    expect(component).toBeDefined();
  });

  it('onClick else executed', () => {
    component.disabled = undefined;

    component.onClick();

    expect(component).toBeDefined();
  });

//   it('ngAfterViewInit else executed', () => {
//     component.disabled = undefined;

//     component.ngAfterViewInit();

//     expect(component).toBeDefined();
//   });


});
