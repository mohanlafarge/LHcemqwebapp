import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ViewChild,
  ElementRef,
  AfterViewInit,
} from '@angular/core';
import { Language } from "angular-l10n";


@Component({
  selector: "aris-button",
  templateUrl: "./aris-button.component.html"
})
export class ArisButtonComponent implements OnInit, AfterViewInit {

  @Language()
  lang: string;

  @Input()
  public enableCorner = true;
  @Input()
  public id = "id";
  @Output()
  public click: any;
  @Input()
  public type = "button";
  @Input()
  public disabled;
  @Input()
  public arisClass = "";
  @Input()
  public btnwidth = "";
  @ViewChild('buttonContainerwidth') buttonContainerwidth: ElementRef;

  constructor() { this.click = new EventEmitter<void>(); }

  ngOnInit() {
    this.click = new EventEmitter<void>();
  }

  ngAfterViewInit() {
    if(this.buttonContainerwidth.nativeElement.querySelectorAll('.btn')[0] !== undefined && this.btnwidth !== "") {
      this.buttonContainerwidth.nativeElement.querySelectorAll('.btn')[0].style.width = this.buttonContainerwidth.nativeElement.offsetWidth - 39 +'px';
    }
  }

  public onClick(): void {
    if (this.disabled !== undefined) {
      this.click.emit();
    }
  }
}
