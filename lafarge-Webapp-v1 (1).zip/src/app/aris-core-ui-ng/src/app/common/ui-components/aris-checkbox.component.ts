import { Component, Input, Output, OnInit, ChangeDetectorRef, EventEmitter, OnChanges } from '@angular/core';
import { ArisFormComponent } from './aris-form-component.component';
import { TranslationService, Language } from 'angular-l10n';
import { modelGroupProvider } from '@angular/forms/src/directives/ng_model_group';

@Component({
  selector: 'aris-checkbox',
  templateUrl: './aris-checkbox.component.html',
})
export class ArisCheckbox extends ArisFormComponent implements OnInit, OnChanges {

  @Input() arisLabel: string;
  @Input() arisValue: string;
  @Input() arisInputType: string;
  @Output() onChangeValue: EventEmitter<string> = new EventEmitter<string>();

  model: string;

  constructor(private cdRef: ChangeDetectorRef) {
    super();
  }

  ngOnInit(): void {
    if (!this.arisInputType) {
      this.arisInputType = 'checkbox';
    }
    this.createArisFormControl();
    this.model = this.arisValue;
    this.cdRef.detectChanges();
  }

  componentValueChanged(event) {
    if (event.currentTarget && event.currentTarget.checked) {
      this.model = "true";
    } else {
      this.model = "false";
    }
    this.onChangeValue.emit(this.model);
  }

  ngOnChanges(changes: any) {
    if (changes.arisValue !== undefined) {
      this.model =  changes.arisValue && changes.arisValue.currentValue ? changes.arisValue.currentValue : undefined;
    } else {
      this.applyChangesOnMask(changes);
    }
  }
}
