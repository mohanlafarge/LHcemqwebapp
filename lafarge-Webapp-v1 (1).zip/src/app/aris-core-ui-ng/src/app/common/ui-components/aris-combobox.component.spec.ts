import { TestBed, ComponentFixture } from '@angular/core/testing';
import { DebugElement } from '@angular/core';

import { ArisCombobox } from './aris-combobox.component';
import { ArisFormComponentError } from './aris-form-component-error.component';

import { ReactiveFormsModule, FormControl, Validators } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import { TranslationService } from 'angular-l10n';

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};
describe('Test: Aris Combobox Component', () => {

  let component: ArisCombobox;
  let fixture: ComponentFixture<ArisCombobox>;

  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [ArisCombobox, ArisFormComponentError],
      providers: [{ provide: TranslationService, useValue: mockTranslationService }],
      imports: [ReactiveFormsModule]
    });

    // create component and test fixture
    fixture = TestBed.createComponent(ArisCombobox);

    // get test component from the fixture
    component = fixture.componentInstance;
    component.arisId = ArisCombobox.name;
    component.arisLabel = ArisCombobox.name + ' Label';
    component.arisOption = 'Option1';
    component.arisOptionList = ['Option1', 'Option2', 'Option3'];
    component.arisHidden = false;
    component.arisDisabled = false;

    const formControl = new FormControl('', Validators.compose([
      Validators.required,
    ])
    );

    component.arisFormControl = formControl;

    component.ngOnInit();

    componentEl = fixture.debugElement.query(By.css('button'));
    componentDiv = fixture.debugElement.query(By.css('.form-group'));
  });

  it('Component Id must be the expected one', () => {
    fixture.detectChanges();
    expect(componentEl.nativeElement.id).toBe('select_ArisCombobox');
  });

  it('Setting disabled to true, disables the component', () => {
    component.arisDisabled = true;

    fixture.detectChanges();
    expect(componentEl.nativeElement.disabled).toBeTruthy();
  });

  it('Setting hidden to true, hides the component', () => {
    component.arisHidden = true;

    fixture.detectChanges();
    expect(componentDiv.nativeElement.hidden).toBeTruthy();
  });

  it('Setting value to undefined, component becomes invalid', () => {
    component.arisOption = '';

    fixture.detectChanges();

    expect(componentEl.nativeElement.classList.contains('ng-invalid')).toBeFalsy();
    expect(component.arisFormControl.hasError('required')).toBeTruthy();
  });

  it('ngOnChanges if executed', () => {
    let changes = { arisOption: { currentValue: 'val' } };
    component.ngOnChanges(changes);
    expect(component).toBeTruthy();
  });

  it('ngOnChanges arisOption is undefined executed', () => {
    let changes = { arisOption: {  } };
    component.ngOnChanges(changes);
    expect(component).toBeTruthy();
  });

  it('ngOnChanges else executed', () => {
    let changes = { arisOption: undefined };
    component.ngOnChanges(changes);
    expect(component).toBeTruthy();
  });

});
