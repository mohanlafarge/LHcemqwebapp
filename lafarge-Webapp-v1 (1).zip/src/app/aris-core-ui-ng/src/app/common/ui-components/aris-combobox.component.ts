import { Component, Input, Output, OnInit, EventEmitter, OnChanges } from '@angular/core';

import { ArisFormComponent } from './aris-form-component.component';
import { ArisFormComponentError } from './aris-form-component-error.component';

import { ISubscription } from 'rxjs/Subscription';

@Component({
  selector: 'aris-combobox',
  templateUrl: './aris-combobox.component.html',
})

export class ArisCombobox extends ArisFormComponent implements OnInit, OnChanges {
  subscription: ISubscription;

  @Input() arisLabel: string;
  @Input() arisOption: string;
  @Input() arisOptionList: string[];

  @Output() onChangeValue: EventEmitter<string> = new EventEmitter<string>();

  constructor() {
    super();
  }

  ngOnInit(): void {
    this.createArisFormControl();
  }

  setOption(newOption) {
    this.arisOption = newOption.target.textContent;
    this.onChangeValue.emit(newOption.target.textContent);
  }

  ngOnChanges(changes: any) {
    if (changes.arisOption && changes.arisOption.currentValue) {
      this.arisOption = changes.arisOption.currentValue;
    }
  }
}
