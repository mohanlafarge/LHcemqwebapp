import { TestBed, ComponentFixture } from '@angular/core/testing';
import { DebugElement, ChangeDetectorRef } from '@angular/core';
import { HttpClientModule  } from '@angular/common/http';
import { ReactiveFormsModule, FormControl, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';

import { NgSelectModule } from '@ng-select/ng-select';

import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisI18nModule } from '../../../translation/aris-i18n.module';
import { ArisCorneredComponent } from './aris-cornered.component';



describe('Test: ArisCorneredComponent', () => {

  let component: ArisCorneredComponent;
  let fixture: ComponentFixture<ArisCorneredComponent>;

  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [ArisCorneredComponent],
      imports: [ReactiveFormsModule, HttpClientModule, NgSelectModule, CommonModule, ArisI18nModule, LocalizationModule],
      providers: [TranslationService, InjectorRef]
    }).compileComponents();

    // create component and test fixture
    fixture = TestBed.createComponent(ArisCorneredComponent);

    // get test component from the fixture
    component = fixture.componentInstance;
  });

  it('Component to be defined', () => {
    expect(component).toBeDefined();
  });

});
