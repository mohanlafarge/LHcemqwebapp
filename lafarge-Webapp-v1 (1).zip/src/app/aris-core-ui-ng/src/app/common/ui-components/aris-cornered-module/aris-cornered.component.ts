import { Component, Input, OnInit } from "@angular/core";
import { Language } from "angular-l10n";

@Component({
  selector: 'aris-cornered',
  templateUrl: './aris-cornered.component.html'
})
export class ArisCorneredComponent {

  @Language()
  lang: string;
  @Input()
  public cornered = false;
  @Input()
  public disabled = false;

  constructor() {
  }

}
