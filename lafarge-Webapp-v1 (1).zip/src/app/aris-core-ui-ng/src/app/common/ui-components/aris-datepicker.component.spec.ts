import { TestBed, ComponentFixture } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { HttpClientModule  } from '@angular/common/http';

import { ArisDatepicker } from './aris-datepicker.component';
import { ArisFormComponentError } from './aris-form-component-error.component';

import { ReactiveFormsModule, FormControl, Validators } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { ArisConfigService } from '../services/aris-config.service';
import { ArisLanguageService } from '../ui-page-sections/language-selector-module/services/aris-language.service';

import { DatePipe } from '@angular/common';
import { ArisPipesModule } from '../pipes/aris-pipes.module';
import { TranslationService } from 'angular-l10n';
import { Observable } from 'rxjs/Observable';

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};
describe('Test: Aris DatePicker Component', () => {

  let component: ArisDatepicker;
  let fixture: ComponentFixture<ArisDatepicker>;

  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [ArisDatepicker, ArisFormComponentError],
      imports: [ReactiveFormsModule, HttpClientModule, BsDatepickerModule.forRoot(), ArisPipesModule],
      providers: [ArisConfigService, ArisLanguageService, DatePipe, { provide: TranslationService, useValue: mockTranslationService } ]
    });

    // create component and test fixture
    fixture = TestBed.createComponent(ArisDatepicker);

    // get test component from the fixture
    component = fixture.componentInstance;
    component.arisId = ArisDatepicker.name;
    component.arisLabel = ArisDatepicker.name + ' Label';
    component.arisValue = '';
    component.arisHidden = false;
    component.arisDisabled = false;

    const formControl = new FormControl('', Validators.compose([
      Validators.required,
    ])
    );
    component.arisFormControl = formControl;
    componentEl = fixture.debugElement.query(By.css('.form-control'));
    componentDiv = fixture.debugElement.query(By.css('.form-group'));
  });

  it('Component Id must be the expected one', () => {
    component.ngOnInit();
    fixture.detectChanges();
    expect(componentEl.nativeElement.id).toBe('datepicker_ArisDatepicker');
  });

  it('Setting disabled to true, disables the component', () => {
    component.ngOnInit();
    component.arisDisabled = true;

    fixture.detectChanges();
    expect(componentEl.nativeElement.disabled).toBeTruthy();

  });

  it('Setting hidden to true, hides the component', () => {
    component.ngOnInit();
    component.arisHidden = true;

    fixture.detectChanges();
    expect(componentDiv.nativeElement.hidden).toBeTruthy();
  });

  it('Setting value to undefined, component becomes invalid', () => {
    component.ngOnInit();
    component.arisValue = undefined;

    fixture.detectChanges();

    expect(componentEl.nativeElement.classList.contains('ng-invalid')).toBeTruthy();
    expect(component.arisFormControl.hasError('required')).toBeTruthy();
  });

  it('ngOnInit if scenario execution', () => {
    component.arisValue = '06/12/2016';
    component.ngOnInit();
    expect(component.bsValue).toBeDefined('');
  });

  it('ngOnDestroy else execution', () => {
    component.configSubscription = undefined;
    component.ngOnDestroy();
    expect(component).toBeTruthy();
  });

});
