import { Component, Input, Output, OnInit, OnDestroy, ChangeDetectorRef, EventEmitter } from '@angular/core';
import { BsDatepickerConfig } from 'ngx-bootstrap';
import { ArisFormComponent } from './aris-form-component.component';
import { ArisConfigService } from '../services/aris-config.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'aris-datepicker',
  templateUrl: './aris-datepicker.component.html'
})

export class ArisDatepicker extends ArisFormComponent implements OnInit, OnDestroy {

  @Input() arisLabel: string;
  @Input() arisValue: string;
  @Input() arisCss: string;
  @Input() arisCalenderPosition: string;
  @Output() onChangeValue: EventEmitter<string> = new EventEmitter<string>();

  configSubscription: any;

  bsValue: Date;
  bsConfig: Partial<BsDatepickerConfig>;

  constructor(private cdRef: ChangeDetectorRef, private arisConfigService: ArisConfigService, private datePipe: DatePipe) {
    super();
  }

  ngOnInit() {
    this.createArisFormControl();

    this.setLocale(this.arisConfigService.getLocale());
    this.configSubscription = this.arisConfigService.locale.subscribe(locale => this.setLocale(locale));

    if (this.arisValue) {
      this.bsValue = new Date(this.arisValue);
      this.cdRef.detectChanges();
    }
  }

  ngOnDestroy() {
    if (this.configSubscription) {
      this.configSubscription.unsubscribe();
    }
  }

  componentValueChanged(value: string) {
    this.onChangeValue.emit(value);
  }

  setLocale(locale: string) {
    this.bsConfig = Object.assign(
      {}, { containerClass: 'theme-' + window.app.config.application.theme + ' ' + this.arisCss, locale: locale.substring(0, 2)  }
    );
  }
}
