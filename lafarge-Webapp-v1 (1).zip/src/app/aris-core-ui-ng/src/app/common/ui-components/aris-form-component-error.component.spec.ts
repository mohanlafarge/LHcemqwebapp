import { TestBed, ComponentFixture } from '@angular/core/testing';
import { ArisFormComponentError } from './aris-form-component-error.component';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { ArisFormComponent } from './aris-form-component.component';
import { Observable } from 'rxjs/Observable';
import { TranslationService } from 'angular-l10n';

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};
describe('Test: Aris Form Component Error', () => {

  let component: ArisFormComponentError;
  let fixture: ComponentFixture<ArisFormComponentError>;
  let translation: TranslationService;

  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [ArisFormComponentError],
      providers: [{ provide: TranslationService, useValue: mockTranslationService }],
      imports: [ReactiveFormsModule]
    });

    // create component and test fixture
    fixture = TestBed.createComponent(ArisFormComponentError);
    translation = fixture.debugElement.injector.get(TranslationService);
    // get test component from the fixture
    component = fixture.componentInstance;
  });

  it('Component execution for minLength', () => {
    component.arisFormControl =  new FormControl('', []);
    component.arisFormControl.errors = { minlength: 1, requiredLength: 2 };
    component.arisFormControl.touched = true;
    component.errorMessage();
    expect(translation.translate).toHaveBeenCalled();
  });

  it('Component execution for maxLength', () => {
    component.arisFormControl =  new FormControl('', []);
    component.arisFormControl.errors = { maxlength: 1, requiredLength: 2 };
    component.arisFormControl.touched = true;
    component.errorMessage();
    expect(translation.translate).toHaveBeenCalled();
  });

  it('Component execution for pattern', () => {
    component.arisFormControl =  new FormControl('', []);
    component.arisFormControl.errors = { pattern: 1, requiredLength: 2 };
    component.arisFormControl.touched = true;
    component.errorMessage();
    expect(translation.translate).toHaveBeenCalled();
  });

  it('Component execution for required', () => {
    component.arisFormControl =  new FormControl('', []);
    component.arisFormControl.errors = { required: true };
    component.arisFormControl.touched = true;
    component.errorMessage();
    expect(translation.translate).toHaveBeenCalled();
  });

  it('hasError executed', () => {
    component.arisFormControl = new FormControl('', []);
    let result = component.hasError();
    expect(result).toEqual(false);
  });

  it('Component execution', () => {
    component.arisFormControl =  new FormControl('', []);
    let result = component.errorMessage();
    expect(result).toEqual('');
  });


});
