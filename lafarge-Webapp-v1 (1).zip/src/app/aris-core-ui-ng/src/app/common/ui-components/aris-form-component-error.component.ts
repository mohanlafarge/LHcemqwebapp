import { Component, Input } from '@angular/core';
import { TranslationService } from 'angular-l10n';

import { ArisFormComponent } from './aris-form-component.component';



@Component({
  selector: 'aris-form-component-error',
  templateUrl: './aris-form-component-error.component.html',
})
export class ArisFormComponentError extends ArisFormComponent {
  @Input() show: boolean = false;

  constructor(private translationService: TranslationService) {
    super();
  }

  hasError(): boolean {
    return this.isRequiredError() || this.isMinLengthError() || this.isMaxLengthError() || this.isPatternError() || this.show === true;
  }

  errorMessage(): string {
    if (this.isRequiredError()) {
      return this.translationService.translate('CLI_ERR_DESC_FIELD_REQUIRED');
      // return "(*) This field requires a value";
    }
    if (this.isMinLengthError()) {
      return this.translationService.translate('CLI_ERR_DESC_FIELD_WITH_WRONG_MIN_LENGTH') + this.arisFormControl.errors['minlength']['requiredLength'];
      // return "(*) Minimum length allowed is " + this.arisFormControl.errors['minlength']['requiredLength'];
    }
    if (this.isMaxLengthError()) {
      return this.translationService.translate('CLI_ERR_DESC_FIELD_WITH_WRONG_MAX_LENGTH') + this.arisFormControl.errors['maxlength']['requiredLength'];
      // return "(*) Maximum length allowed is " + this.arisFormControl.errors['maxlength']['requiredLength'];
    }
    if (this.isPatternError()) {
      return this.translationService.translate('CLI_ERR_DESC_FIELD_WITH_WRONG_PATTERN');
      // return "(*) Information with invalid character or incorrect format";
    }
    return '';
  }

  isMinLengthError(): boolean {
    if (this.arisFormControl &&
        this.arisFormControl.hasError('minlength') &&
        this.arisFormControl.touched
      ) {
      return true;
    }
    return false;
  }

  isMaxLengthError(): boolean {
    if (this.arisFormControl &&
        this.arisFormControl.hasError('maxlength') &&
        this.arisFormControl.touched
      ) {
      return true;
    }
    return false;
  }

  isRequiredError(): boolean {
    if (this.arisFormControl &&
        this.arisFormControl.hasError('required') &&
        this.arisFormControl.touched) {
      return true;
    }
    return false;
  }

  isPatternError(): boolean {
    if (this.arisFormControl &&
        this.arisFormControl.hasError('pattern') &&
        this.arisFormControl.touched
      ) {
      return true;
    }
    return false;
  }
}
