import { TestBed, ComponentFixture } from '@angular/core/testing';
import { ReactiveFormsModule, FormControl, FormBuilder } from '@angular/forms';
import { ArisFormComponent } from './aris-form-component.component';


describe('Test: Aris Form Component', () => {

  let component = new ArisFormComponent();
  const formBuilder: FormBuilder = new FormBuilder();

  it('Component execution for minLength', () => {
    component.arisFormControl =  new FormControl('', []);
    let result = component.isRequired();
    expect(result).toEqual(false);
  });

  it('Component execution for getArisId', () => {
    let result = component.getArisId();
    expect(result).toEqual('Id');
  });

  it('Component execution for setHidden', () => {
    component.setHidden(true);
    expect(component.arisHidden).toBeTruthy();
  });

  it('Component execution for isHidden', () => {
    let result = component.isHidden();
    expect(result).toBeTruthy();
  });

  it('Component execution for setDisabled', () => {
    component.setDisabled(true);
    expect(component.arisDisabled).toBeTruthy();
  });

  it('Component execution for isDisabled', () => {
    let result = component.isDisabled();
    expect(result).toBeTruthy();
  });

  it('Component execution for getRequiredLabelCss', () => {
    let result = component.getRequiredLabelCss();
    expect(result).toEqual('');
  });

  it('Component execution for createArisFormControl', () => {
    component.arisFormControl = undefined;
    component.arisMaxLength = 4;
    component.arisMinLength = 1;
    component.arisPattern = true;
    component.createArisFormControl();
    expect(component.arisName).toEqual('Name');
  });

  it('Component execution for createArisFormControl if else', () => {
    component.arisFormControl = undefined;
    component.arisMaxLength = undefined;
    component.arisMinLength = undefined;
    component.arisPattern = undefined;
    component.arisFormGroup = formBuilder.group({
      Name: ['Name'],
    });
    component.arisName = 'Name';
    component.arisId = 'Name';
    component.createArisFormControl();
    expect(component.arisName).toEqual('Name');
  });

  it('Component execution for createArisFormControl else', () => {
    component.arisFormControl = undefined;
    component.arisMaxLength = undefined;
    component.arisMinLength = undefined;
    component.arisPattern = undefined;
    component.arisFormGroup = formBuilder.group({
      val: ['val'],
    });
    component.arisName = 'Name';
    component.arisId = 'Id';
    component.createArisFormControl();
    expect(component.arisName).toEqual('Name');
  });

  it('Component execution for applyChangesOnMask arisRequired', () => {
    component.arisFormControl = undefined;
    component.arisMaxLength = undefined;
    component.arisMinLength = undefined;
    component.arisPattern = undefined;
    component.arisFormGroup = formBuilder.group({
      val: ['val'],
    });
    component.arisName = 'Name';
    component.arisId = 'Id';
    component.applyChangesOnMask({ arisRequired: { previousValue: 0, currentValue: 1, firstChange: true, isFirstChange() { return true; } } });
    expect(component).toBeDefined();
  });

  it('Component execution for applyChangesOnMask arisMinLength', () => {
    component.arisFormControl = undefined;
    component.arisMaxLength = undefined;
    component.arisMinLength = undefined;
    component.arisPattern = undefined;
    component.arisFormGroup = formBuilder.group({
      val: ['val'],
    });
    component.arisName = 'Name';
    component.arisId = 'Id';
    component.applyChangesOnMask({ arisMinLength: { previousValue: 0, currentValue: 1, firstChange: true, isFirstChange() { return true; } } });
    expect(component).toBeDefined();
  });

  it('Component execution for applyChangesOnMask arisMaxLength', () => {
    component.arisFormControl = undefined;
    component.arisMaxLength = undefined;
    component.arisMinLength = undefined;
    component.arisPattern = undefined;
    component.arisFormGroup = formBuilder.group({
      val: ['val'],
    });
    component.arisName = 'Name';
    component.arisId = 'Id';
    component.applyChangesOnMask({ arisMaxLength: { previousValue: 0, currentValue: 1, firstChange: true, isFirstChange() { return true; } } });
    expect(component).toBeDefined();
  });

  it('Component execution for applyChangesOnMask arisPattern', () => {
    component.arisFormControl = undefined;
    component.arisMaxLength = undefined;
    component.arisMinLength = undefined;
    component.arisPattern = undefined;
    component.arisFormGroup = formBuilder.group({
      val: ['val'],
    });
    component.arisName = 'Name';
    component.arisId = 'Id';
    component.applyChangesOnMask({ arisPattern: { previousValue: 0, currentValue: 1, firstChange: true, isFirstChange() { return true; } } });
    expect(component).toBeDefined();
  });

  it('Component execution for applyChangesOnMask else', () => {
    component.arisFormControl = undefined;
    component.arisMaxLength = undefined;
    component.arisMinLength = undefined;
    component.arisPattern = undefined;
    component.arisFormGroup = formBuilder.group({
      val: ['val'],
    });
    component.arisName = 'Name';
    component.arisId = 'Id';
    component.applyChangesOnMask({ max: { previousValue: 0, currentValue: 1, firstChange: true, isFirstChange() { return true; } } });
    expect(component).toBeDefined();
  });

//   it('Component execution for pattern', () => {
//     component.arisFormControl =  new FormControl('', []);
//     component.arisFormControl.errors = { pattern: 1, requiredLength: 2 };
//     component.arisFormControl.touched = true;
//     let result = component.errorMessage();
//     expect(result).toEqual('(*) Information with invalid character or incorrect format');
//   });

//   it('Component execution for required', () => {
//     component.arisFormControl =  new FormControl('', []);
//     component.arisFormControl.errors = { required: true };
//     component.arisFormControl.touched = true;
//     let result = component.errorMessage();
//     expect(result).toEqual('(*) This field requires a value');
//   });

//   it('hasError executed', () => {
//     component.arisFormControl = new FormControl('', []);
//     let result = component.hasError();
//     expect(result).toEqual(false);
//   });

//   it('Component execution', () => {
//     component.arisFormControl =  new FormControl('', []);
//     let result = component.errorMessage();
//     expect(result).toEqual('');
//   });


});
