import { Component, Input, Output, ChangeDetectorRef, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup, ValidatorFn, Validators, AbstractControl } from '@angular/forms';

export class ArisFormComponent implements OnChanges {

  @Input() arisId = 'Id';
  @Input() arisName = 'Name';
  @Input() arisHidden = false;
  @Input() arisDisabled = false;
  @Input() arisFormControl?: any;
  @Input() arisFormGroup?: any;

  @Input() arisRequired?: false;
  @Input() arisMinLength?: number;
  @Input() arisMaxLength?: number;
  @Input() arisPattern?: any;
  @Input() arisPlaceholder?: any;
  changesDone = false;

  constructor() { }

  createArisFormControl() {
    if (!this.arisFormControl || this.changesDone) {
      // this.arisFormControl = new FormControl('', { updateOn: 'blur' });
      this.arisFormControl = new FormControl('', []);
      let validators: ValidatorFn[] = [];
      if (this.arisRequired) {
        validators.push(Validators.required);
      }
      if (this.arisMaxLength !== undefined) {
        validators.push(Validators.maxLength(this.arisMaxLength));
      }
      if (this.arisMinLength !== undefined) {
        validators.push(Validators.minLength(this.arisMinLength));
      }
      if (this.arisPattern) {
        validators.push(Validators.pattern(this.arisPattern));
      }
      this.arisFormControl.setValidators(validators);
    }

    if (this.arisFormGroup) {
      if (this.arisName === 'Name' && this.arisId !== undefined && this.arisId !== 'Id') {
        this.arisName = this.arisId;
      }
      if (this.arisFormGroup.contains(this.arisName) === true) {
        this.arisFormGroup.removeControl(this.arisName);
      }
      this.arisFormGroup.registerControl(this.arisName, this.arisFormControl);
    }
  }

  getArisId(): string {
    return this.arisId;
  }

  setHidden(val: boolean) {
    this.arisHidden = val;
  }

  isHidden(): boolean {
    return this.arisHidden;
  }

  setDisabled(val: boolean) {
    this.arisDisabled = val;
  }

  isDisabled(): boolean {
    return this.arisDisabled;
  }

  getRequiredLabelCss(): String {
    if (this.isRequired()) {
      return 'control-label required';
    }
    return '';
  }

  isRequired(): boolean {
    if (this.arisFormControl &&
        this.arisFormControl.validator &&
        this.arisFormControl.validator('') &&
        this.arisFormControl.validator('').required) {
      return true;
    }
    return false;
  }

  ngOnChanges(changes: SimpleChanges) {
    this.applyChangesOnMask(changes);
  }

  applyChangesOnMask(changes: SimpleChanges) {
    if ((changes['arisRequired'] !== undefined && (changes['arisRequired'].currentValue !== changes['arisRequired'].previousValue)) ||
        (changes['arisMinLength'] !== undefined && (changes['arisMinLength'].currentValue !== changes['arisMinLength'].previousValue)) ||
        (changes['arisMaxLength'] !== undefined && (changes['arisMaxLength'].currentValue !== changes['arisMaxLength'].previousValue)) ||
        (changes['arisPattern'] !== undefined && (changes['arisPattern'].currentValue !== changes['arisPattern'].previousValue))) {
      console.log('Updated Mask for control: ' + this.arisName);
      this.changesDone = true;
      this.createArisFormControl();
    }
  }
}
