// import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
// import { DebugElement } from '@angular/core';
// import 'rxjs/add/observable/of';
// import { By } from '@angular/platform-browser';
// import { HttpClient, HttpHandler } from '@angular/common/http';
// import { CommonModule } from '@angular/common';
// import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
// import { ArisModule } from '../../../../aris.module';
// import { ArisAngularGenericTableComponent } from './aris-angular-generic-table.component';
// import { LocalizationModule, TranslationService } from 'angular-l10n';
// import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
// import { ArisUiComponentsModule } from '../../aris-ui-components.module';
// import { GenericTableComponent } from '@angular-generic-table/core';


// describe('Component: ArisAngularGenericTableComponent', () => {

//   let component: ArisAngularGenericTableComponent;
//   let fixture: ComponentFixture<ArisAngularGenericTableComponent>;
//   let infoCardElement: DebugElement;
//   let mockConfigObject: any;
//   let mockTableOptions: any;
//   let infoCardElement2: DebugElement;
//   let handler: HttpHandler;
//   let myTable: GenericTableComponent<any, any>;
//   const httpclient = new HttpClient(handler);
//   mockConfigObject = {
//     settings: [{
//       objectKey: 'assetAttributeValueId',
//       visible: true,
//       sort: 'asc',
//       columnOrder: 0,
//       enabled: true

//     }, {
//       objectKey: 'assetName',
//       visible: true,
//       sort: 'enable',
//       columnOrder: 1
//     }, {
//       objectKey: 'assetAttributeName',
//       visible: true,
//       enabled: true,
//       sort: 'enable',
//       sortOrder: 0,
//       columnOrder: 2
//     }
//     ],
//     fields:  [],
//     data: []
//   };

//   mockTableOptions = {
//     csvFileName: 'Asset Config Data',
//     rowsDropDown : true,
//     searchBox: true,
//     exportCsv: true,
//     visibleColumn: true,
//     showColumns: true
//   };

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       declarations: [],
//       schemas: [],
//       imports: [ArisPipesModule, LocalizationModule, ArisModule, ArisUiComponentsModule],
//       providers: [HttpClient, HttpHandler, TranslationService]
//     }).compileComponents();

//     // create component and test fixture
//     fixture = TestBed.createComponent(ArisAngularGenericTableComponent);
//     // get test component from the fixture
//     component = fixture.componentInstance;
//     component.tableConfigData = mockConfigObject;
//     component.tableOptions = mockTableOptions;
//   });

//   it('test : ArisAngularGenericTableComponent should be created', () => {
//     expect(component).toBeTruthy();
//   });

//   it('test : ArisAngularGenericTableComponent ngOninit method checking', () => {
//     spyOn(httpclient, 'post').and.callThrough();
//     component.ngOnInit();
//     expect(component.configObject.settings[0].objectKey).toBe("assetAttributeValueId");
//     expect(component.configObject.settings[2].sortOrder).toBe(0);
//   });

//   it('test : ngOnInit If Scenario working', () => {
//     component.tableOptions = { showNumberOfRows: 2 };
//     spyOn(httpclient, 'post').and.callThrough();
//     component.ngOnInit();
//     expect(component.configObject.settings[0].objectKey).toBe("assetAttributeValueId");
//     expect(component.configObject.settings[2].sortOrder).toBe(0);
//   });

//   it('test : ArisAngularGenericTableComponent getData method checking', () => {
//     spyOn(httpclient, 'get').and.callThrough();
//     component.getData();
//     expect(component.myTable.loading).toBe(true);
//   });

//   it('test : ArisAngularGenericTableComponent getData else scenario', () => {
//     let http = TestBed.get(HttpClient);
//     component.myTable = undefined;
//     component.tableConfigData = { endPointUrl: 'http://localhost:8080' };
//     spyOn(http, 'get').and.callThrough();
//     component.getData();
//     expect(http.get).toHaveBeenCalled();
//   });

//   it('test : ArisAngularGenericTableComponent myexportCsv method checking', () => {
//     component.myexportCsv();
//     expect(component.tableOptions.csvFileName).toBe('Asset Config Data');
//     expect(component.myTable.gtDefaultOptions.csvDelimiter).toBe(',');
//   });

//   it('test : ArisAngularGenericTableComponent myexportCsv method else working', () => {
//     component.tableOptions = { csvFileName: undefined };
//     component.myexportCsv();
//     expect(component.myTable.gtDefaultOptions.csvDelimiter).toBe(',');
//   });

//   it('test : ArisAngularGenericTableComponent trigger method working', () => {
//     let event = { value : { selectedRows: 2 } };
//     component.trigger(event);
//     expect(component.showColumnControls).toBe(false);
//   });
// });
