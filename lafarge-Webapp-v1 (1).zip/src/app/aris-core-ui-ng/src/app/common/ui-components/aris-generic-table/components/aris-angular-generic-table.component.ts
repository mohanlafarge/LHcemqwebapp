
import { Component, Output, EventEmitter, ViewChild, OnInit, Input, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { GenericTableComponent, GtConfig, GtRow, GtTexts } from '@angular-generic-table/core';
import 'rxjs/add/operator/map';
import { Subscription } from "rxjs/Subscription";
import { TranslationService, Language } from 'angular-l10n';
import { ArisLanguageService } from '../../../ui-page-sections/language-selector-module/services/aris-language.service';
import { ArisNotificationBoxService } from '../../../ui-page-sections/error-module/services/aris-notification-box.service';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'aris-angular-generic-table',
  templateUrl: './aris-angular-generic-table.component.html',
  styleUrls: ['../css/aris-angular-generic-table.component.css'],
  encapsulation: ViewEncapsulation.None,
})


export class ArisAngularGenericTableComponent implements OnInit {
  @Input() tableConfigData;
  @Input() tableOptions;
  @Input() tableData;
  @Language() lang: string;
  public configObject: GtConfig<any>;
  @Output() data = new EventEmitter();
  @ViewChild(GenericTableComponent)
  public myTable: GenericTableComponent<any, any>;
  public showColumnControls = false;
  public selectedRows = 0;
  public isButtondisabled = true;
  public gtOptions: any;
  public gtTexts: GtTexts;
  langChangeSubscription: Subscription;
  arisGenricTableForm: FormGroup;
  constructor(private http: HttpClient,
    private translationService: TranslationService,
    private arisLanguageService: ArisLanguageService,
    private arisNotificationBox: ArisNotificationBoxService,
    private cdr: ChangeDetectorRef,
    public fb: FormBuilder
  ) {
     /** subscription to language changes, used to update the column translation */
    this.langChangeSubscription = this.arisLanguageService.languageChange.subscribe((data) => {
      this.gtTexts.noData = this.translationService.translate('NG_NO_DATA');
      this.gtTexts.loading = this.translationService.translate('NG_LOADING');
    });

    this.arisGenricTableForm = fb.group({ });
  }

  public trigger = function ($event) {
    if ($event.value && $event.value.selectedRows) {
      this.selectedRows = $event.value.selectedRows.length;
    }
  };

  gtSearch(seacrhValue) {
    this.myTable.gtSearch(seacrhValue);
    this.cdr.detectChanges();
  }

  myexportCsv() {
    let filename: any;
    if (this.tableOptions.csvFileName) {
      filename = this.tableOptions.csvFileName;
    } else {
      filename = "download";
    }

    this.myTable.gtDefaultOptions.csvDelimiter = ',';
    this.myTable.exportCSV(filename);
  }

  ngOnInit() {  
    this.setTableConfigurations();      
    this.getData();   
    this.configObject = this.tableConfigData; 
    this.tableOptions.pagination = this.tableOptions.pagination !== undefined ? this.tableOptions.pagination : true;
    this.tableOptions.showNumberOfRows = this.gtOptions.numberOfRows = this.tableOptions.showNumberOfRows ? this.tableOptions.showNumberOfRows : window.app.config.application.defaultNumberOfRows;  
  }

  public redraw() {
    this.myTable.redraw();
  }
  public setTableConfigurations() {
    this.gtTexts = { noData: undefined, loading: undefined };
    this.gtTexts.noData = this.translationService.translate('NG_NO_DATA');
    this.gtTexts.loading = this.translationService.translate('NG_LOADING');
    this.gtOptions = { stack: true, highlightSearch: true, rowSelection: true };    
  }
 
  public getData = function () {
    if (this.myTable) {
      this.myTable.loading = true;
    }
    if (this.tableConfigData.endPointUrl) {
      this.http.get(this.tableConfigData.endPointUrl).toPromise().then((data: any) => {
        this.configObject.data = data; 
      });
    }
  };

  getOptionList() {
    return [10, 20, 50, 100, this.translationService.translate('NG_ALL')];
  }
}
