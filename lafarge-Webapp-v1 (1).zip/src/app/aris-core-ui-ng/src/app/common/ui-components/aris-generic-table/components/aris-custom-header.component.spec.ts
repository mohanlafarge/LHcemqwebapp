import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import 'rxjs/add/observable/of';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
import { ArisModule } from '../../../../aris.module';
import { LocalizationModule, TranslationService } from 'angular-l10n';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { ArisUiComponentsModule } from '../../aris-ui-components.module';
import { ArisCustomHeaderComponent } from './aris-custom-header.component';


describe('Component: ArisCustomHeaderComponent', () => {

  let component: ArisCustomHeaderComponent;
  let fixture: ComponentFixture<ArisCustomHeaderComponent>;
  let infoCardElement: DebugElement;
  let mockConfigObject: any;
  let mockTableOptions: any;
  let infoCardElement2: DebugElement;
  let handler: HttpHandler;
  const httpclient = new HttpClient(handler);
  let mockdata = "headerTitle_subTitle";

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      schemas: [],
      imports: [ArisPipesModule, LocalizationModule, ArisModule, ArisUiComponentsModule],
      providers: [HttpClient, HttpHandler, TranslationService]
    }).compileComponents();
    fixture = TestBed.createComponent(ArisCustomHeaderComponent);
    // get test component from the fixture
    component = fixture.componentInstance;
    component.column = mockdata;
  });

  it('test : ArisCustomHeaderComponent should be created', () => {
    expect(component).toBeTruthy();
  });

  it('test : ArisCustomHeaderComponent ngOninit method checking', () => {
    component.ngOnInit();
    expect(component.header).toBe("headerTitle");
    expect(component.subHeader).toBe("subTitle");
  });
});
