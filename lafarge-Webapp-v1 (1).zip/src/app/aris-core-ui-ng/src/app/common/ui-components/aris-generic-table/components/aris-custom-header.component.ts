import { Component, OnInit, Input } from '@angular/core';
import { GtCustomComponent } from '@angular-generic-table/core';


@Component({
  selector: 'aris-custom-header',
  template: '<span>{{header}}</span><br><span style="font-size: 14px;">{{subHeader}}</span>',
})
export class ArisCustomHeaderComponent extends GtCustomComponent<any> implements OnInit {
  @Input() column: any;
  public header: any;
  public subHeader: any;

  ngOnInit () {
    let temp = (this.column).split('_');
    this.header = temp[0];
    this.subHeader = temp[1];

    console.log(this.column);
  }
}
