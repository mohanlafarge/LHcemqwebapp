import { Component, Input, Output, OnInit, ChangeDetectorRef, EventEmitter, OnChanges } from '@angular/core';
import { ArisFormComponent } from './aris-form-component.component';
import { TranslationService, Language } from 'angular-l10n';

@Component({
  selector: 'aris-input',
  templateUrl: './aris-input.component.html',
})
export class ArisInput extends ArisFormComponent implements OnInit, OnChanges {

  @Input() arisLabel: string;
  @Input() arisValue: string;
  @Input() arisInputType: string;
  @Output() onChangeValue: EventEmitter<string> = new EventEmitter<string>();

  model: string;

  constructor(private cdRef: ChangeDetectorRef) {
    super();
  }

  ngOnInit(): void {
    if (!this.arisInputType) {
      this.arisInputType = 'text';
    }
    this.createArisFormControl();
    this.model = this.arisValue;
    this.cdRef.detectChanges();
  }

  componentValueChanged(value: string) {
    this.onChangeValue.emit(value);
  }

  ngOnChanges(changes: any) {
    if (changes.arisValue !== undefined) {
      this.model =  changes.arisValue && changes.arisValue.currentValue ? changes.arisValue.currentValue : undefined;
    } else {
      this.applyChangesOnMask(changes);
    }
  }
}
