import { CommonModule, DatePipe, DecimalPipe } from '@angular/common';
import { NgModule, Injector } from '@angular/core';
import { LocalizationModule } from 'angular-l10n';
import { ArisLoadingComponent } from './component/aris-loading.component';

@NgModule({
  declarations: [    
    ArisLoadingComponent
  ],
  imports: [
    CommonModule,
    LocalizationModule
  ],
  providers: [],
  exports: [ArisLoadingComponent],
  entryComponents: [ArisLoadingComponent]
})
export class ArisLoadingModule {
}

