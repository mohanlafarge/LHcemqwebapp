import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'aris-loading',
  template: `<i class="fa fa-spinner fa-spin fa-3x"></i>`
})
export class ArisLoadingComponent {
  constructor() {}
}
