import { Component, Input, OnInit, Output, EventEmitter, OnDestroy } from '@angular/core';
import { TranslationService, Language } from 'angular-l10n';
import { ArisImagePipe } from '../pipes/aris-image.pipes';
declare var $: any;

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'aris-map-layer',
  templateUrl: './aris-map-layer.component.html',
  providers: [ArisImagePipe]
})
export class ArisMapLayerComponent implements OnInit, OnDestroy {
  @Output() onMapLayerClicked: EventEmitter<any> = new EventEmitter<any>();
  @Output() onShowFilterByLayer: EventEmitter<any> = new EventEmitter<any>();
  public mapLayerArray: any;
  public showMapLayer: any = false;
  @Language() lang: string;
  public geo_config: any = window.app.config.geo;
  @Input() dataArray: any;

  constructor(private translationService: TranslationService) {
  }
  ngOnInit() {
    this.mapLayerArray = this.dataArray;
  }

  ngOnDestroy() {
  }

  /**
   *   Handle click on map layer.
   */
  onMapLayerClick ($event) {
    let currentmapLayer: any;
    for (let i = 0; i < this.mapLayerArray.length; i += 1) {
      if (this.mapLayerArray[i].id === $event.target.id) {
        currentmapLayer = this.mapLayerArray[i];
      }
    }
    if (currentmapLayer && ($('#' + currentmapLayer.id).prop('checked') === false)) {
      if ($('span a.close')[0] !== undefined) {
        $('span a.close')[0].click();
      }
    }
    let data = { mapLayer:  currentmapLayer  , isChecked: $event.target.checked };
    this.onMapLayerClicked.emit(data);
  }
  /**
   *Handle click on filter icon.
   */
  onFilterClick (layerId) {
    let currentmapLayer: any;
    for (let i = 0; i < this.mapLayerArray.length; i += 1) {
      if (this.mapLayerArray[i].id === layerId) {
        currentmapLayer = this.mapLayerArray[i];
      }
    }

    if ($('#' + layerId).prop('checked') === false) {
      $('#' + layerId).trigger('click');
    }
    this.onShowFilterByLayer.emit(currentmapLayer);
  }
}
