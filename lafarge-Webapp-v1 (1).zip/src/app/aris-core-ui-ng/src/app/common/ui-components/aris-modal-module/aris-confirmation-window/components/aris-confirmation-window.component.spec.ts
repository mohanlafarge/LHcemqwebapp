// import { TestBed, ComponentFixture } from '@angular/core/testing';
// import { BsModalService, BsModalRef } from 'ngx-bootstrap';
// import { TranslationService, LocaleService, LocalizationModule, InjectorRef } from 'angular-l10n';
// import { RouterModule } from '@angular/router';
// import { CommonModule } from '@angular/common';
// import { HttpClientTestingModule } from '@angular/common/http/testing';
// import { HttpClientModule } from '@angular/common/http';
// import { ArisDynamicPageModule } from '../../../../ui-page-models/aris-dynamic-page-module/aris-dynamic-page.module';
// import { FilterModule } from '../../../../ui-page-sections/filter-panel-module/aris-filter.module';
// import { ArisConfirmationWindowComponent } from './aris-confirmation-window.component';

// export class MockTranslationService {
//   translate() {}
// }

// describe('Test: ArisConfirmationWindowComponent', () => {

//   let component: ArisConfirmationWindowComponent;
//   let fixture: ComponentFixture<ArisConfirmationWindowComponent>;
//   let modalRef = new BsModalRef();

//   beforeEach(() => {

//     TestBed.configureTestingModule({
//       declarations: [],
//       imports: [RouterModule,
//         LocalizationModule,
//         CommonModule,
//         ArisDynamicPageModule,
//         FilterModule,
//         HttpClientModule,
//         HttpClientTestingModule],
//       providers: [InjectorRef, BsModalService,
//          { provide: TranslationService, useClass: MockTranslationService }, { provide: LocaleService }]
//     });

//     // create component and test fixture
//     fixture = TestBed.createComponent(ArisConfirmationWindowComponent);

//     // get test component from the fixture
//     component = fixture.componentInstance;
//     component.modalRef = modalRef;

//   });

//   it('Component execution for confirm', () => {
//     component.okText = "SAVE";
//     component.cancelText = "FOOTER_CANCEL";
//     component.confirmationText = "confirm";
//     component.headerText = "header";
//     component.changeTemplate = "changeTemplate";
//     component.ngAfterViewInit();
//     component.confirm();
//     expect(component).toBeTruthy();
//   });

//   it('Component execution for decline', () => {
//     component.ngAfterViewInit();
//     spyOn(component, 'decline').and.callThrough();
//     component.decline();
//     expect(component.decline).toHaveBeenCalled();
//   });

// });
