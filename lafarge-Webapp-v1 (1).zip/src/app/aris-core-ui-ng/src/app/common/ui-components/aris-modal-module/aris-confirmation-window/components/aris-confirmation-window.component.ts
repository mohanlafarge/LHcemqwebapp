import { Component, Input, Output, EventEmitter, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';
import { Language, TranslationService, LocaleService } from 'angular-l10n';
import { ArisSvgService } from '../../../../services/aris-svg.service';

@Component({
  selector: 'aris-confirmation-window',
  templateUrl: './aris-confirmation-window.component.html'
})
export class ArisConfirmationWindowComponent implements AfterViewInit {

  @Language() lang: string;
  // Header Section
  @Input() headerText: string;
  headerMessage: string;
  @Output() cancelPopUp: EventEmitter<any> = new EventEmitter<any>();
  // Body Section
  @Input() okText: string;
  @Output() okSelected: EventEmitter<any> = new EventEmitter<any>();
  okMessage: string;

  @Input() cancelText: string;
  @Output() cancelSelected: EventEmitter<any> = new EventEmitter();
  cancelMessage: string;

  @Input() confirmationText: string;
  confirmationMessage: string;
  // for Popup to load
  modalRef: BsModalRef;

  @Input() changeTemplate: any;
  @ViewChild('template') aboutTemplate: ElementRef;

  subscription: any;
  // Required for the popup screen click disable outside popup
  config = {
    animated: true,
    keyboard: true,
    backdrop: true,
    ignoreBackdropClick: true
  };

  constructor(private modalService: BsModalService, private translationService: TranslationService, private localeService: LocaleService,
    private arisSvgService: ArisSvgService) {
    this.subscription = arisSvgService.closeOpenDialog.subscribe((data) => {
      this.decline();
    });
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.okMessage = this.okText ? this.translationService.translate(this.okText) : this.translationService.translate('SAVE');
      this.cancelMessage = this.cancelText ? this.translationService.translate(this.cancelText) : this.translationService.translate('FOOTER_CANCEL');
      this.confirmationMessage = this.confirmationText ? this.translationService.translate(this.confirmationText) : "";
      this.headerMessage = this.headerText ? this.translationService.translate(this.headerText) : "";
      this.modalRef = this.modalService.show(this.changeTemplate ? this.changeTemplate :  this.aboutTemplate, this.config);
    }, 0);
  }

  confirm(): void {
    this.modalRef.hide();
    this.okSelected.emit(null);
  }

  decline(): void {
    this.cancelSelected.emit(null);
    this.modalRef.hide();
  }
}
