import { TestBed, ComponentFixture } from '@angular/core/testing';
import { DebugElement, ChangeDetectorRef } from '@angular/core';
import { HttpClientModule  } from '@angular/common/http';
import { ReactiveFormsModule, FormControl, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';

import { NgSelectModule } from '@ng-select/ng-select';

import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisModalBodyComponent } from './aris-modal-body.component';
import { ArisI18nModule } from '../../../../../translation/aris-i18n.module';
import { Observable } from 'rxjs';
import { ArisLanguageService } from '../../../../ui-page-sections/language-selector-module/services/aris-language.service';

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};

describe('Test: ArisModalBodyComponent', () => {

  let component: ArisModalBodyComponent;
  let fixture: ComponentFixture<ArisModalBodyComponent>;

  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [ArisModalBodyComponent],
      imports: [ReactiveFormsModule, HttpClientModule, NgSelectModule, CommonModule, ArisI18nModule, LocalizationModule],
      providers: [ArisLanguageService, { provide: TranslationService, useValue: mockTranslationService }, InjectorRef]
    }).compileComponents();

    // create component and test fixture
    fixture = TestBed.createComponent(ArisModalBodyComponent);

    // get test component from the fixture
    component = fixture.componentInstance;
    component.lang = 'en-gb';
  });

  afterEach(() => {
    fixture = null;
    component = null;
  });

  it('Component to be defined', () => {
    expect(component).toBeDefined();
  });

});
