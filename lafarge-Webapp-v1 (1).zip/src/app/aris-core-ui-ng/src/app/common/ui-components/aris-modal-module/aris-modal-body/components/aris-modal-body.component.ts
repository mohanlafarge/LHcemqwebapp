import { Component } from '@angular/core';
import { Language } from 'angular-l10n';

@Component({
  selector: 'aris-modal-body',
  templateUrl: './aris-modal-body.component.html'
})
export class ArisModalBodyComponent {

  @Language() lang: string;

}
