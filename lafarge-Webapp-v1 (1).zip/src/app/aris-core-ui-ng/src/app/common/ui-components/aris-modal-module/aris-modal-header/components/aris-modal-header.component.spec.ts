import { TestBed, ComponentFixture } from '@angular/core/testing';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';
import { TranslationService, LocaleService, LocalizationModule, InjectorRef } from 'angular-l10n';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClientModule } from '@angular/common/http';
import { ArisModalHeaderComponent } from './aris-modal-header.component';
import { ArisDynamicPageModule } from '../../../../ui-page-models/aris-dynamic-page-module/aris-dynamic-page.module';
import { FilterModule } from '../../../../ui-page-sections/filter-panel-module/aris-filter.module';
import { Observable } from 'rxjs';

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};

describe('Test: ArisModalHeaderComponent', () => {

  let component: ArisModalHeaderComponent;
  let fixture: ComponentFixture<ArisModalHeaderComponent>;
  let modalRef = new BsModalRef();

  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [],
      imports: [RouterModule,
        LocalizationModule,
        CommonModule,
        ArisDynamicPageModule,
        FilterModule,
        HttpClientModule,
        HttpClientTestingModule],
      providers: [InjectorRef, BsModalService,
         { provide: TranslationService, useValue: mockTranslationService }, { provide: LocaleService }]
    });

    // create component and test fixture
    fixture = TestBed.createComponent(ArisModalHeaderComponent);

    // get test component from the fixture
    component = fixture.componentInstance;
    component.modalRef = modalRef;

  });

  afterEach(() => {
    fixture = null;
    component = null;
  });

  it('Component execution for decline', () => {
    component.ngAfterViewInit();
    spyOn(component, 'decline').and.callThrough();
    component.decline();
    expect(component.decline).toHaveBeenCalled();
  });

  it('Component execution for decline if Condition', () => {
    component.headerText = "header";
    component.ngAfterViewInit();
    spyOn(component, 'decline').and.callThrough();
    component.decline();
    expect(component.decline).toHaveBeenCalled();
  });

});
