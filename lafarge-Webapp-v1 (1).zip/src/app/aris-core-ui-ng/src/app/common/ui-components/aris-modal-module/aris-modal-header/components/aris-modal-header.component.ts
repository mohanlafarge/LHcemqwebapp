import { Component, Input, Output, EventEmitter, TemplateRef, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';
import { Language, TranslationService, LocaleService } from 'angular-l10n';
import { ArisSvgService } from '../../../../services/aris-svg.service';

@Component({
  selector: 'aris-modal-header',
  templateUrl: './aris-modal-header.component.html'
})
export class ArisModalHeaderComponent implements AfterViewInit {

  @Language() lang: string;

  @Input() customHeader = false;
  // Header Section
  @Input() headerText: string;
  headerMessage: string;
  @Output() cancelPopUp: EventEmitter<any> = new EventEmitter();
  @Input() isCancelButtonDisplay: boolean = true;
  @Input() modalRef: BsModalRef;

  constructor(private translationService: TranslationService) {
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.headerMessage = this.headerText ? this.translationService.translate(this.headerText) : "";
    }, 100);
  }

  decline(): void {
    this.modalRef.hide();
    this.cancelPopUp.emit(null);
  }

}
