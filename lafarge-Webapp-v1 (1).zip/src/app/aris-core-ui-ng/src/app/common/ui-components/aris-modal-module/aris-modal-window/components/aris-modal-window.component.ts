import { Component, Input } from '@angular/core';
import { Language } from 'angular-l10n';

@Component({
  selector: 'aris-modal-window',
  templateUrl: './aris-modal-window.component.html'
})
export class ArisModalWindowComponent {

  @Language() lang: string;
}
