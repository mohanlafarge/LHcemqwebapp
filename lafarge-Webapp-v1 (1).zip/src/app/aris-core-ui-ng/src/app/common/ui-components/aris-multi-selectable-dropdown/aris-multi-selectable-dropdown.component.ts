import { Component, OnInit, Input, ViewEncapsulation, OnChanges } from "@angular/core";

import * as $ from "jquery";
import * as _ from "lodash";
import { TranslationService } from "angular-l10n";

@Component({
  selector: "aris-multi-selectable-dropdown",
  templateUrl: "./aris-multi-selectable-dropdown.component.html",
  encapsulation: ViewEncapsulation.None
})
export class ArisMultiSelectableDropdownComponent implements OnInit {
  @Input() dropdownText: string;
  @Input() _data: any;

  private _dataToDisplay: any;

  public expandDropdown = false;
  public checked = false;
  public selectAllClicked = false;
  public selectedItemCount = 0;
  public selectUnselectText;

  constructor(private translation: TranslationService) {
    this.selectUnselectText = this.translation.translate('SELECT_ALL');
  }

  @Input()
  set data(item: any) {
    this._data = item;
  }

  get data(): any {
    return this._data;
  }
  @Input()
  set dataToDisplay(item: any) {
    this._dataToDisplay = item;
  }

  get dataToDisplay(): any {
    return this._dataToDisplay;
  }

  ngOnInit() {
    for (let i = 0; i < this.data.length; i++) {
      this.data[i] = $.extend(this.data[i], {
        checked: false
      });
    }
    this.dataToDisplay = _.cloneDeep(this.data);
  }
  public toggleDropdown(): void {
    this.expandDropdown = !this.expandDropdown;
  }
  public toggleCheckbox(id: string): void {
    this.updateDataAccordingToSelection(this.data, id);
    this.updateDataAccordingToSelection(this.dataToDisplay, id);
    if (this.data[this.findIndexById(this.data, id)].checked) {
      this.selectedItemCount++;
    } else {
      this.selectedItemCount--;
    }
    this.selectUnselectText =
      this.selectedItemCount === this.data.length
        ? this.translation.translate('UNSELECT_ALL')
        : this.translation.translate('SELECT_ALL');
  }
  public updateDataAccordingToSelection(data: any, id: string): void {
    const index = this.findIndexById(data, id);
    data[index].checked = !data[index].checked;
  }
  public findIndexById(data: any, id: string): number {
    const index = _.findIndex(data, (o: any) => {
      return o.id === id;
    });
    return index;
  }
  public onSearchChange(event: string): void {
    this.dataToDisplay = _.cloneDeep(
      _.filter(this.data, (o: any) => {
        return o.name.toLowerCase().indexOf(event.toLowerCase()) >= 0;
      })
    );
  }
  public selectAll(): void {
    this.selectAllClicked = !this.selectAllClicked;
    if (this.selectAllClicked) {
      this.setAllDataAccordingToCheckStatus(this.data, true);
      this.setAllDataAccordingToCheckStatus(this.dataToDisplay, true);
      this.selectedItemCount = this.dataToDisplay.length;
    } else {
      this.setAllDataAccordingToCheckStatus(this.data, false);
      this.setAllDataAccordingToCheckStatus(this.dataToDisplay, false);
      this.selectedItemCount = 0;
    }
    this.selectUnselectText = this.setselectUnselectText();
  }
  public setselectUnselectText(): string {
    return this.selectedItemCount === this.data.length
      ? this.translation.translate('UNSELECT_ALL')
      : this.translation.translate('SELECT_ALL');
  }
  public setAllDataAccordingToCheckStatus(
    data: any,
    checkStatus: boolean
  ): void {
    data.forEach((item) => {
      item.checked = checkStatus;
    });
  }
  public done(): void {
    const elementsSelected: string[] = _.filter(this.data, (o: any) => {
      return o.checked === true;
    }).map((o: any) => {
      return o.name;
    });
    console.log("ELEMENTS", elementsSelected);
    this.toggleDropdown();
  }
}
