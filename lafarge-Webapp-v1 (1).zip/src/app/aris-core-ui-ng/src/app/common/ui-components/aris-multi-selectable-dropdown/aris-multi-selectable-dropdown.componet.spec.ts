import { TestBed, ComponentFixture } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { TranslationService, LocaleService, TranslationHandler, TranslationConfig, TranslationProvider, LocaleStorage, LocaleConfig } from "angular-l10n";
import { ArisMultiSelectableDropdownComponent } from "./aris-multi-selectable-dropdown.component";
import { providers } from 'ng2-dnd';
import { Observable } from 'rxjs';

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};
describe("Test: ArisMultiSelectableDropdownComponent", () => {

  let component: ArisMultiSelectableDropdownComponent;
  let fixture: ComponentFixture<ArisMultiSelectableDropdownComponent>;
  let mockMultiDropDownData = [
    { id: "april", name: "15-Apr", checked: false },
    { id: "may", name: "15-May", checked: false },
    { id: "jun", name: "15-Jun", checked: false },
    { id: "jul", name: "15-Jul", checked: true },
    { id: "aug", name: "15-Aug", checked: false },
    { id: "sep", name: "15-sep", checked: false },
    { id: "oct", name: "15-Oct", checked: false },
    { id: "nov", name: "15-Nov", checked: false },
    { id: "dec", name: "15-Dec", checked: false }
  ];

  beforeEach(() => {
    TestBed.configureTestingModule(
      {
        imports: [],
        providers: [{ provide: TranslationService, useValue: mockTranslationService }],
        declarations : [ArisMultiSelectableDropdownComponent]
      });
    fixture = TestBed.createComponent(ArisMultiSelectableDropdownComponent);
    component = fixture.componentInstance;
    component.data = mockMultiDropDownData;
    component.ngOnInit();
  });

  it("ngOnInit executed", () => {
    component.ngOnInit();
    expect(component.dataToDisplay).toEqual(mockMultiDropDownData);
  });

  it("toggleDropdown executed", () => {
    let val = component.expandDropdown;
    component.toggleDropdown();
    expect(component.expandDropdown).toEqual(!val);
  });

  it("toggleCheckbox executed ", () => {
    let selectCount = component.selectedItemCount;
    component.toggleCheckbox('april');
    expect(component.selectedItemCount).toBeGreaterThan(selectCount);

  });

  it("updating data with index ", () => {

    let checkIndex = component.findIndexById(component.data, 'april');
    let isIndexChecked = component.data[checkIndex].checked;
    component.updateDataAccordingToSelection(component.data, 'april');
    expect(component.data[checkIndex].checked).toEqual(!isIndexChecked);
  });

  it("Test for finding index by id", () => {
    let idIndex = component.findIndexById(component.data, 'jun');
    expect(idIndex).toEqual(2);
  });

  it("Select all - All Items NOT selected ", () => {
    component.selectAllClicked = true;
    component.selectAll();
    expect(component.selectedItemCount).toEqual(0);
  });

  it("Select all - All Items selected ", () => {
    component.selectAllClicked = false;
    component.selectAll();
    expect(component.selectedItemCount).toEqual(component.data.length);
  });

  it("All items selected executed ", () => {
    component.selectedItemCount = mockMultiDropDownData.length;
    let selectText = component.setselectUnselectText();
    expect(mockTranslationService.translate).toHaveBeenCalled();
  });
});
