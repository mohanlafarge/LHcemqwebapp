import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import 'rxjs/add/observable/of';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { LocalizationModule, TranslationService } from 'angular-l10n';
import { ArisUiComponentsModule } from '../aris-ui-components.module';

import { ArisModule } from '../../../aris.module';
import { ArisSmartTableMainComponent } from './aris-smart-table-main.component';


describe('Component: ArisSmartTableMainComponent', () => {

  let component: ArisSmartTableMainComponent;
  let fixture: ComponentFixture<ArisSmartTableMainComponent>;
  let infoCardElement: DebugElement;
  let mockColumnSettings: any;
  let mockData: any;
  let infoCardElement2: DebugElement;
  let handler: HttpHandler;
  const httpclient = new HttpClient(handler);
  mockColumnSettings = {
    actions: false,
    pager: { display: true },
    class: 'smart-table',
    columns: {
      assetAttributeValueId: {
        title: 'ID',
        filter: false
      },
      assetAttributeName: {
        title: 'Asset Attribute Name',
        filter: false,
      },
      assetAttributeType: {
        title: 'Asset Attribute Type'
      },
      assetName: {
        title: 'Asset Name',
      },
      attributeDataType: {
        title: 'Attribute Data Type',
      }
    },
  };
  mockData = {
    assetAttributeValueId: 1,
    assetAttributeName: "testName",
    assetAttributeType: "value",
    assetName: "testAssetName",
    attributeDataType: "String"
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      schemas: [],
      imports: [LocalizationModule, ArisModule, ArisUiComponentsModule],
      providers: [HttpClient, HttpHandler, TranslationService]
    }).compileComponents();
    fixture = TestBed.createComponent(ArisSmartTableMainComponent);
    // get test component from the fixture
    component = fixture.componentInstance;
    component.columnSettings = mockColumnSettings;
    component.data = mockData;
  });

  it('test : ArisSmartTableMainComponent should be created', () => {
    expect(component).toBeTruthy();
  });

  it('test : ArisSmartTableMainComponent ngOninit method checking', () => {
    component.ngOnInit();
    expect(component.settings.actions).toBe(false);
    expect(component.settings.columns.assetAttributeValueId.title).toBe("ID");
    expect(component.source.assetAttributeValueId).toBe(1);
  });

  it('test : ArisSmartTableMainComponent ngOnChanges method checking', () => {
    component.ngOnInit();
    expect(component.settings.class).toBe("smart-table");
    expect(component.settings.columns.assetAttributeName.filter).toBe(false);
    expect(component.source.attributeDataType).toBe("String");
  });
});
