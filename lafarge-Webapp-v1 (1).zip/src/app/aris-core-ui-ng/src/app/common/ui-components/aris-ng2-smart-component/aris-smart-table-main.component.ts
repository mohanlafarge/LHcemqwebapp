import { Component, OnInit, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-grid-table',
  template: '<ng2-smart-table [settings]="settings" [source]="source" style="height: 335px"></ng2-smart-table>',
  styleUrls: ['css/aris-smart-table-main.component.scss', 'css/aris-smart-table-main.component.css']
})

export class ArisSmartTableMainComponent implements OnInit, OnChanges {
  source: any;
  settings: any;
  @Input() data: any;
  @Input() columnSettings: any;

  constructor() {
  }

  ngOnInit() {
    this.source = this.data;
    this.settings = this.columnSettings;
  }

  ngOnChanges() {
    this.source = this.data;
    this.settings = this.columnSettings;
  }
}



