import { Component } from "@angular/core";
import { Language } from "angular-l10n";

@Component({
  selector: "aris-panel-header",
  templateUrl: "./aris-panel-header.component.html"
})
export class ArisPanelHeaderComponent {

  @Language() lang: string;

}
