import { Component, Input, OnInit } from "@angular/core";
import { Language } from "angular-l10n";

@Component({
  selector: "aris-panel",
  templateUrl: "./aris-panel.component.html"
})
export class ArisPanelComponent {

  @Language() lang: string;
  @Input() cornered: boolean;
  @Input() arisClass: string;

  constructor() {
  }
}
