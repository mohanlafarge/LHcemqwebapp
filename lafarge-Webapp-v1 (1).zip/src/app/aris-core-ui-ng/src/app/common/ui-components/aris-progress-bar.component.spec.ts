// import { TestBed, ComponentFixture } from '@angular/core/testing';

// import { ArisProgressComponent } from './aris-progress-bar.component';
// import { ArisFormComponentError } from './aris-form-component-error.component';

// import { ReactiveFormsModule } from '@angular/forms';
// import { Observable } from 'rxjs/Observable';

// describe('Test: Aris Progress Component', () => {

//   let component: ArisProgressComponent;
//   let fixture: ComponentFixture<ArisProgressComponent>;

//   beforeEach(() => {

//     TestBed.configureTestingModule({
//       declarations: [ArisProgressComponent, ArisFormComponentError],
//       providers: [],
//       imports: [ReactiveFormsModule]
//     });

//     // create component and test fixture
//     fixture = TestBed.createComponent(ArisProgressComponent);

//     // get test component from the fixture
//     component = fixture.componentInstance;
//     component.currentPercentage = 40;
//     component.progressBarHeader = 'File Upload';
//     component.progressBarTitle = 'In Progress';

//     component.ngAfterViewInit();
//     component.ngOnChanges();
//   });

//   it('Component progress percentage should be equal to current percentage', () => {
//     component.currentPercentage = 100;    
//     expect(component.progressPercentage).toBeDefined();
//   });
  
// });
