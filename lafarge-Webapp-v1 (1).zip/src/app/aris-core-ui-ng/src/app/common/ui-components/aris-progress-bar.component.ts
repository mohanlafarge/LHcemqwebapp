import { Component, Input, Output, OnInit, OnDestroy, ElementRef, ViewChild, OnChanges, EventEmitter, AfterViewInit } from "@angular/core";
import { Language } from "angular-l10n";
import { BsModalService, BsModalRef } from "ngx-bootstrap";

@Component({
  selector: 'aris-progress-bar',
  templateUrl: './aris-progress-bar.component.html'
})
export class ArisProgressComponent implements OnInit, OnChanges, OnDestroy, AfterViewInit {

  modalRef: BsModalRef;
  @Language() lang: string;
  @Input() progressBarHeader: string;
  @Input() progressBarTitle: string;
  @Input() changeTemplate: any;
  @Input() currentPercentage: any;
  @Input() isProgressBar: boolean = true;
  @Input() isCancelButtonDisplay: boolean;
  @Output() resetProgress: EventEmitter<any> = new EventEmitter<any>();
  @Output() cancelRequest: EventEmitter<any> = new EventEmitter<any>();

  public progressPercentage: any;
  @ViewChild('template') confirmationTemplate: ElementRef;
  config = {
    animated: true,
    keyboard: true,
    backdrop: true,
    ignoreBackdropClick: true
  };

  constructor(private modalService: BsModalService) {
  }

  ngOnInit() {
    // if (this.currentPercentage > 0) {
    //   this.modalRef = this.modalService.show(this.changeTemplate ? this.changeTemplate :  this.confirmationTemplate, this.config);
    // }

    // if(this.currentPercentage === 100) {
    //   this.modalRef.hide();
    // }
  }

  ngAfterViewInit() {
    setTimeout(() => {
      if (this.currentPercentage > 0) {
        this.modalRef = this.modalService.show(this.changeTemplate ? this.changeTemplate :  this.confirmationTemplate, this.config);
      }
    }, 0);
  }
  ngOnChanges() {
    this.progressPercentage = this.currentPercentage;
    if (this.currentPercentage === 100) {
      this.modalRef.hide();
    }
  }
  cancelProgressRequest() {
    this.cancelRequest.emit();
    this.modalRef.hide();
  }
  ngOnDestroy() {
    this.modalRef.hide();
  }
}
