import { Component, Input, OnInit, OnDestroy, ElementRef, ViewChild, OnChanges, SimpleChanges } from "@angular/core";
import { Language } from "angular-l10n";
import * as noUiSlider from 'nouislider';
import { Subject } from 'rxjs/Subject';
import { Subscription } from "rxjs/Subscription";

@Component({
  selector: 'aris-slider',
  templateUrl: './aris-slider.component.html'
})
export class ArisSliderComponent implements OnInit, OnDestroy, OnChanges {

  count = 0;
  slider: any;
  state: any;


  @Input() sliderValue: any;
  @Input() orientation: any;
  @Input() min: any;
  @Input() max: any;


  constructor() {
  }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.max) {
      if (changes.max.currentValue) {
        this.setSlider();
      }
    }
    // console.log("---------------------------");
    if (this.slider) {
      this.slider.noUiSlider.set(this.sliderValue);
    }

  }

  ngOnDestroy() {

  }

  setSlider() {
    this.slider = document.getElementById('range');

    noUiSlider.create(this.slider, {

      range: {
        min: [this.min],
        max: [this.max]
      },
      start: this.min,
      step: 1,
      orientation: this.orientation,
      pips: {
        mode: 'steps',
        density: 3,
        filter: filterPips,
      },
      tooltips: true
    });

    function filterPips(value, type) {
      if (Number.isInteger(value / 10)) {
        return 1;
      // tslint:disable-next-line:no-else-after-return
      } else {
        return 0;
      }
    }

    this.slider.setAttribute('disabled', true);

    console.log(this.slider.noUiSlider.get());
  }
}
