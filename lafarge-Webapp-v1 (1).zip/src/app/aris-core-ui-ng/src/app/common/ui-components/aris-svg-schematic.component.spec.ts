import { ElementRef, Renderer } from '@angular/core';
import { ArisSvgSchematicComponent } from './aris-svg-schematic.component';
import { ArisSvgService } from '../services/aris-svg.service';

describe('Test: ArisSvgSchematicComponent', () => {
  let nativeElement: any;
  let val: any;
  let val1: any = {};
  let elementRef = new ElementRef(nativeElement);
  let renderer: Renderer;
  let arisSvgService = new ArisSvgService();
  let arisSvgSchematicComponent = new ArisSvgSchematicComponent(elementRef, renderer, arisSvgService);
  let date = new Date('Mon Dec 01 1919 00:00:00 GMT+0530 (India Standard Time)');
  let event = { target: val1, currentTarget: { style: { fill: 't' } } };
  let schematic = ['JUN18'];
  let boundaries = ['JUN18'];
  let boundaries1 = [{ boundary: 1 }];
  let exp = { 0: 'JUN18' };
  let schme = { schematicSvg: 1, schematicData: schematic,
    timeInterval: { min: "JAN18" , max: "DEC18" },
    boundaries: "JUN18" };

  it('Component execution for changeOpenNewDialog', () => {
    arisSvgSchematicComponent.changeOpenNewDialog();
    expect(arisSvgSchematicComponent.openNewDialog).toBeFalsy();
  });

  it('Component execution for getMonth', () => {
    let result = arisSvgSchematicComponent.getMonth(1);
    expect(result).toEqual(-1);
  });

  it('Component execution for parseDate', () => {
    let result = arisSvgSchematicComponent.parseDate('JAN-18');
    expect(result).toEqual(new Date(2018, 0));
  });

  it('Component execution for getNewElementById', () => {
    let expected = arisSvgSchematicComponent.getNewElementById(1, 2);
    expect(expected).toBeDefined();
  });

  it('Component execution for getInnerElementById', () => {
    let expected = arisSvgSchematicComponent.getInnerElementById(1, 2);
    expect(expected).toBeDefined();
  });

  it('Component execution for getInnerElementByClass', () => {
    let expected = arisSvgSchematicComponent.getInnerElementByClass(1, 2);
    expect(expected).toBeDefined();
  });

  it('Component execution for filterSchematicDataByInterval', () => {
    let result = arisSvgSchematicComponent.filterSchematicDataByInterval(schematic, "JAN18", "DEC18");
    expect(result).toEqual(exp);
  });

  it('Component execution for filterSchematicDataByInterval else scenario', () => {
    let result = arisSvgSchematicComponent.filterSchematicDataByInterval(['JUN17', '1989-12-12'], "1989-12-12", "1989-12-12");
    expect(result).toBeDefined();
  });

  it('Component execution for getAverageNodeValues', () => {
    let expected = arisSvgSchematicComponent.getAverageNodeValues(schematic);
    expect(expected).toEqual({ 0: 'J', 1: 'U', 2: 'N', 3: '1', 4: '8' });
  });

  it('Component execution for calculateNodesWithColors', () => {
    let expected = arisSvgSchematicComponent.calculateNodesWithColors(schematic, boundaries);
    expect(expected).toEqual([({ name: '0', value: 'JUN18', color: undefined })]);
  });

  it('Component execution for colorNodes', () => {
    arisSvgSchematicComponent.colorNodes(schematic, boundaries);
    expect(arisSvgSchematicComponent).toBeTruthy();
  });

  it('Component execution for colorNodes else scenario', () => {
    spyOn(arisSvgSchematicComponent, 'getNewElementById').and.returnValue(false);
    arisSvgSchematicComponent.colorNodes(schematic, boundaries);
    expect(arisSvgSchematicComponent.getNewElementById).toHaveBeenCalled();
  });

  it('Component execution for addClassToSchematicNodes', () => {
    arisSvgSchematicComponent.addClassToSchematicNodes(schematic, 'pop', 1);
    expect(arisSvgSchematicComponent).toBeTruthy();
  });

  it('Component execution for addClassToSchematicNodes else scenario', () => {
    spyOn(arisSvgSchematicComponent, 'getInnerElementById').and.returnValue(false);
    arisSvgSchematicComponent.addClassToSchematicNodes(schematic, 'pop', 1);
    expect(arisSvgSchematicComponent.getInnerElementById).toHaveBeenCalled();
  });

  it('Component execution for addClickHandlerToNodes', () => {
    arisSvgSchematicComponent.addClickHandlerToNodes(schematic, 'pop', 1, val);
    expect(arisSvgSchematicComponent).toBeTruthy();
  });

  it('Component execution for addClickHandlerToNodes else scenario', () => {
    spyOn(arisSvgSchematicComponent, 'getInnerElementById').and.returnValue(false);
    arisSvgSchematicComponent.addClickHandlerToNodes(schematic, 'pop', 1, val);
    expect(arisSvgSchematicComponent.getInnerElementById).toHaveBeenCalled();
  });

  it('Component execution for initializeSchematics', () => {
    arisSvgSchematicComponent.config = schme;
    arisSvgSchematicComponent.initializeSchematics();
    expect(arisSvgSchematicComponent.svgData).toBeDefined();
  });

  it('Component execution for initializeSchematics else scenario for config.schematicSvg', () => {
    arisSvgSchematicComponent.config = { schematicSvg: undefined };
    spyOn(arisSvgSchematicComponent, 'getNewElementById').and.callThrough();
    arisSvgSchematicComponent.initializeSchematics();
    expect(arisSvgSchematicComponent.getNewElementById).toHaveBeenCalled();
  });

  it('Component execution for initializeSchematics else scenario for showPopovers false', () => {
    arisSvgSchematicComponent.config = schme;
    arisSvgSchematicComponent.showPopovers = false;
    spyOn(arisSvgSchematicComponent, 'getNewElementById').and.callThrough();
    arisSvgSchematicComponent.initializeSchematics();
    expect(arisSvgSchematicComponent.getNewElementById).toHaveBeenCalled();
  });

  it('Component execution for ngOnInit', () => {
    arisSvgSchematicComponent.clickHandler = true;
    arisSvgSchematicComponent.ngOnInit();
    expect(arisSvgSchematicComponent.svgData).toBeDefined();
  });

  it('Component execution for ngAfterViewChecked', () => {
    arisSvgSchematicComponent.ngAfterViewChecked();
    expect(arisSvgSchematicComponent.svgData).toBeDefined();
  });

  it('Component execution for getColorForValue', () => {
    arisSvgSchematicComponent.getColorForValue(1, boundaries1);
    expect(arisSvgSchematicComponent).toBeTruthy();
  });

  it('Component execution for zoomin', () => {
    let svg = { clientWidth: 10, style: { width: '' } };
    spyOn(document, 'getElementById').and.returnValue(svg);
    arisSvgSchematicComponent.zoomin();
    expect(svg.style.width).toEqual('60px');
  });

  it('Component execution for zoomin if scenario', () => {
    let svg = { clientWidth: 500 };
    spyOn(document, 'getElementById').and.returnValue(svg);
    arisSvgSchematicComponent.zoomin();
    expect(arisSvgSchematicComponent).toBeTruthy();
  });

  it('Component execution for zoomout', () => {
    let svg = { clientWidth: 60, style: { width: '' } };
    spyOn(document, 'getElementById').and.returnValue(svg);
    arisSvgSchematicComponent.zoomout();
    expect(svg.style.width).toEqual('10px');
  });

  it('Component execution for zoomout if scenario', () => {
    let svg = { clientWidth: 50 };
    spyOn(document, 'getElementById').and.returnValue(svg);
    arisSvgSchematicComponent.zoomout();
    expect(arisSvgSchematicComponent).toBeTruthy();
  });

  it('Component execution for adjustPopoverTop', () => {
    let popoverElement = { css() {} };
    spyOn(popoverElement, 'css').and.returnValue(false);
    arisSvgSchematicComponent.adjustPopoverTop(popoverElement);
    expect(popoverElement.css).toHaveBeenCalled();
  });

  it('Component execution for adjustPopoverTop if scenario', () => {
    let popoverElement = { css() {}, replace() {} };
    let topCss = { replace() {} };
    spyOn(popoverElement, 'css').and.returnValue(topCss);
    arisSvgSchematicComponent.adjustPopoverTop(popoverElement);
    expect(arisSvgSchematicComponent).toBeTruthy();
  });

  it('Component execution for closeNotificationBox', () => {
    let notificationElement  = { classList: { contains() {} } };
    spyOn(document, 'getElementById').and.returnValue(notificationElement);
    spyOn(notificationElement.classList, 'contains').and.returnValue(true);
    arisSvgSchematicComponent.closeNotificationBox();
    expect(document.getElementById).toHaveBeenCalled();
  });

  it('Component execution for closeNotificationBox if scenario', () => {
    let notificationElement  = { classList: { contains() {}, add() {} } };
    spyOn(document, 'getElementById').and.returnValue(notificationElement);
    spyOn(notificationElement.classList, 'contains').and.returnValue(false);
    arisSvgSchematicComponent.closeNotificationBox();
    expect(document.getElementById).toHaveBeenCalled();
  });

  it('Component execution for openDialog', () => {
    arisSvgSchematicComponent.popupFunc = undefined;
    let notificationElement  = { target: { getAttribute() {}, add() {} }, currentTarget: { style: { fill: 'fill' } } };
    spyOn(notificationElement.target, 'getAttribute').and.returnValue(1.122);
    arisSvgSchematicComponent.openDialog(notificationElement);
    expect(notificationElement.target.getAttribute).toHaveBeenCalled();
  });

  it('Component execution for openDialog if scenario', () => {
    arisSvgSchematicComponent.popupFunc = function () {};
    let notificationElement  = { target: { getAttribute() {}, add() {} }, currentTarget: { style: { fill: 'fill' } } };
    spyOn(notificationElement.target, 'getAttribute').and.returnValue(1.122);
    arisSvgSchematicComponent.openDialog(notificationElement);
    expect(notificationElement.target.getAttribute).toHaveBeenCalled();
  });




});
