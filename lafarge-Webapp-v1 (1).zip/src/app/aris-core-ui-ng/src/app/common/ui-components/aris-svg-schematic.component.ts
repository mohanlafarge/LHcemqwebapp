// ./app/shared/hidden.directive.ts
import { Component, Directive, ElementRef, Renderer, Input, AfterViewChecked, Output, TemplateRef, OnInit, OnDestroy } from '@angular/core';
import { EventEmitter } from 'events';
import { ArisSvgService } from '../services/aris-svg.service';
declare var $: any;
@Component({ selector: '[aris-svg-schematic]',
  templateUrl : './aris-svg-schematic.component.html'})
export class ArisSvgSchematicComponent implements OnInit, AfterViewChecked, OnDestroy {
  @Input() config: any;
  @Input() showPopovers: any =  true;
  @Input() clickHandler: any;
  svgData: any;
  @Input() legendTexts: any;
  @Input() popupFunc: any;
  @Input() boundaries: any;
  @Input() dialogHref: any;
  targetVal: any;
  popoverTemplate: any;
  dialogRef: any;
  fill: any;
  initialZoom: any = 1;
  @Output() eventSendingData: EventEmitter;
  openNewDialog: any = false;
  popoverClassName: any = 'schematic-node-popover';
  constructor(private el: ElementRef, renderer: Renderer, private arisSvgService: ArisSvgService) {}

  openDialog(event: any): void {
    this.openNewDialog = true;
    this.targetVal =  parseFloat(event.target.getAttribute("val")).toFixed(2);
    this.fill = event.currentTarget.style.fill;
    if (this.popupFunc !== undefined) {
      this.popupFunc();
    } else {

    }
  }

  changeOpenNewDialog() {
    this.arisSvgService.closeOpenDialog.next(false);
    this.openNewDialog = false;
  }

  getMonth(mmm) {
    let months = [
      'JAN',
      'FEB',
      'MAR',
      'APR',
      'MAY',
      'JUN',
      'JUL',
      'AUG',
      'SEP',
      'OCT',
      'NOV',
      'DEC'
    ];
    return months.indexOf(mmm);
  }

  parseDate(mmmyy) {
    let parts = mmmyy.split('-');
    let month = this.getMonth(parts[0].toUpperCase());
    let year = parseInt('20' + parts[1], 10);
    return new Date(year, month);
  }

  filterSchematicDataByInterval(schematicData, minDate, maxDate) {
    let parsedMinDate = this.parseDate(minDate).getTime();
    let parsedMaxDate = this.parseDate(maxDate).getTime();
    let schematicDataForInterval = {};

    for (let key in schematicData) {
      if (schematicData.hasOwnProperty(key)) {
        let date = this.parseDate(key).getTime();
        if ((date >= parsedMinDate) && (date <= parsedMaxDate)) {
          schematicDataForInterval[key] = schematicData[key];
        }
      }
    }
    return schematicDataForInterval;
  }

  getAverageNodeValues(schematicData) {
    let numberOfValues = 0;
    let nodes = {};
    for (let date in schematicData) {
      if (schematicData.hasOwnProperty(date)) {
        numberOfValues = numberOfValues + 1;
        let dataForDate = schematicData[date];
        for (let dataNodeKey in dataForDate) {
          if (dataForDate.hasOwnProperty(dataNodeKey)) {
            if (nodes.hasOwnProperty(dataNodeKey)) {
              nodes[dataNodeKey] = (nodes[dataNodeKey] * numberOfValues + dataForDate[dataNodeKey]) / (numberOfValues + 1);
            } else {
              nodes[dataNodeKey] = dataForDate[dataNodeKey];
            }
          }
        }
      }
    }
    return nodes;
  }

  calculatNodeDetails(schematicConfig) {
    let schematicData = schematicConfig.schematicData;
    let minDate = schematicConfig.timeInterval.min;
    let maxDate = schematicConfig.timeInterval.max;
    let boundaries = schematicConfig.boundaries;

    let nodesForInterval = this.filterSchematicDataByInterval(schematicData, minDate, maxDate);

    let nodes = this.getAverageNodeValues(nodesForInterval);

    let nodesWithColor = this.calculateNodesWithColors(nodes, boundaries);

    return nodesWithColor;
  }

  getColorForValue(value, boundaries) {
    for (let i = 0; i < boundaries.length; i = i + 1) {
      if (boundaries[i].boundary <= value) {
        return boundaries[i].colorCode;
      }
    }
    return boundaries[boundaries.length - 1].colorCode;
  }

  calculateNodesWithColors(nodes, boundaries) {
    for (let key in nodes) {
      if (nodes.hasOwnProperty(key)) {
        nodes[key] = {
          name: key,
          value: nodes[key],
          color: this.getColorForValue(nodes[key], boundaries)
        };
      }
    }
    return nodes;
  }

  colorNodes(nodeDetails, containerElementId) {
    for (let key in nodeDetails) {
      if (nodeDetails.hasOwnProperty(key)) {
        let element = this.getNewElementById(key, containerElementId);
        if (!!element) {
          element.attr("val", nodeDetails[key].value);
          element.css({ fill : '' });
          element.css({ fill : nodeDetails[key].color });
        }
      }
    }
  }

  getNewElementById(elementId, containerElementId) {
    return $('#' + elementId);
  }

  getInnerElementById(elementId, containerElementId) {
    return $('#' + containerElementId + ' ' + '#' + elementId);
  }

  initializePopovers(nodeDetails, popoverClassName, containerElementId, scope) {
    let nodeClassName = "schematic-unit-node";
    this.addClassToSchematicNodes(nodeDetails, nodeClassName, containerElementId);
    // this.destroyPopoversByClass(nodeClassName, containerElementId);
    this.createPopoversForNodes(nodeDetails, nodeClassName, popoverClassName, containerElementId, scope);
  }

  closeNotificationBox() {
    let notificationElement = document.getElementById("header-notification");
    if (!notificationElement.classList.contains("ng-hide")) {
      notificationElement.classList.add("ng-hide");
    }
  }

  createPopoversForNodes(nodeDetails, nodeClassName, popoverClassName, containerElementId, scope) {
    for (let node in nodeDetails) {
      if (nodeDetails.hasOwnProperty(node)) {
        let element = this.getInnerElementById(node, containerElementId);
        let that: any;
        that = this;
        element.off('click');
        element.on('click', (e) => {
          this.openDialog(e);
          e.stopPropagation();
          element.off('click');
        })
          .on('shown.bs.popover', () => {
            that.adjustPopoverTop(that.getInnerElementByClass(popoverClassName, containerElementId));
          });
      }
    }
  }

  adjustPopoverTop(popoverElement) {
    let topCss = popoverElement.css('top');
    if (!!topCss) {
      let currentTop = Number(topCss.replace('px', ''));
      let updatedTop = currentTop + $(document).scrollTop();
      popoverElement.css({
        top: updatedTop + 'px'
      });
    }
  }

  getInnerElementByClass(elementClass, containerElementId) {
    return $('#' + containerElementId + ' ' + '.' + elementClass);
  }

  addClassToSchematicNodes(nodeConfigurations, className, containerElementId) {
    for (let key in nodeConfigurations) {
      if (nodeConfigurations.hasOwnProperty(key)) {
        let element = this.getInnerElementById(key, containerElementId);
        if (!!element) {
          element.attr('class', className);
        }
      }
    }
  }

  initializeSchematics() {
    let element = this.getNewElementById('popup', undefined);
    if (this.config.schematicSvg) {
      this.svgData = this.config.schematicSvg;
      let nodeDetails = this.calculatNodeDetails(this.config);
      this.colorNodes(nodeDetails, 'Page-1');
      if (this.showPopovers === true) {
        this.initializePopovers(nodeDetails, this.popoverClassName, 'Page-1', this);
      }
      if (!!this.clickHandler) {
        this. addClickHandlerToNodes(nodeDetails, this.clickHandler, 'Page-1', this);
      }
    }
  }

  addClickHandlerToNodes(nodeDetails, handler, containerElementId, scope) {
    for (let key in nodeDetails) {
      if (nodeDetails.hasOwnProperty(key)) {
        let element = this.getInnerElementById(key, containerElementId);
        if (!!element) {
          element.click(function () {
            handler()(this.id);
          });
        }
      }
    }
  }

  zoomin() {
    let svg = document.getElementById("svg");
    let currWidth = svg.clientWidth;
    if (currWidth === 500) {
      alert("Maximum zoom-in level reached.");
    } else {
      svg.style.width = (currWidth + 50) + "px";
    }
  }
  zoomout() {
    let svg = document.getElementById("svg");
    let currWidth = svg.clientWidth;
    if (currWidth === 50) {
      alert("Maximum zoom-out level reached.");
    } else {
      svg.style.width = (currWidth - 50) + "px";
    }
  }

  ngOnInit() {
    this.initializeSchematics();
  }

  ngAfterViewChecked() {
    this.initializeSchematics();
  }

  ngOnDestroy() {
  }
}
