import { TestBed, ComponentFixture } from '@angular/core/testing';
import { DebugElement } from '@angular/core';

import { ArisTextarea } from './aris-textarea.component';
import { ArisFormComponentError } from './aris-form-component-error.component';

import { ReactiveFormsModule,  FormControl, Validators } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { TranslationService } from 'angular-l10n';
import { Observable } from 'rxjs/Observable';

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};
describe('Test: Aris TextArea Component', () => {

  let component: ArisTextarea;
  let fixture: ComponentFixture<ArisTextarea>;

  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [ArisTextarea, ArisFormComponentError],
      providers: [{ provide: TranslationService, useValue: mockTranslationService }],
      imports: [ReactiveFormsModule]
    });

    // create component and test fixture
    fixture = TestBed.createComponent(ArisTextarea);

    // get test component from the fixture
    component = fixture.componentInstance;
    component.arisId = ArisTextarea.name;
    component.arisLabel = ArisTextarea.name + ' Label';
    component.arisValue = 'Text';
    component.arisHidden = false;
    component.arisDisabled = false;

    const formControl = new FormControl('', Validators.compose([
      Validators.required,
      Validators.minLength(3),
      Validators.maxLength(20)
    ])
    );

    component.arisFormControl = formControl;

    component.ngOnInit();

    componentEl = fixture.debugElement.query(By.css('.form-control'));
    componentDiv = fixture.debugElement.query(By.css('.form-group'));

  });

  it('Component Id must be the expected one', () => {
    expect(componentEl.nativeElement.id).toBe('textarea_ArisTextarea');
  });

  it('Setting disabled to true, disables the component', () => {
    component.arisDisabled = false;

    fixture.detectChanges();
    expect(componentEl.nativeElement.disabled).toBeFalsy();

  });

  it('Setting hidden to true, hides the component', () => {
    component.arisHidden = true;

    fixture.detectChanges();
    expect(componentDiv.nativeElement.hidden).toBeTruthy();
  });

  it('Setting value to undefined, component becomes invalid', () => {
    component.arisValue = '';

    fixture.detectChanges();

    expect(componentEl.nativeElement.classList.contains('ng-invalid')).toBeTruthy();
    expect(component.arisFormControl.hasError('required')).toBeTruthy();
  });

  it('Setting value with less characters than allowed', () => {
    component.arisValue = 'a';

    fixture.detectChanges();

    expect(componentEl.nativeElement.classList.contains('ng-invalid')).toBeTruthy();
    expect(component.arisFormControl.hasError('minlength')).toBeTruthy();
  });

  it('Setting value with more characters than allowed', () => {
    component.arisValue = 'abcdefghijklmnopqrstuvwxyz';

    fixture.detectChanges();

    expect(componentEl.nativeElement.classList.contains('ng-invalid')).toBeTruthy();
    expect(component.arisFormControl.hasError('maxlength')).toBeTruthy();
  });

  it('ngOnChanges if executed', () => {
    let changes = { arisValue: { currentValue: 'val' } };
    component.ngOnChanges(changes);
    expect(component).toBeTruthy();
  });

  it('ngOnChanges currentValue is undefined executed', () => {
    let changes = { arisValue: {  } };
    component.ngOnChanges(changes);
    expect(component).toBeTruthy();
  });

  it('ngOnChanges else executed', () => {
    let changes = { arisValue: undefined };
    component.ngOnChanges(changes);
    expect(component).toBeTruthy();
  });

});
