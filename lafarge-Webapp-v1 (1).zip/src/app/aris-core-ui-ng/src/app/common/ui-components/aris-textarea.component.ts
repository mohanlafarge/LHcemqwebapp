import { Component, Input, Output, EventEmitter, OnInit, ChangeDetectorRef, OnChanges } from '@angular/core';
import { ArisFormComponent } from './aris-form-component.component';

@Component({
  selector: 'aris-textarea',
  templateUrl: './aris-textarea.component.html',
})
export class ArisTextarea extends ArisFormComponent implements OnInit, OnChanges {

  @Input() arisLabel: string;
  @Input() arisValue: string;
  @Input() rows = 10;
  @Output() onChangeValue: EventEmitter<string> = new EventEmitter<string>();

  model: string;

  constructor(private cdRef: ChangeDetectorRef) {
    super();
  }

  ngOnInit(): void {
    this.createArisFormControl();

    this.model = this.arisValue;
    this.cdRef.detectChanges();
  }

  componentValueChanged(value: string) {
    this.onChangeValue.emit(value);
  }

  ngOnChanges(changes: any) {
    if (changes.arisValue !== undefined) {
      this.model =  changes.arisValue && changes.arisValue.currentValue ? changes.arisValue.currentValue : undefined;
    } else {
      this.applyChangesOnMask(changes);
    }
  }
}
