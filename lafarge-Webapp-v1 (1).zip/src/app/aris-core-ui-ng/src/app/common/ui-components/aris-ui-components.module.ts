import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

// Autocomplete
import { NgSelectModule } from "@ng-select/ng-select";
import { ArisAutoComplete } from "./aris-autocomplete.component";

// Date Picker
import { BsDatepickerModule, ModalModule } from "ngx-bootstrap";
import { LocalizationModule } from "angular-l10n";

// Other Components
import { ArisDatepicker } from "./aris-datepicker.component";
import { ArisCombobox } from "./aris-combobox.component";
import { ArisInput } from "./aris-input.component";
import { ArisCheckbox } from "./aris-checkbox.component";
import { ArisTextarea } from "./aris-textarea.component";
import { ArisFormComponentError } from "./aris-form-component-error.component";

import { ChartModule } from "./chart-module/aris-chart.module";
import { DynamicComponentDirective } from "../directives/dynamic-component.directive";
import { ArisSmartTableMainComponent } from "./aris-ng2-smart-component/aris-smart-table-main.component";
import { Ng2SmartTableModule } from "ng2-smart-table";
import { ArisAngularGenericTableComponent } from "./aris-generic-table/components/aris-angular-generic-table.component";
import { GenericTableModule } from "@angular-generic-table/core";
import { ColumnSettingsModule } from "@angular-generic-table/column-settings";
import { ArisSvgService } from "../services/aris-svg.service";
import { ArisCustomHeaderComponent } from "./aris-generic-table/components/aris-custom-header.component";
import { ArisProgressComponent } from "./aris-progress-bar.component";
import { ArisPopUpModule } from "../ui-page-sections/pop-up-module/aris-popup.module";
import { ArisConfirmation } from "../ui-page-sections/pop-up-module/components/aris-confirmation.component";
import { ArisSliderComponent } from "./aris-slider.component";
import { ArisPanelHeaderComponent } from "./aris-panel-header-module/aris-panel-header.component";
import { ArisPanelComponent } from "./aris-panel-module/aris-panel.component";
import { ArisCorneredComponent } from "./aris-cornered-module/aris-cornered.component";
import { ArisButtonComponent } from "./aris-button.component";
import { ArisLoadingModule } from "./aris-loading-module/aris-loading.module";
import { ArisModalWindowComponent } from "./aris-modal-module/aris-modal-window/components/aris-modal-window.component";
import { ArisModalHeaderComponent } from "./aris-modal-module/aris-modal-header/components/aris-modal-header.component";
import { ArisModalBodyComponent } from "./aris-modal-module/aris-modal-body/components/aris-modal-body.component";
import { ArisConfirmationWindowComponent } from "./aris-modal-module/aris-confirmation-window/components/aris-confirmation-window.component";
import { ArisLoadingComponent } from "./aris-loading-module/component/aris-loading.component";
import { ArisMultiSelectableDropdownComponent } from "./aris-multi-selectable-dropdown/aris-multi-selectable-dropdown.component";
import { ChartHarvestingModule } from './chart-harvesting-module/chart-harvesting.module';
import { ArisMapLayerComponent } from './aris-map-layer.component';
import { ArisImagePipe } from '../pipes/aris-image.pipes';

@NgModule({
  declarations: [
    ArisButtonComponent,
    ArisCombobox,
    ArisInput,
    ArisTextarea,
    ArisCheckbox,
    ArisFormComponentError,
    ArisAutoComplete,
    ArisDatepicker,
    DynamicComponentDirective,
    ArisSmartTableMainComponent,
    ArisAngularGenericTableComponent,
    ArisCustomHeaderComponent,
    ArisProgressComponent,
    ArisSliderComponent,
    ArisPanelHeaderComponent,
    ArisPanelComponent,
    ArisCorneredComponent,
    ArisConfirmationWindowComponent,
    ArisModalWindowComponent,
    ArisModalHeaderComponent,
    ArisModalBodyComponent,
    ArisMultiSelectableDropdownComponent,
    ArisMapLayerComponent
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    NgSelectModule,
    LocalizationModule,
    ChartModule,
    ChartHarvestingModule,
    Ng2SmartTableModule,
    BsDatepickerModule.forRoot(),
    ModalModule.forRoot(),
    GenericTableModule,
    ColumnSettingsModule,
    ArisPopUpModule,
    ArisLoadingModule
  ],
  providers: [
    ArisSvgService,
    ArisImagePipe
  ],
  exports: [
    ArisButtonComponent,
    ArisCombobox,
    ArisInput,
    ArisTextarea,
    ArisCheckbox,
    ArisFormComponentError,
    ArisAutoComplete,
    ArisDatepicker,
    DynamicComponentDirective,
    ArisSmartTableMainComponent,
    ArisAngularGenericTableComponent,
    ArisCustomHeaderComponent,
    ArisProgressComponent,
    ArisSliderComponent,
    ArisPanelHeaderComponent,
    ArisPanelComponent,
    ArisCorneredComponent,
    ArisConfirmationWindowComponent,
    ArisModalWindowComponent,
    ArisModalHeaderComponent,
    ArisModalBodyComponent,
    ArisMultiSelectableDropdownComponent,
    ArisLoadingComponent,
    ArisMapLayerComponent
  ]
})
export class ArisUiComponentsModule {}
