export interface ChartData {
  dateTime: Date;
  score: number;
}
