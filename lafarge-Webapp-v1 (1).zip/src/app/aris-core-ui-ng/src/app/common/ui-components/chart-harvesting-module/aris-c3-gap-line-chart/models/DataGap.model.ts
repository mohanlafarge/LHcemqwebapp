import { GapType } from './GapType.enum';

export interface DataGap {
  startDate: Date;
  endDate: Date;
  type: GapType;
}
