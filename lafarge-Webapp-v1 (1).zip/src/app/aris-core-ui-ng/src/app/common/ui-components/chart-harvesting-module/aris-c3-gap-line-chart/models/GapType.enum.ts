export enum GapType {
  DOWNTIME = 'DOWNTIME',
  MISSING_DATA = 'MISSING_DATA'
}
