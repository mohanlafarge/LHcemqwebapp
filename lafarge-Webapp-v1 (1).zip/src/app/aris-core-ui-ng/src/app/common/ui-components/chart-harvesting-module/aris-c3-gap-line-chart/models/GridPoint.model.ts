export interface GridPoint {
  value: number | Date;
  class: string;
  text?: string;
}
