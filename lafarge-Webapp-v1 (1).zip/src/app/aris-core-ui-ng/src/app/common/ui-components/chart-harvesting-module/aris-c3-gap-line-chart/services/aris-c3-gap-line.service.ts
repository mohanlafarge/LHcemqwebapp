import { Injectable } from "@angular/core";

import { DatePipe } from "@angular/common";

import * as d3_ from "d3";
import * as c3 from "c3";
let d3: any = (<any>d3_).default || d3_;
import * as dc from "dc";

import { TranslationService } from "angular-l10n";
import { ArisC3ChartService } from "../../../chart-module/services/aris-c3-chart.service";
import { ArisChartCommonService } from "../../../chart-module/services/aris-chart-common.service";
import { DataGap } from "../models/DataGap.model";
import { GridPoint } from "../models/GridPoint.model";
import { GapType } from "../models/GapType.enum";
declare var $: any;

@Injectable()
export class ArisC3GapLineService extends ArisC3ChartService {
  gaps: DataGap[];
  lineChart: any;

  constructor(
    protected arisChartCommonService: ArisChartCommonService,
    private datePipe: DatePipe,
    protected translation: TranslationService
  ) {
    super(arisChartCommonService, translation);
  }

  drawChart(chartScope) {
    this.lineChart = chartScope.data[0];
    this.lineChart.forEach((value) => {
      value['dateTime'] = new Date(value['dateTime']);
    });
    this.gaps = chartScope.data[1];
    let ygrid;
    if (chartScope.options.threshold.isTrue) {
      ygrid = this.createThresholds(chartScope);
    }
    chartScope.c3chart = c3.generate({
      bindto: chartScope.chartElement,
      size: {
        height: chartScope.options.height,
        width: chartScope.options.width
      },
      data: {
        json: this.lineChart,
        keys: {
          x: "dateTime",
          value: ["score"]
        },
        types: {
          score: "line"
        },
        colors: {
          score: "#01f1ff"
        },
        names: {
          score: "Score"
        }
      },
      point: {
        r: 5,
        focus: {
          expand: {
            r: 6
          }
        }
      },
      axis: {
        x: {
          type: "timeseries",
          localtime: false,
          tick: {
            format: "%d/%m",
            fit: false
          },
          height: 60
        },
        y: {
          min: 0,
          max: 100,
          padding: 10
        }
      },
      grid: {
        x: {
          show: true
        },
        y: {
          show: true,
          lines: ygrid
        }
      },
      regions: this.getRegions(),
      padding: {
        right: 15
      },
      legend: {
        hide: true
      }
    });
  }

  private createThresholds(chartScope): GridPoint[] {
    const thresholds = [];
    thresholds.push(
      {
        value: chartScope.options.threshold.upperThreshold.value,
        class: "c3-ygrid threshold threshold--upper",
        color: "yellow"
      },
      {
        value: chartScope.options.threshold.lowerThreshold.value,
        class: "c3-ygrid threshold threshold--lower",
        color: "red"
      }
    );
    return thresholds;
  }

  private getRegions(): any[] {
    return this.gaps.map(gap => ({
      axis: "x",
      start: gap.startDate,
      end: gap.endDate,
      class: gap.type === GapType.DOWNTIME ? "down-time" : "missing-data"
    }));
  }

  getCsvData(data: any) {
    let localData = data[0];
    localData.forEach(element => {
      element.dateTime = element.dateTime.toLocaleString().split(",").join("");
    });
    return localData;
  }
}
