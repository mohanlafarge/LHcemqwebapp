import { CommonModule, DatePipe, DecimalPipe } from "@angular/common";
import { NgModule, Injector } from "@angular/core";
import { LocalizationModule } from "angular-l10n";
import { ArisPipesModule } from "../../pipes/aris-pipes.module";
import { ArisC3ChartUptimeService } from "./uptime-chart/services/aris-c3-chart-uptime.service";
import { ArisUptimeChartComponent } from "./uptime-chart/aris-uptime-chart.component";
import { ArisC3GapLineService } from "./aris-c3-gap-line-chart/services/aris-c3-gap-line.service";

@NgModule({
  declarations: [],
  imports: [CommonModule, LocalizationModule, ArisPipesModule],
  providers: [ArisC3ChartUptimeService, ArisC3GapLineService],
  exports: []
})
export class ChartHarvestingModule {}
