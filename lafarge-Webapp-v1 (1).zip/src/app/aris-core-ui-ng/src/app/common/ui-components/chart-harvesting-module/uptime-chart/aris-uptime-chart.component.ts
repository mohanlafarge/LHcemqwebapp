import {
  Component,
  OnInit,
  OnChanges,
  ViewChild,
  ElementRef,
  Input,
  ViewEncapsulation,
  ContentChildren,
  ContentChild,
  EventEmitter,
  QueryList,
  Injector,
  AfterViewInit,
  OnDestroy
} from "@angular/core";
import { DatePipe } from "@angular/common";
import { Language, TranslationService } from "angular-l10n";
import * as d3 from "d3";
import * as dc from "dc";
import * as crossfilter_ from "crossfilter";
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;
import * as FileSaver from "file-saver";
import * as html2canvas_ from "html2canvas";
import { ArisChartComponent } from "../../chart-module/aris-chart.component";
import { UptimeConfig } from "./models/UptimeConfig.model";
import { ArisChartCommonService } from "../../chart-module/services/aris-chart-common.service";
import { ArisChartService } from "../../chart-module/services/aris-chart.service";
import { ArisLanguageService } from "../../../ui-page-sections/language-selector-module/services/aris-language.service";
import { ArisC3ChartUptimeService } from "./services/aris-c3-chart-uptime.service";
let html2canvas: any = (<any>html2canvas_).default || html2canvas_;

declare let $: any;
declare global {
  interface Window {
    chartOptions: any;
    chartData: any;
    chartType: any;
    pageName: any;
    opener: any;
    chartsConfig: any;
  }
}

@Component({
  selector: "aris-uptime-chart",
  templateUrl: "./aris-uptime-chart.component.html",
  styleUrls: [
    "../../../../../../lib/c3_css/c3.min.css",
    "../../chart-module/aris-chart.scss",
    "./aris-uptime-chart.component.scss"
  ],
  encapsulation: ViewEncapsulation.None,
  providers: [ArisC3ChartUptimeService]
})
export class ArisUptimeChartComponent extends ArisChartComponent
  implements OnInit, OnChanges, AfterViewInit, OnDestroy {
  @ViewChild("uptimeLineChart") uptimeLineChart: ElementRef;
  @ViewChild("arisChartContainer") arisChartContainer: ElementRef;
  chartData: UptimeConfig;
  uniqueChartClass: String;

  constructor(
    injector: Injector,
    arisChartCommonService: ArisChartCommonService,
    arisChartService: ArisChartService,
    transalation: TranslationService,
    arisTrans: ArisLanguageService
  ) {
    super(
      injector,
      arisChartCommonService,
      arisChartService,
      transalation,
      arisTrans
    );
    this.uniqueChartClass = "";
    console.log(this.uptimeLineChart);
    console.log(this.arisChartContainer);
  }

  getShapeColor(data: any) {
    return this.chartService.getShapeColor(data);
  }

  setLegendShape(data: any) {
    return this.chartService.setLegendShape(data);
  }
}
