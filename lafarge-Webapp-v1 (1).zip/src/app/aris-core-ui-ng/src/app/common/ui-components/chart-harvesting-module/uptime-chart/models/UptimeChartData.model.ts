import { UptimeShape } from "./UptimeShape.enum";

export interface UptimeChartData {
  name: string;
  value: number;
  class?: string;
  color?: string;
  type?: UptimeShape;
}
