import { UptimeChartData } from "./UptimeChartData.model";
import { UptimeThresholds } from "./UptimeThreshold.model";

export interface UptimeConfig {
  data: UptimeChartData[];
  upperLabel: any[];
  upperHeader: string;
  lowerLabel: any[];
  lowerHeader: string;
  thresholds?: UptimeThresholds;
}
