export enum UptimeShape {
  CIRCLE,
  TRIANGLE,
  RECTANGLE
}
