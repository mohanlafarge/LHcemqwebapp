export interface UptimeThresholds {
  upper: number;
  lower: number;
  upperColor: string;
  middleColor: string;
  lowerColor: string;
}
