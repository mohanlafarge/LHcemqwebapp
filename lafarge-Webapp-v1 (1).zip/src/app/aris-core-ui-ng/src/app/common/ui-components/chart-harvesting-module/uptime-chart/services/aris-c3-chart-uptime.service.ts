import { Injectable } from "@angular/core";

import { DatePipe } from "@angular/common";
import { v4 as uuid } from "uuid";

import * as d3_ from "d3";
import * as c3 from "c3";
let d3: any = (<any>d3_).default || d3_;
import * as dc from "dc";
import { TranslationService } from "angular-l10n";
import { ArisC3ChartService } from "../../../chart-module/services/aris-c3-chart.service";
import { ArisChartCommonService } from "../../../chart-module/services/aris-chart-common.service";
import { UptimeShape } from "../models/UptimeShape.enum";
import { UptimeChartData } from "../models/UptimeChartData.model";
declare var $: any;

@Injectable()
export class ArisC3ChartUptimeService extends ArisC3ChartService {
  defaultColor = "#dddddd";

  constructor(
    protected arisChartCommonService: ArisChartCommonService,
    private datePipe: DatePipe,
    protected translation: TranslationService
  ) {
    super(arisChartCommonService, translation);
  }

  drawChart(chartScope) {
    chartScope.chartData = chartScope.data[0];
    chartScope.uniqueChartClass = "a" + uuid();
    const valuePoints = this.arrangeValuePoints(chartScope);
    const xAxisLine = this.arrangeXAxisLine(chartScope);
    const lowerLabel = chartScope.chartData.lowerLabel;
    chartScope.c3chart = c3.generate({
      bindto: chartScope.uptimeLineChart.nativeElement,
      data: {
        x: "valuePoints",
        columns: [valuePoints, xAxisLine]
      },
      axes: {
        xAxisLine: "y"
      },
      size: {
        height: 120
      },
      legend: {
        show: false
      },
      axis: {
        x: {
          show: true,
          tick: {
            values: lowerLabel
          },
          min: this.arrangeStartPoint(chartScope),
          max: this.arrangeEndPoint(chartScope),
          padding: 0
        },
        y: {
          show: true,
          tick: {
            count: 2
          },
          max: 1,
          min: -1
        },
        y2: {
          show: true,
          tick: {
            count: 2
          },
          max: 1,
          min: -1
        }
      },
      tooltip: {
        grouped: false,
        contents: d => {
          const temp = d[0];
          if (
            temp.index === 0 ||
            temp.index > chartScope.chartData.data.length
          ) {
            return;
          }
          return `<table class='c3-tooltip' style="color: black;">
               <tr class='c3-tooltip-name'>
               <td class='name'>
               <span style="background-color: ${
                 chartScope.chartData.data[temp.index - 1].color
               };">
               </span>
               ${chartScope.chartData.data[temp.index - 1].name}
               </td>
               <td>
               ${chartScope.chartData.data[temp.index - 1].value}
              </td>
              </tr>
              </table>`;
        }
      },
      onrendered: () => {
        this.removeSameElements(chartScope);
        this.addYAxisLabelText(chartScope);
        this.addUpperLabels(chartScope);
        this.setShapeAndColor(chartScope);
        this.moveLabelsUp(chartScope);
      }
    });
  }

  private sortData(chartScope) {
    chartScope.chartData.data.sort((pre, cur) => pre.value - cur.value);
  }

  private arrangeValuePoints(chartScope): any[] {
    return ["valuePoints", this.arrangeStartPoint(chartScope)].concat(
      ...this.getDataValues(chartScope),
      this.arrangeEndPoint(chartScope)
    );
  }

  private arrangeXAxisLine(chartScope): any[] {
    const xAxisLine = this.arrangeValuePoints(chartScope).fill(0);
    xAxisLine[0] = "xAxisLine";
    return xAxisLine;
  }

  private arrangeStartPoint(chartScope): number {
    return (
      chartScope.chartData.lowerLabel[0] -
      (chartScope.chartData.lowerLabel[1] - chartScope.chartData.lowerLabel[0])
    );
  }

  private arrangeEndPoint(chartScope): number {
    return (
      chartScope.chartData.lowerLabel[
        chartScope.chartData.lowerLabel.length - 1
      ] +
      (chartScope.chartData.lowerLabel[
        chartScope.chartData.lowerLabel.length - 1
      ] -
        chartScope.chartData.lowerLabel[
          chartScope.chartData.lowerLabel.length - 2
        ])
    );
  }

  private getDataValues(chartScope): number[] {
    return chartScope.chartData.data.map(data => data.value);
  }

  private setShapeAndColor(chartScope): void {
    chartScope.chartData.data.forEach((data, index) => {
      const circleClass = ".c3-circle-" + (index + 1);
      if (chartScope.chartData.thresholds) {
        chartScope.chartData.data[index].color = this.getThresholdColor(
          chartScope,
          chartScope.chartData.data[index].value
        );
      }
      const line = d3
        .select(chartScope.uptimeLineChart.nativeElement)
        .select(` .c3-circles-xAxisLine`);
      const circle = d3
        .select(chartScope.uptimeLineChart.nativeElement)
        .select(` .c3-circles-xAxisLine ${circleClass}`);
      const defaultClass = circle.attr("class").replace(" hide", "");
      const xCoord = circle[0][0]["cx"].baseVal.value;
      const yCoord = circle[0][0]["cy"].baseVal.value;
      circle
        .attr("class", `${defaultClass} data-circle ${data.class}`)
        .style(
          "fill",
          data.color ? data.color : this.setDefaultColor(chartScope, index)
        );
      if (
        this.setShape(line, data.type, data.color, xCoord, yCoord, defaultClass)
      ) {
        circle.attr("class", `${defaultClass} hide`);
      }
    });
  }

  private setDefaultColor(chartScope: any, index: number): string {
    chartScope.chartData.data[index].color = this.defaultColor;
    return chartScope.chartData.data[index].color;
  }

  private addYAxisLabelText(chartScope): void {
    d3.select(chartScope.uptimeLineChart.nativeElement)
      .select(` svg`)
      .style("overflow", "visible");

    d3.select(chartScope.uptimeLineChart.nativeElement)
      .select(` svg`)
      .append("text")
      .attr("class", "y-axis-label-text")
      .text(chartScope.chartData.upperHeader)
      .attr("dx", 10)
      .attr("dy", -8);

    d3.select(chartScope.uptimeLineChart.nativeElement)
      .select(` svg`)
      .append("text")
      .attr("class", "y-axis-label-text")
      .text(chartScope.chartData.lowerHeader)
      .attr("dx", 10)
      .attr("dy", 110);
  }

  private addUpperLabels(chartScope): void {
    const svg = d3
      .select(chartScope.uptimeLineChart.nativeElement)
      .select(` svg`);
    const ticks = d3
      .select(chartScope.uptimeLineChart.nativeElement)
      .selectAll(` .c3-axis-x .tick`);
    const upperLabelContainer = svg
      .append("g")
      .attr("class", "upper-label-container")
      .attr("transform", `translate(${this.getSidePadding(chartScope)}, 15)`);
    const hasThreshold = chartScope.chartData.thresholds;
    ticks.each((datum, index) => {
      const tick = d3.select(ticks[0][index]);
      const transform = tick.attr("transform");
      const color = hasThreshold
        ? this.getThresholdColor(chartScope, datum)
        : "#fff";
      tick.select("text").style("fill", color);
      const xValue = this.getTranslateX(transform);
      upperLabelContainer
        .append("text")
        .attr("class", "upper-label-text")
        .text(chartScope.chartData.upperLabel[index])
        .attr("x", xValue)
        .style("fill", color);
    });
  }

  private moveLabelsUp(chartScope): void {
    const lowerLabel = d3
      .select(chartScope.uptimeLineChart.nativeElement)
      .select(` .c3-axis-x`);
    d3.select(chartScope.uptimeLineChart.nativeElement)
      .select(` .c3-axis-x`)
      .attr(
        "transform",
        `translate(0, ${this.getTranslateY(lowerLabel.attr("transform")) - 15})`
      );
  }

  private getTranslateX(translateString: string): number {
    const openingParanthesisIndex = translateString.indexOf("(");
    const commaIndex = translateString.indexOf(",");
    return +translateString.substring(openingParanthesisIndex + 1, commaIndex);
  }

  private getTranslateY(translateString: string): number {
    const openingParanthesisIndex = translateString.indexOf(",");
    const commaIndex = translateString.indexOf(")");
    return +translateString.substring(openingParanthesisIndex + 1, commaIndex);
  }

  private getSidePadding(chartScope): number {
    console.log(
      d3.select(chartScope.uptimeLineChart.nativeElement).select(`svg g`)
    );
    return this.getTranslateX(
      d3
        .select(chartScope.uptimeLineChart.nativeElement)
        .select(` svg g`)
        .attr("transform")
    );
  }

  private getThresholdColor(chartScope: any, value: number): string {
    if (value <= chartScope.chartData.thresholds.lower) {
      return chartScope.chartData.thresholds.lowerColor;
    }
    if (
      chartScope.chartData.thresholds.lower < value &&
      value < chartScope.chartData.thresholds.upper
    ) {
      return chartScope.chartData.thresholds.middleColor;
    }
    return chartScope.chartData.thresholds.upperColor;
  }

  private setShape(
    line: d3.Selection<any>,
    type: number,
    color: string,
    x: number,
    y: number,
    defaultClass: string
  ): boolean {
    if (type === UptimeShape.RECTANGLE) {
      this.createRect(line, color, x, y, defaultClass);
      return true;
    }
    if (type === UptimeShape.TRIANGLE) {
      this.createTriangle(line, color, x, y, defaultClass);
      return true;
    }
    return false;
  }

  private createRect(
    line: d3.Selection<any>,
    color: string,
    x: number,
    y: number,
    defaultClass: string
  ) {
    const size = 25;
    line
      .append("rect")
      .attr("class", `${defaultClass} data-rect`)
      .attr("x", x)
      .attr("y", y)
      .attr("width", size)
      .attr("height", size)
      .style("fill", color)
      .style("transform", `translate(${-size / 2}px, ${-size / 2}px)`);
  }

  private createTriangle(
    line: d3.Selection<any>,
    color: string,
    x: number,
    y: number,
    defaultClass: string
  ) {
    const size = 15;
    line
      .append("path")
      .attr(
        "d",
        `M ${x - size}, ${y + size}, L ${x}, ${y - size}, L ${x + size}, ${y +
          size} Z`
      )
      .attr("class", `${defaultClass} data-tri`)
      .style("fill", color);
  }

  public setLegendShape(type: UptimeShape): string {
    if (type && type === UptimeShape.RECTANGLE) {
      return "legend-rect";
    }
    if (type && type === UptimeShape.TRIANGLE) {
      return "legend-tri";
    }
    return "legend-circle";
  }

  public getShapeColor(data: UptimeChartData): any {
    if (data.type && data.type === UptimeShape.TRIANGLE) {
      return { "border-bottom-color": data.color };
    }
    return { "background-color": data.color };
  }

  private removeSameElements(chartScope): void {
    d3.select(chartScope.uptimeLineChart.nativeElement)
      .select(` .upper-label-container`)
      .remove();
    d3.select(chartScope.uptimeLineChart.nativeElement)
      .select(` .y-axis-label-text`)
      .remove();
    d3.select(chartScope.uptimeLineChart.nativeElement)
      .select(
        ` .c3-circles-xAxisLine .c3-circle-${chartScope.chartData.data.length +
          1}`
      )
      .style("display", "none");
    d3.select(chartScope.uptimeLineChart.nativeElement)
      .select(` .c3-circles-xAxisLine .c3-circle-0`)
      .style("display", "none");
    d3.select(chartScope.uptimeLineChart.nativeElement)
      .select(` .c3-circles-xAxisLine .data-rect`)
      .remove();
    d3.select(chartScope.uptimeLineChart.nativeElement)
      .select(` .c3-circles-xAxisLine .data-tri`)
      .remove();
  }

  getCsvData(data: any) {
    return data[0].data;
  }
}
