// /* tslint:disable:no-unused-variable */
// import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
// import { ArisChartComponent } from './aris-chart.component';
// import { ArisChartCommonService } from './services/aris-chart-common.service';
// import { DebugElement } from '@angular/core';
// import { DatePipe, DecimalPipe } from '@angular/common';
// import { By } from '@angular/platform-browser';
// import { ArisDcCustomRowChartService } from './services/aris-dc-chart-customrow.service';
// import { ArisDcChartService } from './services/aris-dc-chart.service';
// import { ArisDcAreaChartService } from './services/aris-dc-chart-area.service';
// import { Language, LocalizationModule, TranslationService, InjectorRef } from 'angular-l10n';
// import { ArisPipesModule } from '../../../common/pipes/aris-pipes.module';
// import { Observable } from 'rxjs/Observable';
// import { ArisChartService } from './services/aris-chart.service';
// import { ArisConfigService } from '../../../common/services/aris-config.service';
// import { HttpClient, HttpHandler } from '@angular/common/http';
// import { ArisLanguageService } from '../../../common/ui-page-sections/language-selector-module/services/aris-language.service';

// let mockTranslationService = {
//   translate: jasmine.createSpy('translate'),
//   translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
// };
// describe('Component: ArisChartComponent', () => {
//   let component: ArisChartComponent;
//   let fixture: ComponentFixture<ArisChartComponent>;
//   let componentDiv: DebugElement;
//   let componentEl: DebugElement;
// //   let authService: AuthService;

//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       declarations: [ArisChartComponent],
//       providers: [HttpClient, HttpHandler, InjectorRef, ArisChartCommonService, DatePipe, ArisChartService, ArisConfigService, ArisLanguageService, DecimalPipe,
//         ArisDcCustomRowChartService, ArisDcChartService, ArisDcAreaChartService, { provide: TranslationService, useValue: mockTranslationService }],
//       imports: [LocalizationModule, ArisPipesModule]
//     }).compileComponents();
//   });

//   beforeEach(() => {
//       // create component and test fixture
//     fixture = TestBed.createComponent(ArisChartComponent);

//     // get test component from the fixture
//     component = fixture.componentInstance;

//     // component.data = [{ projectCount: 4, contractorCompanyName: 'CiSCo 8' },
//     // { projectCount: 114, contractorCompanyName: 'Contractor (Regular Award)' }];

//     // component.data = [{ title: 'PRODUCTION', supplyStatus: 16.08033 },
//     // { title: 'TARGET', supplyStatus: 26.0 }, { title: 'DEMAND', supplyStatus: 27.530473926 }];

//     // component.type = "customrow" ;
//     // component.options = {
//     //   height: 200,
//     //   width: 200,
//     //   xAxisAttribute: 'title',
//     //   yAxisAttribute: 'supplyStatus',
//     //   chartTitle: 'Custom Row Chart',
//     //   exportable: true,
//     //   openWindow: false,
//     // };

//   });

//     // // UserService provided to the TestBed
//     // authService = TestBed.get(AuthService)

//   // it('export executed', () => {
//   //   let arisChartService = TestBed.get(ArisChartService);
//   //   spyOn(arisChartService, 'export').and.callThrough();
//   //   let chartScope = { chartService: { preExportAsPNG() {}, exportAsPNG() {} } };
//   //   arisChartService.onClickExportAsPNG(chartScope);
//   //   component.export("png");
//   //   expect(arisChartService.export).toHaveBeenCalled();
//   //   expect(component.exporting).toBeTruthy();
//   // });

//   it('export executed else', () => {
//     component.chartOptionsChangeSubscription = undefined;
//     component.exporting = false;
//     let arisChartService = TestBed.get(ArisChartService);
//     spyOn(arisChartService, 'export').and.callThrough();
//     component.export("true");
//     expect(arisChartService.export).toHaveBeenCalled();
//   });

//   // it('export executed else', () => {
//   //   component.chartOptionsChangeSubscription = undefined;
//   //   component.exporting = false;
//   //   let arisChartService = TestBed.get(ArisChartService);
//   //   spyOn(arisChartService, 'export').and.callThrough();
//   //   component.export("true");
//   //   expect(arisChartService.export).toHaveBeenCalled();
//   // });

//   it('ngOnInit else scenario', () => {
//     component.type = "DC_AREA_CHART";
//     component.chart = true;
//     component.data = "data";
//     component.ngOnInit();
//     expect(component.chartService).toBeUndefined();
//   });

//   it('ngOnChanges else scenario', () => {
//     component.type = "DC_AREA_CHART";
//     component.chart = { svg() {} };
//     component.data = "data";
//     component.ngOnChanges();
//     expect(component).toBeTruthy();
//   });

//   // it('ngOnChanges if scenario', () => {
//   //   component.type = "DC_AREA_CHART";
//   //   component.chart = { svg() { return true; } };
//   //   component.data = null;
//   //   component.ngOnChanges();
//   //   expect(component).toBeTruthy();
//   // });

//   // it('ngOnInit if scenario', () => {
//   //   component.type = "DC_AREA_CHART";
//   //   component.data = "data";
//   //   component.chart = false;
//   //   let chartScope = { options: { scale: 'ordinal' } };
//   //   let arisChartService = TestBed.get(ArisChartService);
//   //   spyOn(arisChartService, 'init').and.callThrough();
//   //   component.ngOnInit();
//   //   expect(arisChartService.init).toHaveBeenCalledWith(chartScope);
//   //   expect(component.chartService).toBeDefined();
//   // });

//   // it('svg element is created', () => {
//   //   chartsTestConfig.forEach((value, key) => {
//   //     component.data = value.data;
//   //     component.type = value.type;
//   //     component.options = value.options;

//   //     component.ngOnInit();
//   //     componentEl = fixture.debugElement.query(By.css('.dc-chart'));
//   //     console.log(component);
//   //     expect(componentEl.nativeElement.querySelector('svg')).toBeTruthy();
//   //   });
//   // });


//   // it('Should translate markdown to HTML!',
//   //   inject([ArisDcCustomRowChartService, ArisDcChartService],
//   //      (arisDcCustomRowChartService, arisDcChartService) => {
//   //     spyOn(component, 'ngOnInit');
//   //     spyOn(arisDcCustomRowChartService, 'init');
//   //        chartsTestConfig.forEach((value, key) => {
//   //          component.data = value.data;
//   //          component.type = value.type;
//   //          component.options = value.options;

//   //          component.ngOnInit();

//   //          spyOn(arisDcChartService, 'setupTip');

//   //          arisDcCustomRowChartService.setGroup(component);

//   //          component.chart

//   //       // component.chart.group().all().
//   //        });

//   //  }));

// });
