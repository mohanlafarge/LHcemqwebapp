import {
  Component,
  OnInit,
  OnChanges,
  ViewChild,
  ElementRef,
  Input,
  ViewEncapsulation,
  ContentChildren,
  ContentChild,
  EventEmitter,
  QueryList,
  Injector,
  AfterViewInit,
  OnDestroy
} from "@angular/core";
import { DatePipe } from "@angular/common";
import { Language, TranslationService } from "angular-l10n";
import * as d3 from "d3";
import * as dc from "dc";
import * as crossfilter_ from "crossfilter";
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;
import * as FileSaver from "file-saver";
import * as html2canvas_ from "html2canvas";
let html2canvas: any = (<any>html2canvas_).default || html2canvas_;
import { ArisDcChartErrbarService } from "./services/aris-dc-chart-errbar.service";
import { ArisChartCommonService } from "./services/aris-chart-common.service";
import { ArisChartService } from "./services/aris-chart.service";
import { ArisChartEventService } from "./services/aris-chart-event.service";
import { Subscription } from "rxjs/Subscription";
import { ArisLanguageService } from "../../ui-page-sections/language-selector-module/services/aris-language.service";

declare let $: any;
declare global {
  interface Window {
    chartOptions: any;
    chartData: any;
    chartType: any;
    pageName: any;
    opener: any;
    chartsConfig: any;
  }
}

@Component({
  selector: "aris-chart",
  templateUrl: "./aris-chart.component.html",
  styleUrls: [
    "../../../../../lib/dc_css/dc.min.css",
    "../../../../../lib/c3_css/c3.min.css",
    "../../../../../lib/nvd3_css/nv.d3.min.css",
    "./aris-chart.scss"
  ],
  encapsulation: ViewEncapsulation.None,
  providers: []
})
export class ArisChartComponent
  implements OnInit, OnChanges, AfterViewInit, OnDestroy {
  public chartService: any;
  public chartOptionsChangeSubscription: Subscription;

  @Language() lang: string;
  languageSubscription: Subscription;

  constructor(
    protected injector: Injector,
    protected arisChartCommonService: ArisChartCommonService,
    protected arisChartService: ArisChartService,
    protected transalation: TranslationService,
    protected arisTrans: ArisLanguageService
  ) {}

  @ViewChild("arisChartContainer") protected arisChartContainer: ElementRef;
  @ViewChild("chart") protected chartContainer: ElementRef;
  @Input() data: any;
  @Input() type: string;
  @Input() options: any;
  data1: any;
  public chart: any;
  private dcChartScope: any;
  public exporting: boolean;
  public onChangesCount = 0;

  ngOnInit() {
    this.languageSubscription = this.arisTrans.languageChange.subscribe(() => {
      if (this.chart) {
        this.arisChartService.updateChart(this);
      }
    });
    this.chartOptionsChangeSubscription = this.arisChartCommonService.chartOptionsChange.subscribe(
      data => {
        if (this.chart) {
          this.arisChartService.updateChart(this);
        }
      }
    );
  }

  initChart() {
    this.chartService = this.injector.get(
      window.app.config.chartsConfig[this.type].service
    );
    if (this.data && this.data.length > 0 && !this.chart) {
      this.data1 = JSON.stringify(this.data);
      this.chartService.init(this, this.arisChartContainer.nativeElement);
    }
  }
  getChart() {
    return this.chart;
  }

  resizeFn() {
    this.arisChartService.resizeChart(this);
  }

  ngOnChanges() {
    if (this.data && this.chart && this.chart.svg()) {
      this.arisChartService.updateChart(this);
    } else if (this.data && this.data.length > 0 && !this.chart) {
      this.initChart();
    }
  }

  ngAfterViewInit() {
    this.initChart();
  }

  export(type) {
    if (type === "png") {
      this.exporting = true;
    }
    this.arisChartService.export(type, this);
  }

  openInNewWindow() {
    this.arisChartCommonService.openInNewWindow(this);
  }

  ngOnDestroy() {
    if (this.chartOptionsChangeSubscription) {
      this.chartOptionsChangeSubscription.unsubscribe();
    }
    if (this.languageSubscription) {
      this.languageSubscription.unsubscribe();
    }
  }
}
