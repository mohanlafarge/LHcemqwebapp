import { CommonModule, DatePipe, DecimalPipe } from "@angular/common";
import { NgModule, Injector, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { LocalizationModule } from "angular-l10n";
import { ArisChartComponent } from "./aris-chart.component";
import { ArisChartService } from "./services/aris-chart.service";
import { ArisChartCommonService } from "./services/aris-chart-common.service";
import { ArisDcLineChartService } from "./services/aris-dc-chart-line.service";
import { ArisDcPieChartService } from "./services/aris-dc-chart-pie.service";
import { ArisDcChartRowService } from "./services/aris-dc-chart-row.service";
import { ArisDcChartScatterService } from "./services/aris-dc-chart-scatter.service";
import { ArisNvd3LineChartService } from "./services/aris-nvd3-line-chart.service";
import { ArisC3LineChartService } from "./services/aris-c3-chart-line.service";
import { ArisDcChartCompositeMultilineService } from "./services/aris-dc-chart-composite-multiline.service";
import { ArisDChartMultilineService } from "./services/aris-dc-chart-multiline.service";
import { ArisDcAreaChartService } from "./services/aris-dc-chart-area.service";
import { ArisDcChartBarService } from "./services/aris-dc-chart-bar.service";
import { ArisSankeyChartService } from "./services/aris-sankey-chart.service";
import { ArisDcChartErrbarService } from "./services/aris-dc-chart-errbar.service";
import { ArisDcChartBarLineService } from "./services/aris-dc-chart-bar-line.service";
import { ArisDcChartStkRowService } from "./services/aris-dc-chart-stkrow.service";
import { ArisDcChartCustomBarService } from "./services/aris-dc-chart-custombar.service";
import { ArisDcHorizontalErrorBarChartService } from "./services/aris-dc-chart-horizerrbar.service";
import { ArisDcStkBarChartService } from "./services/aris-dc-chart-stkbar.service";
import { ArisDcCustomRowChartService } from "./services/aris-dc-chart-customrow.service";
import { ArisLiquidFillGaugeComponent } from "./aris-liquid-fill-gauge.component";
import { ArisPipesModule } from "../../../common/pipes/aris-pipes.module";
import { ArisNvd3BarChartService } from "./services/aris-nvd3-bar-chart.service";
import { ArisSimpleGauge } from "./aris-simple-gauge.component";
import { ArisLoadingModule } from "../aris-loading-module/aris-loading.module";
import { ArisUptimeChartComponent } from "../chart-harvesting-module/uptime-chart/aris-uptime-chart.component";
import { ChartHarvestingModule } from "../chart-harvesting-module/chart-harvesting.module";
import { ArisC3GapLineService } from "../chart-harvesting-module/aris-c3-gap-line-chart/services/aris-c3-gap-line.service";

@NgModule({
    declarations: [
        ArisChartComponent,
        ArisLiquidFillGaugeComponent,
        ArisSimpleGauge,
        ArisUptimeChartComponent
    ],
    imports: [
        CommonModule,
        LocalizationModule,
        ArisPipesModule,
        ArisLoadingModule,
        ChartHarvestingModule
    ],
    providers: [
        ArisChartService,
        ArisChartCommonService,
        DatePipe,
        DecimalPipe,
        ArisDcAreaChartService,
        ArisDcHorizontalErrorBarChartService,
        ArisDcLineChartService,
        ArisDcPieChartService,
        ArisDcChartRowService,
        ArisDcStkBarChartService,
        ArisDcChartStkRowService,
        ArisDcChartScatterService,
        ArisNvd3LineChartService,
        ArisC3LineChartService,
        ArisDcChartCompositeMultilineService,
        ArisDChartMultilineService,
        ArisDcCustomRowChartService,
        ArisDcChartCustomBarService,
        ArisDcChartBarService,
        ArisSankeyChartService,
        ArisDcChartErrbarService,
        ArisDcChartBarLineService,
        ArisNvd3BarChartService,
        ArisC3GapLineService
    ],
    exports: [
        ArisChartComponent,
        ArisLiquidFillGaugeComponent,
        ArisSimpleGauge,
        ArisUptimeChartComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ChartModule { }
