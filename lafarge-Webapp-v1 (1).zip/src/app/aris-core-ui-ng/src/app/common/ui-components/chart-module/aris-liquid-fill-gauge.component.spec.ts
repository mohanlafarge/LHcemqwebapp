/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';

import { DebugElement, SimpleChanges } from '@angular/core';
import { DatePipe } from '@angular/common';
import { By } from '@angular/platform-browser';
import { ArisLiquidFillGaugeComponent } from './aris-liquid-fill-gauge.component';




describe('Service: ArisLiquidFilledGuage', () => {

  let component: ArisLiquidFillGaugeComponent;
  let fixture: ComponentFixture<ArisLiquidFillGaugeComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisLiquidFillGaugeComponent],
      providers: []
    }).compileComponents();
  });

  beforeEach(() => {
      // create component and test fixture
    fixture = TestBed.createComponent(ArisLiquidFillGaugeComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    component.color = "#ff0000";
    component.exp = 1;
    component.id = "liq2";
    component.isRunning = true;
    component.size = "70";


  });

  it('svg element is created', () => {
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('svg'));
    expect(componentEl.nativeElement).toBeTruthy();
  });

  it('ngOnInit if scenario', () => {
    component.value = 0;
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('svg'));
    expect(componentEl.nativeElement).toBeTruthy();
  });

  it('onValueChange first if and second if scenario', () => {
    component.showGauge = true;
    component.guage1 = { update() {}, pause() {} };
    let obj = { expression: 10, waveAnimateTime: '', color: 'red' };
    component.onValueChange("", obj);
    expect(component.showGauge).toBeTruthy();
  });

  it('ngOnChanges else scenario', () => {
    component.showGauge = true;
    component.color = 'asdsdasd';
    let data: SimpleChanges;
    component.ngOnChanges(data);
    expect(component.showGauge).toBeTruthy();
  });


});
