import { AfterContentInit, Component, ElementRef, Inject, Input, OnChanges, OnInit, ViewChild } from '@angular/core';
import * as liquidFillGuage from '../chart-module/charts/liquidfilledgauge';
import { SimpleChanges, AfterViewChecked } from '@angular/core/src/metadata/lifecycle_hooks';
declare var $: any;
import { SimpleChange } from '@angular/core/src/change_detection/change_detection_util';

@Component({
  selector: 'aris-liquid-fill-gauge',
  template: '<svg width="50" height="50"></svg>'
})

 export class ArisLiquidFillGaugeComponent implements OnInit, OnChanges {
  showGauge: boolean;
  width: any;
  height: any;
  svgId: any;
  guage1: any;
  config1: any;
  exp: any;
  @Input() id: string;
  @Input() value: any;
  @Input() color: string;
  @Input() data: any;
  @Input() size: any;
  @Input() isRunning: boolean;
  
  @Input() minValue: number;
  @Input() maxValue: number;

  @Input() chartConfig: any;
  constructor(private element: ElementRef) { }



  ngOnInit() {
    try {
      this.exp = parseInt((isNaN(this.value) ? 1 : this.value), 10);
      if (this.exp === 0) {
        this.exp = 1;
      }
    } catch (e) {
      this.exp = 1;
    }
    this.svgId = this.id;
    //added :not([id]).first() to below line because if was assigning last received properties to all svg elements
    $('svg:not([id])').first().attr({ id: 'id-' + this.svgId, width: this.size, height: this.size });
    this.config1 = liquidFillGuage.default.liquidFillGaugeDefaultSettings();
    this.config1.circleColor = this.colorLuminance(this.color, -0.3);
    this.config1.textColor = this.colorLuminance(this.color, -0.3);
    this.config1.waveTextColor = this.colorLuminance(this.color, -0.3);
    this.config1.waveColor = this.convertHex(this.color, 90);
    this.config1.waveAnimateTime = 1000;

    this.config1.minValue = this.minValue ? this.minValue : this.config1.minValue;
    this.config1.maxValue = this.maxValue ? this.maxValue : this.config1.maxValue;
    if (this.chartConfig) {
      this.config1.displayPercent = this.chartConfig.displayPercent != undefined ? this.chartConfig.displayPercent : this.config1.displayPercent;
      this.config1.circleThickness = this.chartConfig.circleThickness ? parseFloat(this.chartConfig.circleThickness) : this.config1.circleThickness;
      this.config1.waveHeight = this.chartConfig.waveHeight ? parseFloat(this.chartConfig.waveHeight) : this.config1.waveHeight;
      this.config1.textColor = this.chartConfig.textColor ? this.chartConfig.textColor : this.config1.textColor;
      this.config1.waveTextColor = this.chartConfig.waveTextColor ? this.chartConfig.waveTextColor : this.config1.waveTextColor;
    }

    this.onValueChange(null, { expression: this.value, color: this.color });
  }


  ngOnChanges(changes: SimpleChanges) {
    let valueChange = changes;
    try {
      if (valueChange.value) {
        if (valueChange.value.previousValue !== valueChange.value.currentValue) {
          this.onValueChange(null, { expression: valueChange.value.currentValue, color: this.color });
        }
      }
    } catch (err) {
      if (this.color.length <= 6) {
        if (valueChange.color) {
          if (valueChange.color.previousValue !== valueChange.color.currentValue) {
            this.onValueChange(null, { expression: this.value, color: valueChange.color.currentValue });
          }
        }
      }
    }
  }

  onValueChange(args, obj) {
    if (obj.expression === "" || isNaN(obj.expression)) {
      obj.expression = 1;
    }
    obj.waveAnimateTime = 1000;
    if (obj.expression > 1 && obj.expression <= 100) {
      obj.waveAnimateTime = ((obj.expression) / 100) * 1000 + 500;
    }
    obj.circleColor = this.colorLuminance(obj.color, -0.3);
    obj.textColor = this.colorLuminance(obj.color, -0.3);
    obj.waveTextColor = this.colorLuminance(obj.color, -0.3);
    obj.waveColor = this.convertHex(obj.color, 90);
    if (this.chartConfig) {
      obj.textColor = this.chartConfig.textColor ? this.chartConfig.textColor : this.config1.textColor;
      obj.waveTextColor = this.chartConfig.waveTextColor ? this.chartConfig.waveTextColor : this.config1.waveTextColor;
    }

    if (obj.expression !== undefined && !isNaN(obj.expression)) {
      if (this.showGauge) {
        this.guage1.update(parseInt(obj.expression, 10), obj, this.element);
      } else {
        this.guage1 = liquidFillGuage.default.loadLiquidFillGauge('id-' + this.svgId, this.exp, this.config1);
        this.showGauge = true;
      }
    }
    if (this.guage1) {
      this.guage1.pause(!this.isRunning);
    }
  }

  convertHex(hex, opacity) {
    let newHex = hex.replace('#', '');
    let r = parseInt(newHex.substring(0, 2), 16);
    let g = parseInt(newHex.substring(2, 4), 16);
    let b = parseInt(newHex.substring(4, 6), 16);

    let result = 'rgba(' + r + ',' + g + ',' + b + ',' + opacity / 100 + ')';
    return result;
  }

  colorLuminance(hex: string, lum: number) {
    let newHex: string;
    let newLum;
    newHex = hex.replace(/[^0-9a-f]/gi, '');
    if (newHex.length < 6) {
      newHex = newHex[0] + newHex[0] + newHex[1] + newHex[1] + newHex[2] + newHex[2];
    }
    newLum = lum || 0;
    let rgb = '#';
    let c: any;
    let i = 0;
    while (i < 3) {
      c = parseInt(newHex.substr(i * 2, 2), 16);
      c = Math.round(Math.min(Math.max(0, c + (c * lum)), 255)).toString(16);
      rgb += ('00' + c.toString()).substr(c.toString().length);
      i += 1;
    }
    return rgb;
  }

}

