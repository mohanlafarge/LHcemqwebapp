import { Component, Input, Output, EventEmitter, OnInit, OnChanges, ViewChild, ElementRef, AfterContentChecked, AfterContentInit } from '@angular/core';
import * as c3 from 'c3';
import * as d3 from 'd3';

@Component({
  selector: 'aris-simple-gauge',
  templateUrl: './aris-simple-gauge.component.html'
})

// tslint:disable-next-line:component-class-suffix
export class ArisSimpleGauge implements OnInit, OnChanges {
  @ViewChild('arisSimpleGauge') private arisSimpleGauge: ElementRef;
  @Input() title: any;
  @Input() value: any = 0;
  @Input() min: any;
  @Input() max: any;

  chart: any;

  constructor() {
  }

  ngOnInit(): void {

    this.chart = c3.generate({
      bindto: this.arisSimpleGauge.nativeElement,
      data: {
        columns: [
                  ['data', 0]
        ],
        type: 'gauge',
      },
      gauge: {
        min: this.min,
        max: this.max,
        label: {
          format(value, ratio) {
            return value; // returning here the value and not the ratio
          },
        }
      },

      color: {
        pattern: ['#60B044', '#F6C600', '#F6C700', '#FF0000'], // the three color levels for the percentage values.
        threshold: {
          unit: 'value',
//            unit: 'value', // percentage is default
//            max: 200, // 100 is default
          values: [60, 80, 90] // alternate first value is 'value'
        }
      },
      tooltip: {
        show: false
      }
    });

    d3.select(this.arisSimpleGauge.nativeElement.querySelector('.c3-chart-arcs-background'))
    .transition()
    .style('opacity', "0.3");

    d3.select(this.arisSimpleGauge.nativeElement.querySelector('svg')).append("text")
    .attr("x", 45)
    .attr("y", 85)
    .attr("font-size", "1.1em")
    .style("text-anchor", "middle")
    .text(this.title);
  }

  ngOnChanges(changes: any) {
    setTimeout(() => {
      this.chart.load({
        columns: [['data', this.value.toFixed(2)]]
      });
    }, 100);
  }

}
