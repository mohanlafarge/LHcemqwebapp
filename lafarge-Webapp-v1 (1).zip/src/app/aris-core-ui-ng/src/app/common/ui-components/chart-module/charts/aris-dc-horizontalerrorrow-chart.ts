/**
* aris row Horiz Error chart
*/
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc_ from 'dc';
let dc: any = (<any>dc_).default || dc_;
    function arisHorizontalErrorRowChart(dc, parent, chartGroup) {
    var _chart = dc.rowChart(parent, chartGroup);
    var _minErrorAccessor;
    var _maxErrorAccessor;
    var _errorEndPointHeight;


    /**
     * Add error lines on row-chart.
     */
    var addErrorLines = function(chart){
      //Remove old error-bar elements.
      chart.selectAll('g.row .errorbar').remove();

      var barHeight = chart.select('g.row rect').empty() ? 0 : chart.select('g.row rect').attr('height')/2.0;
      var errorEndPointHeight = chart.errorEndPointHeight()? _chart.errorEndPointHeight():5;


      var ebar = chart.selectAll('g.row')
       .append('g')
        .attr('class', 'errorbar');
      ebar
        .append('line')
        .attr({
          'stroke-width': 1,
          stroke: 'orange',
          x1: function(d) {
            return chart.x()(chart.minErrorAccessor()(d));
          },
          y1: function(d) {
            return barHeight; 
          },
          x2: function(d) {
            return chart.x()(chart.maxErrorAccessor()(d));
          },
          y2: function(d) {
            return  barHeight; 
          }
        });
      ebar.append('line')
        .attr({
          'stroke-width': 1,
          stroke: 'orange',
          x1: function(d) {
            return chart.x()(chart.minErrorAccessor()(d));
          },
          y1: function(d) {
            return barHeight- errorEndPointHeight;
          },
          x2: function(d) {
            return chart.x()(chart.minErrorAccessor()(d));
          },
          y2: function(d) {
            return barHeight + errorEndPointHeight;
          }
        });
      ebar.append('line')
        .attr({
          'stroke-width': 1,
          stroke: 'orange',
          x1: function(d) {
            return chart.x()(chart.maxErrorAccessor()(d));
          },
          y1: function(d) {
            return barHeight - errorEndPointHeight;
          },
          x2: function(d) {
            return chart.x()(chart.maxErrorAccessor()(d));
          },
          y2: function(d) {
            return barHeight + errorEndPointHeight;
          }
        });
    }

    _chart.minErrorAccessor = function (minErrorAccessor) {
        if (!arguments.length) {
            return _minErrorAccessor;
        }
        _minErrorAccessor = minErrorAccessor;
        return _chart;
    };

     _chart.maxErrorAccessor = function (maxErrorAccessor) {
        if (!arguments.length) {
            return _maxErrorAccessor;
        }
        _maxErrorAccessor = maxErrorAccessor;
        return _chart;
    };

    _chart.errorEndPointHeight = function (errorEndPointHeight) {
        if (!arguments.length) {
            return _errorEndPointHeight;
        }
        _errorEndPointHeight = errorEndPointHeight;
        return _chart;
    };


     _chart.cappedValueAccessor = function (d, i) {
        if (d.others) {
            return d.value;
        }
        return _chart.maxErrorAccessor()(d,i);
    };


    _chart.on("postRender.arisHorizontalErrorRowChart", addErrorLines);
    _chart.on("postRedraw.arisHorizontalErrorRowChart", addErrorLines);

     return _chart;
}
export default arisHorizontalErrorRowChart;