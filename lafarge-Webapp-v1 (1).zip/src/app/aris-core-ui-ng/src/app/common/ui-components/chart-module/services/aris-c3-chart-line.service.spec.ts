/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { ArisChartComponent } from '../aris-chart.component';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DebugElement } from '@angular/core';
import { DatePipe } from '@angular/common';
import { By } from '@angular/platform-browser';

import { ArisDcChartService } from './aris-dc-chart.service';
import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { ArisChartService } from './aris-chart.service';
import { ArisDcCustomRowChartService } from './aris-dc-chart-customrow.service';
import { ArisC3LineChartService } from './aris-c3-chart-line.service';
import { ArisC3ChartService } from './aris-c3-chart.service';



xdescribe('Service: ArisC3LineChartService', () => {
  let component: ArisChartComponent;
  let fixture: ComponentFixture<ArisChartComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisChartComponent],
      imports: [ArisI18nModule, LocalizationModule],
      providers: [ArisChartCommonService, ArisC3ChartService,  ArisChartService, DatePipe,
        TranslationService, InjectorRef, ArisC3LineChartService]
    }).compileComponents();
  });

  beforeEach(() => {
      // create component and test fixture
    fixture = TestBed.createComponent(ArisChartComponent);

    // get test component from the fixture
    component = fixture.componentInstance;
    component.data =   [
      {
        index: "0",
        "sine wave": "0"
      },
      {
        index: "1",
        "sine wave": "0.09983341664682815"
      },
      {
        index: "2",
        "sine wave": "0.19866933079506122"
      },
      {
        index: "3",
        "sine wave": "0.29552020666133955"
      },
      {
        index: "4",
        "sine wave": "0.3894183423086505"
      },
      {
        index: "5",
        "sine wave": "0.479425538604203"
      }
    ];

    component.type = "C3_LINE_CHART" ;
    component.options = {
      height: 200,
      width: 200,
      xAxisAttribute: "index",
      yAxisAttribute: "sine wave",
      xAxisLabel: "Time(ms)",
      yAxisLabel: "Voltage(v)",
      chartTitle: "C 3 Line Chart",
      lineColor: "#ff7f0e"
    };

  });

  it('svg element is created', () => {
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('.c3'));
    console.log(component);
    expect(componentEl.nativeElement.querySelector('svg')).toBeTruthy();
  });

});
