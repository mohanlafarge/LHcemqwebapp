import { Injectable } from '@angular/core';
import { ArisDcChartService } from './aris-dc-chart.service';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DatePipe } from '@angular/common';

import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import { ArisC3ChartService } from './aris-c3-chart.service';
import { TranslationService } from 'angular-l10n';
declare var $: any;


@Injectable()
export class ArisC3LineChartService extends ArisC3ChartService {

  constructor(protected arisChartCommonService: ArisChartCommonService, private datePipe: DatePipe,
    protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }


  processData(scope) {
    let xValues = [];
    let yValues = [];

    xValues.push('x');
    yValues.push('data1');
    scope.data.forEach((value, key) => {
    // check numeric values and convert string to number.
      let x = value[scope.options.xAxisAttribute];
      x = +x;
      let y = value[scope.options.yAxisAttribute];
      y = +y;

      xValues.push(x);
      yValues.push(y);
    });

    let data = {
      x: 'x',
      columns: [xValues, yValues]   ,
      type: 'line',
      color: {
        data1: scope.options.lineColor ? scope.options.lineColor : '#1f77b4'
      }
    };
    return data;
  }


}
