import { Injectable } from '@angular/core';
import { ArisChartService } from './aris-chart.service';
import { ArisChartCommonService } from './aris-chart-common.service';
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as c3 from 'c3';
import * as d3Tip from 'd3-tip';
import * as FileSaver from 'file-saver';
import { ArisChartEventService } from './aris-chart-event.service';
import { TranslationService } from 'angular-l10n';

declare var $: any;


@Injectable()
export class ArisC3ChartService extends ArisChartService {

  private dcTypeChild: any;
  private dcScope: any;
  private arisChartService: any;
  constructor(protected arisChartCommonService: ArisChartCommonService, protected translation: TranslationService) {
    super(arisChartCommonService, translation);
    this.arisChartService = new ArisChartService(arisChartCommonService, translation);
    d3.tip = d3Tip;
  }

  init(chartScope, element) {
    this.arisChartService.init(chartScope, element);
   // chartScope.chart = that.dcTypeChild.getChart(chartScope);



    this.drawChart(chartScope);
  }

  /**
   * Draw chart. It will draw chart completely (including chart size, axis labels, margins)
   */
  drawChart(chartScope) {
    this.arisChartService.drawChart(chartScope);

    let chartConfig: any = {
      size: {
        height: chartScope.options.height,
        width: chartScope.options.width
      },
      padding: {
        right: 5
      },
      data: chartScope.chartService.processData(chartScope),
      axis: {
        x: {
          label: chartScope.options.xAxisLabel ? chartScope.options.xAxisLabel : '',
        },
        y: {
          label: chartScope.options.yAxisLabel ? chartScope.options.yAxisLabel : ''
        }
      },
      legend: {
        show: false
      },
      bindto :  chartScope.chartElement
    };

    if (chartScope.options.numXAxisTicks) {
      chartConfig.axis.x.tick = {};
      chartConfig.axis.x.tick.count = chartScope.options.numXAxisTicks;
    }

    chartConfig.bindto = chartScope.chartElement;

    chartScope.c3chart = c3.generate(chartConfig);
  }

      /**
     * ToDo: Not tested.
     * redraw chart.
     */
  redrawChart(scope) {
    /* Convert data in C3 data format*/
    let data = scope.this.processData(scope);
    scope.chart.load(data);
  }


  resize(scope, containerHeight, containerWidth) {
    // this.arisChartService.calculateChartWidthHeight(scope, undefined, undefined);
    // scope.c3chart.resize({ height: scope.options.height, width: scope.options.width });
  }

  /**
   * Export chart as PNG
   */
  exportAsPNG(scope) {
    scope.exportOptions.externalCssFileData = $("style:contains('.c3')")[0].innerText;
    scope.exportOptions.rootCssClass = '.c3';
    this.arisChartService.exportAsPNG(scope);
  }
}
