import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { TranslationService } from 'angular-l10n';
import * as crossfilter_ from 'crossfilter';
import * as d3_ from 'd3';
import * as dc from 'dc';
import { Subject } from 'rxjs/Subject';

let d3: any = (<any>d3_).default || d3_;
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;

declare var $: any;



@Injectable()
export class ArisChartCommonService {

  chartOptionsChange: Subject<Object> = new Subject<Object>();
  constructor(protected translation: TranslationService, protected datePipe: DatePipe) {
  }

  setLinearScale(chartScope, min, max) {
    chartScope.chart.x(d3.scale.linear().domain([min, max]));
    if (chartScope.rangeChart) {
      chartScope.rangeChart.x(d3.scale.linear().domain([min, max]));
    }
  }

  // setLinearScaleForBarCharts(chartScope, min, max) {
  //   chartScope.chart.x(d3.scale.linear().domain([min, max + 1]));
  //   if (chartScope.rangeChart) {
  //     chartScope.rangeChart.x(d3.scale.linear().domain([min, max + 1]));
  //   }
  // }

  setTimeScaleForGroupBarChart(chartScope) {
    chartScope.chart.x(d3.scale.ordinal());
    chartScope.chart.xUnits(dc.units.ordinal);
    if (chartScope.rangeChart) {
      chartScope.rangeChart.x(d3.scale.ordinal());
      chartScope.rangeChart.xUnits(dc.units.ordinal);
    }
  }

  setScale(chartScope) {
    switch (chartScope.options.scale) {
      case 'ordinal':
        if (chartScope.options.ordinalDomain) {
          chartScope.chart.x(d3.scale.ordinal().domain(chartScope.options.ordinalDomain));
          chartScope.chart.xUnits(dc.units.ordinal);
          if (chartScope.rangeChart) {
            chartScope.rangeChart.x(d3.scale.ordinal().domain(chartScope.options.ordinalDomain));
            chartScope.rangeChart.xUnits(dc.units.ordinal);
          }
        } else {
          chartScope.chart.x(d3.scale.ordinal());
          if (chartScope.chart.xUnits) {
            chartScope.chart.xUnits(dc.units.ordinal);
          }
          if (chartScope.rangeChart) {
            chartScope.rangeChart.x(d3.scale.ordinal());
            chartScope.rangeChart.xUnits(dc.units.ordinal);
          }
        }
        break;
      case 'linear':
        const dimList = [];
        // $.each(chartScope.dimension.top(Infinity), function(key, value){
        //   dimList.push(parseFloat(value[chartScope.options.xAxisAttribute]))
        // })

        chartScope.dimension.top(Infinity).forEach((value, key) => {
          dimList.push(parseFloat(value[chartScope.options.xAxisAttribute]));
        });

        let max = dimList.reduce((a, b) => {
          return Math.max(a, b);
        });

        let min = dimList.reduce((a, b) => {
          return Math.min(a, b);
        });

        if (min > max) {
          max = [min, min = max][0];
        }

        if (chartScope.chartService.setLinearScale) {
          chartScope.chartService.setLinearScale(chartScope, min, max);
        } else {
          this.setLinearScale(chartScope, min, max);
        }
        break;
      case 'date':
        if (chartScope.options.grouped) {
          this.setTimeScaleForGroupBarChart(chartScope);
        } else {
          let minDate;
          let maxDate;

          chartScope.dimension.top(Infinity).forEach((val, key) => {
            if (key === 0) {
              minDate = maxDate = val[chartScope.options.xAxisAttribute];
            }
            if (val[chartScope.options.xAxisAttribute] > maxDate) {
              maxDate = val[chartScope.options.xAxisAttribute];
            } else if (val[chartScope.options.xAxisAttribute] < minDate) {
              minDate = val[chartScope.options.xAxisAttribute];
            }
          });
          chartScope.chart.x(d3.time.scale().domain([minDate, maxDate]));
          if (chartScope.rangeChart) {
            chartScope.rangeChart.x(d3.time.scale().domain([minDate, maxDate]));
            chartScope.rangeChart.xUnits(d3.time.months);
          }
        }
        break;
      case 'month':
        const monthNameFormat = d3.time.format('%b-%Y');

        if (chartScope.options.grouped) {
          this.setTimeScaleForGroupBarChart(chartScope);
          chartScope.chart.xAxis().tickFormat(d3.time.format('%b-%y'));
        } else {
          chartScope.chart
            .x(d3.time.scale()).elasticX(true)
            .round(d3.time.month.round)
            .alwaysUseRounding(true)
            .xUnits(d3.time.months)
            .xAxis().tickFormat(monthNameFormat).ticks(d3.time.months, 1);
        }
        break;
      case 'scaleLinear':
        chartScope.chart
          .x(d3.scaleLinear)
          .elasticX(true);
        break;
      default:
        break;
    }
  }

  // crossfilter functions
  reduceAvgAdd(f) {
    return (p, v) => {
      p.sum = p.sum + parseFloat(f(v));
      p.count = p.count + 1;
      p.avg = p.sum / p.count;
      return p;
    };
  }

  reduceAvgRemove(f) {
    return (p, v) => {
      p.sum = p.sum - parseFloat(f(v));
      p.count = p.count + 1;
      p.avg = p.sum / p.count;
      return p;
    };
  }

  applyLabel(chartScope: any, label?: string) {
    if (label === 'y-axis') {
      // if (chartScope.chart.yAxisLabel) {
      chartScope.chart.yAxisLabel(this.translation.translate(chartScope.options.yAxisLabel));
      // }
    } else if (label === 'x-axis') {
      if (chartScope.rangeChart) {
        chartScope.rangeChart.xAxisLabel(this.translation.translate(chartScope.options.xAxisLabel));
      } else {
        chartScope.chart.xAxisLabel(this.translation.translate(chartScope.options.xAxisLabel));
      }
    } else {
      chartScope.chart.yAxisLabel(this.translation.translate(chartScope.options.yAxisLabel));
      chartScope.rangeChart ? chartScope.rangeChart.xAxisLabel(this.translation.translate(chartScope.options.xAxisLabel)) :
        chartScope.chart.xAxisLabel(this.translation.translate(chartScope.options.xAxisLabel));
    }

  }

  reduceAvgInitial() {
    return function () { return { sum: 0, avg: 0, count: 0 }; };
  }

  setCommonCoordinateGridChartAttributes(chartScope) {
    chartScope.chart
      .renderHorizontalGridLines(true)
      .renderTitle(false)
      .elasticY(true)
      .elasticX(false)
      .brushOn(false);
  }

  setValueAcc(chartScope) {
    let valueAccessorFn;
    switch (chartScope.options.calc) {
      case 'sum':
        valueAccessorFn = d => +d.value.sum;
        break;
      case 'count':
        valueAccessorFn = d => +d.value.count;
        break;
      case 'avg':
        valueAccessorFn = d => +d.value.avg;
        break;
      default:
        valueAccessorFn = d => +d.value;
    }

    chartScope.chart.valueAccessor(valueAccessorFn);
    if (chartScope.rangeChart) {
      chartScope.rangeChart.valueAccessor(valueAccessorFn);
    }

  }

  setCompositeValueAcc(chart, calc) {
    let valueAccessorFn;
    switch (calc) {
      case 'sum':
        valueAccessorFn = d => +d.value.sum;
        break;
      case 'count':
        valueAccessorFn = d => +d.value.count;
        break;
      case 'avg':
        valueAccessorFn = d => +d.value.avg;
        break;
      default:
        valueAccessorFn = d => +d.value;
    }

    chart.valueAccessor(valueAccessorFn);
  }

  openInNewWindow(scope) {
    window.chartOptions = Object.assign({}, scope.options);
    // window.chartData = Object.assign([], JSON.parse(scope.data1));
    window.chartType = scope.type;
    window.chartData = scope.chartService.sendDataToNewWindow ? scope.chartService.sendDataToNewWindow(scope) : scope.data;
    const path = window.location.href.split('#/page/');
    window.pageName = path[path.length - 1];
    let chartTitle = scope.options.chartTitle.replace(/[^a-zA-Z0-9]/g, '');
    const randomNum = Math.floor(Date.now() / 1000);
    let obj = {
      chartOptions: window.chartOptions, chartData: window.chartData,
      chartType: window.chartType, pageName: window.pageName
    };
    for (let i = 0; i < window.localStorage.length; i += 1) {
      let key = window.localStorage.key(i);
      if (window.localStorage.key(i) !== 'arisLocalConfig' && window.localStorage.key(i) !== 'arisThemeConfig') {
        localStorage.removeItem(key);
      }
    }
    localStorage.setItem('' + chartTitle + randomNum, JSON.stringify(obj));
    sessionStorage.setItem('' + chartTitle + randomNum, JSON.stringify(obj));
    window.open('#/zoomInChart/' + chartTitle + randomNum, '_blank');
    /* Comment the previous line and Uncomment this if you prefer pass the information as queryparam
       instead store it in the sessionStorage */
    //    window.open('#/zoomInChart/data?chartId=' + chartTitle + randomNum + '&chartData=' + JSON.stringify(obj), '_blank');
  }

  csvFileDateFormat(val) {
    let newDate = val.split`T`[0] + " " + val.split`T`[1].substring(0, 8);
    return newDate;
    //return this.datePipe.transform(newDate, "mm-dd-yyyy HH:mm:ss");
  }

  storeXAxisLabels(chartScope) {
    let textElm = chartScope.chartElement.querySelectorAll(".axis.x .tick text");
    textElm.forEach((elm) => {
      chartScope.options.listXAxisLabels.push(elm.textContent);
    });
  }

  setXAxisLabelsWidthForOrdinalCharts(chartScope, chartElm) {
    let textElm = chartElm.querySelectorAll(".axis.x .tick text");

    textElm.forEach((elm, i) => {
      let xAxisWidth = chartElm.querySelector(".axis.x").getBBox().width;
      let noOfTicks = chartElm.querySelectorAll(".axis.x .tick").length;
      let noOfChar;
      chartScope.options.xAxisCharLimit ? noOfChar = chartScope.options.xAxisCharLimit :
        noOfChar = (xAxisWidth / noOfTicks) / 9; // 9 is the px for each character
      let originalText;
      originalText = Object.assign(elm.textContent);
      if (elm.textContent.length > Math.round(noOfChar)) {
        if (chartScope.options.ordinalLabelList[i]) {
          elm.textContent = chartScope.options.ordinalLabelList[i].toString().substr(0, Math.round(noOfChar - 1)) + "...";
        }
      }
      d3.select(elm).append('title').text(originalText);
      d3.select(elm).style('pointer-events', 'all');
    });
  }
}
