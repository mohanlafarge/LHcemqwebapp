import { Injectable } from '@angular/core';
// import * as $ from 'jquery';

@Injectable()
export class ArisChartEventService {
  postRedraw(chartScope: any, dcTypeChild: any) {
    if (chartScope.chart.mouseZoomable) {
      chartScope.chart.mouseZoomable(true);
    }
    chartScope.chart.on('postRender', () => {
      dcTypeChild.setTip(chartScope);
      dcTypeChild.postRender(chartScope);
    });
  }
  resize(chartService: any, arisChartService: any, that: any) {

    if (that.type === 'sankey') {
      chartService.redrawChart(that);
    } else {
      arisChartService.resizeChart(that, chartService);
    }
  }

  exportAsPNG(type: string, chartService: any, arisChartService: any, that: any) {
    arisChartService.exportPNG(that, chartService, type);
  }
}
