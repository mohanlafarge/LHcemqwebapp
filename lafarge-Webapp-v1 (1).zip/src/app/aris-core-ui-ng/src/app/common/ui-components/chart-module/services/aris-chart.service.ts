import { Injectable } from "@angular/core";
import { TranslationService } from "angular-l10n";
import * as crossfilter_ from "crossfilter";
import * as d3_ from "d3";
import * as FileSaver from "file-saver";
import * as html2canvas_ from "html2canvas";
import { ArisChartCommonService } from "./aris-chart-common.service";

let d3: any = (<any>d3_).default || d3_;
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;

let html2canvas: any = (<any>html2canvas_).default || html2canvas_;


declare var $: any;

@Injectable()
export class ArisChartService {
  constructor(
    protected arisChartCommonService: ArisChartCommonService,
    protected translation: TranslationService
  ) { }
  private chart: any;
  private crossfilterObj: any;
  private dimension: any;
  private group: any;
  private element: any;
  private chartElement: any;
  private isHidden: any;
  private child: any;

  init(chartScope: any, element: any) {
    chartScope.element = element.parentElement;
    chartScope.chartElement = element.querySelector(".o-mainChartContainer");

    console.log(chartScope);
    if (chartScope.options.scale === "ordinal") {
      chartScope.options.showRangeChart = undefined;
    }
    if (chartScope.options.showRangeChart) {
      chartScope.rangeChartElement = element.querySelector(
        ".o-rangeChartContainer"
      );
    }
    chartScope.exportOptions = {};
  }

  drawChart(chartScope) {
    // Calculate dynamic size of chart

    this.calculateChartWidthHeight(chartScope, undefined, undefined);

    // If width is not defined (if chart container is not yet loaded/visible), ignore drawing.
    if (!chartScope.options.width) {
      console.log("Width is not defined for chart");
      return;
    }
  }

  calculateChartWidthHeight(chartScope, containerWidth, containerHeight) {
    let vertPaddingMain;
    // Access chart directive's container
    const el = chartScope.element.parentElement;

    // If chart directive's container is available, calculate chart size.
    if (el.nodeType === 1) {
      // Chart directive's container's style.
      let styles = window.getComputedStyle(el);
      const horizPaddingRoot =
        parseFloat(styles.paddingLeft) + parseFloat(styles.paddingRight);
      const vertPaddingRoot =
        parseFloat(styles.paddingTop) + parseFloat(styles.paddingBottom);

      // Chart container's style.
      styles = window.getComputedStyle(chartScope.chartElement);
      const horizPaddingMain =
        parseFloat(styles.paddingLeft) + parseFloat(styles.paddingRight);
      vertPaddingMain =
        parseFloat(styles.paddingTop) +
        parseFloat(styles.paddingBottom) +
        parseFloat(styles.top);

      console.log(
        chartScope.options.chartTitle +
        " height:" +
        el.clientHeight +
        " vertPaddingRoot:" +
        vertPaddingRoot +
        " vertPaddingMain:" +
        vertPaddingMain
      );

      // Chart size
      chartScope.options.width =
        el.clientWidth - horizPaddingRoot - horizPaddingMain;
      chartScope.options.height =
        el.clientHeight - vertPaddingRoot - vertPaddingMain - 10; // 10 (?)
      chartScope.element.style.height = 40 + chartScope.options.height + "px";
      chartScope.element.querySelector(".o-chartContainer").style.height =
        40 + chartScope.options.height + "px";
      chartScope.element.style.width =
        horizPaddingMain + chartScope.options.width + "px";
      chartScope.element.querySelector(".o-chartContainer").style.width =
        horizPaddingMain + chartScope.options.width + "px";
    }
    // In case of range-chart, assign 35% to range chart and 65% to main chart.
    if (chartScope.rangeChart) {
      chartScope.options.rangeChartHeight = chartScope.options.height * 0.35;
      chartScope.options.height = chartScope.options.height * 0.65;
      chartScope.rangeChartElement.style.top =
        chartScope.options.height + vertPaddingMain + 5 + "px";
    }
  }

  export(type: string, chartScope: any) {
    this.onClickExportChart(type, chartScope);
  }

  onClickExportChart = (exportType: string, chartScope: any) => {
    if (exportType === "png") {
      this.onClickExportAsPNG(chartScope);
    } else if (exportType === "csv") {
      this.onClickExportAsCSV(chartScope);
    }
  };

  onClickExportAsCSV = (chartScope: any) => {
    let chartdata;
    if (chartScope.chartService.getCsvData) {
      chartdata = JSON.parse(
        JSON.stringify(chartScope.chartService.getCsvData(chartScope.data))
      );
    } else {
      chartdata = JSON.parse(JSON.stringify(chartScope.data));
    }
    chartdata = this.convertTimestamps(chartdata);
    const blob = new Blob([(<any>d3).csv.format(chartdata)], {
      type: "text/csv;charset=utf-8"
    });
    FileSaver.saveAs(
      blob,
      this.generateExportedChartFileName(chartScope) + ".csv"
    );
  };

  generateExportedChartFileName = (chartScope: any) => {
    let chartFilename = "chartFile";
    if (chartScope.options.chartTitle) {
      chartFilename = this.camelize(chartScope.options.chartTitle);
    }
    return chartFilename;
  };

  // renderChart() {
  //   this.chart.render();
  // }
  isChartAvailable(chartScope) {
    return chartScope.chartElement.getElementsByTagName("svg").length > 0;
  }

  updateChart(chartScope) {
    // if chart is already drawn, call redraw else draw from scratch.
    if (!this.isChartAvailable(chartScope)) {
      chartScope.chartService.drawChart(chartScope);
    } else {
      chartScope.chartService.redrawChart(chartScope);
    }
  }

  setSharedCrossFiltersForChartTiles(chartScope) {
    if (chartScope.chartOptions.forEach === undefined) {
      return;
    }

    chartScope.crossfilters = {};

    let dataSources: any[] = [];
    chartScope.chartOptions.forEach((value, key) => {
      if (value.crossfilter) {
        if (!dataSources[value.crossfilter]) {
          dataSources[value.crossfilter] = [];
        }
        dataSources[value.crossfilter].push(key);
      }
    });

    dataSources.forEach((chartOptionIds, dataSourceId) => {
      let customDataHandler =
        chartScope.dataSources[dataSourceId].customDataHandler;
      // tslint:disable-next-line:no-shadowed-variable
      chartScope.dataSources[dataSourceId].customDataHandler = (
        scope,
        data
      ) => {
        let dataUpdated = data;
        if (customDataHandler) {
          dataUpdated = customDataHandler(chartScope, dataUpdated);
        }
        if (!scope.crossfilters[dataSourceId]) {
          scope.crossfilters[dataSourceId] = crossfilter(dataUpdated);
        }
        chartOptionIds.forEach((chartOptionId, index) => {
          scope.chartOptions[chartOptionId].crossfilter =
            scope.crossfilters[dataSourceId];
        });
        return dataUpdated;
      };
    });
  }

  convertTimestamps(obj: any) {
    if (!String.prototype.startsWith) {
      String.prototype.startsWith = function (searchString, position) {
        let positionUpdated = position || 0;
        return (
          this.substr(positionUpdated, searchString.length) === searchString
        );
      };
    }
    for (let i = 0; i < obj.length; i += 1) {
      Object.keys(obj[i]).forEach((key, y) => {
        if (key === "dateTimeValue" || key === "sampleDate" || key === "startTime" || key.startsWith("dtv")) {
          obj[i][key] = this.arisChartCommonService.csvFileDateFormat(
            obj[i][key]
          );
        }
      });
    }
    return obj;
  }

  camelize(str: string) {
    // str = $filter('translate')(str);
    return this.translation
      .translate(str)
      .replace(/(?:^\w|[A-Z]|\b\w)/g, (letter: string, index: number) => {
        return index === 0 ? letter.toLowerCase() : letter.toUpperCase();
      })
      .replace(/\s+/g, "");
  }

  onClickExportAsPNG(chartScope) {
    chartScope.chartService.preExportAsPNG(chartScope);

    // Rendering of chart may take time so wait for some time before export is started.

    setTimeout(() => {
      chartScope.chartService.exportAsPNG(chartScope);
    }, 1000);
  }

  preExportAsPNG(chartScope, child?) {
    // Show loader
    chartScope.exporting = true;
    chartScope.element.querySelector(".o-arisChartContainer").style.visibility =
      "hidden";
    // Resize chart to fixed size used for exported charts
    let width = $(window).width();
    chartScope.chartService.resize(chartScope, width, 400);
  }

  postExportAsPNG(chartScope) {
    chartScope.exporting = false;
    chartScope.element.querySelector(".o-arisChartContainer").style.visibility =
      "visible";
  }

  exportAsPNG(chartScope) {
    // If css is already set.
    // TODO once we find the solution for loading css we should uncommet below code

    // If external css
    if (chartScope.exportOptions.externalCssFileData) {
      chartScope.exportOptions.externalCssFileData = chartScope.exportOptions.externalCssFileData.replace(
        ".dc-chart g.row text {",
        ".dc-chart g.row text1 {"
      );
      chartScope.exportOptions.css =
        chartScope.exportOptions.externalCssFileData;

      // Add any inline css if provided.
      if (chartScope.chartService.getInlineCssForChartExport) {
        chartScope.exportOptions.css.concat(
          "\n" + chartScope.chartService.getInlineCssForChartExport()
        );
      }
      if (chartScope.exportOptions.rootCssClass) {
        const regExp = new RegExp(chartScope.exportOptions.rootCssClass, "g");
        chartScope.exportOptions.css = chartScope.exportOptions.css.replace(
          regExp,
          ".exported-chart"
        );
      }
      // Css is set, so start exporting.
      this.exportingAsPNG(chartScope);
    } else {
      // if no external css

      // Add any inline css if provided.
      if (chartScope.chartService.getInlineCssForChartExport) {
        chartScope.exportOptions.css = chartScope.chartService.getInlineCssForChartExport();
        if (chartScope.exportOptions.rootCssClass) {
          chartScope.exportOptions.css = chartScope.exportOptions.css.replace(
            /chartScope.exportOptions.rootCssClass/g,
            ".exported-chart"
          );
        }
      }
      // Css is set, so start exporting.
      this.exportingAsPNG(chartScope);
    }
  }

  exportingAsPNG(chartScope) {
    const hideChartTitle = chartScope.options.hideChartTitle;
    chartScope.options.hideChartTitle = false;
    // Create duplicate root container for export
    setTimeout(() => {
      const rootElement = chartScope.element
        .querySelector(".o-arisChartContainer")
        .cloneNode(true);
      const chartElement = rootElement.querySelector(".o-mainChartContainer");
      const rangeChartElement = rootElement.querySelector(
        ".o-rangeChartContainer"
      );
      const chartContainer = rootElement.querySelector(".o-chartContainer");

      // set it transparent and add to main body of the page.
      rootElement.style.position = "relative";
      rootElement.style.opacity = 0;
      rootElement.style.visibility = "visible";
      document.body.appendChild(rootElement);

      if (chartScope.exportOptions.css) {
        // Add DC styles to charts
        const svg = chartElement.getElementsByTagName("svg");
        $(svg)
          .prepend("<style></style>")
          .find("style")
          .text(chartScope.exportOptions.css);
        $(svg).attr("class", "exported-chart");

        let rangechartSvg;
        if (chartScope.rangeChart) {
          rangechartSvg = rangeChartElement.getElementsByTagName("svg");
          $(rangechartSvg)
            .prepend("<style></style>")
            .find("style")
            .text(chartScope.exportOptions.css);
          $(rangechartSvg).attr("class", "exported-chart");
        }
      }
      // set chart title text color to black
      if (rootElement.querySelector(".o-arisChartExport")) {
        rootElement.querySelector(".o-arisChartExport").style.display = "none";
      }
      if (rootElement.querySelector(".o-arisChartWindow")) {
        rootElement.querySelector(".o-arisChartWindow").style.display = "none";
      }
      if (rootElement.querySelector(".o-arisChartTitle-container")) {
        rootElement.querySelector(".o-arisChartTitle-container").style.border =
          "none";
        rootElement.querySelector(".o-arisChartTitle").style.width = "89%";
        rootElement.querySelector(".o-arisChartTitle-container").style.color =
          "#000000";
        if (
          rootElement
            .querySelector(".o-arisChartTitle-container")
            .getAttribute("hidden") === ""
        ) {
          this.isHidden = true;
          rootElement
            .querySelector(".o-arisChartTitle-container")
            .removeAttribute("hidden");
        }
      }
      if (rootElement.querySelector(".circle-left")) {
        rootElement.querySelector(".circle-left").style.display = "none";
      }
      if (rootElement.querySelector(".circle-right")) {
        rootElement.querySelector(".circle-right").style.display = "none";
      }
      rootElement.querySelector(".o-arisChartExport").style.display = "none";
      // Export
      html2canvas(chartContainer, {
        allowTaint: true,
        background: "#ffffff",
        logging: false // Note: Only for debug mode.
      }).then(canvas => {
        const chartFilename =
          this.generateExportedChartFileName(chartScope) + ".png";
        if (/MSIE|Trident|Edge/.test(window.navigator.userAgent)) {
          // if IE Browser
          window.navigator.msSaveBlob(canvas.msToBlob(), chartFilename);
        } else {
          // Export png image
          const url = canvas.toDataURL("img/png");
          $("<a>", {
            href: url.replace(
              /^data[:]image\/png[;]/i,
              "data:application/download;"
            ), // force download
            download: chartFilename
          })
            .on("click", () => {
              $(this).remove();
            })
            .appendTo("body")[0]
            .click();
        }

        if (chartScope.chartService.postExportAsPNG) {
          if (this.isHidden) {
            // rootElement.querySelector('.o-arisChartTitle').setAttribute("hidden", true);
          }
          chartScope.chartService.postExportAsPNG(chartScope);
        }

        chartScope.options.hideChartTitle = hideChartTitle;

        // Remove duplicate container.
        document.body.removeChild(rootElement);
      }); // html2canvas
    }, 300);
  }

  resizeChart(chartScope) {
    if (chartScope.type === "SANKEY_CHART") {
      chartScope.chartService.redrawChart(chartScope);
    } else {
      chartScope.chartService.resize(chartScope, undefined, undefined);
    }
  }

  exportPNG(chartScope, type) {
    setTimeout(() => {
      chartScope.chartService.exportAsPNG(chartScope);
    }, 300);
  }
}
