import { Injectable } from '@angular/core';
import { ArisDcChartService } from './aris-dc-chart.service';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DatePipe } from '@angular/common';

import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import * as crossfilter_ from 'crossfilter';
import { TranslationService } from 'angular-l10n';
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;
declare var $: any;


@Injectable()
export class ArisDcAreaChartService extends ArisDcChartService {

  constructor(protected arisChartCommonService: ArisChartCommonService, private datePipe: DatePipe,
    protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }

  init(chartScope, element) {
    super.init(chartScope, element);
  }

  getChart (chartScope) {
    console.log('-----------------get chart -----------------------');
    return dc.lineChart(chartScope.chartElement);
  }

  setTip (chartScope) {
    super.setupTip(chartScope, this.htmlTemplateFn(chartScope), '.dot');
  }


/**
 * Set scale for chart.
 */

  setScale (chartScope) {
    this.arisChartCommonService.setScale(chartScope);
  }

  setAdditionalChartAttributes (chartScope) {
    this.arisChartCommonService.setCommonCoordinateGridChartAttributes(chartScope);

    chartScope.chart
      .renderArea(true)
      // .mouseZoomable(true)
      .elasticY(true)
      .renderHorizontalGridLines(true)
      .renderTitle(false);
    if (chartScope.options.calcAttribute) {
      let stk;
      const di = {};

      for (let i = 0; i < chartScope.data.length; i++) {
        const item = chartScope.data[i][chartScope.options.yAxisAttribute];
        if (!di[item]) {
          di[item] = [];
        }
        di[item].push(chartScope.data[i]);
      }

      const groupKeys1 = {};

      for (const g in Object.keys(di)) {
        if (g) {
          groupKeys1[Object.keys(di)[g]] = 0;
        }
      }

      if (chartScope.options.calcAttribute) {
        stk = chartScope.dimension.group().reduce(
                 (p, v) => {
                   p[v[chartScope.options.yAxisAttribute]] = v[chartScope.options.calcAttribute];
                   return p;
                 },
                 (p, v) => {
                   return p[v[chartScope.options.yAxisAttribute]] = v[chartScope.options.calcAttribute];
                 },
                 () => {
                   // return angular.copy(groupKeys1);
                   return $.extend(true, {}, groupKeys1);
                 }
               );
      } else {
        stk = chartScope.dimension.group().reduce(
                (p, v) => {
                  p[v[chartScope.options.yAxisAttribute]] = p[v[chartScope.options.yAxisAttribute]] + 1;
                  return p;
                },
                (p, v) => {
                  return p[v[chartScope.options.yAxisAttribute]] = p[v[chartScope.options.yAxisAttribute]] - 1;
                },
                () => {
                  // return angular.copy(groupKeys1);
                  return $.extend(true, {}, groupKeys1);
                }
              );
      }

      const dimList = [];

      for (const value of (<any>Object.keys(di).map(val => di[val]))) {
        dimList.push(value[0][chartScope.options.yAxisAttribute]);
      }

      chartScope.chart.group(stk, dimList[0], this.sel_stack(dimList[0]));
      const woType = dimList.splice(1, dimList.length - 1);
      for (const w in woType) {
        if (woType.hasOwnProperty(w)) {
          chartScope.chart.stack(stk, '' + woType[w], this.sel_stack(woType[w]));
        }
      }
    } else {
      const grp = chartScope.dimension.group().reduce(
                this.arisChartCommonService.reduceAvgAdd(d =>  d[chartScope.options.yAxisAttribute]),
                this.arisChartCommonService.reduceAvgRemove(d => d[chartScope.options.yAxisAttribute]),
                this.arisChartCommonService.reduceAvgInitial()
                );

      chartScope.options.calc.forEach((value, key) => {
        chartScope.chart.valueAccessor(d =>  d.value[value]);
        if (key === 0) {
          chartScope.chart.group(grp, '' + chartScope.options.yAxisLabel + ' ' + value);
        } else {
          chartScope.chart.stack(grp, '' + chartScope.options.yAxisLabel + ' ' + value,  d => d.value[value]);
        }
      });
    }

    if (chartScope.options.lineColor) {
      chartScope.chart.lineColor(chartScope.options.lineColor);
    }

    if (chartScope.options.numXAxisTicks) {
      chartScope.chart.xAxis().ticks(parseInt(
              chartScope.options.numXAxisTicks, 10)).tickFormat(d3.time.format(chartScope.options.timeFormatType));
      if (chartScope.rangeChart) {
        chartScope.rangeChart.xAxis().ticks(parseInt(
              chartScope.options.numXAxisTicks, 10)).tickFormat(d3.time.format(chartScope.options.timeFormatType));
      }
    }
  }

  setGroup (chartScope) {
  }

    // Area Chart legend width
  setLegendWidth(chartScope) {
      // generic solution implemented in aris-dc-chart-service
    super.setLegendWidth(chartScope);
  }

  calculateLegendWidthFromGroup(chartScope) {
    let keys = chartScope.chart.group().all();
    let maxLengendChars = 0;
    keys.forEach((element, index) => {
      let dataKeys = keys[index].key;
      let legendText;
      if  (Array.isArray(dataKeys)) {
        legendText = dataKeys[1];
      } else {
        legendText = dataKeys.toString();
      }
      if (legendText.length > maxLengendChars) {
        maxLengendChars = legendText.length;
      }
    });
    maxLengendChars * 7 > chartScope.options.width * 0.1 ? chartScope.options.legendWidth = maxLengendChars * 7 :
      chartScope.options.legendWidth = chartScope.options.width * 0.1;
  }

   /* ---------------------------------- Private methods ----------------------------------------------------*/

  htmlTemplateFn(chartScope) {
    if (chartScope.options.scale === 'date') {
      return d =>  '<span style=\'color: #d4cf2f\'><i>' +
         this.datePipe.transform(d.x, 'yyyy-MM-dd HH:mm:ss') + '</i></span> : '  + d.y.toFixed(2);
    } else {
      return d => '<span style=\'color: #d4cf2f\'><i>' + d.x + '</i></span> : '  + d.y;
    }
  }

  sel_stack(i) {
    return d => d.value[i];
  }

}
