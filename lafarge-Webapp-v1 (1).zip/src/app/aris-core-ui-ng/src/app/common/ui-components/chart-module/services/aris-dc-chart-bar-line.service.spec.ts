/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { ArisChartComponent } from '../aris-chart.component';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DebugElement } from '@angular/core';
import { DatePipe } from '@angular/common';
import { By } from '@angular/platform-browser';

import { ArisDcChartService } from './aris-dc-chart.service';
import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { ArisChartService } from './aris-chart.service';
import { ArisDcChartBarLineService } from './aris-dc-chart-bar-line.service';



xdescribe('Service: ArisDcChartBarLineService', () => {

  let component: ArisChartComponent;
  let fixture: ComponentFixture<ArisChartComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisChartComponent],
      imports: [ArisI18nModule, LocalizationModule],
      providers: [ArisChartCommonService, ArisChartService, DatePipe, ArisDcChartService,
        TranslationService, InjectorRef, ArisDcChartBarLineService]
    }).compileComponents();
  });

  beforeEach(() => {
      // create component and test fixture
    fixture = TestBed.createComponent(ArisChartComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    component.data =   [{
      INCIDENT_REFERENCE_NUMBER: "7444764",
      SPILL_DURATION_MINUTES: "26",
      DOWNSTREAM_MANHOLE: "43112119",
    },
    {
      INCIDENT_REFERENCE_NUMBER: "7444519",
      SPILL_DURATION_MINUTES: "36",
      DOWNSTREAM_MANHOLE: "62409025",
    },
    {
      INCIDENT_REFERENCE_NUMBER: "7444780",
      SPILL_DURATION_MINUTES: "31",
      DOWNSTREAM_MANHOLE: "65"
    }];

    component.type = "DC_BAR_LINE_CHART" ;
    component.options = {
      height: 200,
      width: 200,
      xAxisAttribute : 'SPILL_DURATION_MINUTES',
      yAxisAttribute : 'DOWNSTREAM_MANHOLE',
      rightYAxisAttribute : 'INCIDENT_REFERENCE_NUMBER',
      type: 'solid',
      zoomable: 'false',
      exportable: 'true',
      chartTitle: 'Ordinal Bar Line Chart',
      openWindow: true
    };


  });

  it('svg element is created', () => {
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('.dc-chart'));
    console.log(component);
    expect(componentEl.nativeElement.querySelector('svg')).toBeTruthy();
  });

});
