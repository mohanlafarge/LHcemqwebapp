import { ArisDcChartService } from './aris-dc-chart.service';
import { ArisChartCommonService } from './aris-chart-common.service';
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import * as crossfilter_ from 'crossfilter';
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;
import { Injectable } from '@angular/core';
import { TranslationService } from 'angular-l10n';
@Injectable()
export class ArisDcChartBarLineService extends ArisDcChartService {
  constructor(protected arisChartCommonService: ArisChartCommonService, protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }

  init(scope, element) {
    super.init(scope, element);
  }

  /* need to check this method with the old version*/
  getChart(scope) {
    let compositeChart: any = dc.compositeChart(scope.chartElement);
    compositeChart.compose([dc.barChart(compositeChart), dc.lineChart(compositeChart)]);
    return compositeChart;
  }

  setTip(scope) {
    this.setupTip(scope, this.htmlTemplateFn(scope), ".dot,.bar");
  }

  setScale(scope) {
    let keys = [];
    scope.data.forEach((value, key) => {
      if (keys.length === 0 || keys.indexOf(value[scope.options.xAxisAttribute]) <= -1) {
        keys.push(value[scope.options.xAxisAttribute]);
      }
    });
    scope.chart.children()[0].x(d3.scale.ordinal().domain(keys.sort()));
    scope.chart.x(d3.scale.ordinal().domain(keys.sort()));
    this.arisChartCommonService.setScale(scope);
  }

  setAdditionalChartAttributes(scope) {
    this.arisChartCommonService.setCommonCoordinateGridChartAttributes(scope);
    scope.chart.children()[0]
        .colors('#7be1ff')
        // .gap()
        .centerBar(true)
        .elasticX(true)
        .elasticY(true);

    scope.options.width > 600 ?  scope.chart.children()[0].gap(5) :  scope.chart.children()[0].gap(1);

    scope.chart.children()[1]
        .interpolate('linear')
        .colors('#fb1515')
        .elasticX(true)
        .elasticY(true)
        .dashStyle([5, 5])
        .useRightYAxis(true)
        .renderTitle(true)
        .brushOn(false);

    scope.chart
        ._rangeBandPadding(0)
        .xUnits(dc.units.ordinal)
        .yAxisLabel(scope.options.yAxisLabel)
        .xAxisLabel(scope.options.xAxisLabel)
        .rightYAxisLabel(scope.options.rightYAxisLabel)
        .renderHorizontalGridLines(true);
    // if (!scope.element[0].querySelector('.o-chartContainer').classList.contains('barlineChart')) {
    scope.element.querySelector('.o-chartContainer').classList.add("barlineChart");
    this.arisChartCommonService.setValueAcc(scope);

  }

  setGroup(scope) {
    let grp1 = scope.dimension.group().reduceCount((d) => {
      return d[scope.options.yAxisAttribute];
    });
    let grp2 = scope.dimension.group().reduceCount((d) => {
      return d[scope.options.rightYAxisAttribute];
    });
    scope.chart.children()[0].group(grp1, scope.options.barLegend);
    scope.chart.children()[1].group(grp2, scope.options.lineLegend);
  }

  setDimension(scope) {
    scope.dimension = scope.crossfilter.dimension((d) => {
      return d[scope.options.xAxisAttribute];
    });
  }

  postRedraw(scope) {
    let raw = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);
    if (raw) {
      let obj1 = scope.chart.selectAll('.grid-line.horizontal').attr('transform').replace(/[^0-9\-.,]/g, '').split(',');
      let obj2 = scope.chart.selectAll('.sub .chart-body').attr('transform').replace(/[^0-9\-.,]/g, '').split(',');
      let xAxis = parseInt(obj2[0], 10);
      let yAxis = parseInt(obj1[1], 10) - 2;
      scope.chart.selectAll("g.chart-body").attr("transform", 'translate(' + xAxis + ',' + yAxis + ')');
    }
    super.postRedraw(scope);
  }

  /**********************   Private method(s) ***************************************/

  htmlTemplateFn(scope) {
    return (d) => {
      return "<span style='color: #d4cf2f'><i>" + d.x + "</i></span> : " + d.y;
    };
  }

}
