/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { ArisChartComponent } from '../aris-chart.component';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DebugElement } from '@angular/core';
import { DatePipe } from '@angular/common';
import { By } from '@angular/platform-browser';

import { ArisDcChartService } from './aris-dc-chart.service';
import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { ArisChartService } from './aris-chart.service';
import { ArisDcChartBarService } from './aris-dc-chart-bar.service';



xdescribe('Service: ArisDcChartBarService', () => {

  let component: ArisChartComponent;
  let fixture: ComponentFixture<ArisChartComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisChartComponent],
      imports: [ArisI18nModule, LocalizationModule],
      providers: [ArisChartCommonService, ArisChartService, DatePipe, ArisDcChartService,
        TranslationService, InjectorRef, ArisDcChartBarService]
    }).compileComponents();
  });

  beforeEach(() => {
      // create component and test fixture
    fixture = TestBed.createComponent(ArisChartComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    component.data =   [
      {
        Expt: "1",
        Run: "1",
        Speed: "850"
      },
      {
        Expt: "1",
        Run: "2",
        Speed: "740"
      },
      {
        Expt: "1",
        Run: "3",
        Speed: "900"
      },
      {
        Expt: "1",
        Run: "4",
        Speed: "1070"
      }
    ];

    component.type = "DC_BAR_CHART" ;
    component.options = {
      height: 200,
      width: 200,
      xAxisAttribute: 'Expt',
      yAxisAttribute: 'Speed',
      scale: 'linear',
      calc: 'avg',
      xAxisLabel: '',
      yAxisLabel: 'Critical Presssure Point',
      exportable: 'true',
      chartTitle: 'Linear Bar Chart',
      openWindow: true
    };

  });

  it('svg element is created', () => {
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('.dc-chart'));
    console.log(component);
    expect(componentEl.nativeElement.querySelector('svg')).toBeTruthy();
  });

});
