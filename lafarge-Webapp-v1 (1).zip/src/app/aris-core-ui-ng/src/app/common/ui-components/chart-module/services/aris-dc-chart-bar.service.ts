import { ArisChartCommonService } from './aris-chart-common.service';
import { ArisDcChartService } from "./aris-dc-chart.service";
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import * as crossfilter_ from 'crossfilter';
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;
import { Injectable } from '@angular/core';
import { TranslationService } from 'angular-l10n';
@Injectable()
export class ArisDcChartBarService extends ArisDcChartService {
  constructor(protected commonService: ArisChartCommonService, protected translation: TranslationService) {
    super(commonService, translation);
  }

  init(scope, element) {
    super.init(scope, element);
  }

  getChart(scope) {
    return dc.barChart(scope.chartElement);
  }

  

  setScale(scope) {
    this.commonService.setScale(scope);
  }
  
  setLinearScale(scope, min, max) {
    scope.chart.x(d3.scale.linear().domain([min, max + 1]));
    if (scope.rangeChart) {
      scope.rangeChart.x(d3.scale.linear().domain([min, max + 1]));
    }
  }

  setTip(scope) {
    this.setupTip(scope, this.htmlTemplateFn, ".bar");
  }

  setAdditionalChartAttributes(scope) {
    this.commonService.setCommonCoordinateGridChartAttributes(scope);

    scope.chart
    //.mousezoomable(true)
    .elasticY(true)
    .renderHorizontalGridLines(true)
    .renderTitle(false)
    .elasticX(true);

    this.commonService.setValueAcc(scope);
  }

  setGroup(scope) {
    let group = null;
    if (scope.options.calc === "sameColVal") {
      group = scope.dimension.group().reduceSum((d) => {
        return d[scope.options.yAxisAttribute];
      });
    } else if (scope.options.calc !== "sameColVal" || !scope.options.calc) {
      group = scope.dimension.group().reduce(
        this.commonService.reduceAvgAdd((d) => {
          return d[scope.options.yAxisAttribute];
        }),
      this.commonService.reduceAvgRemove((d) => {
        return d[scope.options.yAxisAttribute];
      }),
      this.commonService.reduceAvgInitial());
    }
    scope.chart.group(group);
  }

  /**************************************** Private Method ****************************************/

  htmlTemplateFn(d) {
    let tempHtml;
    if (d.y % 1 !== 0) {
      tempHtml = "<span style='color: #d4cf2f'>" +  d.x + "</span>: "  + d.y.toFixed(2);
    } else {
      tempHtml = "<span style='color: #d4cf2f'>" +  d.x + "</span>: "  + d.y;
    }
    return tempHtml;
  }


}
