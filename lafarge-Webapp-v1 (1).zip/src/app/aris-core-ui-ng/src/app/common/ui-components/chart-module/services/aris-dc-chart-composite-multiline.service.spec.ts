/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { ArisChartComponent } from '../aris-chart.component';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DebugElement } from '@angular/core';
import { DatePipe } from '@angular/common';
import { By } from '@angular/platform-browser';

import { ArisDcChartService } from './aris-dc-chart.service';
import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { ArisChartService } from './aris-chart.service';
import { ArisDcChartCompositeMultilineService } from './aris-dc-chart-composite-multiline.service';



xdescribe('Service: ArisDcChartCompositeMultilineService', () => {

  let component: ArisChartComponent;
  let fixture: ComponentFixture<ArisChartComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisChartComponent],
      imports: [ArisI18nModule, LocalizationModule],
      providers: [ArisChartCommonService, ArisChartService, DatePipe, ArisDcChartService,
        TranslationService, InjectorRef, ArisDcChartCompositeMultilineService]
    }).compileComponents();
  });

  beforeEach(() => {
      // create component and test fixture
    fixture = TestBed.createComponent(ArisChartComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    component.data =   [
      {
        date: "1985-10-31T18:30:00.000Z",
        open: "115.48",
        high: "116.78",
        low: "115.48",
        close: "116.28",
        volume: "9009",
        oi: "0"
      },
      {
        date: "1985-11-15T18:30:00.000Z",
        open: "115.48",
        high: "116.78",
        low: "115.48",
        close: "116.28",
        volume: "9009",
        oi: "0"
      },
      {
        date: "1985-11-16T18:30:00.000Z",
        open: "116.28",
        high: "117.07",
        low: "115.82",
        close: "116.04",
        volume: "7534",
        oi: "0"
      }
    ];

    component.type = "DC_COMPOSITE_MULTILINE_CHART" ;
    component.options = {
      height: 200,
      width: 200,
      yAxisAttribute: 'open',
      xAxisAttribute: 'date',
      rightYAxisAttribute: 'volume',
      yAxisLabel: 'open',
      rightYAxisLabel: 'volume',
      xAxisLabel: 'Date',
      lineLegend: 'YAxis',
      rightLineLegend: 'Right-YAxis',
      chartTitle: 'Monthly Index Abs Move & Volume Chart',
      showRangeChart: false,
      scale: 'date',
      rightYaxisCalc: 'sum',
      calc: 'sum',
      rightYAxisOrdinalCol: 'red',
      yAxisOrdinalCol: 'blue',
      showLegends: true,
      exportable: 'true',
      openWindow: true
    };

  });

  it('svg element is created', () => {
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('.dc-chart'));
    console.log(component);
    expect(componentEl.nativeElement.querySelector('svg')).toBeTruthy();
  });

});
