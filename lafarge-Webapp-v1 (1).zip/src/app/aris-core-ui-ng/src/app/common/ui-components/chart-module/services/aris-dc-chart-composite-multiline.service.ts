import { ArisChartCommonService } from './aris-chart-common.service';
import { ArisDcChartService } from "./aris-dc-chart.service";
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import * as crossfilter_ from 'crossfilter';
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;
import { Injectable } from '@angular/core';
import { TranslationService } from 'angular-l10n';
@Injectable()
export class ArisDcChartCompositeMultilineService extends ArisDcChartService {
  constructor(protected commonService: ArisChartCommonService, protected translation: TranslationService) {
    super(commonService, translation);
  }

  init(scope, element) {
    super.init(scope, element);
  }

  getChart(scope) {
    let compositeChart: any = dc.compositeChart(scope.chartElement);
    let leftChart = this.setChart(scope.options.chartType, compositeChart);
    let rightChart = this.setChart(scope.options.rightChartType, compositeChart);;
    compositeChart.compose([leftChart, rightChart]);
    return compositeChart;
  }

  setChart(type, chart) {
    if (type === "bar") {
      return dc.barChart(chart);
    } else if (type === "line") {
      return dc.lineChart(chart);
    }
  }

  setTip(scope) {
    this.setupTip(scope, this.htmlTemplateFn(scope), ".bar, .dot");
  }

  setScale(scope) {
    this.commonService.setScale(scope);
  }

  setAdditionalChartAttributes(scope) {
    this.commonService.setCommonCoordinateGridChartAttributes(scope);
    scope.chart.children()[0]
      .colors(scope.options.yAxisOrdinalCol);
    scope.chart.children()[1]
      .colors(scope.options.rightYAxisOrdinalCol)
      .useRightYAxis(true);
    scope.chart
         .yAxisLabel(scope.options.yAxisLabel)
         .rightYAxisLabel(scope.options.rightYAxisLabel)
         // .mouseZoomable(true)
         .renderHorizontalGridLines(true);    this.commonService.setCompositeValueAcc(scope.chart.children()[0], scope.options.calc);
    this.commonService.setCompositeValueAcc(scope.chart.children()[1], scope.options.rightCalc);
  }

  setGroup(scope) {
    let group1 = scope.dimension.group().reduce(
                   this.commonService.reduceAvgAdd((d) => {
                     return d[scope.options.yAxisAttribute];
                   }),
                   this.commonService.reduceAvgRemove((d) => {
                     return d[scope.options.yAxisAttribute];
                   }),
                   this.commonService.reduceAvgInitial()
                   );
    let group2 = scope.dimension.group().reduce(
                   this.commonService.reduceAvgAdd((d) => {
                     return d[scope.options.rightYAxisAttribute];
                   }),
                   this.commonService.reduceAvgRemove((d) => {
                     return d[scope.options.rightYAxisAttribute];
                   }),
                   this.commonService.reduceAvgInitial()
                   );
    scope.chart.children()[0].group(group1, scope.options.lineLegend);
    scope.chart.children()[1].group(group2, scope.options.rightLineLegend);
  }

  setDimension(scope) {
    scope.dimension = scope.crossfilter.dimension((d) => {
      return d[scope.options.xAxisAttribute];
    });
  }

  setLegendWidth(scope) {
    super.setLegendWidth(scope);
  }

  calculateLegendWidthFromGroup(scope) {
    let maxLengendChars = 0;
    let legends = scope.chart.children()[1].group().all()[0].value;
    Object.keys(legends).forEach((value, key) => {
      if (value.length > maxLengendChars) {
        maxLengendChars = value.length;
      }
    });
    scope.options.legendWidth = maxLengendChars * 15; // 5 is width of one char.
  }

  postRedraw(scope) {
  }

  /******************************* Private Method ************************************/
  htmlTemplateFn(scope) {
    return (d) => {
      return "<span style='color: #d4cf2f'><i>" + d.x + "</i></span> : " + d.y;
    };
  }


}
