/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { ArisChartComponent } from '../aris-chart.component';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DebugElement } from '@angular/core';
import { DatePipe } from '@angular/common';
import { By } from '@angular/platform-browser';

import { ArisDcChartService } from './aris-dc-chart.service';
import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { ArisChartService } from './aris-chart.service';
import { ArisDcChartCustomBarService } from './aris-dc-chart-custombar.service';



xdescribe('Service: ArisDcChartCustomBarService', () => {

  let component: ArisChartComponent;
  let fixture: ComponentFixture<ArisChartComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisChartComponent],
      imports: [ArisI18nModule, LocalizationModule],
      providers: [ArisChartCommonService, ArisChartService, DatePipe, ArisDcChartService,
        TranslationService, InjectorRef, ArisDcChartCustomBarService]
    }).compileComponents();
  });

  beforeEach(() => {
      // create component and test fixture
    fixture = TestBed.createComponent(ArisChartComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    component.data =  [
      {
        sewer_spill_100mile: 7.3,
        city: "L.A."
      },
      {
        sewer_spill_100mile: 4.5,
        city: "Dallas"
      },
      {
        sewer_spill_100mile: 5.6,
        city: "Atlanta"
      }
    ];

    component.type = "DC_CUSTOM_BAR_CHART" ;
    component.options = {
      xAxisAttribute: 'city',
      yAxisAttribute: 'sewer_spill_100mile',
      yAxisLabel: 'Total Spills km of sewer',
      chartTitle: 'Custom Bar Chart',
      scale: 'ordinal',
      exportable: true,
      openWindow: true,
      barPadding: 0.1,
      outerPadding: 0.05,
      gap: 60
    };

  });

  it('svg element is created', () => {
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('.dc-chart'));
    console.log(component);
    expect(componentEl.nativeElement.querySelector('svg')).toBeTruthy();
  });

});
