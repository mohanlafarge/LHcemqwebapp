import { ArisDcChartService } from './aris-dc-chart.service';
import { Injectable } from '@angular/core';
import { ArisChartCommonService } from './aris-chart-common.service';
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';

import * as arisCustomBarChart from '../charts/aris-dc-custombar-chart';
import { TranslationService } from 'angular-l10n';

@Injectable()
export class ArisDcChartCustomBarService extends ArisDcChartService {

  constructor(protected arisChartCommonService: ArisChartCommonService, protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }

  init(chartScope, element) {
    super.init(chartScope, element);
  }

  getChart(chartScope) {
    return arisCustomBarChart.default(dc, chartScope.chartElement, null);
  }

  setScale(chartScope) {
    this.arisChartCommonService.setScale(chartScope);
  }

  setTip(chartScope) {
    super.setupTip(chartScope, this.htmlTemplateFn, 'rect');
  }

  setAdditionalChartAttributes(chartScope) {
    chartScope.chart
    .brushOn(false)
    .gap(chartScope.options.gap || 60)
    .barPadding(chartScope.options.barPadding || 0.1)
    .outerPadding(chartScope.options.outerPadding || 0.05)
    .renderTitle(false);
  }

  setGroup(chartScope) {
    chartScope.chart.group(
        chartScope.dimension.group().reduceSum((d) => {
          return d[chartScope.options.yAxisAttribute];
        })
      );
  }

  postRender(scope) {
    super.postRender(scope);
  }

  postRedraw(chartScope) {

  }

  redrawChart(chartScope) {
    chartScope.chart = this.getChart(chartScope.chartElement);
    super.drawChart(chartScope);
  }

  /* ---------------------------------- Private methods ----------------------------------------------------*/
  htmlTemplateFn(d) {
    return '<span style="color: #d4cf2f">' +  d.x + '</span>: '  + d.y;
  }

}
