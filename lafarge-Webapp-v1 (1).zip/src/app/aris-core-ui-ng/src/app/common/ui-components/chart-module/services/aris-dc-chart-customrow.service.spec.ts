/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { ArisChartComponent } from '../aris-chart.component';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DebugElement } from '@angular/core';
import { DatePipe } from '@angular/common';
import { By } from '@angular/platform-browser';

import { ArisDcChartService } from './aris-dc-chart.service';
import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { ArisChartService } from './aris-chart.service';
import { ArisDcCustomRowChartService } from './aris-dc-chart-customrow.service';



xdescribe('Service: ArisDcCustomRowChartService', () => {

  let component: ArisChartComponent;
  let fixture: ComponentFixture<ArisChartComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisChartComponent],
      imports: [ArisI18nModule, LocalizationModule],
      providers: [ArisChartCommonService, ArisChartService, DatePipe, ArisDcChartService,
        TranslationService, InjectorRef, ArisDcCustomRowChartService]
    }).compileComponents();
  });

  beforeEach(() => {
      // create component and test fixture
    fixture = TestBed.createComponent(ArisChartComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    component.data = [{ title: 'PRODUCTION', supplyStatus: 16.08033 },
                    { title: 'TARGET', supplyStatus: 26.0 },
                    { title: 'DEMAND', supplyStatus: 27.530473926 }];

    component.type = "DC_CUSTOM_ROW_CHART" ;
    component.options = {
      height: 200,
      width: 200,
      xAxisAttribute: 'title',
      yAxisAttribute: 'supplyStatus',
      chartTitle: 'Custom Row Chart',
      exportable: true,
      openWindow: false,
    };

  });

  it('svg element is created', () => {
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('.dc-chart'));
    console.log(component);
    expect(componentEl.nativeElement.querySelector('svg')).toBeTruthy();
  });

});
