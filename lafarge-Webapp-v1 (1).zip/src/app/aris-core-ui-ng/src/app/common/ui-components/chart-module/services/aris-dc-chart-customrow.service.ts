import { Injectable } from '@angular/core';
import { ArisDcChartService } from './aris-dc-chart.service';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DatePipe } from '@angular/common';

import * as d3 from 'd3';
import * as dc from 'dc';
import * as crossfilter from 'crossfilter';
import * as customRowChart from '../charts/aris-dc-customrow-chart';
import { TranslationService } from 'angular-l10n';

// let customRowChart =  require('../charts/aris-dc-customrow-chart.js');

declare var $: any;


@Injectable()
export class ArisDcCustomRowChartService extends ArisDcChartService {

  constructor(protected arisChartCommonService: ArisChartCommonService, private datePipe: DatePipe,
    protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }

  init(chartScope, element) {
    super.init(chartScope, element);
  }

  getChart (chartScope) {
    console.log('-----------------get chart -----------------------');
    return customRowChart.default(dc, chartScope.chartElement, null);
  }

  setTip (chartScope) {
    super.setupTip(chartScope, this.htmlTemplateFn, 'rect');
  }


/**
 * Set scale for chart.
 */

  setScale (chartScope) {
    this.arisChartCommonService.setScale(chartScope);
  }

  setAdditionalChartAttributes (chartScope) {
    chartScope.chart
              .renderTitle(false)
              .ordering(function(d) {
                return +d.key
            });
  }

  setGroup (chartScope) {
    chartScope.chart.group(chartScope.dimension.group().reduceSum((d) => {
      return d[chartScope.options.yAxisAttribute];
    }));
  }

  redrawChart(chartScope) {
    chartScope.chart = this.getChart(chartScope.chartElement);
    super.drawChart(chartScope);
  }

  /* ---------------------------------- Private methods ----------------------------------------------------*/

  htmlTemplateFn(d) {
    return "<span style='color: #d4cf2f'>" +  d.key + "</span>: "  + d.value.toFixed(2);
  }

}
