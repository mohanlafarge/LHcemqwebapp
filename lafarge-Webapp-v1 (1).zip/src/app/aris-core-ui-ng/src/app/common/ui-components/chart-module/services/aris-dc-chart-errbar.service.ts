import { ArisDcChartService } from './aris-dc-chart.service';
import { ArisChartCommonService } from "./aris-chart-common.service";
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import * as crossfilter_ from 'crossfilter';
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;
import { Injectable } from '@angular/core';
import { TranslationService } from 'angular-l10n';
@Injectable()
export class ArisDcChartErrbarService extends ArisDcChartService {
  constructor(protected arisChartCommonService: ArisChartCommonService, protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }

  init(scope, element) {
    super.init(scope, element);
  }

  getChart(scope) {
    return dc.barChart(scope.chartElement);
  }

  setTip(scope) {
    this.setupTip(scope, this.htmlTemplateFn, ".bar");
  }

  setDimension(scope) {
    scope.dimension = scope.crossfilter.dimension((d) => {
      return parseFloat(d[scope.options.xAxisAttribute]);
    });
  }

  setAdditionalChartAttributes(scope) {
    scope.chart
         .elasticY(true)
         .brushOn(false)
         .renderTitle(false)
         .valueAccessor((kv) => {
           return kv.value.avg;
         });
  }

  setGroup(scope) {
    let speedSumGroup = scope.dimension.group().reduce((p, v) => {
      p.count += 1;
      p.sum +=  parseFloat(v[scope.options.yAxisAttribute]);
      let avg = p.sum / p.count;
      let da = avg - p.avg;
      if (p.count > 1) {
        p.let = (p.count - 2) * p.let / (p.count - 1) + da * da / p.count;
      }
      p.stddev = Math.sqrt(p.let);
      p.avg = avg;
      return p;
    }, (p, v) => {
                 // exercise for the reader
    }, () => {
      return {
        sum: 0, count: 0, avg: 0, let: 0
      };
    });

    scope.chart.group(speedSumGroup);
  }

  setScale(scope) {
    this.arisChartCommonService.setScale(scope);
  }

  setLinearScale(chartScope, min, max) {
    chartScope.chart.x(d3.scale.linear().domain([min, max + 1]));
    if (chartScope.rangeChart) {
      chartScope.rangeChart.x(d3.scale.linear().domain([min, max + 1]));
    }
  }

  postRender(scope) {
    let endwid = 5;
    let barWidth = scope.chart.select('rect.bar').attr('width');
    console.log(barWidth);
    let bar = scope.chart.g().select('g.chart-body').selectAll('g.errorbar')
    .data(scope.chart.data()[0].values)
    .enter()
      .append('g')
      .attr('class', 'errorbar');
    bar
      .append('line')
      .attr({
        'stroke-width': 1,
        stroke: 'orange',
        x1: (d) => {
          return scope.chart.x()(d.x) + barWidth / 2;
        },
        y1: (d) => {
          return scope.chart.y()(d.y - d.data.value.stddev);
        },
        x2: (d) => {
          return scope.chart.x()(d.x) + barWidth / 2;
        },
        y2: (d) => {
          return scope.chart.y()(d.y + d.data.value.stddev);
        }
      });
    bar.append('line')
      .attr({
        'stroke-width': 1,
        stroke: 'orange',
        x1: (d) => {
          return scope.chart.x()(d.x) + barWidth / 2 - endwid;
        },
        y1: (d) => {
          return scope.chart.y()(d.y - d.data.value.stddev);
        },
        x2: (d) => {
          return scope.chart.x()(d.x) + barWidth / 2 + endwid;
        },
        y2: (d) => {
          return scope.chart.y()(d.y - d.data.value.stddev);
        }
      });
    bar.append('line')
      .attr({
        'stroke-width': 1,
        stroke: 'orange',
        x1: (d) => {
          return scope.chart.x()(d.x) + barWidth / 2 - endwid;
        },
        y1: (d) => {
          return scope.chart.y()(d.y + d.data.value.stddev);
        },
        x2: (d) => {
          return scope.chart.x()(d.x) + barWidth / 2 + endwid;
        },
        y2: (d) => {
          return scope.chart.y()(d.y + d.data.value.stddev);
        }
      });

    super.postRender(scope);
  }

  /***************** Private Method ******************************/
  htmlTemplateFn(d) {
    let tempHtml;
    if (d.y % 1 !== 0) {
      tempHtml = "<span style='color: #d4cf2f'>" +  d.x + "</span>: "  + d.y.toFixed(2);
    } else {
      tempHtml = "<span style='color: #d4cf2f'>" +  d.x + "</span>: "  + d.y;
    }
    return tempHtml;
  }
}
