/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { ArisChartComponent } from '../aris-chart.component';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DebugElement } from '@angular/core';
import { DatePipe, CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';

import { ArisDcChartService } from './aris-dc-chart.service';
import { ArisDcChartErrbarService } from './aris-dc-chart-errbar.service';
import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { ArisChartService } from './aris-chart.service';
import { ArisDcHorizontalErrorBarChartService } from './aris-dc-chart-horizerrbar.service';
// import { TranslationService } from 'angular-l10n';





xdescribe('Service: ArisDcChartHorizErrbarService', () => {

  let component: ArisChartComponent;
  let fixture: ComponentFixture<ArisChartComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisChartComponent],
      imports: [ReactiveFormsModule, HttpClientModule, NgSelectModule, CommonModule, ArisI18nModule, LocalizationModule],
      providers: [ArisChartCommonService, ArisChartService, DatePipe, ArisDcChartErrbarService, ArisDcChartService,
        TranslationService, InjectorRef, ArisDcHorizontalErrorBarChartService]
    }).compileComponents();
  });

  beforeEach(() => {
      // create component and test fixture
    fixture = TestBed.createComponent(ArisChartComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    component.data =   [
      {
        assetName: "ST3080",
        avg: 40.77803872259886,
        min: 6.099999905,
        max: 58.5
      },
      {
        assetName: "ST2281",
        avg: 37.608859785779806,
        min: 17.60000038,
        max: 61
      },
      {
        assetName: "ST2280",
        avg: 35.04312830732393,
        min: -0.899999976,
        max: 51.29999924
      }
    ];

    component.type = "DC_HORIZONTAL_ERROR_BAR_CHART" ;
    component.options = {
      xAxisAttribute: 'assetName',
      xAxisLabel: 'Asset Id',
      yAxisAttribute: 'avg',
      yAxisLabel: 'Avg Pressure',
      chartTitle: 'Error Chart',
      scale: 'ordinal',
      exportable: true,
      openWindow: true,
      width: '390',
      height: '260',
      timeFormatType: '%b %d',
      maxErrorAttribute: 'max',
      minErrorAttribute: 'min',
      renderTitle: false,
      errorEndPointHeight: 5,
      maxErrorValue: 2,
      minErrorValue: 2,
      avgValue: 2
    };

  });

  it('svg element is created', () => {
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('.dc-chart'));
    console.log(component);
    expect(componentEl.nativeElement.querySelector('svg')).toBeTruthy();
  });

});
