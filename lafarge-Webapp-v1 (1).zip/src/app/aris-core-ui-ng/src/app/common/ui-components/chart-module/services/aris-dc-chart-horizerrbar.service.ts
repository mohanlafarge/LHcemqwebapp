import { ArisDcChartService } from './aris-dc-chart.service';
import { Injectable } from '@angular/core';
import * as dc from 'dc';
import * as d3 from 'd3';
import * as arisHorizontalErrorRowChart from '../charts/aris-dc-horizontalerrorrow-chart';
import { ArisChartCommonService } from './aris-chart-common.service';
import { TranslationService } from 'angular-l10n';

@Injectable()
export class ArisDcHorizontalErrorBarChartService extends ArisDcChartService {

  maxAvgFloor: any;
  minAvgFloor: any;
  errorBarGroup: any;
  val: any;
  constructor(protected arisChartCommonService: ArisChartCommonService, protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }

  init(chartScope, element) {
    super.init(chartScope, element);
  }

  getChart(chartScope) {
    return arisHorizontalErrorRowChart.default(dc, chartScope.chartElement, null);
  }

  setTip(chartScope) {
    this.setupTip(chartScope, this.htmlTemplateFn(chartScope), '.row');
  }

  htmlTemplateFn(chartScope) {
    return function (d) {
      this.maxAvgFloor = d.value.maxError.avg.toFixed(chartScope.options.maxErrorValue || 2);
      this.minAvgFloor = d.value.minError.avg.toFixed(chartScope.options.minErrorValue || 2);
      return '<span style="color: #d4cf2f"><i>' + d.key + '</i></span> : '  + d.value.avg.toFixed(chartScope.options.avgValue || 2) +
                 '<span style="color: #dad4d4; font-family: monospace;"><i> (-' + this.minAvgFloor + ', +' + this.maxAvgFloor + ')</i></span>';
    };
  }

  setAdditionalChartAttributes(chartScope) {
    chartScope.chart
    .elasticX(true)
    .valueAccessor((p) => {
      return p.value.avg;
    })
    .minErrorAccessor((p) => {
      return p.value.minError.avg;
    })
    .maxErrorAccessor((p) => {
      return p.value.maxError.avg;
    })
    .errorEndPointHeight(chartScope.options.errorEndPointHeight || 5)
    .renderTitle(chartScope.options.renderTitle || false);
  }

  getMaxLengthOfYAxisTickLabel(chartScope) {
    return 0;
  }

  setGroup(chartScope) {
    this.errorBarGroup = chartScope.dimension.group().reduce(
        this.reduceAvgAdd(chartScope),
        this.reduceAvgRemove(chartScope),
        this.reduceAvgInitial(chartScope)
        );

    chartScope.chart.group(this.errorBarGroup);
  }

  reduceAvgAdd(chartScope) {
    return  (p, v) => {
      this.avgAdd(p, v[chartScope.options.yAxisAttribute]);
      this.avgAdd(p.maxError, v[chartScope.options.maxErrorAttribute]);
      this.avgAdd(p.minError, v[chartScope.options.minErrorAttribute]);
      return p;
    };
  }

  reduceAvgRemove(chartScope) {
    return  (p, v) => {
      this.avgRemove(p, v[chartScope.options.yAxisAttribute]);
      this.avgRemove(p.maxError, v[chartScope.options.maxErrorAttribute]);
      this.avgRemove(p.minError, v[chartScope.options.minErrorAttribute]);
      return p;
    };
  }


  reduceAvgInitial(chartScope) {
    return  () => { return { sum: 0, avg: 0, count: 0, maxError: { sum: 0, avg: 0, count: 0 }, minError: { sum: 0, avg: 0, count: 0 } }; };
  }

  avgAdd(d, v) {
    this.val = (v === '' || isNaN(v)) ? 0.0 : parseFloat(v);
    d.sum = d.sum + this.val;
    d.count = d.count + 1;
    d.avg = d.sum / d.count;

    return d;
  }

  avgRemove(d, v) {
    d.sum = d.sum - parseFloat(v);
    d.count = d.count + 1;
    d.avg = d.sum / d.count;

    return d;
  }

}
