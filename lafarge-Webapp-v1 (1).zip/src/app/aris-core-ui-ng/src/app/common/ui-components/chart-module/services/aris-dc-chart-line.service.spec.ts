/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { ArisChartComponent } from '../aris-chart.component';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DebugElement } from '@angular/core';
import { DatePipe, CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';

import { ArisDcChartService } from './aris-dc-chart.service';
import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { ArisChartService } from './aris-chart.service';
import { ArisDcLineChartService } from './aris-dc-chart-line.service';




xdescribe('Service: ArisDcLineChartService', () => {

  let component: ArisChartComponent;
  let fixture: ComponentFixture<ArisChartComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisChartComponent],
      imports: [ArisI18nModule, LocalizationModule],
      providers: [ArisChartCommonService, ArisChartService, DatePipe, ArisDcChartService,
        TranslationService, InjectorRef, ArisDcLineChartService]
    }).compileComponents();
  });

  beforeEach(() => {
      // create component and test fixture
    fixture = TestBed.createComponent(ArisChartComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    component.data =   [
      {
        incidentreferencenumber: 10,
        incidentCause: "COLLAPSE",
        dtvIncidentDate: 1262322000000,
        dtvLevel: null
      },
      {
        incidentreferencenumber: 17,
        incidentCause: "DEBRIS",
        dtvIncidentDate: 1262322000000,
        dtvLevel: null
      },
      {
        incidentreferencenumber: 23,
        incidentCause: "GREASE",
        dtvIncidentDate: 1262322000000,
        dtvLevel: null
      },
      {
        incidentreferencenumber: 6,
        incidentCause: "RAIN",
        dtvIncidentDate: 1262322000000,
        dtvLevel: null
      },
      {
        incidentreferencenumber: 9,
        incidentCause: "ROOTS",
        dtvIncidentDate: 1262322000000,
        dtvLevel: null
      },
      {
        incidentreferencenumber: 11,
        incidentCause: "UNKNOWN ",
        dtvIncidentDate: 1262322000000,
        dtvLevel: null
      }
    ];

    component.type = "DC_LINE_CHART" ;
    component.options = {
      height: 200,
      width: 200,
      xAxisAttribute: 'incidentreferencenumber',
      yAxisAttribute: 'incidentreferencenumber',
      scale: 'linear',
      xAxisLabel: 'Line Chart linear X Axis',
      yAxisLabel: 'Line Chart linear Y Axis',
      chartTitle: 'Line Chart Linear',
      exportable: true,
      calc: 'sum',
      showRangeChart: true,
      openWindow: true
    };

  });

  it('svg element is created', () => {
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('.dc-chart'));
    console.log(component);
    expect(componentEl.nativeElement.querySelector('svg')).toBeTruthy();
  });

});
