import { Injectable } from '@angular/core';
import { ArisDcChartService } from './aris-dc-chart.service';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DatePipe } from '@angular/common';
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import * as crossfilter_ from 'crossfilter';
import { TranslationService } from 'angular-l10n';
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;

declare var $: any;


@Injectable()
export class ArisDcLineChartService extends ArisDcChartService {

  constructor(protected arisChartCommonService: ArisChartCommonService, private datePipe: DatePipe,
    protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }

  countDecimals(value) {
    if (Math.floor(value) === value) {
      return 0;
    }
    return value.toString().split(".")[1].length || 0;
  }

  init(chartScope, element) {
    // $.extend(chartScope, this);
    super.init(chartScope, element);
  }

  getChart(chartScope) {
    console.log('-----------------get chart -----------------------');
    return dc.lineChart(chartScope.chartElement);
  }

  setTip(chartScope) {
    super.setupTip(chartScope, this.htmlTemplateFn(chartScope), '.dot');
  }


  /**
   * Set scale for chart.
   */

  setScale(chartScope) {
    this.arisChartCommonService.setScale(chartScope);
  }

  setAdditionalChartAttributes(chartScope) {
    this.arisChartCommonService.setCommonCoordinateGridChartAttributes(chartScope);

    chartScope.chart
      // .mousezoomable(false)
      .transitionDuration(1000);
    if (chartScope.options.yAxisTickLimit) {
      chartScope.chart.yAxis().tickFormat((d) => {
        if (this.countDecimals(d) > 2) {
          return d.toFixed(chartScope.options.yAxisTickLimit);
        } else {
          return d;
        }
      });
    }


    if (chartScope.options.lineColor) {
      chartScope.chart.lineColor(chartScope.options.lineColor);
    }

    this.arisChartCommonService.setValueAcc(chartScope);

    if (chartScope.options.numXAxisTicks) {
      chartScope.chart.xAxis().ticks(parseInt(
        chartScope.options.numXAxisTicks, 10)).tickFormat(d3.time.format(chartScope.options.timeFormatType));
      if (chartScope.rangeChart) {
        chartScope.rangeChart.xAxis().ticks(parseInt(
          chartScope.options.numXAxisTicks, 10)).tickFormat(d3.time.format(chartScope.options.timeFormatType));
      }
    }
  }

  getRangeChart(chartScope, rangeChartElement) {
    return dc.lineChart(rangeChartElement);
  }

  setGroup(chartScope) {
    let group;
    // if calc is equal to "sameColVal", the value present in the chartScope.yAxisAttribute column would be used as the y axis values//
    if (chartScope.options.calc === 'sameColVal') {
      group = chartScope.dimension.group().reduceSum(function (d) { return d[chartScope.options.yAxisAttribute]; });
    } else if (chartScope.options.calc !== 'sameColVal' || !chartScope.options.calc) {
      group = chartScope.dimension.group().reduce(
        this.arisChartCommonService.reduceAvgAdd(function (d) { return d[chartScope.options.yAxisAttribute]; }),
        this.arisChartCommonService.reduceAvgRemove(function (d) { return d[chartScope.options.yAxisAttribute]; }),
        this.arisChartCommonService.reduceAvgInitial()
      );
    }
    chartScope.chart.group(group);
  }

  /* ---------------------------------- Private methods ----------------------------------------------------*/

  htmlTemplateFn(chartScope) {
    if (chartScope.options.scale === 'date') {
      return (d) => {
        return '<span style="color: #d4cf2f"><i>' +
          this.datePipe.transform(d.x, 'yyyy-MM-dd HH:mm:ss') + '</i></span> : ' + d.y.toFixed(2);
      };
    // tslint:disable-next-line:no-else-after-return
    } else {
      return (d) => {
        return '<span style="color: #d4cf2f"><i>' + d.x + '</i></span> : ' + d.y;
      };
    }
  }

  getDashStyle(chartScope) {
    if (chartScope.options.dashStyle === 'dashed') {
      return '10,10';
    }
    if (chartScope.options.dashStyle === 'dotted') {
      return '2,2';
    }
    return '';
  }
}
