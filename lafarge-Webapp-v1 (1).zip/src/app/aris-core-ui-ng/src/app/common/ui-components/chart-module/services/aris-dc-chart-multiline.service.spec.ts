/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { ArisChartComponent } from '../aris-chart.component';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DebugElement } from '@angular/core';
import { DatePipe, CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';

import { ArisDcChartService } from './aris-dc-chart.service';
import { ArisDcChartErrbarService } from './aris-dc-chart-errbar.service';
import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { ArisChartService } from './aris-chart.service';
import { ArisDChartMultilineService } from './aris-dc-chart-multiline.service';



xdescribe('Service: ArisDChartMultilineService', () => {

  let component: ArisChartComponent;
  let fixture: ComponentFixture<ArisChartComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisChartComponent],
      imports: [ReactiveFormsModule, HttpClientModule, NgSelectModule, CommonModule, ArisI18nModule, LocalizationModule],
      providers: [ArisChartCommonService, ArisChartService, DatePipe, ArisDcChartErrbarService, ArisDcChartService,
        TranslationService, InjectorRef, ArisDChartMultilineService]
    }).compileComponents();
  });

  beforeEach(() => {
      // create component and test fixture
    fixture = TestBed.createComponent(ArisChartComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    component.data =   [
      {
        WATER_SUPPLY_ZONE_TREND_ID: "1",
        FUNCTIONAL_AREA_ID: "11",
        ASSET_OBJECT_TYPE_ID: "11",
        ASSET_ID: "0",
        ASSET_OBJECT_TYPE_NAME: "Water Supply Zone",
        ASSET_NAME: "CROMERS",
        WSZ_FLOW: "0.24",
        DTV_WSZ_FLOW: "2015-10-18T18:30:00.000Z",
        WSZ_RISK_ALERT_RAG: "GREEN",
        DTV_WSZ_RISK_ALERT_RAG: "10/19/2015 0:00",
        WSZ_ROLLING_24_HOUR_FLOW: "0.41",
        DTV_WSZ_ROLLING_24_HOUR_FLOW: "10/19/2015 0:00",
        DATE_TIME_VALUE: "9/13/2016 10:33",
        TIME_WSZ_FLOW: 1
      },
      {
        WATER_SUPPLY_ZONE_TREND_ID: "2",
        FUNCTIONAL_AREA_ID: "11",
        ASSET_OBJECT_TYPE_ID: "11",
        ASSET_ID: "0",
        ASSET_OBJECT_TYPE_NAME: "Water Supply Zone",
        ASSET_NAME: "CROMERS",
        WSZ_FLOW: "0.23",
        DTV_WSZ_FLOW: "2015-10-18T18:45:00.000Z",
        WSZ_RISK_ALERT_RAG: "GREEN",
        DTV_WSZ_RISK_ALERT_RAG: "10/19/2015 0:15",
        WSZ_ROLLING_24_HOUR_FLOW: "0.41",
        DTV_WSZ_ROLLING_24_HOUR_FLOW: "10/19/2015 0:15",
        DATE_TIME_VALUE: "9/13/2016 10:33",
        TIME_WSZ_FLOW: 1
      },
      {
        WATER_SUPPLY_ZONE_TREND_ID: "3",
        FUNCTIONAL_AREA_ID: "11",
        ASSET_OBJECT_TYPE_ID: "11",
        ASSET_ID: "0",
        ASSET_OBJECT_TYPE_NAME: "Water Supply Zone",
        ASSET_NAME: "CROMERS",
        WSZ_FLOW: "0.23",
        DTV_WSZ_FLOW: "2015-10-18T19:00:00.000Z",
        WSZ_RISK_ALERT_RAG: "GREEN",
        DTV_WSZ_RISK_ALERT_RAG: "10/19/2015 0:30",
        WSZ_ROLLING_24_HOUR_FLOW: "0.41",
        DTV_WSZ_ROLLING_24_HOUR_FLOW: "10/19/2015 0:30",
        DATE_TIME_VALUE: "9/13/2016 10:33",
        TIME_WSZ_FLOW: 1
      },
      {
        WATER_SUPPLY_ZONE_TREND_ID: "377",
        FUNCTIONAL_AREA_ID: "11",
        ASSET_OBJECT_TYPE_ID: "11",
        ASSET_ID: "0",
        ASSET_OBJECT_TYPE_NAME: "Water Supply Zone",
        ASSET_NAME: "KINGSBOR ",
        WSZ_FLOW: "0.09",
        DTV_WSZ_FLOW: "2015-10-19T16:30:00.000Z",
        WSZ_RISK_ALERT_RAG: "AMBER",
        DTV_WSZ_RISK_ALERT_RAG: "10/19/2015 22:00",
        WSZ_ROLLING_24_HOUR_FLOW: "0",
        DTV_WSZ_ROLLING_24_HOUR_FLOW: "0000-00-00 00:00:00",
        DATE_TIME_VALUE: "9/13/2016 10:33",
        TIME_WSZ_FLOW: 23
      },
      {
        WATER_SUPPLY_ZONE_TREND_ID: "378",
        FUNCTIONAL_AREA_ID: "11",
        ASSET_OBJECT_TYPE_ID: "11",
        ASSET_ID: "0",
        ASSET_OBJECT_TYPE_NAME: "Water Supply Zone",
        ASSET_NAME: "KINGSBOR ",
        WSZ_FLOW: "0.08",
        DTV_WSZ_FLOW: "2015-10-19T16:45:00.000Z",
        WSZ_RISK_ALERT_RAG: "AMBER",
        DTV_WSZ_RISK_ALERT_RAG: "10/19/2015 22:15",
        WSZ_ROLLING_24_HOUR_FLOW: "0",
        DTV_WSZ_ROLLING_24_HOUR_FLOW: "0000-00-00 00:00:00",
        DATE_TIME_VALUE: "9/13/2016 10:33",
        TIME_WSZ_FLOW: 23
      },
      {
        WATER_SUPPLY_ZONE_TREND_ID: "379",
        FUNCTIONAL_AREA_ID: "11",
        ASSET_OBJECT_TYPE_ID: "11",
        ASSET_ID: "0",
        ASSET_OBJECT_TYPE_NAME: "Water Supply Zone",
        ASSET_NAME: "KINGSBOR ",
        WSZ_FLOW: "0.08",
        DTV_WSZ_FLOW: "2015-10-19T17:00:00.000Z",
        WSZ_RISK_ALERT_RAG: "AMBER",
        DTV_WSZ_RISK_ALERT_RAG: "10/19/2015 22:30",
        WSZ_ROLLING_24_HOUR_FLOW: "0",
        DTV_WSZ_ROLLING_24_HOUR_FLOW: "0000-00-00 00:00:00",
        DATE_TIME_VALUE: "9/13/2016 10:33",
        TIME_WSZ_FLOW: 23
      }
    ];

    component.type = "DC_MULTILINE_CHART" ;
    component.options = {
      xAxisAttribute: 'WATER_SUPPLY_ZONE_TREND_ID',
      yAxisAttribute: 'WSZ_FLOW',
      seriesAttribute: 'ASSET_NAME',
      calc: 'sum',
      scale: 'linear' ,
      xAxisLabel: 'DTV',
      yAxisLabel: 'Average Flow',
      chartTitle: 'Linear Multi Line Chart',
      timeFormatType : '%b %d',
      showRangeChart: true,
      showLegends: true,
      exportable: true,
      openWindow: true
    };

  });

  it('svg element is created', () => {
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('.dc-chart'));
    console.log(component);
    expect(componentEl.nativeElement.querySelector('svg')).toBeTruthy();
  });

});
