import { Injectable } from '@angular/core';
import { ArisDcChartService } from './aris-dc-chart.service';
import { ArisChartCommonService } from './aris-chart-common.service';
import { ArisDataSourceService } from '../../../services/aris-datasource.service';
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import * as crossfilter_ from 'crossfilter';
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;
import { DatePipe } from '@angular/common';
import { TranslationService } from 'angular-l10n';

@Injectable()
export class ArisDChartMultilineService extends ArisDcChartService {

  constructor(protected arisChartCommonService: ArisChartCommonService, private dataFilter: DatePipe,
    protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }


  init(scope, element) {
    super.init(scope, element);
  }

  getChart(scope) {
    return dc.seriesChart(scope.chartElement);
  }

  getRangeChart(scope, rangeChartElement)  {
    return dc.seriesChart(rangeChartElement);
  }

  setDimension(scope) {
    scope.dimension = scope.crossfilter.dimension(
      (d) => {
        return [d[scope.options.xAxisAttribute], d[scope.options.seriesAttribute]];
      }
    );
  }

  setTip(scope) {
    super.setupTip(scope, this.htmlTemplateFn(scope), '.dot');
  }

  setScale(scope) {
    if (scope.data.length !== 0) {
      this.arisChartCommonService.setScale(scope);
    }
  }




  setAdditionalChartAttributes(scope) {
    this.arisChartCommonService.setCommonCoordinateGridChartAttributes(scope);
    scope.chart
      .renderVerticalGridLines(scope.options.renderVerticalGridLines || true)
      .clipPadding(scope.options.clipPadding || 10)
      .seriesAccessor((d) => {
        return '' + d.key[1];
      })
      .keyAccessor((d) => {
        return +d.key[0];
      });

    this.arisChartCommonService.setValueAcc(scope);
    if (scope.options.numXAxisTicks) {
      scope.chart.xAxis().ticks(parseInt(scope.options.numXAxisTicks, scope.options.ticks || 10))
         .tickFormat(d3.time.format(scope.options.timeFormatType));
    }
    if (scope.rangeChart) {
      scope.rangeChart.xAxis().ticks(parseInt(scope.options.numXAxisTicks, scope.options.ticks || 10))
      .tickFormat(d3.time.format(scope.options.timeFormatType));
    }
    if (scope.rangeChart) {
      scope.rangeChart
           .chart((c, a, b, i) => {
             let chart = dc.lineChart(c).interpolate('basis');
             if (i === 0) {
               chart.on('filtered', () => {
                 if (!chart.filter()) {
                   dc.events.trigger(() => {
                     scope.chart.x().domain(scope.chart.xOriginalDomain());
                     scope.chart.redraw();
                   });
                 } else if (!this.rangesEqual(chart.filter(), scope.chart.filter())) {
                   dc.events.trigger(() => {
                     scope.chart.focus(chart.filter());
                   });
                 }
               });
             }
             return chart;
           })
           .clipPadding(scope.options.clipPadding || 10)
           .seriesAccessor((d) => {
             return ' ' + d.key[1];
           })
           .keyAccessor((d) => {
             return +d.key[0];
           });
    }
  }

  setGroup(scope) {
    let group = scope.dimension.group().reduce(
      this.arisChartCommonService.reduceAvgAdd((d) => {
        return d[scope.options.yAxisAttribute];
      }),
      this.arisChartCommonService.reduceAvgRemove((d) => {
        return d[scope.options.yAxisAttribute];
      }),
      this.arisChartCommonService.reduceAvgInitial());
    scope.chart.group(group);
  }

  // TODO: to be reviewed once the datawatch is working
  /*processData(scope) {
    scope.data = scope.data.length !== undefined ? scope.data.sort(this.dynamicSort(scope.options.xAxisAttribute)) : [];
  }*/

  setLegendWidth(scope) {
    // generic solution implemented in aris-dc-chart-service
    super.setLegendWidth(scope);
  }

  calculateLegendWidthFromGroup(chartScope) {
    let keys = chartScope.chart.group().all();
    let maxLengendChars = 0;
    keys.forEach((element, index) => {
      let dataKeys = keys[index].key;
      let legendText;
      if  (Array.isArray(dataKeys)) {
        legendText = dataKeys[1];
      } else {
        legendText = dataKeys.toString();
      }
      if (legendText.length > maxLengendChars) {
        maxLengendChars = legendText.length;
      }
    });
    maxLengendChars * 7 > chartScope.options.width * 0.1 ? chartScope.options.legendWidth = maxLengendChars * 7 :
      chartScope.options.legendWidth = chartScope.options.width * 0.1;
  }

  /*************************************** Private Methods *********************************************************************/

  htmlTemplateFn(scope) {
    if (scope.options.id === "diurnalChart" && scope.options.scale === "ordinal") {
      return (d) => {
        return "<span>" +  d.layer + " (<span style='color: #d4cf2f'><i>" + (d.x - 1) + ":00 - " + d.x +  ":00 hours </i></span>) : "  + d.y.toFixed(2);
      };
    // tslint:disable-next-line:no-else-after-return
    } else if (scope.options.scale === "date") {
      return (d) => {
        return "<span>" +  d.layer + " (<span style='color: #d4cf2f'><i>" + this.dataFilter.transform(d.x, "yyyy-MM-dd HH:mm:ss") + "</span> ): "  + d.y.toFixed(2);
      };
    }  else {
      return (d) => {
        return"<span>" +  d.layer + " (<span style='color: #d4cf2f'><i>" + d.x + "</span> ): "  + d.y.toFixed(2);
      };
    }
  }

  // TODO: to be reviewed once the datawatch is working
  /*dynamicSort(property) {
    let sortOrder = 1;
    let propertyUpdated;
    if (property[0] === '-') {
      sortOrder = -1;
      propertyUpdated = property.substr(1);
    }
    return ((a, b) => {
      let result = (a[propertyUpdated] < b[propertyUpdated]) ? -1 : (a[propertyUpdated] > b[propertyUpdated]) ? 1 : 0;
      return result * sortOrder;
    });
  }*/

  rangesEqual (range1, range2) {
    let isRangeEqual = false;
    if (!range1 && !range2) {
      isRangeEqual = true;
    } else if (!range1 || !range2) {
      isRangeEqual = false;
    } else if (range1.length === 0 && range2.length === 0) {
      isRangeEqual = true;
    } else if (range1[0].valueOf() === range2[0].valueOf() &&
      range1[1].valueOf() === range2[1].valueOf()) {
      isRangeEqual = true;
    }
    return isRangeEqual;
  }
}
