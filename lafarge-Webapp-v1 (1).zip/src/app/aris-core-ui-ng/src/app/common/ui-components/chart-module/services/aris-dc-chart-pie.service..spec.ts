/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { ArisChartComponent } from '../aris-chart.component';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DebugElement } from '@angular/core';
import { DatePipe } from '@angular/common';
import { By } from '@angular/platform-browser';

import { ArisDcChartService } from './aris-dc-chart.service';
import { ArisDcChartErrbarService } from './aris-dc-chart-errbar.service';
import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { ArisChartService } from './aris-chart.service';
import { ArisDcPieChartService } from './aris-dc-chart-pie.service';




xdescribe('Service: ArisDcPieChartService', () => {

  let component: ArisChartComponent;
  let fixture: ComponentFixture<ArisChartComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisChartComponent],
      imports: [ArisI18nModule, LocalizationModule],
      providers: [ArisChartCommonService, ArisChartService, DatePipe, ArisDcChartService,
        TranslationService, InjectorRef, ArisDcPieChartService]
    }).compileComponents();
  });

  beforeEach(() => {
      // create component and test fixture
    fixture = TestBed.createComponent(ArisChartComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    component.data =   [
      {
        asset_id: "109525",
        parent_asset_name: "WALLEND WBS",
        asset_name: "Wallend WBS flow to Kingsborough",
        date_time_value: "1/6/2016 5:00",
        flow_mld: "6.484375",
        pressure_m: "",
        pump_status1: "STOPPED",
        dateTimeValue: "2016-05-31T23:30:00.000Z",
        parentAssetName: "WALLEND WBS",
        assetName: "Wallend WBS flow to Kingsborough",
        assetId: "109525",
        flowMld: "6.484375",
        pressureM: "",
        pumpStatus1: "STOPPED"
      },
      {
        asset_id: "109525",
        parent_asset_name: "WALLEND WBS",
        asset_name: "Wallend WBS flow to Kingsborough",
        date_time_value: "1/6/2016 5:15",
        flow_mld: "6.445312023",
        pressure_m: "",
        pump_status1: "STOPPED",
        dateTimeValue: "2016-05-31T23:45:00.000Z",
        parentAssetName: "WALLEND WBS",
        assetName: "Wallend WBS flow to Kingsborough",
        assetId: "109525",
        flowMld: "6.445312023",
        pressureM: "",
        pumpStatus1: "STOPPED"
      },
      {
        asset_id: "109525",
        parent_asset_name: "WALLEND WBS",
        asset_name: "Wallend WBS flow to Kingsborough",
        date_time_value: "1/6/2016 5:30",
        flow_mld: "6.414062023",
        pressure_m: "",
        pump_status1: "STOPPED",
        dateTimeValue: "2016-06-01T00:00:00.000Z",
        parentAssetName: "WALLEND WBS",
        assetName: "Wallend WBS flow to Kingsborough",
        assetId: "109525",
        flowMld: "6.414062023",
        pressureM: "",
        pumpStatus1: "STOPPED"
      },
      {
        asset_id: "109525",
        parent_asset_name: "WALLEND WBS",
        asset_name: "Wallend WBS flow to Kingsborough",
        date_time_value: "1/6/2016 5:45",
        flow_mld: "6.375",
        pressure_m: "",
        pump_status1: "STOPPED",
        dateTimeValue: "2016-06-01T00:15:00.000Z",
        parentAssetName: "WALLEND WBS",
        assetName: "Wallend WBS flow to Kingsborough",
        assetId: "109525",
        flowMld: "6.375",
        pressureM: "",
        pumpStatus1: "STOPPED"
      }
    ];

    component.type = "DC_PIE_CHART" ;
    component.options = {
      radius: '120',
      innerRadius: '60',
      nameAttribute: 'parent_asset_name',
      additionalNameAttribute: 'pump_status1',
      chartTitle: 'Donut Chart',
      calc: 'reduceCount',
      openWindow: true,
      exportable: true,
      legendWidth: 150,
    };

  });

  it('svg element is created', () => {
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('.dc-chart'));
    console.log(component);
    expect(componentEl.nativeElement.querySelector('svg')).toBeTruthy();
  });

});
