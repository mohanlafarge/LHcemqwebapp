import { Injectable } from '@angular/core';
import { ArisDcChartService } from './aris-dc-chart.service';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DatePipe } from '@angular/common';
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import * as crossfilter_ from 'crossfilter';
import { TranslationService } from 'angular-l10n';
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;

declare var $: any;


@Injectable()
export class ArisDcPieChartService extends ArisDcChartService {

  constructor(protected arisChartCommonService: ArisChartCommonService, private datePipe: DatePipe,
    protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }

  init(chartScope, element) {
      // $.extend(chartScope, this);
    super.init(chartScope, element);
  }

  getChart (chartScope) {
    console.log('-----------------get chart -----------------------');
    return dc.pieChart(chartScope.chartElement);
  }

  setTip (chartScope) {
    super.setupTip(chartScope, this.htmlTemplateFn, '.pie-slice');
  }

  postRender(scope) {
    super.postRender(scope);
  }

/**
 * Set scale for chart.
 */

  setScale (chartScope) {
    this.arisChartCommonService.setScale(chartScope);
  }

  setAdditionalChartAttributes (chartScope) {

    chartScope.chart
          .transitionDuration(1000)
          .radius(chartScope.options.radius)
          .innerRadius(chartScope.options.innerRadius)
          .renderTitle(false);

    // chartScope.chart.filter = () => { chartScope.postRedraw(chartScope); };
    if (chartScope.options.rag) {
      chartScope.chart.colors((d) => {
        switch (d) {
          case "AMBER":
            return "rgba(255, 194, 0, 0.67)";
          case "GREEN":
            return "rgba(46, 128, 0, 0.67)";
          case "RED":
            return "rgba(255, 0, 0, 0.6)";
          default:
            return;
        }
      });
    } else {
      chartScope.chart.colors(d3.scale.category10());
    }
  }

  setLegend (chartScope) {
      // If rag pie, don't show legend.
    if (chartScope.options.rag) {
      return;
    }
    chartScope.chart.legend(
      dc.legend()
      .x(chartScope.options.width - 150) // 15 margin between chart and legend.
      .y(25)
      .autoItemWidth(true)
      .itemHeight(10)
      .gap(5)
      );
  }

  setLegendWidth (chartScope) {
    super.setLegendWidth(chartScope);
  }

  setDimension (chartScope) {
    if (chartScope.options.additionalNameAttribute) {
      chartScope.dimension = chartScope.crossfilter.dimension((d) => {
        return [d[chartScope.options.nameAttribute], d[chartScope.options.additionalNameAttribute]];
      });
    } else {
      chartScope.dimension = chartScope.crossfilter.dimension((d) => {
        return d[chartScope.options.nameAttribute];
      });
    }
  }

  setGroup (chartScope) {
    let group;
    if (chartScope.options.calc === "sameColVal") {
      group = chartScope.dimension.group().reduce(
        (p, v) => {
          return v[chartScope.options.valAttribute];
        },
        (p, v) => {
          return v[chartScope.options.valAttribute];
        },
        () => {
        }
    );
    } else if (chartScope.options.calc === "reduceCount") {
      if (chartScope.options.additionalNameAttribute) {
        group = chartScope.dimension.group().reduceCount((d) => {
          return [d[chartScope.options.nameAttribute], d[chartScope.options.additionalNameAttribute]];
        });
      } else {
        group = chartScope.dimension.group().reduceCount((d) => {
          return d[chartScope.options.nameAttribute];
        });
      }
    } else {
      group = chartScope.dimension.group().reduce(
        this.arisChartCommonService.reduceAvgAdd((d) => {
          return d[chartScope.options.valAttribute];
        }),
        this.arisChartCommonService.reduceAvgRemove((d) => {
          return d[chartScope.options.valAttribute];
        }),
        this.arisChartCommonService.reduceAvgInitial()
            );
    }
    chartScope.chart.group(group);
  }

  postRedraw(chartScope) {
    chartScope.chart.selectAll('text.pie-slice').text((d) => {
      let text = dc.utils.printSingleValue((d.endAngle - d.startAngle) / (2 * Math.PI) * 100) + '%';
      return text;
    });

    if (chartScope.options.rag) {
      chartScope.chart.selectAll('g.pie-slice path').attr('fill', (d) => {
        console.log("color: " + d.data.key);
        switch (d.data.key) {
          case "AMBER":
            return "rgba(255, 194, 0, 0.67)";
          case "GREEN":
            return "rgba(46, 128, 0, 0.67)";
          case "RED":
            return "rgba(255, 0, 0, 0.6)";
          default:
            return;
        }
      });
    }
    super.postRedraw(chartScope);
  }

  setLegendDivide(chartScope) {

  }

   /* ---------------------------------- Private methods ----------------------------------------------------*/

  htmlTemplateFn(d) {
    return "<span style='color: #d4cf2f'>" +  d.data.key + "</span>: "  + d.value;
  }

}
