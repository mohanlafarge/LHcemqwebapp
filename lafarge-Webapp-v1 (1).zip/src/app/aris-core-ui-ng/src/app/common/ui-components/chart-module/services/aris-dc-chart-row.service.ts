import { ArisChartCommonService } from './aris-chart-common.service';
import { ArisDcChartService } from './aris-dc-chart.service';
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import * as crossfilter_ from 'crossfilter';
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;
import { Injectable } from '@angular/core';
import { TranslationService } from 'angular-l10n';

@Injectable()
export class ArisDcChartRowService extends ArisDcChartService {
  constructor(protected arisChartCommonService: ArisChartCommonService, protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }

  init(scope, element) {
    super.init(scope, element);
  }

  getChart(scope) {
    return dc.rowChart(scope.chartElement);
  }

  setTip(scope) {
    this.setupTip(scope, this.htmlTemplateFn(scope), 'rect');
  }

  setScale (chartScope) {
    this.arisChartCommonService.setScale(chartScope);
  }

  setAdditionalChartAttributes(scope) {
    this.arisChartCommonService.setValueAcc(scope);
    scope.chart.renderTitle(false);
    if (scope.options.sortable) {
      if (scope.options.sortOrder === "desc") {
        scope.chart.ordering((d) => {
          return -d.value[scope.options.calc];
        });
      } else {
        scope.chart.ordering((d) => {
          return +d.value[scope.options.calc];
        });
      }
    }
  }

  setGroup(scope) {
    let grp = null;
  // if calc is equal to "sameColVal", the value present in the scope.yAxisAttribute column would be used as the y axis values// 
    if (scope.options.calc === 'sameColVal') {
      grp = scope.dimension.group().reduceSum((d) => {
        return d[scope.options.xAxisAttribute];
      });
    } else if (scope.options.calc !== 'sameColVal') {
      grp = scope.dimension.group().reduce(
        this.arisChartCommonService.reduceAvgAdd((d) => {
          return d[scope.options.xAxisAttribute];
        }),
        this.arisChartCommonService.reduceAvgRemove((d) => {
          return d[scope.options.xAxisAttribute];
        }),
        this.arisChartCommonService.reduceAvgInitial()
      );
    }
    scope.chart.group(grp);
    scope.chart.ordering(function(d) { return +d.value[scope.options.calc]; });
  }

  setDimension(scope) {
    scope.dimension = scope.crossfilter.dimension((d) => {
      return d[scope.options.yAxisAttribute];
    });
  }

  // Functions to add x-label & y-label to Row Charts (Unsupported by dc.js)
  addXLabel(scope) {
    let textSelection = scope.chart.svg()
              .append("text")
                .attr("class", "x-axis-label")
                .attr("text-anchor", "middle")
                .attr("x", scope.chart.width() / 2)
                .attr("y", scope.chart.height() - 10)
                .text(this.translation.translate(scope.options.xAxisLabel));
    let textDims = textSelection.node().getBBox();
    let chartMargins = scope.chart.margins();
 
    // Dynamically adjust positioning after reading text dimension from DOM
    textSelection
        .attr("x", chartMargins.left + (scope.chart.width()
          - chartMargins.left - chartMargins.right) / 2)
        .attr("y", scope.chart.height() - Math.ceil(textDims.height) / 2);
  }

  addYLabel (scope) {
    let textSelection = scope.chart.svg()
              .append("text")
                .attr("class", "y-axis-label")
                .attr("text-anchor", "middle")
                .attr("transform", "rotate(-90)")
                .attr("x", -scope.chart.height() / 2)
                .attr("y", 10)
                .text(this.translation.translate(scope.options.yAxisLabel));
    let textDims = textSelection.node().getBBox();
    let chartMargins = scope.chart.margins();
 
    // Dynamically adjust positioning after reading text dimension from DOM
    textSelection
        .attr("x", -chartMargins.top - (scope.chart.height()
          - chartMargins.top - chartMargins.bottom) / 2)
        .attr("y", Math.max(Math.ceil(textDims.height), chartMargins.left + 5
          - Math.ceil(textDims.height) - 1));
  }

  postRedraw(scope) {
    if (!scope.chartElement.querySelector('text.x-axis-label')) {
      this.addXLabel(scope);
    }
    if (!scope.chartElement.querySelector('text.y-axis-label')) {
      this.addYLabel(scope);
    }
    super.postRedraw(scope);
  }


  /***************************** Private Methods **********************************/

  htmlTemplateFn(scope) {
    if (scope.options.calc === 'sameColVal') {
      return ((d) => {
        return '<span style="color: #d4cf2f">' +  d.key + '</span>: '  + d.value;
      });
    // tslint:disable-next-line:no-else-after-return
    } else {
      return (d) => {
        return '<span style="color: #d4cf2f">' +  d.key + '</span>: '  + d.value[scope.options.calc];
      };
    }
  }


}
