/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { ArisChartComponent } from '../aris-chart.component';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DebugElement } from '@angular/core';
import { DatePipe } from '@angular/common';
import { By } from '@angular/platform-browser';

import { ArisDcChartService } from './aris-dc-chart.service';
import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { ArisChartService } from './aris-chart.service';
import { ArisDcChartScatterService } from './aris-dc-chart-scatter.service';




xdescribe('Service: ArisDcChartScatterService', () => {

  let component: ArisChartComponent;
  let fixture: ComponentFixture<ArisChartComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisChartComponent],
      imports: [ArisI18nModule, LocalizationModule],
      providers: [ArisChartCommonService, ArisChartService, DatePipe, ArisDcChartService,
        TranslationService, InjectorRef, ArisDcChartScatterService]
    }).compileComponents();
  });

  beforeEach(() => {
      // create component and test fixture
    fixture = TestBed.createComponent(ArisChartComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    component.data =   [
      {
        Expt: "1",
        Run: "1",
        Speed: "850"
      },
      {
        Expt: "2",
        Run: "16",
        Speed: "940"
      },
      {
        Expt: "3",
        Run: "17",
        Speed: "950"
      },
      {
        Expt: "4",
        Run: "18",
        Speed: "800"
      },
      {
        Expt: "5",
        Run: "19",
        Speed: "810"
      },
      {
        Expt: "6",
        Run: "20",
        Speed: "870"
      }];

    component.type = "DC_SCATTER_CHART" ;
    component.options = {
      width: '990',
      xAxisAttribute: 'Run',
      yAxisAttribute: 'Speed',
      height: '400',
      calcAttribute: 'Expt',
      xAxisLabel: 'Expt',
      color: 'green',
      yAxisLabel: 'Speed',
      exportable: 'true',
      chartTitle: 'Scatter Chart',
      scale: 'linear',
      openWindow: true
    };

  });

  it('svg element is created', () => {
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('.dc-chart'));
    console.log(component);
    expect(componentEl.nativeElement.querySelector('svg')).toBeTruthy();
  });

});
