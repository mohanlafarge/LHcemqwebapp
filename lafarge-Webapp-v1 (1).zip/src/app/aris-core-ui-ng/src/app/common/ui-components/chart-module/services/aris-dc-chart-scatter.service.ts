import { ArisChartCommonService } from './aris-chart-common.service';
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import * as crossfilter_ from 'crossfilter';
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;
import { Injectable } from '@angular/core';
import { ArisDcChartService } from './aris-dc-chart.service';
import { TranslationService } from 'angular-l10n';

@Injectable()
export class ArisDcChartScatterService extends ArisDcChartService {
  constructor(protected arisChartCommonService: ArisChartCommonService, protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }

  init(scope, element) {
    super.init(scope, element);
  }

  getChart(scope) {
    return dc.seriesChart(scope.chartElement);
  }

  setTip(scope) {
    this.setupTip(scope, this.htmlTemplateFn, '.symbol');
  }

  setScale(scope) {
    this.arisChartCommonService.setScale(scope);
  }

  setAdditionalChartAttributes(scope) {
    this.arisChartCommonService.setCommonCoordinateGridChartAttributes(scope);

    let symbolScale = d3.scale.ordinal().range(d3.svg.symbolTypes);
    const symbolAccessor = ((d) => {
      return symbolScale(d.key[0]);
    });
    let subChart = ((c) => {
      return dc.scatterPlot(c)
				// TO DO : .symbol(symbolAccessor)                
				.symbolSize(8)
                .highlightedSize(scope.options.highlightedSize || 10);
    });

    scope.chart
         .chart(subChart)
         //.mousezoomable(true)
         .clipPadding(10)
         .seriesAccessor((d) => {
           return +d.key[0];
         })
         .keyAccessor((d) => {
           return +d.key[1];
         })
         .valueAccessor((d) => {
           return +d.value;
         });
  }

  setDimension(scope) {
    scope.dimension = scope.crossfilter.dimension((d) => {
      return [+d[scope.options.calcAttribute], +d[scope.options.xAxisAttribute]];
    });
  }

  setGroup(scope) {
    let grp = scope.dimension.group().reduceSum((d) => {
      return +d[scope.options.yAxisAttribute];
    });
    scope.chart.group(grp);
  }

  calculateLegendWidthFromGroup(scope) {
    let keys = scope.chart.group().all();
    let maxLengendChars = 0;
    keys.forEach((element, index) => {
      let dataKeys = keys[index].key;
      let legendText = '' + scope.options.calcAttribute + ' ' + dataKeys[1];
      if (legendText.length > maxLengendChars) {
        maxLengendChars = legendText.length;
      }
    });
    scope.options.legendWidth = maxLengendChars * 5; // 5 is width of one char.
  }
/******************************* Private Method *************************************/
  htmlTemplateFn(d) {
    return '<span>' +  d.key[1] + '(</span><span style="color: #d4cf2f">' + d.key[0] + '</span><span>)' + ':' + d.value;
  }
}

