import { Injectable } from '@angular/core';
import { ArisDcChartService } from './aris-dc-chart.service';
import { ArisChartCommonService } from './aris-chart-common.service';

import * as d3 from 'd3';
import * as dc from 'dc';

import * as arisDCGroupedBarChart from '../charts/aris-dc-groupedbar-chart';
import { DatePipe } from '@angular/common';
import { TranslationService } from 'angular-l10n';

@Injectable()
export class ArisDcStkBarChartService extends ArisDcChartService {

  constructor(protected arisChartCommonService: ArisChartCommonService, private datePipe: DatePipe,
  protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }

  init(chartScope, element) {
    super.init(chartScope, element);
  }

  getChart (chartScope) {
    return arisDCGroupedBarChart.default(dc, chartScope.chartElement, null);
  }

  setTip (chartScope) {
    super.setupTip(chartScope, this.htmlTemplateFn(chartScope), '.bar');
  }

  setScale (chartScope) {
    this.arisChartCommonService.setScale(chartScope);
  }

  setAdditionalChartAttributes (chartScope) {
    this.arisChartCommonService.setCommonCoordinateGridChartAttributes(chartScope);

    if (chartScope.options.grouped) {

      chartScope.chart
        .groupBars(chartScope.options.groupBars || true)
        .groupGap(chartScope.options.groupGap || 10)
        .centerBar(chartScope.options.centerBar || true);
    }

    // chartScope.chart.filter = () => { chartScope.postRedraw(chartScope); };

    let stk;
    const di = {};

    chartScope.data.forEach((element, i) => {
      const item = chartScope.data[i][chartScope.options.yAxisAttribute];
      if (!di[item]) {
        di[item] = [];
      }
      di[item].push(chartScope.data[i]);
    });

    const groupKeys1 = {};

    for (const g in Object.keys(di)) {
      if (g) {
        groupKeys1[Object.keys(di)[g]] = 0;
      }
    }

    if (chartScope.options.calcAttribute) {
      stk = chartScope.dimension.group().reduce(
                 (p, v) => {
                   p[v[chartScope.options.yAxisAttribute]] = v[chartScope.options.calcAttribute];
                   return p;
                 },
                 (p, v) => {
                  if (p && p[v[chartScope.options.yAxisAttribute]] === v[chartScope.options.calcAttribute]) {
                   return p[v[chartScope.options.yAxisAttribute]] = v[chartScope.options.calcAttribute];
                  }
                 },
                 () => {
                   return Object.assign({}, groupKeys1);
                 }
            );
    } else {
      stk = chartScope.dimension.group().reduce(
                (p, v) => {
                  p[v[chartScope.options.yAxisAttribute]] = p[v[chartScope.options.yAxisAttribute]] + 1;
                  return p;
                },
                (p, v) => {
                  return p[v[chartScope.options.yAxisAttribute]] = p[v[chartScope.options.yAxisAttribute]] - 1;
                },
                () => {
                  return (<any>Object).assign({}, groupKeys1);
                });
    }

    const dimList = [];

    for (const value of (<any>Object.keys(di).map(val => di[val]))) {
      dimList.push(value[0][chartScope.options.yAxisAttribute]);
    }

    chartScope.chart.group(stk, dimList[0], this.sel_stack(dimList[0]));
    const woType = dimList.splice(1, dimList.length - 1);
    for (const w in woType) {
      if (woType.hasOwnProperty(w)) {
        chartScope.chart.stack(stk, '' + woType[w], this.sel_stack(woType[w]));
      }
    }

    if (chartScope.options.numXAxisTicks) {
      chartScope.chart.xAxis().ticks(parseInt(
                chartScope.options.numXAxisTicks, 10)).tickFormat(d3.time.format(chartScope.options.timeFormatType));
    }
  }

  setGroup (chartScope) {
  }

  setLegendWidth (chartScope) {
    super.setLegendWidth(chartScope);
  }

  htmlTemplateFn(chartScope) {
    if (chartScope.options.scale === 'month') {
      return (d) => {
        return '<span>' + this.datePipe.transform(d.x, 'MMM-yy') + ' (<span style=\'color: #d4cf2f\'><i>'
              + d.layer + '</i></span>) : '  + d.y;
      };
    }
    if (chartScope.options.scale === 'date') {
      return (d) => {
        return'<span>' + this.datePipe.transform(d.x, 'yyyy-MM-dd HH:mm:ss') + ' (<span style=\'color: #d4cf2f\'><i>'
              + d.layer + '</i></span>) : '  + d.y;
      };
    // tslint:disable-next-line:no-else-after-return
    } else {
      return (d) => {
        return'<span>' +  d.x + ' (<span style=\'color: #d4cf2f\'><i>'
                       + d.layer + '</i></span>) : '  + d.y;
      };
    }
  }

  sel_stack(i) {
    return function (d) {
      return d.value[i];
    };
  }
}
