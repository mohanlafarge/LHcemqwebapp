/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { ArisChartComponent } from '../aris-chart.component';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DebugElement } from '@angular/core';
import { DatePipe } from '@angular/common';
import { By } from '@angular/platform-browser';

import { ArisDcChartService } from './aris-dc-chart.service';
import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { ArisChartService } from './aris-chart.service';
import { ArisDcStkBarChartService } from './aris-dc-chart-stkbar.service';




xdescribe('Service: ArisDcStkBarChartService', () => {

  let component: ArisChartComponent;
  let fixture: ComponentFixture<ArisChartComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisChartComponent],
      imports: [ArisI18nModule, LocalizationModule],
      providers: [ArisChartCommonService, ArisChartService, DatePipe, ArisDcChartService,
        TranslationService, InjectorRef, ArisDcStkBarChartService]
    }).compileComponents();
  });

  beforeEach(() => {
      // create component and test fixture
    fixture = TestBed.createComponent(ArisChartComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    component.data =   [
      {
        incidentreferencenumber: 118,
        streamBasin: "COMPTON",
        incidentPublicOrPrivate: "PRIVATE"
      },
      {
        incidentreferencenumber: 34,
        streamBasin: "COMPTON",
        incidentPublicOrPrivate: "PUBLIC"
      },
      {
        incidentreferencenumber: 183,
        streamBasin: "CULVER CITY",
        incidentPublicOrPrivate: "PRIVATE"
      },
      {
        incidentreferencenumber: 153,
        streamBasin: "CULVER CITY",
        incidentPublicOrPrivate: "PUBLIC"
      },
      {
        incidentreferencenumber: 84,
        streamBasin: "HARBOUR GATEWAY",
        incidentPublicOrPrivate: "PUBLIC"
      },
      {
        incidentreferencenumber: 156,
        streamBasin: "HARBOUR GATEWAY",
        incidentPublicOrPrivate: "PRIVATE"
      },
      {
        incidentreferencenumber: 57,
        streamBasin: "HOLLYWOOD",
        incidentPublicOrPrivate: "PUBLIC"
      },
      {
        incidentreferencenumber: 109,
        streamBasin: "HOLLYWOOD",
        incidentPublicOrPrivate: "PRIVATE"
      }];

    component.type = "DC_STACK_ROW_CHART" ;
    component.options = {
      xAxisAttribute: 'incidentCause',
      yAxisAttribute: 'incidentreferencenumber',
      xAxisLabel: 'X Axis',
      yAxisLabel: 'Y Axis',
      scale: 'ordinal',
      chartTitle : 'Stk chart: Ordinal Chart',
      exportable: true,
      groupBars: true,
      centerBar: true,
      openWindow: true,
      xAxisAngle: 20,
      height: 200,
      width: 200
    };

  });

  it('svg element is created', () => {
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('.dc-chart'));
    console.log(component);
    expect(componentEl.nativeElement.querySelector('svg')).toBeTruthy();
  });

});
