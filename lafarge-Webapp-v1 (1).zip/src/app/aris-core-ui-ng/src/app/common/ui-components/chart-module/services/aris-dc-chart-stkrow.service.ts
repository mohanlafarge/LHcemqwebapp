import { Injectable } from '@angular/core';
import { ArisDcChartService } from './aris-dc-chart.service';
import { ArisChartCommonService } from './aris-chart-common.service';
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import * as arisStackableRowChart from '../charts/aris-dc-stackablerow-chart';
import { TranslationService } from 'angular-l10n';

@Injectable()
export class ArisDcChartStkRowService extends ArisDcChartService {
  groupKeys1 = {};
  constructor(protected arisChartCommonService: ArisChartCommonService, protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }

  init(chartScope, element) {
    super.init(chartScope, element);
  }

  getChart(chartScope) {
    return arisStackableRowChart.default(dc, chartScope.chartElement, null);
  }

  setScale(chartScope) {
    chartScope.chart.isOrdinal = function () { return true; };
  }

  setTip(chartScope) {
    this.setupTip(chartScope, this.htmlTemplateFn, '.stack > .row > rect');
  }

  setLegendWidth(chatScope) {
    super.setLegendWidth(chatScope);
  }

  setAdditionalChartAttributes(chartScope) {

    chartScope.chart
          .colors(d3.scale.category10())
          .cappedValueAccessor((d, i) => {
            if (d.others) {
              return d.value;
            }
            return d.y + d.y0;
          });

    let stk: any;
    const di = {};

    for (let i = 0; i < chartScope.data.length; i += 1) {
      let item = chartScope.data[i][chartScope.options.yAxisAttribute];
      if (di !== {}) {
        di[item] = [];
      }
      di[item].push(chartScope.data[i]);
    }

    this.groupKeys1 = {};

    for (let g of Object.keys(di)) {
      this.groupKeys1[g] = 0;
    }
    if (chartScope.options.calcAttribute) {
      stk = chartScope.dimension.group().reduce(
          (p, v) => {
            p[v[chartScope.options.yAxisAttribute]] = v[chartScope.options.calcAttribute];
            return p;
          },
          (p, v) => {
            if (p[v[chartScope.options.yAxisAttribute]] === v[chartScope.options.calcAttribute]) {
              p[v[chartScope.options.yAxisAttribute]] = v[chartScope.options.calcAttribute];
            }
            return p;
          },
          () => {
            return Object.assign({}, this.groupKeys1);
          }
        );
    } else {
      stk = chartScope.dimension.group().reduce((p, v) => {
        p[v[chartScope.options.yAxisAttribute]] = p[v[chartScope.options.yAxisAttribute]] + 1;
        return p;
      },
      (p, v) => {
        return p[v[chartScope.options.yAxisAttribute]] = p[v[chartScope.options.yAxisAttribute]] - 1;
      },
      () => {
        return Object.assign({}, this.groupKeys1);
      }
        );
    }

    const dimList = [];
    for (const value of (<any>Object.keys(di).map(val => di[val]))) {
      dimList.push(value[0][chartScope.options.yAxisAttribute]);
    }

    chartScope.chart.group(stk, dimList[0], this.sel_stack(dimList[0]));
    const woType = dimList.splice(1, dimList.length - 1);
    for (let w in woType) {
      if (woType.hasOwnProperty(w)) {
        chartScope.chart.stack(stk, '' + woType[w], this.sel_stack(woType[w]));
      }
    }

    if (chartScope.options.numXAxisTicks) {
      chartScope.chart.xAxis().ticks(chartScope.options.numXAxisTicks);
    }
  }

  setGroup(chartScope) {
    // Group is set in setAdditionalChartAttributes();
  }


  htmlTemplateFn(d) {
    return "<span>" +  d.x + " (<span style='color: #d4cf2f'><i>" + d.layer + "</i></span>) : "  + d.y;
  }

  sel_stack(i) {
    return function (d) {
      if (d.value === undefined) {
        return d.data.value[i];
      }
      return d.value[i];
    };
  }
}
