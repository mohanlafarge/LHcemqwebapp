import { ArisDcChartService } from "./aris-dc-chart.service";
import { TestBed } from "@angular/core/testing";
import { ArisChartCommonService } from "./aris-chart-common.service";
import { TranslationService, LocalizationModule } from "angular-l10n";
import { DatePipe } from "@angular/common";
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { ArisChartService } from "./aris-chart.service";

xdescribe('Aris DC Chart Service UnitTest:', () => {
  let arisDcChartService: ArisDcChartService;
  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [
      ],
      imports: [
        ArisI18nModule,
        LocalizationModule
      ],
      providers: [
        ArisDcChartService,
        ArisChartCommonService,
        TranslationService,
        DatePipe,
        ArisChartService
      ]
    }).compileComponents();

    afterAll(() => {
      arisDcChartService = null;
    });

    arisDcChartService = TestBed.get(ArisDcChartService);
       //http = TestBed.get(HttpClient);
  });


  it('1. CHeck if dc chart service method setLegendWidth is instanciated', () => {
    let chartScope = {
      options: {
        legendWidth: 5
      }
    };
    arisDcChartService.setLegendWidth(chartScope);
    expect(arisDcChartService).toBeTruthy();
  });


  it('2. CHeck if dc chart service method setScale is instanciated', () => {
    let arisChartCommonService =  TestBed.get(ArisChartCommonService);
    let chartScope = {
      options: {
        legendWidth: 5
      }
    };
    spyOn(arisChartCommonService, 'setScale').and.callThrough();
    arisDcChartService.setScale(chartScope);
    expect(arisChartCommonService.setScale).toHaveBeenCalled();
  });

  it('3. check for method getMaxLengthOfYAxisTickLabel()', () => {
    let chartScope = {
      options: {
        legendWidth: 5
      }
    };
    let result = arisDcChartService.getMaxLengthOfYAxisTickLabel(chartScope);
    expect(result).toBe(20);
  });

  it('4. check for method cleanUp()', () => {
    let chartScope = {
      options: {
        legendWidth: 5
      }
    };
    spyOn(arisDcChartService, 'cleanUp').and.callThrough();
    arisDcChartService.cleanUp(chartScope);
    expect(arisDcChartService.cleanUp).toHaveBeenCalled();
  });

  it('5. check for method onClickExportAsPNG()', () => {
    let chartScope = {
      options: {
        legendWidth: 5
      }
    };
    spyOn(arisDcChartService, 'onClickExportAsPNG').and.callThrough();
    arisDcChartService.onClickExportAsPNG(chartScope);
    expect(arisDcChartService.onClickExportAsPNG).toHaveBeenCalled();
  });

  it('6. check for method addDataWatch()', () => {
    let chartScope = {
      options: {
        legendWidth: 5
      }
    };
    spyOn(arisDcChartService, 'addDataWatch').and.callThrough();
    arisDcChartService.addDataWatch(chartScope);
    expect(arisDcChartService.addDataWatch).toHaveBeenCalled();
  });

  it('7. check for method setLegend if part ()', () => {
    let chartScope = {
      options: {
        legendWidth: 0
      }
    };
    arisDcChartService.setLegend(chartScope);
    expect(arisDcChartService).toBeTruthy();
  });

  it('8. check for method setLegend else part()', () => {
    let chartScope = {
      options: {
        legendWidth: true
      },
      chart : {
        legend() {}
      }
    };
    arisDcChartService.setLegend(chartScope);
    expect(arisDcChartService).toBeTruthy();
  });

  it('9. check for method postRedraw()', () => {
    let data = { style() {} };
    let chartScope = {
      options: {
        hideXAxis: true
      },
      chart: {
        selectAll() {}
      }
    };
    spyOn(chartScope.chart, 'selectAll').and.returnValue(data);
    arisDcChartService.postRedraw(chartScope);
    expect(arisDcChartService).toBeTruthy();
  });

  it('10. check for method removeChartListeners()', () => {
    let chartScope = {
      rangeChart: {
        on() {}
      },
      chart : {
        on() {}
      }
    };
    arisDcChartService.removeChartListeners(chartScope);
    expect(arisDcChartService).toBeTruthy();
  });

  it('11. check for method addChartListeners()', () => {
    let chartScope = {
      options: {
        on() {}
      },
      chart : {
        mouseZoomable() {},
        on() {}
      },
      chartService: {
        setTip() {},
        postRender() {},
        postRedraw() { }
      }
    };
    spyOn(chartScope.chart, 'on').and.returnValue(123);
    arisDcChartService.addChartListeners(chartScope);
    expect(arisDcChartService).toBeTruthy();
  });
});

