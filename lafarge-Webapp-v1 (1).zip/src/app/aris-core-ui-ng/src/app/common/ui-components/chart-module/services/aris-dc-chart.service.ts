import { Injectable } from '@angular/core';
import { ArisChartService } from './aris-chart.service';
import { ArisChartCommonService } from './aris-chart-common.service';

import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import * as d3Tip from 'd3-tip';
import * as crossfilter_ from 'crossfilter';
import * as FileSaver from 'file-saver';
import { ArisChartEventService } from './aris-chart-event.service';
import { TranslationService } from 'angular-l10n';
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;
declare var $: any;

@Injectable()
export class ArisDcChartService extends ArisChartService {

  private dcTypeChild: any;
  private dcScope: any;

  constructor(protected arisChartCommonService: ArisChartCommonService, protected translation: TranslationService) {
    super(arisChartCommonService, translation);
    d3.tip = d3Tip;
  }

  init(chartScope, element) {
    super.init(chartScope, element);
    chartScope.chart = chartScope.chartService.getChart(chartScope);

    if (chartScope.rangeChartElement) {
      chartScope.rangeChart = this.getRangeChart(chartScope, chartScope.rangeChartElement);
    }

    dc.override(chartScope.chart, 'onClick', (d) => {
      let filter: any;
      if (typeof d.key === "string" || typeof d.key === "object") {
        filter = chartScope.chart.keyAccessor()(d);
      } else {
        filter = chartScope.chart.keyAccessor()(d.data);
      }
      dc.events.trigger(() => {
        chartScope.chart.filter(filter);
        chartScope.chart._doRedraw();

      });
    });

    this.drawChart(chartScope);

    this.addChartListeners(chartScope);
  }
   /**
   * Reset chart object. Note: It is required for custom charts created in dc.js.
   * Read redrawChart() in all custom charts for more details.
   */
  reset(chartScope) {
    this.removeChartListeners(chartScope);

    chartScope.chart = chartScope.this.getChart(chartScope.chartElement);
    if (chartScope.options.showRangeChart) {
      chartScope.rangeChart = this.getRangeChart(chartScope, chartScope.rangeChartElement);
    }
    this.addChartListeners(chartScope);
  }

  /**
   * Get Range Chart DC object.
   */
  getRangeChart(chartScope, rangeChartElement): any {
    if (chartScope.chartService.getRangeChart()) {
      chartScope.chartService.getRangeChart(rangeChartElement);
    } else {
      return dc.lineChart(rangeChartElement);
    }
  }

  /**
   * Redraw chart. This will redraw charts (i.e. lines, bars) and not entire chart container (width, height, margins, axis labels)
   */
  redrawChart(chartScope) {
    // Add new data
    chartScope.crossfilter.remove();
    chartScope.crossfilter.add(chartScope.data);
    // Reset filters
    chartScope.chart.filterAll();
    if (chartScope.rangeChart) {
      chartScope.rangeChart.filterAll();
    }

    if (chartScope.options.scale === "ordinal") {
      this.storeXAxisLabels(chartScope);
    }
    if (chartScope.options.scale === "date") {
      chartScope.chart.xAxis().ticks(this.setNumberOfTicksForTimeAxis(chartScope));
    }

    // Reset scale
    chartScope.chartService.setScale(chartScope);
    chartScope.chartService.setGroup(chartScope);


    // Now let's redraw!
    chartScope.chart.redraw();

    if (chartScope.rangeChart) {
      chartScope.rangeChart.redraw();
    }
  }
  /**
   * Draw chart. It will draw chart completely (including chart size, axis labels, margins)
   */
  drawChart(chartScope) {
    super.drawChart(chartScope);

    // Get cross filter and dimension objects.
    if (!chartScope.options.crossfilter) {
      if (chartScope.data) {
        chartScope.crossfilter = crossfilter(chartScope.data);
      } else {
        return;
      }
    } else {
      chartScope.crossfilter = chartScope.options.crossfilter;
    }
    if (chartScope.chartService.setDimension) {
      chartScope.chartService.setDimension(chartScope);
    }  else {
      this.setDimension(chartScope);
    }

    chartScope.options.listXAxisLabels = [];

    // Command chart attributes
    chartScope.chart
      .width(chartScope.options.width)
      .height(chartScope.options.height)
      .dimension(chartScope.dimension);

    // Set scale for chart
    this.setScale(chartScope);

    // Always set Y-axis label before setAdditionalChartAttributes() is called so that range-chart is left-aligned with main chart.
    if (chartScope.chart.yAxisLabel) {
      this.arisChartCommonService.applyLabel(chartScope,  'y-axis');
    }
    // Set misc chart attributes for given chart.
    chartScope.chartService.setAdditionalChartAttributes(chartScope);

    // Set group.
    chartScope.chartService.setGroup(chartScope);

    // Always after setAdditionalChartAttributes() to get chart.group()
   // and before setChartMargin() to adjust right margin according to legend width.
    if (chartScope.options.showLegends) {
      this.setLegendWidth(chartScope);
    }
    // Always call getMaxLengthOfYAxisLabel() after group is set in setAdditionalChartAttributes().
    if (chartScope.chart.margins) {
      this.setChartMargin(chartScope);
    }
    // Always set axis labels after margin is set. Set it for main chart only if range-chart is not available.
    if (chartScope.chart.xAxisLabel) {
      this.arisChartCommonService.applyLabel(chartScope,  'x-axis');
    }

    // Always after setLegendWidth().
    if (chartScope.options.showLegends) {
      this.setLegend(chartScope);
    }

    // Common range chart attributes
    if (chartScope.rangeChart) {
      chartScope.rangeChart
        .width(chartScope.options.width)
        .height(chartScope.options.rangeChartHeight)
        .dimension(chartScope.dimension)
        .group(chartScope.chart.group())
        .elasticY(true)
        .elasticX(true)
        .xUnits(() => {
          return 5;
        })
        .renderHorizontalGridLines(true)
        .brushOn(true);

      // Restrict ticks to 3 in range chart.
      chartScope.rangeChart.yAxis().ticks(3);

      // Connect range chart to main chart
      chartScope.chart.rangeChart(chartScope.rangeChart);
      if (chartScope.options.scale === "date") {
        chartScope.rangeChart.xAxis().ticks(this.setNumberOfTicksForTimeAxis(chartScope));
      }
      chartScope.rangeChart.render();
    }

    if (chartScope.options.showScatterPlot) {
      chartScope.chart
        .on('renderlet', (chart) => {
          const xData = chart.x()(chartScope.options.cx);
          const yData = chart.y()(chartScope.options.cy);
          const dotData = [];
          dotData.push(xData);
          dotData.push(yData);
          const chartBody = chartScope.chart.select('g.chart-body');
          const path = chartBody.selectAll('.circle').data([dotData]);
          path.enter().append('circle')
            .attr('r', 4)
            .style('fill', chartScope.options.scatterPlotCol)
            .style('stroke', chartScope.options.scatterPlotCol)
            .style('fill-opacity', 'inherit')
            .attr('class', 'circle')
            .attr('cx', (d) => {
              return d[0];
            })
            .attr('cy', (d) => {
              return d[1];
            })
            .append('title')
            .text(() => {
              return chartScope.options.cx + ' : ' + chartScope.options.cy;
            });
        });
    }
    if (chartScope.options.scale === "date") {
      chartScope.chart.xAxis().ticks(this.setNumberOfTicksForTimeAxis(chartScope));
    }
    if (chartScope.options.scale === "ordinal") {
      this.storeXAxisLabels(chartScope);
    }

    console.log('render in drawChart');
    chartScope.chart.render();
  }

  /**
   * Setup basic view for chart tool-tips.
   */
  setD3Tip(chartScope,  tipSourceElementClass) {
    if  (chartScope.data && chartScope.data.length !== 0) {
      if (chartScope.chart.selectAll(tipSourceElementClass)[0].length > 0) {
        chartScope.chart.selectAll(tipSourceElementClass)
        .call(chartScope.tip)
        .on('mouseover.tip',  chartScope.tip.show)
        .on('mouseout.tip', () => {
        // IE-11 doesnt support tipSourceElementClass.includes(".dot")
          if  (tipSourceElementClass.indexOf(tipSourceElementClass) >= 0) {
            chartScope.chart.selectAll(tipSourceElementClass)
            .transition()
            .delay(50)
            .duration(50)
            .style('fill-opacity',  '1e-06')
            .style('stroke-opacity',  '1e-06');
          }
          chartScope.tip.hide();
        });
      }
    }
  }
  setupTip(chartScope, htmlTemplateFn, tipSourceElementClass) {

    if (chartScope.options.showRangeChart) {
      chartScope.chart.on('pretransition', (chart) => {
        this.setD3Tip(chartScope, tipSourceElementClass);
      });
    }

    if (!chartScope.tip) {
      chartScope.tip = d3.tip()
        .attr('class', 'd3-tip')
        .style('background-color', 'rgba(0,0,0,0.5)')
        .style('padding', '5px')
        .style('border-radius', '5px')
        .offset([-10, 0])
        .html(htmlTemplateFn);
    }

    this.setD3Tip(chartScope, tipSourceElementClass);
  }

  /**
   * Default post-render operation.
   */
  postRender(chartScope) {
    console.log(chartScope.options.chartTitle + ' postRender');

    // IE 11 only - Increase width of SVG
    if (chartScope.exporting && /MSIE|Trident/.test(window.navigator.userAgent)) {
      chartScope.chart.svg().attr('width', chartScope.options.width + 20);

      if (chartScope.rangeChart) {
        chartScope.rangeChart.svg().attr('width', chartScope.options.width + 20);
      }

      // For row chart and its versions, row text moves upward during export.
      const chartContainer = chartScope.element.querySelector('.o-chartContainer');
      chartContainer.id = 'exportedChart';
      let rowElements = $(chartScope.chart.selectAll('#exportedChart .row text'));
      if (rowElements && rowElements.length) {
        rowElements = rowElements[0];
        for (let i = 0; i < rowElements.length; i += 1) {
          $(rowElements[i]).attr('y', parseFloat($(rowElements[i]).attr('y')) + 5);
        }
      }
      chartContainer.id = '';
    }
    if (chartScope.options.scale === "ordinal") {
      this.setEllipsesForLabels(chartScope);
    }

    this.addTitleToLegend(chartScope);

    // Should always be at end of this method.
    this.postRedraw(chartScope);
  }

  storeXAxisLabels(chartScope) {
    chartScope.options.ordinalLabelList = [];
    chartScope.chart.xAxis().tickFormat((l, i) => {
      chartScope.options.ordinalLabelList.push(l);
      return l;
    });
  }

  setEllipsesForLabels(chartScope) {
    this.arisChartCommonService.setXAxisLabelsWidthForOrdinalCharts(chartScope, chartScope.chartElement);
    if (chartScope.rangeChartElement) {
      this.arisChartCommonService.setXAxisLabelsWidthForOrdinalCharts(chartScope, chartScope.rangeChartElement);
    }
  }

  /**
  * Default post-redraw operation.
  */
  postRedraw(chartScope) {
    console.log('base postRedraw');
    if (chartScope.options.hideXAxis) {
      chartScope.chart.selectAll('g.x .tick').style('display', 'none');
    }
  }

  /**
   * Default Dimension of chart.
   */
  setDimension(chartScope) {
    if (chartScope.options.scale && chartScope.options.scale === 'linear') {
      chartScope.dimension = chartScope.crossfilter.dimension((d) => {
        return +d[chartScope.options.xAxisAttribute];
      });
    } else {
      chartScope.dimension = chartScope.crossfilter.dimension((d) => {
        return d[chartScope.options.xAxisAttribute];
      });
    }
  }

  /**
   * Default margin of chart.
   */
  setChartMargin(chartScope) {
    const margin = {
      top: 15, right: 15,
      bottom: 0, left: 10
    };
    const rangeChartMargin = {
      top: 5, right: 15,
      bottom: 0, left: 10
    };
    const maxLengthOfYAxisTickLabel = this.getMaxLengthOfYAxisTickLabel(chartScope);

    // ================= Left margin =========================

    // adjust for Y axis label
    if (chartScope.options.yAxisLabel && chartScope.options.yAxisLabel.length > 0) {
      margin.left = margin.left + 20;
      rangeChartMargin.left = rangeChartMargin.left + 20;
    }
    margin.left = margin.left + maxLengthOfYAxisTickLabel;
    rangeChartMargin.left = rangeChartMargin.left + maxLengthOfYAxisTickLabel;

    // ================== Right Margin =========================
    if (chartScope.options.legendWidth) {
      margin.right = margin.right + chartScope.options.legendWidth;
      rangeChartMargin.right = rangeChartMargin.right + chartScope.options.legendWidth;
    }
    if (chartScope.options.rightYAxisLabel && chartScope.options.rightYAxisLabel.length > 0) {
      margin.right = margin.right + 20;
      rangeChartMargin.right = rangeChartMargin.right + 20;
    }

    margin.right = margin.right + maxLengthOfYAxisTickLabel;
    rangeChartMargin.right = rangeChartMargin.right + maxLengthOfYAxisTickLabel;
    // ================== Bottom margin =========================
    if (chartScope.options.hideXAxis) {
      margin.bottom = margin.bottom + 10;
    } else {
      margin.bottom = margin.bottom + 25;
    }

    if (chartScope.options.xAxisLabel && chartScope.options.xAxisLabel.length > 0) {
      margin.bottom = margin.bottom + 10;
    }

    if (chartScope.rangeChart) {
      rangeChartMargin.bottom = margin.bottom;
      margin.bottom = 17;
    }

    console.log(chartScope.options.chartTitle + ' margin:  ' + margin.left + ' ' + margin.right
      + ' ' + margin.top + ' ' + margin.bottom + ' ' + maxLengthOfYAxisTickLabel + ' ' + chartScope.options.legendWidth);

    if(chartScope.chart.margins) {
      chartScope.chart.margins(margin);
    }
    if (chartScope.rangeChart) {
      chartScope.rangeChart.margins(rangeChartMargin);
    }
  }

  /**
   * Default legend positioning implementation.
   */
  setLegend(chartScope) {
    if (!chartScope.options.legendWidth) {
      return;
    }

    chartScope.chart.legend(
      dc.legend()
        .x(chartScope.options.width - chartScope.options.legendWidth)
        .y(30)
        .autoItemWidth(true)
        .itemHeight(10)
        .gap(5)
    );
  }

  /**
   * Default legend width of chart.
   */
  setLegendWidth(chartScope) {
    chartScope.options.legendWidth = undefined;
    if (chartScope.options.width < 400) {
      chartScope.options.legendWidth = chartScope.options.width * 0.2;
    } else  if (chartScope.options.width > 400 && chartScope.options.width < 800) {
      chartScope.options.legendWidth = chartScope.options.width * 0.2;
    } else  if (chartScope.options.width > 800) {
      if (chartScope.chartService.calculateLegendWidthFromGroup) {
        chartScope.chartService.calculateLegendWidthFromGroup(chartScope);
      } else {
        chartScope.options.legendWidth = chartScope.options.width * 0.2;
      }
    }

  }

  /**
  * Default scale for chart.
  */
  setScale(chartScope) {
    this.arisChartCommonService.setScale(chartScope);
  }

  /**
   *  Calculate length of longest Y-Axis tick label, dynamically.
   */
  getMaxLengthOfYAxisTickLabel(chartScope) {
    return 20;
  }

  /**
 * Perform cleanup when chart is destroyed.
 */
  cleanUp(chartScope) {
    // // Remove all event listeners
    //  removeChartListeners(chartScope);

    //  if(chartScope.tip){
    //    chartScope.tip.hide();
    //    chartScope.tip.destroy();
    //    chartScope.tip = null;
    //  }

    //  //Always be at end.
    //  arisChartService.cleanUp(chartScope);
  }

  /**
   * Perform actual chart resize operation.
   */
  resize(chartScope, containerWidth, containerHeight) {
    // If chart is not available, ignore.
    if (!chartScope.chart.svg()) {
      return;
    }

    super.calculateChartWidthHeight(chartScope, containerWidth, containerHeight);

    // Reassign new size to chart.
    chartScope.chart.width(chartScope.options.width);
    chartScope.chart.height(chartScope.options.height);

    if (chartScope.options.scale === "date") {
      chartScope.chart.xAxis().ticks(this.setNumberOfTicksForTimeAxis(chartScope));
    }

    // Reassign legend positions.
    if (chartScope.options.showLegends) {
      this.setLegendWidth(chartScope);
      this.setLegend(chartScope);
    }

    console.log('render in resize');
    chartScope.chart.render();

    // If range-chart, resize range chart too.
    if (chartScope.rangeChart) {
      if (chartScope.options.scale === "date") {
        chartScope.rangeChart.xAxis().ticks(this.setNumberOfTicksForTimeAxis(chartScope));
      }
      chartScope.rangeChart.width(chartScope.options.width);
      chartScope.rangeChart.height(chartScope.options.rangeChartHeight);
      chartScope.rangeChart.render();
    }
  }

  setNumberOfTicksForTimeAxis(chartScope) {
    console.log(chartScope.element.parentElement.clientWidth);
    let length = chartScope.element.parentElement.clientWidth / 11;
    let ticks = Math.round(chartScope.element.parentElement.clientWidth / 100);
    console.log(ticks);
    return ticks;
  }

  onClickExportAsPNG(chartScope) {}

  /**
   * Any operation before exporting as PNG is started e.g. add custom css, resizing chart to fix size, background
   */
  preExportAsPNG(chartScope, child) {
    // CSS manipulation for IE 11 browser only.
    if (/MSIE|Trident/.test(window.navigator.userAgent)) {
      if (chartScope.chart.yAxisLabel) {
        chartScope.chart.yAxisLabel(chartScope.options.yAxisLabel, 20);
      }
      if (chartScope.chart.xAxis) {
        chartScope.chart.xAxis().tickPadding(15);
      }
      if (chartScope.chart.margins) {
        chartScope.chart.margins().left = chartScope.chart.margins().left + 8;
        chartScope.chart.margins().bottom = chartScope.chart.margins().bottom + 10;
      }
      if (chartScope.rangeChart) {
        chartScope.rangeChart.xAxis().tickPadding(15);
        if (chartScope.rangeChart.margins) {
          chartScope.rangeChart.margins().top = chartScope.rangeChart.margins().top + 20;
        }
      }
    }

    // Increase legend width to take different font in account for exported charts.
    if (chartScope.options.legendWidth) {
      chartScope.options.legendWidth = chartScope.options.legendWidth + 50;
      if (chartScope.chart.margins) {
        chartScope.chart.margins().right = chartScope.chart.margins().right + 50;
      }
      if (chartScope.rangeChart && chartScope.rangeChart.margins) {
        chartScope.rangeChart.margins().right = chartScope.chart.margins().right + 50;
      }
    }

    super.preExportAsPNG(chartScope, child);
  }

  getInlineCssForChartExport() {
    let inlineCssForChartExport = '';

    // For pie chart, text label is white in dc css so make it black explicitly for exported charts.
    inlineCssForChartExport = inlineCssForChartExport.concat('\n.dc-chart text.pie-slice {fill: black;}\n');
    // for line chart, applying css on stroke lines
    inlineCssForChartExport = inlineCssForChartExport.concat('\n.dc-chart g.grid-line line {stroke: black;}\n');
    // for row chart, applying css on stroke lines
    inlineCssForChartExport = inlineCssForChartExport.concat('\n.dc-chart g.axis .tick line {stroke: black;}\n');
    // for row chart, applying css on text-color
    inlineCssForChartExport = inlineCssForChartExport.concat('\n.dc-chart g.row text {fill: black !important, stroke: black;}\n');

    return inlineCssForChartExport;
  }

  exportAsPNG(chartScope) {
    chartScope.exportOptions.externalCssFileData = $("style:contains('dc-chart')")[0].innerText;
    chartScope.exportOptions.externalCssFileData = chartScope.exportOptions.externalCssFileData.replace(/fill: #fff;/g, "fill: black;")
                                                  .replace(/fill:#fff;/g, "fill:black;");
    chartScope.exportOptions.rootCssClass = '.dc-chart';
    super.exportAsPNG(chartScope);
  }
  /**
   * Any operation after chart is exported as PNG. e.g. resetting chart if any pre-export operation has changed chart UI.
   * Optional
   */
  postExportAsPNG(chartScope) {
    // Restore CSS back to original after export - IE 11 only.
    if (/MSIE|Trident/.test(window.navigator.userAgent)) {
      if (chartScope.chart.yAxisLabel) {
        chartScope.chart.yAxisLabel(chartScope.options.yAxisLabel, 12);
      }
      if (chartScope.chart.xAxis) {
        chartScope.chart.xAxis().tickPadding(0);
      }
      if (chartScope.chart.margins) {
        chartScope.chart.margins().left = chartScope.chart.margins().left - 8;
        chartScope.chart.margins().bottom = chartScope.chart.margins().bottom - 10;
      }
      if (chartScope.rangeChart) {
        chartScope.rangeChart.xAxis().tickPadding(0);
        chartScope.rangeChart.margins().top = chartScope.rangeChart.margins().top - 20;
      }
    }

    // Restore legendWidth to original value after export.
    if (chartScope.options.legendWidth) {
      chartScope.options.legendWidth = chartScope.options.legendWidth - 50;
      if (chartScope.chart.margins) {
        chartScope.chart.margins().right = chartScope.chart.margins().right - 50;
      }
      if (chartScope.rangeChart && chartScope.rangeChart.margins) {
        chartScope.rangeChart.margins().right = chartScope.chart.margins().right - 50;
      }
    }

    super.postExportAsPNG(chartScope);
  }

  setLegendSize(chartScope: any) {
    let svgElm = chartScope.chart.svg()[0][0];
    let chartElm = svgElm.querySelector('g');
    let legendElm: any = svgElm.querySelector('.dc-legend');
    if (chartElm.getBoundingClientRect().width + legendElm.getBoundingClientRect().width >
    svgElm.getBoundingClientRect().width) {

    } else {
      let widthOverlap = (legendElm.getBoundingClientRect().width +  this.getTranslateX(legendElm))
       - svgElm.getBoundingClientRect().width;
      console.log(widthOverlap);
      d3.select(legendElm).attr("transform", "translate(" + (this.getTranslateX(legendElm) - widthOverlap) + ","
      + this.getTranslateY(legendElm) + ")");
      d3.select(chartElm).attr("transform", "translate(" + (this.getTranslateX(chartElm) - widthOverlap) + ","
      + this.getTranslateY(chartElm) + ")");
    }
  }

  addTitleToLegend(chartScope) {
    let chartElm = chartScope.chart.svg()[0][0];
    let textElm = chartElm.querySelectorAll(".dc-legend text");
    textElm.forEach((elm, i) => {
      let originalText = Object.assign(elm.textContent);
      d3.select(elm).append('title').text(originalText);
    });
  }

  getTranslateX(elm) {
    return parseInt(window.getComputedStyle(elm).getPropertyValue("transform").match(/(-?[0-9\.]+)/g)[4], 10);
  }

  getTranslateY(elm) {
    return parseInt(window.getComputedStyle(elm).getPropertyValue("transform").match(/(-?[0-9\.]+)/g)[5], 10);
  }

  /* ---------------------------------- Private methods ----------------------------------------------------*/

  /**
   * Add watch on chart data so that chart can be updated when data is modified.
   */
  addDataWatch(chartScope) {
  }

  /**
   * Add chart event listeners.
   */
  addChartListeners(chartScope) {
    if (chartScope.chart.mouseZoomable) {
      chartScope.chart.mouseZoomable(true);
    }
    chartScope.chart.on('renderlet', (d) => {
      chartScope.chartService.setTip(chartScope);
    });
    chartScope.chart.on('postRender', () => {
      if (chartScope.options.xAxisAngle) {
        d3.selectAll(chartScope.element.querySelectorAll('.axis.x > .tick > text')).attr("transform", "translate(0,8) rotate(" + - chartScope.options.xAxisAngle + ")");
        let x = d3.transform(chartScope.chart.selectAll('.x-axis-label').attr("transform")).translate[0];
        let y = d3.transform(chartScope.chart.selectAll('.x-axis-label').attr("transform")).translate[1];
        y = y + 10;
        chartScope.chart.selectAll(".x-axis-label").attr("transform", "translate(" + x + "," + y + ")");
      }
      chartScope.chartService.postRender(chartScope);
    });

    chartScope.chart.on('postRedraw', () => {
      console.log("call postRedraw");
      chartScope.chartService.postRedraw(chartScope);
    });
  }
  /**
   * Remove chart event listeners.
   */
  removeChartListeners(chartScope) {
    chartScope.chart.on('postRender', null);
    chartScope.chart.on('preRender', null);
    chartScope.chart.on('preRedraw', null);
    chartScope.chart.on('postRedraw', null);
    chartScope.chart.on('filtered', null);
    chartScope.chart.on('renderlet', null);
    chartScope.chart.on('pretransition', null);
    chartScope.chart.on('zoomed', null);

    if (chartScope.rangeChart) {
      chartScope.rangeChart.on('postRender', null);
      chartScope.rangeChart.on('preRender', null);
      chartScope.rangeChart.on('preRedraw', null);
      chartScope.rangeChart.on('postRedraw', null);
      chartScope.rangeChart.on('filtered', null);
      chartScope.rangeChart.on('renderlet', null);
      chartScope.rangeChart.on('pretransition', null);
      chartScope.rangeChart.on('zoomed', null);
    }
  }
}
