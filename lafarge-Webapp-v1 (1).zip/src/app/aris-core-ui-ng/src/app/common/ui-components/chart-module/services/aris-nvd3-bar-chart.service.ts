import { TranslationService } from "angular-l10n";
import * as d3 from 'd3/d3.js';
import * as dc from 'dc';
import * as nv from 'nvd3';
import { Injectable } from "@angular/core";
import { Subject } from 'rxjs/Subject';
import { ArisNvd3ChartService } from "./aris-nvd3-chart.service";
import { ArisChartCommonService } from "./aris-chart-common.service";

declare var $: any;

@Injectable()
export class ArisNvd3BarChartService extends ArisNvd3ChartService {

  private toData = new Subject<any>();

  constructor(protected arisChartCommonService: ArisChartCommonService, protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }


  init(scope, element) {
    $('head').append('<style>.nvd3 rect {stroke-opacity: 1 !important;fill-opacity: 0.7!important;}</style>');
    super.init(scope, element);

    var toDataEvent = this.toData;
    if (scope.options.isElementclick) {

      scope.chart.discretebar.dispatch.on('elementClick',  (event) => {
        event.data.title = scope.options.chartTitle;
        toDataEvent.next(event.data);
      });

    }

  }

  getChart() {
    return nv.models.discreteBarChart();
  }

  translateText() {
    $('.nvd3.nv-wrap.nv-discreteBarWithAxes>g').attr('transform', 'translate(30,10)');
  }
  setAdditionalChartAttributes(scope) {
    scope.chart.yAxis.tickFormat(d3.format('d'));
    scope.chart.yAxis.ticks(scope.options.numberOfTicks);
    scope.chart.color(scope.options.barColors);
    scope.chart.margin({ top: 10, right: 70, bottom: 50, left: 10 });
    scope.chart.legend.margin({ top: 0, right: 30, bottom: 15, left: 60 });
    scope.chart.width(scope.options.chartWidth);
    scope.chart.height(scope.options.chartHeight);

    if (scope.options.tickValues) {
      scope.chart.yAxis.tickValues(scope.options.tickValues);
    }
  }

  processData(scope): any {
    let values = [];
    scope.data.forEach((value, key) => {
      let x = value[scope.options.xAxisAttribute];
      let y = value[scope.options.yAxisAttribute];

      values.push({ x, y });
    });
    setTimeout(() => this.translateText(), 1000);
    return [
      {
        values,      // values - represents the array of {x,y} data points
        key: scope.options.yAxisAttribute, // key  - the name of the series.
        color: scope.options.barColors  // color - optional: choose your own line color.   
      }
    ];
  }

  resize(scope) {
    super.resize(scope);
    setTimeout(() => this.translateText(), 1000);
  }


}

