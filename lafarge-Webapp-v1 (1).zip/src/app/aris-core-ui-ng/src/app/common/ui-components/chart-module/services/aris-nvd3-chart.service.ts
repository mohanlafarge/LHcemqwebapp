import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import * as nv from 'nvd3';
import { TranslationService } from "angular-l10n";
import { Injectable } from "@angular/core";
import { ArisChartService } from "./aris-chart.service";
import { ArisDcChartService } from './aris-dc-chart.service';
import { ArisChartCommonService } from './aris-chart-common.service';

@Injectable()
export class ArisNvd3ChartService extends ArisChartService {

  private childObj: any;
  constructor(protected arisChartCommonService: ArisChartCommonService, protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }

  init(scope, element) {
    super.init(scope, element);
    scope.chart = scope.chartService.getChart();
    this.drawChart(scope);
  }

  drawChart(scope) {
    nv.addGraph(() => {
      super.drawChart(scope);
      if (scope.options.height >= 570) {
        scope.options.height = scope.options.height - (scope.options.height * 4) / 100;
      }
      scope.chart.options({
        duration: 300,
        useInteractiveGuideline: true
      })
      .width(scope.options.width)
      .height(scope.options.height)
      .showLegend(false);

      if (scope.options.xAxisLabel) {
      }

      if (scope.options.yAxisLabel) {
       // scope.chart.yAxis.axisLabel(this.translation.translate(scope.options.yAxisLabel));
      }
      scope.chartService.setAdditionalChartAttributes(scope);
      let data = [];
      data = scope.chartService.processData(scope);
      let svg: any;
      svg = d3.select(scope.chartElement).append("svg");
      svg
      .attr('width', scope.options.width)
      .attr('height', scope.options.height)
      .datum(data)         // Populate the <svg> element with chart data...
      .call(scope.chart);     // Finally, render the chart!

      return scope.chart;
    });
  }

  resize (scope) {
    scope.chart
        .width(scope.options.width)
        .height(scope.options.height);
    if (d3.select(scope.chartElement).select("svg")[0][0]) {
      d3.select(scope.chartElement).select("svg").remove();
      scope.chart = scope.chartService.getChart();
      this.drawChart(scope);
    }
  }

  exportAsPNG(scope) {
    // scope.exportOptions.externalCssFileData = './../node_modules/nvd3/build/nv.d3.min.css';
    // scope.exportOptions.externalCssFileData.concat('\n' + "../chart.css");
    // scope.exportOptions.externalCssFileData.concat('\n' + "../../css/common.css");
    scope.exportOptions.externalCssFileData = $("style:contains('nvd3')")[0].innerText;
    scope.exportOptions.rootCssClass = '.nvd3';
    super.exportAsPNG(scope);
  }

  getInlineCssForChartExport() {
    let inlineCssForChartExport = '';

    // For pie chart, text label is white in dc css so make it black explicitly for exported charts.
    inlineCssForChartExport = inlineCssForChartExport.concat('\n.dc-chart text.pie-slice {fill: black;}\n');
    // for line chart, applying css on stroke lines
    inlineCssForChartExport = inlineCssForChartExport.concat('\n.dc-chart g.grid-line line {stroke: black;}\n');
    // for row chart, applying css on stroke lines
    inlineCssForChartExport = inlineCssForChartExport.concat('\n.dc-chart g.axis .tick line {stroke: black;}\n');
    // for row chart, applying css on text-color
    inlineCssForChartExport = inlineCssForChartExport.concat('\n.dc-chart g.row text {stroke: black;}\n');

    return inlineCssForChartExport;
  }

}
