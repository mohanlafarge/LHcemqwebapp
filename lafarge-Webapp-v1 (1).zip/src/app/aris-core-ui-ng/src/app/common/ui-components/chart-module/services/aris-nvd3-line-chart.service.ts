import { ArisNvd3ChartService } from "./aris-nvd3-chart.service";
import { ArisChartCommonService } from "./aris-chart-common.service";
import { TranslationService } from "angular-l10n";
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import * as nv from 'nvd3';
import { Injectable } from "@angular/core";
import { ArisChartService } from "./aris-chart.service";

@Injectable()
export class ArisNvd3LineChartService extends ArisNvd3ChartService {
  constructor(protected arisChartCommonService: ArisChartCommonService, protected translation: TranslationService) {
    super(arisChartCommonService, translation);
  }

  init(scope, element) {
    super.init(scope, element);
  }

  getChart() {
    return nv.models.lineChart();
  }

  setAdditionalChartAttributes(scope) {
    scope.chart.yAxis.tickFormat(d3.format('.02f'));
  }

  processData(scope): any {
    let values = [];

    scope.data.forEach((value, key) => {
      let x = value[scope.options.xAxisAttribute];
      x = typeof +x === 'number' ? +x : x;
      let y = value[scope.options.yAxisAttribute];
      y = typeof +y === 'number' ? +y : y;

      values.push({x: x, y : y});
    });

    return[
      {
        values: values,      // values - represents the array of {x,y} data points
        key: scope.options.yAxisAttribute, // key  - the name of the series.
        color: scope.options.lineColor || '#1f77b4'  // color - optional: choose your own line color.   
      }
    ];
  }

  resize(scope) {
    super.resize(scope);
  }
}
