/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { ArisChartComponent } from '../aris-chart.component';
import { ArisChartCommonService } from './aris-chart-common.service';
import { DebugElement } from '@angular/core';
import { DatePipe } from '@angular/common';
import { By } from '@angular/platform-browser';

import { ArisDcChartService } from './aris-dc-chart.service';
import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { ArisChartService } from './aris-chart.service';
import { ArisSankeyChartService } from './aris-sankey-chart.service';

xdescribe('Service: ArisSankeyChartService', () => {

  let component: ArisChartComponent;
  let fixture: ComponentFixture<ArisChartComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;
  let componentEl1: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisChartComponent],
      imports: [ArisI18nModule, LocalizationModule],
      providers: [ArisChartCommonService, ArisChartService, DatePipe, ArisDcChartService,
        TranslationService, InjectorRef, ArisSankeyChartService]
    }).compileComponents();
  });
  beforeEach(() => {
      // create component and test fixture
    fixture = TestBed.createComponent(ArisChartComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    component.data =   [{
      links: [
        {
          value: 1,
          target: 5,
          source: 0
        },
        {
          value: 1,
          target: 5,
          source: 1
        },
        {
          value: 1,
          target: 5,
          source: 2
        },
        {
          value: 1,
          target: 7,
          source: 3
        },
        {
          value: 1,
          target: 6,
          source: 4
        },
        {
          value: 3,
          target: 8,
          source: 5
        }
      ],
      nodes: [
        {
          name: "51",
          id: "0",
          type: "event",
          description: "Detected Pressure exceeding Operating Threshold ",
          severity: "Amber",
          childNode: {
            name: "17",
            type: "insight"
          }
        },
        {
          name: "52",
          id: "1",
          type: "event",
          description: "Medium risk rank(12) for the control value in the fractation unit.",
          severity: "Amber",
          childNode: {
            name: "17",
            type: "insight"
          }
        },
        {
          name: "50",
          id: "2",
          type: "event",
          description: "Detected Failure Probability of 70%",
          severity: "Red",
          childNode: {
            name: "17",
            type: "insight"
          }
        },
        {
          name: "94",
          id: "3",
          type: "event",
          description: "Risk of functional failure due to difference in viscosity of liquid from design condition. Risk score is : 10",
          severity: "Amber",
          childNode: {
            name: "30",
            type: "insight"
          }
        },
        {
          name: "94",
          id: "4",
          type: "event",
          description: "Risk of functional failure due to difference in viscosity of liquid from design condition. Risk score is : 10",
          severity: "Amber",
          childNode: {
            name: "29",
            type: "insight"
          }
        },
        {
          name: "17",
          id: "5",
          type: "insight",
          description: "Possible failure of equipment in 7days",
          severity: "",
          childNode: {
            name: "267",
            type: "action"
          }
        },
        {
          name: "29",
          id: "6",
          type: "insight",
          description: "hhhh",
          severity: "",
          childNode: null
        },
        {
          name: "30",
          id: "7",
          type: "insight",
          description: "create insight",
          severity: "",
          childNode: null
        },
        {
          name: "267",
          id: "8",
          type: "action",
          description: "q",
          severity: "",
          childNode: null
        }
      ]
    }
    ];

    component.type = "SANKEY_CHART" ;
    component.options = {
      height: "250",
      width: "800",
      chartTitle: 'Sankey Diagram'
    };

  });

  it('svg element is created for sankey chart', () => {
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('.o-chartContainer'));
    console.log(component);
    expect(componentEl.nativeElement.querySelector('svg')).toBeTruthy();
  });

});
