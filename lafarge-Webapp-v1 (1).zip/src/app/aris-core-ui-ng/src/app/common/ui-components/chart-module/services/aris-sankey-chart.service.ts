
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import * as dc from 'dc';
import * as crossfilter_ from 'crossfilter';
let crossfilter: any = (<any>crossfilter_).default || crossfilter_;
import * as d3Sankey from 'd3-sankey';
import { ArisChartCommonService } from './aris-chart-common.service';
import { Injectable, OnInit } from '@angular/core';
import { ArisDcChartService } from './aris-dc-chart.service';
import { ArisChartService } from './aris-chart.service';
import { TranslationService } from 'angular-l10n';
import * as d3Tip from 'd3-tip';
@Injectable()
export class ArisSankeyChartService extends ArisChartService {

  svg: any;
  parentNode: any;
  constructor(protected arisChartCommonService: ArisChartCommonService, protected translation: TranslationService) {
    super(arisChartCommonService, translation);
    d3.tip = d3Tip;
  }

  init(scope, element) {
    super.init(scope, element);
    scope.chart = this.getChart(scope);
    this.drawChart(scope);
  }

  getChart(scope) {
    return this.svg;
  }

  drawChart(scope) {
    let sankeyData = scope.data[0];
    let units = scope.options.unit;

    super.drawChart(scope);

    let margin = {
      top: 0,
      right: 1,
      bottom: 0,
      left: 1
    };
    let width = scope.options.width - margin.left - margin.right;
    let height = scope.options.height - margin.top - margin.bottom;

    let sankeyTip = d3.tip()
    .attr('class', 'd3-tip')
    .style('background-color', 'rgba(0,0,0,0.5)')
    .style('padding', '5px')
    .style('border-radius', '5px')
    .offset([-10, 0])
    .html(htmlTemplateFn);

    let formatNumber = d3.format(",.0f"); // zero decimal places
    let   format =  (d) => {
      return formatNumber(d) + " " + units;
    };
    let color = d3.scale.category20();

    // append the svg canvas to the page
    this.svg = d3.select(scope.chartElement).append("svg")
    .attr("width", width + margin.left + margin.right)
       .attr("height", height + margin.top + margin.bottom)
       .append("g")
       .attr("transform",
               "translate(" + margin.left + "," + margin.top + ")");
    scope.chart = this.svg;

    let defs = this.svg.append("defs");

    // Set the sankey diagram properties
    let sankey = d3Sankey.sankey()
        .nodeWidth(15)
        .nodePadding(10)
        .size([width, height]);

    let path = sankey.link();


    if ((sankeyData) && (sankeyData != null)) {
      sankey.nodes(sankeyData.nodes)
        .links(sankeyData.links)
        .layout(32);
    }

    let grads = defs.selectAll("linearGradient")
            .data(sankeyData.links, getLinkID);

    grads.enter().append("linearGradient")
            .attr("id", getLinkID)
            .attr("gradientUnits", "objectBoundingBox");
                    // stretch to fit

    grads.html("") // erase any existing <stop> elements on update
        .append("stop")
        .attr("offset", "0%")
        .attr("stop-color", (d) => {
          return nodeColor((+d.source.x <= +d.target.x) ?  d.source : d.target);
        });

    grads.append("stop")
        .attr("offset", "100%")
        .attr("stop-color", (d) => {
          return nodeColor((+d.source.x > +d.target.x) ? d.source : d.target);
        });

    // add in the links
    let link = this.svg.append("g").selectAll(".link")
        .data(sankeyData.links)
        .enter().append("path")
        .attr("class", "link")
        .attr("d", path)
         .style("fill", "none")
         .style("stroke", (d) => {
             return "url(#" + getLinkID(d) + ")";
         })
        .style("stroke-opacity", "0.4")
        .on("mouseover", function () {
          d3.select(this).style("stroke-opacity", "0.7");
        })
        .on("mouseout", function () {
          d3.select(this).style("stroke-opacity", "0.4");
        })
        .call(sankeyTip)
        .on('mouseover.tip', sankeyTip.show)
        .on('mouseout.tip', () => {
          sankeyTip.hide();
        })
        .style("stroke-width", (d) => {
            return Math.max(1, d.dy);
        })
        .sort((a, b) => {
          return b.dy - a.dy;
        });
    this.svg.selectAll("path")
        .style("stroke", "black")
        .style("opacity", "0.3");

    // add in the nodes
    let node = this.svg.append("g").selectAll(".node")
        .data(sankeyData.nodes)
        .enter().append("g")
        .attr("class", "node")
        .attr("transform",  (d) => {
            return "translate(" + d.x + "," + d.y + ")";
        })
        .call(d3.behavior.drag()
        .origin((d) => {
            return d;
        })
        .on("dragstart", function () {
            this.parentNode.appendChild(this);
        })
        .on("drag", dragmove))
        .call(sankeyTip)
        .on('mouseover.tip', sankeyTip.show)
        .on('mouseout.tip', () => {
          sankeyTip.hide();
        });

    // add the rectangles for the nodes
    node.append("rect")
        .attr("height",  (d) => {
          return d.dy;
        })
        .attr("width", sankey.nodeWidth())
        .style("fill",  (d) => {
          return d.color = color(d.name.replace(/ .*/, ""));
        })
         .style("fill-opacity", ".9")
         .style("shape-rendering", "crispEdges")
        .style("stroke",  (d) => {
          return d3.rgb(d.color).darker(2);
        });

    // add in the title for the nodes
    node.append("text")
        .attr("x", -6)
        .attr("y",  (d) => {
          return d.dy / 2;
        })
        .attr("font-size", "12px")
        .style("fill", "white")
        .attr("dy", ".35em")
        .attr("text-anchor", "end")
        .attr("text-shadow", "0 1px 0 #fff")
        .attr("transform", null)
        .text((d) => {
          return d.name;
        })
        .filter((d) => {
          return d.x < width / 2;
        })
        .attr("x", 6 + sankey.nodeWidth())
        .attr("text-anchor", "start");

    function dragmove(d) {
      d3.select(this).attr("transform",
              "translate(" + (
          d.x = Math.max(0, Math.min(width - d.dx, d3.event.x))) + "," + (
          d.y = Math.max(0, Math.min(height - d.dy, d3.event.y))) + ")");
      sankey.relayout();
      link.attr("d", path);
    }

    function getLinkID(d) {
      return "link-" + d.source.name + "-" + d.target.name;
    }

    function nodeColor(d) {
      return d.color = color(d.name.replace(/ .*/, ""));
    }

    function htmlTemplateFn(d) {
      if (scope.options.tip) {
        scope.options.tip();
      } else {
        return () => {
          if (d.source && d.target) {
            return "<span style='color: #d4cf2f'><i>" + d.source.name + "</i></span>  → " + d.target.name + "\n" + format(d.value);
          // tslint:disable-next-line:no-else-after-return
          } else {
            return  "<span style='color: #d4cf2f'><i>" + d.name + "</i></span> : " + format(d.value);
          }
        };
      }
    }


  }

  sendDataToNewWindow(scope) {
    return Object.assign([], JSON.parse(scope.data1));
  }

  redrawChart(scope) {
    super.drawChart(scope);
    if (!scope.options.openWindow) {
      d3.select(".o-mainChartContainer").select("svg").remove();
    } else {
      d3.select("aris-chart[type='SANKEY_CHART'] .o-mainChartContainer").select("svg").remove();
    }
    this.drawChart(scope);
  }
}
