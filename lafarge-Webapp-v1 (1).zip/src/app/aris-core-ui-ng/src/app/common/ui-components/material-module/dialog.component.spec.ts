import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import 'rxjs/add/observable/of';
import { By, BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { DemoMaterialModule } from './material.module';
import { ArisPipesModule } from '../../pipes/aris-pipes.module';
import { LocalizationModule } from 'angular-l10n';
import { ArisModule } from '../../../aris.module';
import { DialogOverviewExampleDialog } from './dialog.component';
import { MatDialogRef, MatDialogModule, MatButtonModule, MAT_DIALOG_DATA } from '@angular/material';


describe('Component: DialogOverviewExampleDialog', () => {

  let component: DialogOverviewExampleDialog;
  let fixture: ComponentFixture<DialogOverviewExampleDialog>;
  let infoCardElement: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DialogOverviewExampleDialog],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      imports: [ArisPipesModule, LocalizationModule, ArisModule, DemoMaterialModule, MatButtonModule, MatDialogModule, BrowserModule],
      providers: [{ provide: MatDialogRef }, { provide: MAT_DIALOG_DATA }],
    }).compileComponents();
    fixture = TestBed.createComponent(DialogOverviewExampleDialog);
    // get test component from the fixture
    component = fixture.componentInstance;
  });

  it('test : DialogOverviewExampleDialog should be created', () => {
    expect(component).toBeTruthy();
  });
});
