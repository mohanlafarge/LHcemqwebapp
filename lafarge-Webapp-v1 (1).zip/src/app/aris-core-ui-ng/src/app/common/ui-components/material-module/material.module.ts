import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {
  MatDialogModule,
  MatButtonModule
} from '@angular/material';
import { HttpModule } from '@angular/http';
import { DialogOverviewExampleDialog } from './dialog.component';

@NgModule({
  imports: [ReactiveFormsModule],
  exports: [

    MatButtonModule,
    MatDialogModule,
  ],
  entryComponents : [DialogOverviewExampleDialog]
})
export class DemoMaterialModule {}
