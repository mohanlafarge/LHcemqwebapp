// ANGULAR & PLUGINS MODULES
// Angular Core
import { NgModule } from '@angular/core';
import { DatePipe } from '@angular/common';

// Forms & Reactive Forms --> to manage validation at component level
import { FormsModule } from '@angular/forms';

// ARIS MODULES & COMPONENTS
import { ArisDynamicPageComponent } from './components/aris-dynamic-page.component';
import { ArisDynamicPageService } from './services/aris-dynamic-page.service';

import { DynamicModule } from 'ng-dynamic-component';
import { ArisPageSharedModule } from '../../../pages/page-shared.module';
import { ChartModule } from '../../ui-components/chart-module/aris-chart.module';
import { ArisTilesTemplatesModule } from '../../ui-tiles-templates/aris-tiles-templates.module';
import { ArisChartComponent } from '../../ui-components/chart-module/aris-chart.component';
import { ArisPipesModule } from '../../pipes/aris-pipes.module';


@NgModule({
  declarations: [
    ArisDynamicPageComponent
  ],
  imports: [
    ArisPageSharedModule,
    ChartModule,
    ArisTilesTemplatesModule,
    FormsModule,
    DynamicModule.withComponents([ArisChartComponent]),
    ArisPipesModule
  ],
  providers:    [
    ArisDynamicPageService,
    DatePipe
  ],
  exports: [ArisDynamicPageComponent]
})
export class ArisDynamicPageModule { }
