import { ArisPageSectionObservableEventService } from '../../../ui-page-sections/services/aris-page-section-observable-event.service';
import { ArisDynamicPageComponent } from "./aris-dynamic-page.component";
import { TestBed, ComponentFixture } from '@angular/core/testing';
import { ArisDynamicPageService } from './../services/aris-dynamic-page.service';

import { DynamicModule } from 'ng-dynamic-component';
import { ArisPageSharedModule } from '../../../../pages/page-shared.module';
import { ChartModule } from '../../../ui-components/chart-module/aris-chart.module';
import { ArisTilesTemplatesModule } from '../../../ui-tiles-templates/aris-tiles-templates.module';
import { ArisChartComponent } from '../../../ui-components/chart-module/aris-chart.component';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { InjectorRef } from 'angular-l10n';



class MockSharedCommunicationService extends ArisPageSectionObservableEventService {
  getPageName(): string {
    return 'SamplaePage';
  }
}

class MockTile {
  plugin = "TILE_TYPE_CHART";
  size: string;
  input = { chartData: { data: 'data' } };
  static: string;
}
class MockTile2 {
  plugin = "TILE_TYPE_CHART";
  size: string;
  input: string;
  static: string;
}
class MockTile1 {
  plugin = "TILE_TYPE_CUSTOM_TEMPLATE";
  size: string;
  input = { headerConfig: 'headerConfig', internalInput: { templateData: 'data' },
    internalComponent: 'internalComponent'};
  static: string;
  component = 'component';
}
class MockTile3 {
  plugin = "TILE_TYPE_CUSTOM_TEMPLATE";
  size: string;
  input = { headerConfig: 'headerConfig' };
  static: string;
  component: string;
}
class MockTile4 {
  plugin = "TILE";
  size: string;
  input = { headerConfig: 'headerConfig' };
  static: string;
  component: string;
}
class PageModel {
  layout: any[] = new Array();
}

describe('Test: Aris Dynamic Page Component:', () => {
  let save = true;
  // let mockTile1 = new MockTile();
  // let mockTile2 = new MockTile();
  // let container1: MockTile[] = new Array();
  // container1.push(mockTile1);
  // container1.push(mockTile2);
  // let pageModel = new PageModel();
  // pageModel.layout.push(container1);

  let component: ArisDynamicPageComponent;
  let fixture: ComponentFixture<ArisDynamicPageComponent>;
  let listRecycled = ["listRecycled"];
  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [
        ArisDynamicPageComponent
      ],
      imports: [
        ArisPageSharedModule,
        ChartModule,
        ArisTilesTemplatesModule,
        FormsModule,
        DynamicModule.withComponents([ArisChartComponent]),
        ArisPipesModule
      ],
      providers: [InjectorRef, ArisPageSectionObservableEventService,
      ]
    }).compileComponents();

    afterAll(() => {
      component = null;
          });
      // create component and test fixture
    fixture = TestBed.createComponent(ArisDynamicPageComponent);

      // get test component from the fixture
    component = fixture.componentInstance;
    component.listRecycled = listRecycled;
  });


  it('function savePage .', () => {
    let mockTile1 = new MockTile();
    let mockTile2 = new MockTile();
    let container1: MockTile[] = new Array();
    container1.push(mockTile1);
    container1.push(mockTile2);
    let pageModel = new PageModel();
    pageModel.layout.push(container1);
    component.pageModel = pageModel;
    spyOn(component, 'savePage').and.callThrough();
    component.ngOnInit();
    component.savePage(save);
    expect(component.savePage).toHaveBeenCalled();
    expect(component.editSubscription).toBeDefined();
  });

  it('function ngOnDestroy .', () => {
    let mockTile1 = new MockTile();
    let mockTile2 = new MockTile();
    let container1: MockTile[] = new Array();
    container1.push(mockTile1);
    container1.push(mockTile2);
    let pageModel = new PageModel();
    pageModel.layout.push(container1);
    component.pageModel = pageModel;
    component.ngOnDestroy();
    expect(component).toBeTruthy();
  });

  it('function savePage and ngoninit else.', () => {
    component.pageModel = undefined;
    component.ngOnInit();
    component.savePage(save);
    expect(component).toBeDefined();
  });

  it('function savePage TILE_TYPE_CUSTOM_TEMPLATE', () => {
    let mockTile1 = new MockTile1();
    let mockTile2 = new MockTile1();
    let container1: MockTile1[] = new Array();
    container1.push(mockTile1);
    container1.push(mockTile2);
    let pageModel = new PageModel();
    pageModel.layout.push(container1);
    component.pageModel = pageModel;
    spyOn(component, 'savePage').and.callThrough();
    component.ngOnInit();
    component.savePage(save);
    expect(component.savePage).toHaveBeenCalled();
    expect(component.editSubscription).toBeDefined();
  });

  it('function savePage TILE_TYPE_CUSTOM_TEMPLATE else', () => {
    let mockTile1 = new MockTile3();
    let mockTile2 = new MockTile3();
    let container1: MockTile3[] = new Array();
    container1.push(mockTile1);
    container1.push(mockTile2);
    let pageModel = new PageModel();
    pageModel.layout.push(container1);
    component.pageModel = pageModel;
    spyOn(component, 'savePage').and.callThrough();
    component.ngOnInit();
    component.savePage(save);
    expect(component.savePage).toHaveBeenCalled();
    expect(component.editSubscription).toBeDefined();
  });

  it('function savePage TILE_TYPE_CHART else ', () => {
    let mockTile1 = new MockTile2();
    let mockTile2 = new MockTile2();
    let container1: MockTile2[] = new Array();
    container1.push(mockTile1);
    container1.push(mockTile2);
    let pageModel = new PageModel();
    pageModel.layout.push(container1);
    component.pageModel = pageModel;
    spyOn(component, 'savePage').and.callThrough();
    component.ngOnInit();
    component.savePage(save);
    expect(component.savePage).toHaveBeenCalled();
    expect(component.editSubscription).toBeDefined();
  });

  it('function savePage break ', () => {
    let mockTile1 = new MockTile4();
    let mockTile2 = new MockTile4();
    let container1: MockTile4[] = new Array();
    container1.push(mockTile1);
    container1.push(mockTile2);
    let pageModel = new PageModel();
    pageModel.layout.push(container1);
    component.pageModel = pageModel;
    spyOn(component, 'savePage').and.callThrough();
    component.ngOnInit();
    component.savePage(save);
    expect(component.savePage).toHaveBeenCalled();
    expect(component.editSubscription).toBeDefined();
  });

});
