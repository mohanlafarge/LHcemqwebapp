import { OnInit, Component, OnDestroy, Input } from '@angular/core';
import { forEach } from '@angular/router/src/utils/collection';
// import * as $ from 'jquery';
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;
import { ArisPageSectionObservableEventService } from '../../../ui-page-sections/services/aris-page-section-observable-event.service';

@Component({
  selector: 'aris-dynamic-page',
  templateUrl: './aris-dynamic-page.component.html',
  providers: []
})
export class ArisDynamicPageComponent implements OnInit, OnDestroy {
  editLayoutFlag = false;
  saveLayoutFlag: boolean;
  restoreLayoutFlag: boolean;
  editSubscription: any;
  saveSubscription: any;

  @Input() pageModel: any;
  listRecycled = [];

  constructor(private sharedCommunicationService: ArisPageSectionObservableEventService) {
    console.log('Information Received: ' + this.pageModel);
  }

  ngOnDestroy() {
    this.sharedCommunicationService.setEditLayout(false);
    if (this.editSubscription) {
      this.editSubscription.unsubscribe();
    }
    if (this.saveSubscription) {
      this.saveSubscription.unsubscribe();
    }
  }

  ngOnInit() {
    if (this.pageModel !== undefined) {
      this.sharedCommunicationService.setPageName(this.pageModel.name);
      this.editSubscription = this.sharedCommunicationService.editLayout.subscribe(editLayoutFlag => this.editLayoutFlag = editLayoutFlag);
      this.saveSubscription = this.sharedCommunicationService.saveLayout.subscribe(saveLayoutFlag => this.savePage(saveLayoutFlag));
    }
  }

  savePage(save: boolean) {
    if (save) {
      let pageLayoutContent: any[][] = [];
      if (this.pageModel !== undefined && this.pageModel.layout !== undefined) {
        this.pageModel.layout.forEach((container: any[]) => {
          let tilesRow: any[] = [];

          container.forEach((tile) => {
            switch (tile.plugin) {
              case 'TILE_TYPE_CHART':
                if (tile.input && tile.input.chartData && tile.input.chartData.data) {
                  delete tile.input.chartData.data;
                }
                break;
              case 'TILE_TYPE_CUSTOM_TEMPLATE':
                tile.headerConfig = tile.input.headerConfig;
                if (tile.input &&
                    tile.input.internalInput) {
                  delete tile.input.internalComponent;
                  delete tile.input.internalInput.templateData;
                }
                if (tile.component) {
                  delete tile.component;
                }
                break;
              default:
            }

            tilesRow.push(
              {
                plugin: tile.plugin,
                tileName: tile.tileName,
                size: tile.size,
                title: tile.title,
                headerConfig: tile.headerConfig,
                dataSourceId: tile.dataSourceId,
                dataSource: tile.dataSource,
                chartType: tile.chartType,
                chartOptions: tile.chartOptions,
                input: tile.input,
                static: tile.static
              }
            );
          });
          pageLayoutContent.push(tilesRow);
        });

        let layout = {
          name: this.sharedCommunicationService.getPageName(),
          content: '{"layout":' + JSON.stringify(pageLayoutContent) + '}'
        };

        this.sharedCommunicationService.setPageLayout(layout);
      }
    }
  }
}
