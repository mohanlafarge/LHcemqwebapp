import { HttpClient, HttpHandler } from "@angular/common/http";
import { ArisDynamicPageService } from "./aris-dynamic-page.service";


describe('ArisDynamicPageService', () => {
  let handler: HttpHandler;
  let http = new HttpClient(handler);
  let arisDynamicPageService: ArisDynamicPageService = new ArisDynamicPageService(http);

  it('should create ArisDynamicPageService', () => {
    expect(arisDynamicPageService).toBeTruthy();
  });
});

