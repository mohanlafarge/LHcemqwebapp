import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Tile } from '../types/Tile';

import 'rxjs/add/operator/toPromise';

@Injectable()
export class ArisDynamicPageService {

  constructor(private http: HttpClient) { }
}
