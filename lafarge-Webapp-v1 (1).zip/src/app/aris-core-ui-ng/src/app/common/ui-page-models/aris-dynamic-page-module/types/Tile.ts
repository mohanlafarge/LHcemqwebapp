
export class Tile {
  componentId: string;
  componentType: string;
  content: string;
  pagename: string;
}
