export const mapLayerIDs =  {
  FLOW_MONITORS: "flowMonitors",
  CIP_WW_PROJECTS: "cipWwProjects",
  SEWER_PILLS: "sewerPills",
  WORK_ORDERS: "workOrders",
  VEHICLE_TRACKING: "vehicleTracking",
  CITY_DISTRICTS: "atlantaDistricts",
  SEWER_STRUCTURES: "SewerStructures",
  SEWER_PIPES: "SewerPipes",
  RAIN_FORECAST: "rainForecast",
  SEWER_WYE_CONNECTORS: "SewerWyeConnectors",
  WATER_TREATMENT_PLANT: "waterTreatmentPlant",
  SERVICE_RESERVOIRS: "serviceReservoirs",
  CUSTOMER_CONTACTS: "customerContacts",
  CRITICAL_PRESSURE_POINTS: "criticalPressurePoints",
  CUSTOMER_WATER_METERS: "customerWaterMeters",
  WATER_BOOSTER_STATIONS: "waterBoosterStations",
  SPILL_INCIDENT: "spillIncident",
  WEATHER_STATION: "weatherStation",
  ABSTRACTION_UNDERGROUND_SOURCE_SUMMARY: "abstractionUndergroundSourse",
  MONITORED_SEWER_FACILITY_SUMMARY: "monitoredSewerFacilitySummary",
  CIP_ASSET: "cipAsset",
  WATER_SUPPLY_ZONE: "waterSupplyZone"
};

export const mapLayerTypes =  {
  // Layer will be shown using markers.
  MARKER: "marker",
  // Layer will be shown using clusters.
  CLUSTER: "cluster",
  // Layer will be shown using shapes.
  SHAPE: "shape"
};

export const chartTypes =  {
  // Line chart.
  LINE_CHART: "lineChart",
  // Multi line chart.
  MULTI_LINE_CHART: "multiLineChart"
};

export const defaultTimeRangeDuration = "6";





