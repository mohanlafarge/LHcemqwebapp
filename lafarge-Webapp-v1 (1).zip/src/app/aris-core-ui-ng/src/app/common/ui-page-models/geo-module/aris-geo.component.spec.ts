/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { ArisGeoComponent } from './aris-geo.component';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA, Injector } from '@angular/core';
import { DatePipe, LowerCasePipe } from '@angular/common';
import { By } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { LocalizationModule, TranslatePipe, InjectorRef,
   TranslationService, TRANSLATION_CONFIG, LocaleService,
   LOCALE_CONFIG, LocaleStorage, TranslationProvider, TranslationHandler } from 'angular-l10n';
import { ArisGeoService } from './services/aris-geo.service';
import { ArisGeoInfoCardService } from './services/aris-geo-infocard.service';
import { ArisGeoInfoCardCommonService } from './services/aris-geo-infocard-common.service';
import { ArisConfigService } from '../../services/aris-config.service';
import { ArisLanguageService } from '../../ui-page-sections/language-selector-module/services/aris-language.service';
import { ArisFooterService } from '../../ui-page-sections/footer-module/services/aris-footer-service';
import { ArisPageRefreshService } from '../../services/aris-page-refresh.service';
import { ArisGeoMapLayersService } from './services/aris-geo-maplayers.service';
import { ArisPermissionPipe } from '../../pipes/aris-permission.pipes';
import { ArisPermissionService } from '../../services/aris-permission.service';
import { ArisPageSectionObservableEventService } from '../../ui-page-sections/services/aris-page-section-observable-event.service';
import { ArisGeoMarkerClustersDelegateService } from './services/aris-geo-markerclusters-layer-delegate.service';
import { ArisDataSourceService } from '../../services/aris-datasource.service';
import { ArisGeoShapeLayerDelegateService } from './services/aris-geo-shape-layer-delegate.service';
import { ArisGeoGeoJsonDataLayerDelegateService } from './services/aris-geo-geojsondata-layer-delegate.service';
import { Subject } from 'rxjs';
import { ArisLibraryLoadService } from '../../services/aris-library-load.service';
declare var google: any;

describe('Component: ArisGeoComponent', () => {

  let component: ArisGeoComponent;
  let fixture: ComponentFixture<ArisGeoComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisGeoComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [LocalizationModule],
      providers: [InjectorRef, Injector, ArisGeoService, ArisGeoInfoCardService, ArisGeoInfoCardCommonService, ArisConfigService,
        HttpClient, HttpHandler, ArisLanguageService, ArisFooterService, ArisPageRefreshService, ArisLibraryLoadService,
        TranslationService, ArisGeoMapLayersService, ArisPermissionPipe, ArisPermissionService, ArisGeoShapeLayerDelegateService, ArisPageSectionObservableEventService,
        LowerCasePipe,  ArisGeoGeoJsonDataLayerDelegateService, {
          provide: TRANSLATION_CONFIG,
          useValue: null
        }, LocaleService, {
          provide: LOCALE_CONFIG,
          useValue: null
        }, LocaleStorage, TranslationProvider, TranslationHandler, ArisGeoMarkerClustersDelegateService, ArisDataSourceService]
      // providers: [TranslatePipe, ArisGeoService, ArisGeoInfoCardService,
      //   ArisGeoInfoCardCommonService, ArisConfigService, HttpClient, HttpHandler,
      //   ArisLanguageService, ArisFooterService, ArisPageRefreshService, TranslationService]
    }).compileComponents();
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(ArisGeoComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

    component.showInfoCard = false;
    component.mapLayer = {};
    component.displayFilter = false;
    component.filterPanelCategoryTab = false;
    component.selectedMapLayers = {};
    component.wmslegend = 'hide';
    component.pageType = 'geo';
    component.infoCardMainSection = 'infoCardMainSection';
    let arisLibraryLoadService = TestBed.get(ArisLibraryLoadService);
    spyOn(arisLibraryLoadService, 'getGoogleMapLibrary').and.returnValue(google.maps);
    componentEl = fixture.debugElement;
    component.ngOnInit();
    // let gmap = document.createElement("script");
    // gmap.setAttribute("src", "https://maps.googleapis.com/maps/api/js?key=AIzaSyAi3evjH1w943dlUq9EDTrmKuC83dplfSI&libraries=places");
    // componentEl.appendChild(gmap);

  });

  it('component defined', () => {
    expect(component).toBeDefined();
  });

  it('ngOnDestroy executed', () => {
    component.layerTypes = {};
    component.ngOnDestroy();
    expect(component.layerTypes).toEqual({});
  });

  it('getParamsForMapBound executed', () => {
    let arisGeoService = TestBed.get(ArisGeoService);
    let data = { getBounds() {} };
    let value = { getSouthWest() {}, getNorthEast() {} };
    let latLngSouthWest = { lat() {}, lng() {} };
    let latLngNorthEast  = { lat() {}, lng() {} };
    spyOn(arisGeoService, 'getMap').and.returnValue(data);
    spyOn(data, 'getBounds').and.returnValue(value);
    spyOn(value, 'getSouthWest').and.returnValue(latLngSouthWest);
    spyOn(value, 'getNorthEast').and.returnValue(latLngNorthEast);
    spyOn(latLngNorthEast, 'lat').and.returnValue(1);
    spyOn(latLngNorthEast, 'lng').and.returnValue(1);
    spyOn(latLngSouthWest, 'lat').and.returnValue(1);
    spyOn(latLngSouthWest, 'lng').and.returnValue(1);
    let expected = component.getParamsForMapBound();
    expect(expected).toEqual('south=1&north=1&west=1&east=1');
  });

  it('applySingleLayerUpdate executed', () => {
    let arisGeoService = TestBed.get(ArisGeoService);
    let injector = TestBed.get(Injector);
    let mapLayerData = { service: 'ArisGeoMapLayersService' };
    let data1 = { filterData: 1, dateRange: 1, refreshPage: true };
    let data = { getBounds() {} };
    let value = { getSouthWest() {}, getNorthEast() {} };
    let latLngSouthWest = { lat() {}, lng() {} };
    let latLngNorthEast  = { lat() {}, lng() {} };
    let injectorValue = { displayLayerOverlaysOnMap() {} };
    spyOn(arisGeoService, 'getMap').and.returnValue(data);
    spyOn(data, 'getBounds').and.returnValue(value);
    spyOn(value, 'getSouthWest').and.returnValue(latLngSouthWest);
    spyOn(value, 'getNorthEast').and.returnValue(latLngNorthEast);
    spyOn(latLngNorthEast, 'lat').and.returnValue(1);
    spyOn(latLngNorthEast, 'lng').and.returnValue(1);
    spyOn(latLngSouthWest, 'lat').and.returnValue(1);
    spyOn(latLngSouthWest, 'lng').and.returnValue(1);
    spyOn(injector, 'get').and.returnValue(injectorValue);
    component.applySingleLayerUpdate(mapLayerData, data1);
    expect(injector.get).toHaveBeenCalled();
  });

  it('applySingleLayerUpdate else executed', () => {
    let arisGeoService = TestBed.get(ArisGeoService);
    let injector = TestBed.get(Injector);
    let mapLayerData = { type: 0 };
    let service = { service: 'ArisGeoMapLayersService' };
    component.layerTypes = [service];
    let data1 = { filterData: 1, dateRange: 1, refreshPage: true };
    let data = { getBounds() {} };
    let value = { getSouthWest() {}, getNorthEast() {} };
    let latLngSouthWest = { lat() {}, lng() {} };
    let latLngNorthEast  = { lat() {}, lng() {} };
    let injectorValue = { displayLayerOverlaysOnMap() {} };
    spyOn(arisGeoService, 'getMap').and.returnValue(data);
    spyOn(data, 'getBounds').and.returnValue(value);
    spyOn(value, 'getSouthWest').and.returnValue(latLngSouthWest);
    spyOn(value, 'getNorthEast').and.returnValue(latLngNorthEast);
    spyOn(latLngNorthEast, 'lat').and.returnValue(1);
    spyOn(latLngNorthEast, 'lng').and.returnValue(1);
    spyOn(latLngSouthWest, 'lat').and.returnValue(1);
    spyOn(latLngSouthWest, 'lng').and.returnValue(1);
    spyOn(injector, 'get').and.returnValue(injectorValue);
    component.applySingleLayerUpdate(mapLayerData, data1);
    expect(injector.get).toHaveBeenCalled();
  });

  it('onFilterChange executed', () => {
    let arisGeoService = TestBed.get(ArisGeoService);
    let injector = TestBed.get(Injector);
    component.mapLayer = { service: 'ArisGeoMapLayersService' };
    let data1 = { filterData: 1, dateRange: 1, refreshPage: true };
    let data = { getBounds() {} };
    let value = { getSouthWest() {}, getNorthEast() {} };
    let latLngSouthWest = { lat() {}, lng() {} };
    let latLngNorthEast  = { lat() {}, lng() {} };
    let injectorValue = { displayLayerOverlaysOnMap() {} };
    spyOn(arisGeoService, 'getMap').and.returnValue(data);
    spyOn(data, 'getBounds').and.returnValue(value);
    spyOn(value, 'getSouthWest').and.returnValue(latLngSouthWest);
    spyOn(value, 'getNorthEast').and.returnValue(latLngNorthEast);
    spyOn(latLngNorthEast, 'lat').and.returnValue(1);
    spyOn(latLngNorthEast, 'lng').and.returnValue(1);
    spyOn(latLngSouthWest, 'lat').and.returnValue(1);
    spyOn(latLngSouthWest, 'lng').and.returnValue(1);
    spyOn(injector, 'get').and.returnValue(injectorValue);
    component.onFilterChange(data1);
    expect(injector.get).toHaveBeenCalled();
  });

  it('resetState executed', () => {
    component.map = { setZoom() {}, setCenter() {}, setMapTypeId() {} };
    let data = { zoomLevel: 1 };
    let arisGeoService = TestBed.get(ArisGeoService);
    spyOn(arisGeoService, 'getProperties').and.returnValue(data);
    component.resetState();
    expect(arisGeoService.getProperties).toHaveBeenCalled();
  });

  it('onMapLayerClick executed', () => {
    let arisGeoService = TestBed.get(ArisGeoService);
    let injector = TestBed.get(Injector);
    component.mapLayer = { service: 'ArisGeoMapLayersService', showLegend: true };
    let data1 = { filterData: 1, dateRange: 1, isChecked: true, mapLayer: { name: 'name', hasFilter: undefined, service: 'ArisGeoMapLayersService' } };
    let data = { getBounds() {} };
    let value = { getSouthWest() {}, getNorthEast() {} };
    let latLngSouthWest = { lat() {}, lng() {} };
    let latLngNorthEast  = { lat() {}, lng() {} };
    let injectorValue = { displayLayerOverlaysOnMap() {} };
    spyOn(arisGeoService, 'getMap').and.returnValue(data);
    spyOn(data, 'getBounds').and.returnValue(value);
    spyOn(value, 'getSouthWest').and.returnValue(latLngSouthWest);
    spyOn(value, 'getNorthEast').and.returnValue(latLngNorthEast);
    spyOn(latLngNorthEast, 'lat').and.returnValue(1);
    spyOn(latLngNorthEast, 'lng').and.returnValue(1);
    spyOn(latLngSouthWest, 'lat').and.returnValue(1);
    spyOn(latLngSouthWest, 'lng').and.returnValue(1);
    spyOn(injector, 'get').and.returnValue(injectorValue);
    component.onMapLayerClick(data1);
    expect(injector.get).toHaveBeenCalled();
    expect(component.showInfoCard).toBeFalsy();
  });

  it('onMapLayerClick hasFilter True executed', () => {
    let arisGeoService = TestBed.get(ArisGeoService);
    let injector = TestBed.get(Injector);
    component.showRefreshData = new Subject();
    component.mapLayer = { service: 'ArisGeoMapLayersService', showLegend: true };
    let data1 = { filterData: 1, dateRange: 1, isChecked: true, mapLayer: { name: 'name', hasFilter: true, service: 'ArisGeoMapLayersService' } };
    let data = { getBounds() {} };
    let value = { getSouthWest() {}, getNorthEast() {} };
    let latLngSouthWest = { lat() {}, lng() {} };
    let latLngNorthEast  = { lat() {}, lng() {} };
    let injectorValue = { displayLayerOverlaysOnMap() {} };
    spyOn(arisGeoService, 'getMap').and.returnValue(data);
    spyOn(data, 'getBounds').and.returnValue(value);
    spyOn(value, 'getSouthWest').and.returnValue(latLngSouthWest);
    spyOn(value, 'getNorthEast').and.returnValue(latLngNorthEast);
    spyOn(latLngNorthEast, 'lat').and.returnValue(1);
    spyOn(latLngNorthEast, 'lng').and.returnValue(1);
    spyOn(latLngSouthWest, 'lat').and.returnValue(1);
    spyOn(latLngSouthWest, 'lng').and.returnValue(1);
    spyOn(injector, 'get').and.returnValue(injectorValue);
    component.onMapLayerClick(data1);
    expect(injector.get).toHaveBeenCalled();
    expect(component.showInfoCard).toBeFalsy();
  });

  it('onMapLayerClick data.mapLayer.service empty executed', () => {
    let arisGeoService = TestBed.get(ArisGeoService);
    let injector = TestBed.get(Injector);
    component.showRefreshData = new Subject();
    component.mapLayer = { service: 'ArisGeoMapLayersService', showLegend: true };
    let data1 = { filterData: 1, dateRange: 1, isChecked: true, mapLayer: { name: 'name', hasFilter: true, type: 0 } };
    let service = { service: 'ArisGeoMapLayersService' };
    component.layerTypes = [service];
    let data = { getBounds() {} };
    let value = { getSouthWest() {}, getNorthEast() {} };
    let latLngSouthWest = { lat() {}, lng() {} };
    let latLngNorthEast  = { lat() {}, lng() {} };
    let injectorValue = { displayLayerOverlaysOnMap() {} };
    spyOn(arisGeoService, 'getMap').and.returnValue(data);
    spyOn(data, 'getBounds').and.returnValue(value);
    spyOn(value, 'getSouthWest').and.returnValue(latLngSouthWest);
    spyOn(value, 'getNorthEast').and.returnValue(latLngNorthEast);
    spyOn(latLngNorthEast, 'lat').and.returnValue(1);
    spyOn(latLngNorthEast, 'lng').and.returnValue(1);
    spyOn(latLngSouthWest, 'lat').and.returnValue(1);
    spyOn(latLngSouthWest, 'lng').and.returnValue(1);
    spyOn(injector, 'get').and.returnValue(injectorValue);
    component.onMapLayerClick(data1);
    expect(injector.get).toHaveBeenCalled();
    expect(component.showInfoCard).toBeFalsy();
  });

  it('onMapLayerClick else scenario executed', () => {
    let arisGeoService = TestBed.get(ArisGeoService);
    let injector = TestBed.get(Injector);
    component.mapLayer = { service: 'ArisGeoMapLayersService', showLegend: true, id: 1 };
    let data1 = { filterData: 1, dateRange: 1, isChecked: false, mapLayer: { id: 1, name: 'name', hasFilter: undefined, service: 'ArisGeoMapLayersService' } };
    let injectorValue = { removeLayerOverlaysFromMap() {} };
    spyOn(injector, 'get').and.returnValue(injectorValue);
    component.onMapLayerClick(data1);
    expect(injector.get).toHaveBeenCalled();
    expect(component.filterPanelCategoryTab).toBeFalsy();
  });

  it('onShowFilterByLayer executed', () => {
    component.openFooterFilter = new Subject();
    let maplayer = { id: 1 };
    let injectorValue = { removeLayerOverlaysFromMap() {} };
    component.onShowFilterByLayer(maplayer);
    expect(component.filterPanelCategoryTab).toEqual(1);
  });

  it('onPageRefresh executed', () => {
    let maplayer = { id: 1 };
    component.onPageRefresh(maplayer);
    expect(component.filterPanelCategoryTab).toEqual(false);
  });
});
