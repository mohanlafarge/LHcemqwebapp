import { Component, Input, OnInit, ChangeDetectorRef, Injector, ViewEncapsulation } from '@angular/core';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { TranslationService, Language } from 'angular-l10n';
import { Subject } from 'rxjs/Subject';
import { ArisLibraryLoadService } from '../../services/aris-library-load.service';
import { ArisGeoService } from './services/aris-geo.service';
import { ArisFooterService } from '../../ui-page-sections/footer-module/services/aris-footer-service';
import { ArisGeoInfoCardService } from './services/aris-geo-infocard.service';
import { ArisGeoInfoCardCommonService } from './services/aris-geo-infocard-common.service';
import { ArisConfigService } from '../../services/aris-config.service';


declare var google: any;
declare var $: any;

@Component({
  selector: 'aris-geo',
  templateUrl: './aris-geo.component.html',
  styleUrls: ['./css/aris-geo.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class ArisGeoComponent implements OnInit, OnDestroy {

  showRefreshData: Subject<any> = new Subject();
  openFooterFilter: Subject<any> = new Subject();
  showInfoCard: boolean;
  mapLayer: any;
  displayFilter: boolean;
  filterPanelCategoryTab: any;
  selectedMapLayers: any;
  wmslegend: string;
  pageType: string;
  zoom: any;
  map: any;
  latLng: any;
  centerControlDiv: any;
  infoCardMainSection: String;
  layerTypes: any;
  mapLayerData: any;

  @Language() lang: string;

  constructor(
    private arisGeoService: ArisGeoService,
    private arisGeoInfoCardService: ArisGeoInfoCardService,
    private arisFooterService: ArisFooterService,
    private injector: Injector,
    private arisGeoInfoCardCommonService: ArisGeoInfoCardCommonService,
    private arisLibraryLoadService: ArisLibraryLoadService
  ) {
    this.showInfoCard = false;
    this.mapLayer = {};
    this.displayFilter = false;
    this.filterPanelCategoryTab = false;
    this.selectedMapLayers = {};
    this.wmslegend = 'hide';
    this.pageType = 'geo';
    this.infoCardMainSection = 'infoCardMainSection';
  }

  ngOnInit() {
    this.arisGeoService.setProperties();

    if (window.app.config.geo.footerConfig !== undefined) {
      this.arisFooterService.setFooterInfo(window.app.config.geo.footerConfig);
    } else {
      this.arisFooterService.setFooterInfo('exceptEditLayout');
    }

    this.layerTypes = this.arisGeoService.getMapLayersService().getLayerTypes();
    this.arisGeoService.getMapLayersService().setLayers();

    this.arisLibraryLoadService.getGoogleMapLibrary(this.initGeoPage.bind(this));
    this.mapLayerData = this.getMapLayersArray();
  }

  getMapLayersArray() {
    return this.arisGeoService.getMapLayersService().getLayers();
  }

  initGeoPage() {
    this.latLng = new google.maps.LatLng(this.arisGeoService.getProperties().latitude, this.arisGeoService.getProperties().longitude);

    this.zoom = this.arisGeoService.getProperties().zoomLevel;

    // dynamically calculate height of map
    let footerElm = $('footer.footer').offset();

    let height = (footerElm && footerElm.top !== undefined && footerElm.top > 500) ? footerElm.top : $('body').height() - 50 ;
    height = height - $('#map').offset().top;
    $('#map').css('height', height);

    this.map = new google.maps.Map(document.getElementById('map'), {
      center: this.latLng,
      zoom: this.zoom,
      mapTypeId: 'roadmap'
    });

    this.arisGeoService.setMap(this.map);
    this.map.setCenter(this.latLng);

    // Create the DIV to hold the control and call the CenterControl()
    // constructor passing in this DIV.
    this.centerControlDiv = document.createElement('div');
    this.centerControl(this.centerControlDiv, this.map);
    this.centerControlDiv.index = 1;
    this.map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(this.centerControlDiv);

    // Create the search box and link it to the UI element.
    let input = document.getElementById('pac-input');
    let searchBox = new google.maps.places.SearchBox(input);
    this.map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

    // Bias the SearchBox results towards current map's viewport.
    this.map.addListener('bounds_changed', () => {
      searchBox.setBounds(this.map.getBounds());
    });

    let markers = [];
    // Listen for the event fired when the user selects a prediction and retrieve
    // more details for that place.
    searchBox.addListener('places_changed', () => {
      let places = searchBox.getPlaces();

      if (places.length === 0) {
        return;
      }

        // Clear out the old markers.
      markers.forEach((marker) => {
        marker.setMap(null);
      });

      markers = [];

        // For each place, get the icon, name and location.
      let bounds = new google.maps.LatLngBounds();
      places.forEach((place) => {
        if (!place.geometry) {
          console.log('Returned place contains no geometry');
          return;
        }

        let icon = {
          url: place.icon,
          size: new google.maps.Size(71, 71),
          origin: new google.maps.Point(0, 0),
          anchor: new google.maps.Point(17, 34),
          scaledSize: new google.maps.Size(25, 25)
        };

        // Create a marker for each place.
        markers.push(new google.maps.Marker({
          map: this.map,
          icon: '{icon}',
          title: place.name,
          position: place.geometry.location
        }));

        if (place.geometry.viewport) {
                    // Only geocodes have viewport.
          bounds.union(place.geometry.viewport);
        } else {
          bounds.extend(place.geometry.location);
        }
      });
      this.map.fitBounds(bounds);
    });
  }

  // on Map layer click
  onMapLayerClick(data: any) {
    console.log('mapLayer: ' + data.mapLayer.name + ' isChecked: ' + data.isChecked);
    let layerService;
    if (data.mapLayer.service) {
      layerService = this.injector.get((data.mapLayer.service));
    } else {
      layerService = this.injector.get((this.layerTypes[data.mapLayer.type]).service);
    }
    // Reset previous infocard data.
    // It occurs when user selects another map layer while previous infocard window is shown.
    this.showInfoCard = false;
    this.arisGeoInfoCardService.clear();
    if (data.isChecked) { // if checked
      this.mapLayer = data.mapLayer;
      if (data.mapLayer.hasFilter) {
        this.showRefreshData.next(data.mapLayer.id);
      } else {
        layerService.displayLayerOverlaysOnMap(this.mapLayer,
            this.arisGeoService.getMap(), this.getParamsForMapBound());
      }
      this.selectedMapLayers[data.mapLayer.id] = layerService;
      this.mapLayer.showLegend = true;
      this.arisGeoService.showLegend.next(this.mapLayer);
            // call change function for show updated data
    } else {
      delete this.selectedMapLayers[data.mapLayer.id];
      console.log('Remove Markers:' + this.mapLayer.id);
      let mapLayerData: any = this.mapLayer;
      this.mapLayer = {};
      this.filterPanelCategoryTab = false;
      layerService.removeLayerOverlaysFromMap(data.mapLayer.id, data.mapLayer.type);
      this.arisGeoInfoCardCommonService.closeInfoCard.next();
      mapLayerData.showLegend = false;
      this.arisGeoService.showLegend.next(mapLayerData);
    }
  }

  onFilterChange(data) {
    this.applySingleLayerUpdate(this.mapLayer, data);
  }

  // 'RESET' button in panel filter and 'REFRESH PAGE' event
  onPageRefresh(data) {
    this.applyMultipleLayersUpdate(data);
  }

  onShowFilterByLayer(maplayer) {
    console.log('in geo component', maplayer);
    this.mapLayer = maplayer;
    this.filterPanelCategoryTab = maplayer.id;
    this.openFooterFilter.next(this.filterPanelCategoryTab);
    // $scope.$broadcast('openFooterFilter', this.filterPanelCategoryTab);
  }

  // Function for Reset Button functionality
  resetState() {
    this.map.setZoom(this.arisGeoService.getProperties().zoomLevel);
    this.map.setCenter(this.latLng);
    this.map.setMapTypeId(google.maps.MapTypeId.ROADMAP);
    (<HTMLInputElement>document.getElementById('pac-input')).value = '';
  }

/*
* The CenterControl adds a control to the map that recenters the map
* This constructor takes the control DIV as an argument.
*/
  centerControl(controlDiv, map) {
          // Set CSS for the control border.
    let controlUI = document.createElement('div');
    controlUI.style.backgroundColor = '#fff';
    controlUI.style.border = '2px solid #fff';
    controlUI.style.borderRadius = '3px';
    controlUI.style.boxShadow = '0 2px 6px rgba(0,0,0,.3)';
    controlUI.style.cursor = 'pointer';
    controlUI.style.marginBottom = '2px';
    controlUI.style.marginRight = '8px';
    controlUI.style.textAlign = 'center';
    controlUI.title = 'My Location';
    controlDiv.appendChild(controlUI);

    let locImage = document.createElement('img');
    locImage.setAttribute('src', 'app/common/resources/img/location.png');
    locImage.setAttribute('height', '23');
    locImage.setAttribute('width', '25');
    locImage.setAttribute('alt', 'My Location');

    controlUI.appendChild(locImage);

      // Setup the click event listeners: simply set the map to current location.
    controlUI.addEventListener('click', () => {
      // Code for MyLocation Map Layer
      let marker = new google.maps.Marker({
        title: 'Your current location',
        icon: 'app/common/resources/img/marker_blue.png',
        map: this.map
      });

      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position) => {
          let pos = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };
          marker.setPosition(pos);
          map.setCenter(pos);
        });
      }
    });
  }

  /**
   * It will refresh the information relative to a specifi layer, appling the 'data' criteria
   */
  applySingleLayerUpdate(mapLayerData, data) {
    let layerService;
    if (mapLayerData.service) {
      layerService = this.injector.get((mapLayerData.service));
    } else {
      layerService = this.injector.get((this.layerTypes[mapLayerData.type]).service);
    }
    layerService.displayLayerOverlaysOnMap(mapLayerData,
            this.arisGeoService.getMap(), this.getParamsForMapBound(), data.filterData, data.dateRange, data.refreshPage);
  }

    /**
   * It will refresh the information of all the active layers, appling the 'data' criteria
   */

  applyMultipleLayersUpdate(data) {
    let checkRadioState: any;
    $(document.querySelector('.mapLayer')).find('li').each((index, value) => {
      checkRadioState = $(value).find('.mapLayerOuter').find('input').prop('checked');
      if (checkRadioState) {
        const layerId = $(value).find('.mapLayerOuter').find('input').attr('id');
        const mapLayerData =  this.arisGeoService.mapLayersService.getMapLayerById(layerId);
        this.applySingleLayerUpdate(mapLayerData, data);
      }
    });
  }

  /**
   * It will return map bounds in url GET param format.
   */
  getParamsForMapBound() {
    let map = this.arisGeoService.getMap();
    let latLngSouthWest = map.getBounds().getSouthWest();
    let latLngNorthEast = map.getBounds().getNorthEast();

    return 'south='  + latLngSouthWest.lat() +
                         '&north=' + latLngNorthEast.lat() +
                         '&west='  + latLngSouthWest.lng() +
                         '&east='  + latLngNorthEast.lng();
  }

  ngOnDestroy () {
    if (this.layerTypes) {
      for (let key in this.layerTypes) {
        if (this.layerTypes[key]) {
          let layerService = this.injector.get(this.layerTypes[key].service);
          layerService.clear();
        }
      // Use `key` and `value`
      }
    }
  }

}
