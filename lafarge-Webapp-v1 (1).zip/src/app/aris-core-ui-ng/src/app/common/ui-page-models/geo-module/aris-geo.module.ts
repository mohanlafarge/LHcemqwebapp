import { CommonModule, DatePipe, UpperCasePipe, LowerCasePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule, Injector } from '@angular/core';
import { LocalizationModule } from 'angular-l10n';
import { ArisGeoComponent } from './aris-geo.component';
import { ArisGeoService } from './services/aris-geo.service';
import { arisGeoRoutes } from './aris-geo.routes';
import { ArisGeoInfocardBottomComponent } from './components/aris-geo-infocard-bottom.component';
import { ArisNoDataPipe } from '../../pipes/aris-nodata.pipes';
import { ArisLibraryLoadService } from '../../services/aris-library-load.service';
import { ArisDateTimePipe } from '../../pipes/aris-datetime.pipes';
import { ArisPipesModule } from '../../pipes/aris-pipes.module';
import { ArisGeoInfocardMiddleComponent } from './components/aris-geo-infocard-middle.component';
import { ArisGeoInfoCardService } from './services/aris-geo-infocard.service';
import { ArisGeoInfoCardCommonService } from './services/aris-geo-infocard-common.service';
import { ChartModule } from '../../ui-components/chart-module/aris-chart.module';
import { ArisDynamicInfocardComponent } from './components/aris-dynamic-infocard.component';
import { ArisGeoInfocardTopComponent } from './components/aris-geo-infocard-top.component';
import { ArisGeoInfocardComponent } from './components/aris-geo-infocard-main.component';
import { GeoPrototypesModule } from '../../../prototypes/geo-module/aris-geo-prototype.module';
import { ArisGeoMapLayerComponent } from './components/aris-geo-maplayer.component';
import { ArisGeoMapLayersService } from './services/aris-geo-maplayers.service';
import { ArisGeoLayerDelegateService } from './services/aris-geo-layer-delegate.service';
import { ArisGeoGeoJsonDataLayerDelegateService } from './services/aris-geo-geojsondata-layer-delegate.service';
import { ArisGeoMarkerClustersDelegateService } from './services/aris-geo-markerclusters-layer-delegate.service';
import { ArisDataSourceService } from '../../services/aris-datasource.service';
import { ArisPageRefreshService } from '../../services/aris-page-refresh.service';
import { FilterModule } from '../../ui-page-sections/filter-panel-module/aris-filter.module';
import { ArisGeoShapeLayerDelegateService } from './services/aris-geo-shape-layer-delegate.service';
import { ArisInfocardCommonMiddleComponent } from './components/aris-geo-infocard-common-middle.component';
import { ArisInfocardCommonTopComponent } from './components/aris-geo-infocard-common-top.component';
import { ArisInfocardCommonBottomComponent } from './components/aris-geo-infocard-common-bottom.component';
import { ArisGeoWmslayerLegendComponent } from './components/aris-geo-wmslayer-legend.component';
import { ArisGeoMaplayerLegendComponent } from './components/aris-geo-maplayer-legend.component';
import { ArisInfocardCommonMainComponent } from './components/aris-geo-infocard-common-main.component';
import { ArisUiComponentsModule } from '../../ui-components/aris-ui-components.module';
import { ArisGeoMaplayerCommonLegendComponent } from './components/aris-geo-maplayer-common-legend.component';



@NgModule({
  declarations: [
    ArisGeoComponent,
    ArisDynamicInfocardComponent,
    ArisGeoInfocardBottomComponent,
    ArisGeoInfocardMiddleComponent,
    ArisGeoInfocardTopComponent,
    ArisGeoInfocardComponent,
    ArisGeoMapLayerComponent,
    ArisGeoWmslayerLegendComponent,
    ArisGeoMaplayerLegendComponent,
    ArisInfocardCommonMainComponent,
    ArisInfocardCommonTopComponent,
    ArisInfocardCommonMiddleComponent,
    ArisInfocardCommonBottomComponent,
    ArisGeoMaplayerCommonLegendComponent
  ],
  imports: [
    CommonModule,
    arisGeoRoutes,
    LocalizationModule,
    ArisPipesModule,
    ChartModule,
    GeoPrototypesModule,
    FilterModule,
    ArisUiComponentsModule,
    FormsModule
  ],
  providers: [
    DatePipe,
    ArisLibraryLoadService,
    ArisGeoService,
    UpperCasePipe,
    LowerCasePipe,
    ArisNoDataPipe,
    ArisDateTimePipe,
    ArisGeoInfoCardService,
    ArisGeoInfoCardCommonService,
    ArisGeoMapLayersService,
    ArisDataSourceService,
    ArisGeoMarkerClustersDelegateService,
    ArisPageRefreshService,
    ArisGeoLayerDelegateService,
    ArisGeoGeoJsonDataLayerDelegateService,
    ArisGeoShapeLayerDelegateService
  ],
  exports: [
    ArisGeoComponent,
    ArisInfocardCommonTopComponent,
    ArisInfocardCommonMiddleComponent,
    ArisInfocardCommonBottomComponent
  ],
  entryComponents: [
    ArisGeoInfocardComponent,
    ArisGeoInfocardTopComponent,
    ArisGeoInfocardBottomComponent,
    ArisGeoInfocardMiddleComponent,
    ArisGeoMaplayerLegendComponent
  ]
})
export class ArisGeoModule {
}
