import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ArisGeoComponent } from './aris-geo.component';

const routes: Routes = [
  { path: '', component: ArisGeoComponent }
];

export const arisGeoRoutes: ModuleWithProviders = RouterModule.forChild(routes);
