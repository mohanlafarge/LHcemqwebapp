/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DebugElement, ComponentFactoryResolver } from '@angular/core';
import 'rxjs/add/observable/of';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
import { ArisModule } from '../../../../aris.module';
import { ArisDynamicInfocardComponent } from './aris-dynamic-infocard.component';
import { ArisGeoInfoCardCommonService } from '../services/aris-geo-infocard-common.service';
import { DynamicComponentDirective } from '../../../directives/dynamic-component.directive';
import { TranslationService } from 'angular-l10n';

export class MockDynamicComponentDirective {
  static componentRef = { instance: { schematicInfocardData: '' } };
  viewContainerRef: any = { clear() { } , createComponent(value: any) { return MockDynamicComponentDirective.componentRef; } };
}

describe('Component: ArisDynamicInfocardComponent', () => {

  let component: ArisDynamicInfocardComponent;
  let fixture: ComponentFixture<ArisDynamicInfocardComponent>;
  let infoCardElement: DebugElement;
  let infoCardElement2: DebugElement;
  let componentFactoryResolver: ComponentFactoryResolver;
  let componentData = { component: "component", data: "data" };
  let arisDynamicDirective: DynamicComponentDirective;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisDynamicInfocardComponent],
      schemas: [],
      imports: [ArisModule],
      providers: [ArisDynamicInfocardComponent, HttpClient, HttpHandler,  TranslationService, ArisGeoInfoCardCommonService, { provide: DynamicComponentDirective,
        useClass: MockDynamicComponentDirective }]
    }).compileComponents();
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(ArisDynamicInfocardComponent);
    // get test component from the fixture
    componentFactoryResolver = TestBed.get(ComponentFactoryResolver);
    arisDynamicDirective = TestBed.get(DynamicComponentDirective);
    component = fixture.componentInstance;

  });

  it('ArisDynamicInfocardComponent should be created', () => {
    expect(component).toBeTruthy();
  });

  it('ArisDynamicSchematicInfocardComponent ngOnInit executed', () => {
    component.componentData = { component: "ArisSchematicInfoCardInterfaceComponent()", data: "data" };
    spyOn(componentFactoryResolver, 'resolveComponentFactory').and.returnValue('ArisSchematicInfoCardInterfaceComponent');
    component.arisDynamicDirective = arisDynamicDirective;
    component.ngOnInit();
    expect(componentFactoryResolver.resolveComponentFactory).toHaveBeenCalled();
  });

  it('ArisDynamicSchematicInfocardComponent ngOnDestroy executed', () => {
    component.ngOnDestroy();
    expect(component).toBeTruthy();
  });

});
