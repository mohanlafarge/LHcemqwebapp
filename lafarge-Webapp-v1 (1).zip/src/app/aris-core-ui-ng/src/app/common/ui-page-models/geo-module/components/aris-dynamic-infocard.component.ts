import { Component, Input, AfterViewInit, ViewChild, ComponentFactoryResolver, OnDestroy, OnInit } from '@angular/core';
import { ArisInfoCardDataComponent } from './aris-infocard-data.component';
import { DynamicComponentDirective } from '../../../directives/dynamic-component.directive';
import { ArisGeoInfoCardCommonService } from '../services/aris-geo-infocard-common.service';

@Component({
  selector: 'aris-dynamic-infocard-template',
  template: `<ng-template arisDynamicDirective></ng-template>`
})
export class ArisDynamicInfocardComponent implements OnInit, OnDestroy {
  @Input() componentData: any;
  @ViewChild(DynamicComponentDirective) arisDynamicDirective: DynamicComponentDirective;
  subscription: any;
  interval: any;
  reloadSubscription: any;

  constructor(private componentFactoryResolver: ComponentFactoryResolver,
    private arisGeoInfoCardCommonService: ArisGeoInfoCardCommonService) {
  }

  ngOnInit() {
    this.reloadSubscription = this.arisGeoInfoCardCommonService.componentReload.subscribe((data) => {
      this.loadComponent();
    });
    this.loadComponent();
  }

  ngOnDestroy() {
    if (this.reloadSubscription) {
      this.reloadSubscription.unsubscribe();
    }
  }

  loadComponent() {
    let componentFactory = this.componentFactoryResolver.resolveComponentFactory(this.componentData.component);

    let viewContainerRef = this.arisDynamicDirective.viewContainerRef;
    viewContainerRef.clear();

    let componentRef = viewContainerRef.createComponent(componentFactory);
    (<ArisInfoCardDataComponent>componentRef.instance).infocardData = this.componentData.data;
  }
}
