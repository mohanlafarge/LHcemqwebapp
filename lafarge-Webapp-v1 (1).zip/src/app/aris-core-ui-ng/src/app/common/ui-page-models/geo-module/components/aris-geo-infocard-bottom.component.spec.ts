import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import 'rxjs/add/observable/of';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
import { ArisModule } from '../../../../aris.module';
import { ArisGeoInfoCardCommonService } from '../services/aris-geo-infocard-common.service';
import { LocalizationModule, TranslationService } from 'angular-l10n';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { ArisGeoInfocardBottomComponent } from './aris-geo-infocard-bottom.component';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoService } from '../services/aris-geo.service';

describe('Component: ArisGeoInfocardBottomComponent', () => {

  let component: ArisGeoInfocardBottomComponent;
  let fixture: ComponentFixture<ArisGeoInfocardBottomComponent>;
  let infoCardElement: DebugElement;
  let infoCardElement2: DebugElement;
  let mockData = {
    mapLayer: {
      id: "workOrders",
      name: "MAPLAYER_WORK_ORDERS",
      type: "cluster",
      hasFilter: true,
      hasLegend: true
    },
    bottomSection: {
      tables: [
        {
          header: "Work Order Details",
          rows: [
            {
              title: "Postcode:",
              value: "92078"
            },
            {
              title: "DMA:",
              value: "KB10"
            }
          ],
          headerTextColor: "rgb(255, 165, 0)"
        }
      ]
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisGeoInfocardBottomComponent],
      schemas: [],
      imports: [ArisPipesModule, LocalizationModule, ArisModule],
      providers: [ArisGeoService,ArisGeoInfoCardService, ArisGeoInfocardBottomComponent, HttpClient, HttpHandler, TranslationService, ArisGeoInfoCardCommonService]
    }).compileComponents();
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(ArisGeoInfocardBottomComponent);
    // get test component from the fixture
    component = fixture.componentInstance;
    component.infocardData = mockData;
  });

  it('test : ArisGeoInfocardBottomComponent should be created', () => {
    expect(component).toBeTruthy();
  });

  it('test: ngOnInit method checking ', () => {
    component.ngOnInit();
    expect(component.bottomSection.tables[0].header).toBe("Work Order Details");
    expect(component.bottomSection.tables[0].rows[1].value).toBe("KB10");
    expect(component.mapLayer.id).toBe("workOrders");
    expect(component.mapLayer.type).toBe("cluster");
  });
});