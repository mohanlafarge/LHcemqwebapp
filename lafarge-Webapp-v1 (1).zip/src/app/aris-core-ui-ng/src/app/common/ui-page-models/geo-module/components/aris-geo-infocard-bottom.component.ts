import { Component, Input, OnInit } from '@angular/core';
import { ArisInfoCardDataComponent } from './aris-infocard-data.component';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';

@Component({
  selector: 'aris-infocard-bottom',
  templateUrl: './aris-geo-infocard-bottom.component.html'
})
export class ArisGeoInfocardBottomComponent implements OnInit , ArisInfoCardDataComponent {
  @Input() infocardData: any;
  bottomSection: any = {};
  mapLayer: any;

  constructor(private arisGeoInfoCardService: ArisGeoInfoCardService) {}

  ngOnInit() {
    // this.bottomSection = this.arisGeoInfoCardService.getBottomSection();
    this.bottomSection = this.infocardData.bottomSection;
    this.mapLayer = this.infocardData.mapLayer;
  }
}


