import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DebugElement, ApplicationRef, Injector } from '@angular/core';
import 'rxjs/add/observable/of';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
import { ArisModule } from '../../../../aris.module';
import { ArisGeoInfoCardCommonService } from '../services/aris-geo-infocard-common.service';
import { LocalizationModule, TranslationService } from 'angular-l10n';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoService } from '../services/aris-geo.service';
import { ArisDynamicInfocardComponent } from './aris-dynamic-infocard.component';
import { ArisLanguageService } from '../../../ui-page-sections/language-selector-module/services/aris-language.service';
import { ArisConfigService } from '../../../services/aris-config.service';
import { ArisGeoInfocardComponent } from './aris-geo-infocard-main.component';
import { ChartModule } from '../../../ui-components/chart-module/aris-chart.module';
import { ArisGeoModule } from '../aris-geo.module';
import { ArisGeoInfocardBottomComponent } from './aris-geo-infocard-bottom.component';
import { ArisInfocardCommonBottomComponent } from './aris-geo-infocard-common-bottom.component';

describe('Component: ArisInfocardCommonBottomComponent', () => {

  let component: ArisInfocardCommonBottomComponent;
  let fixture: ComponentFixture<ArisInfocardCommonBottomComponent>;
  let infoCardElement: DebugElement;
  let infoCardElement2: DebugElement;
  let applicationRef: ApplicationRef;
  let handler: HttpHandler;
  let http = new HttpClient(handler);
  let  arisLanguageService: ArisLanguageService = new ArisLanguageService();
  let arisConfigService: ArisConfigService = new ArisConfigService(http, arisLanguageService);
  let injector: Injector;
  let arisGeoService = new ArisGeoService(arisConfigService, injector);
  // let arisGeoInfoCardService = new ArisGeoInfoCardService(arisGeoService, applicationRef);
  let mockData = {
	mapLayer: {
		id: "monitoredSewerFacilitySummary",
		name: "MAPLAYER_MONITORED_SEWER_FACILITY_SUMMARY",
        type: "marker",
        bottomSectionComponent: ArisGeoInfocardComponent
	},
	header: { title: "SSOM 8313 Amber Trail" },
	topSection: {},
	middleSection: {},
	bottomSection: {}
};
let mockData2 = {
	mapLayer: {
		id: "monitoredSewerFacilitySummary",
		name: "MAPLAYER_MONITORED_SEWER_FACILITY_SUMMARY",
        type: "marker"
	},
	header: { title: "SSOM 8313 Amber Trail" },
	topSection: {},
	middleSection: {},
	bottomSection: {}
};
let configMockData = {
    arisConfig: [{
      assetAttributeName: 'Map Initial Zoom',
      value: '10',
    }, {
      assetAttributeName: 'Map Initial Latitude',
      value: '33.758199',
    }, {
      assetAttributeName: 'Map Initial Longitude',
      value: '-84.425731',
    }],
  };
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      schemas: [],
      imports: [LocalizationModule, ArisModule, ChartModule, ArisGeoModule],
      providers: [ArisGeoService,ArisGeoInfoCardService, HttpClient, HttpHandler, TranslationService, ArisGeoInfoCardCommonService]
    }).compileComponents();
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(ArisInfocardCommonBottomComponent);
    // get test component from the fixture
    component = fixture.componentInstance;
  });

  it('test : ArisInfocardCommonBottomComponent should be created', () => {
    expect(component).toBeTruthy();
  });

  it('test: ngOnInit method checking, maplyer override info card  bottomSectionComponent should load ', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    arisGeoInfoCardService.infocard = mockData;
    const asrisGeoService = TestBed.get(ArisGeoService);
    const arisConfigService = TestBed.get(ArisConfigService);
    arisConfigService.setArisConfig(configMockData.arisConfig);
    asrisGeoService.setProperties();
    component.ngOnInit();
    expect(component.componentData.component).toEqual(ArisGeoInfocardComponent);
  });

  it('test: ngOnInit method checking, maplyer default info card bottomSectionComponent should load ', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    arisGeoInfoCardService.infocard = mockData2;
    const asrisGeoService = TestBed.get(ArisGeoService);
    const arisConfigService = TestBed.get(ArisConfigService);
    arisConfigService.setArisConfig(configMockData.arisConfig);
    asrisGeoService.setProperties();
    component.ngOnInit();
    expect(component.componentData.component).toEqual(ArisGeoInfocardBottomComponent);
  });
})
