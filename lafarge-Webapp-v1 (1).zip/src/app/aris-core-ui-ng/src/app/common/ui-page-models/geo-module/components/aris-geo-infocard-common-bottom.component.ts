import { Component, OnInit, Input } from '@angular/core';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoService } from '../services/aris-geo.service';

@Component({
  selector: 'aris-infocard-bottom-section',
  template: `<aris-dynamic-infocard-template [componentData]="componentData"></aris-dynamic-infocard-template>`
})
export class ArisInfocardCommonBottomComponent implements OnInit {
  componentData: any = {};
  mapLayer: any;
  layerTypes: any;
  bottomSection: any;

  constructor(private arisGeoInfoCardService: ArisGeoInfoCardService,
              private arisGeoService: ArisGeoService) {
  }

  ngOnInit() {
    this.initializeInfoCardBottomComponent();
  }

  initializeInfoCardBottomComponent() {
    this.mapLayer = this.arisGeoInfoCardService.getMapLayer();
    this.layerTypes = this.arisGeoService.getMapLayersService().getLayerTypes();
    this.bottomSection = this.arisGeoInfoCardService.getBottomSection();
    this.componentData.data = { mapLayer: this.mapLayer, bottomSection: this.bottomSection };

    if (this.mapLayer && this.mapLayer.bottomSectionComponent) {
      this.componentData.component = this.mapLayer.bottomSectionComponent;
    } else if (this.mapLayer && this.mapLayer.type) {
      if (this.layerTypes) {
        this.componentData.component = this.layerTypes[this.mapLayer.type].bottomSectionComponent;
      }
    }
  }
}
