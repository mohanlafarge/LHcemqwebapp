import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoService } from '../services/aris-geo.service';
import { ArisGeoInfoCardCommonService } from '../services/aris-geo-infocard-common.service';
import { ArisGeoInfocardComponent } from './aris-geo-infocard-main.component';

@Component({
  selector: 'aris-infocard-main-section',
  template: `<aris-dynamic-infocard-template [componentData]="componentData"></aris-dynamic-infocard-template>`
})
export class ArisInfocardCommonMainComponent implements OnInit, OnDestroy {
  componentData: any = {};
  mapLayer: any;
  layerTypes: any;
  header: any;
  infoCard: any;
  onInfoCardDataChangeSubscription: any;

  constructor(private arisGeoInfoCardService: ArisGeoInfoCardService,
              private arisGeoService: ArisGeoService,
              private arisGeoInfoCardCommonService: ArisGeoInfoCardCommonService) {
    this.onInfoCardDataChangeSubscription = this.arisGeoInfoCardCommonService.onInfoCardDataChange.subscribe((data) => {
      this.initializeMainInfoCardComponent();
    });
  }

  ngOnInit() {
    this.initializeMainInfoCardComponent();
  }

  ngOnDestroy() {
    if (this.onInfoCardDataChangeSubscription) {
      this.onInfoCardDataChangeSubscription.unsubscribe();
    }
  }

  initializeMainInfoCardComponent() {
    this.mapLayer = this.arisGeoInfoCardService.getMapLayer();
    this.layerTypes = this.arisGeoService.getMapLayersService().getLayerTypes();
    this.header = this.arisGeoInfoCardService.getHeader();
    this.infoCard = this.arisGeoInfoCardService.getInfoCard();
    this.componentData.data = { mapLayer: this.mapLayer, header: this.header, infoCard: this.infoCard };

    if (this.mapLayer && this.mapLayer.mainSectionComponent) {
      this.componentData.component = this.mapLayer.mainSectionComponent;
      this.arisGeoInfoCardCommonService.componentReload.next();
    } else if (this.mapLayer && this.mapLayer.type) {
      if (this.layerTypes) {
        this.componentData.component = this.layerTypes[this.mapLayer.type].mainSectionComponent;
        this.arisGeoInfoCardCommonService.componentReload.next();
      }
    } else {
      this.componentData.component = ArisGeoInfocardComponent;
    }
  }
}
