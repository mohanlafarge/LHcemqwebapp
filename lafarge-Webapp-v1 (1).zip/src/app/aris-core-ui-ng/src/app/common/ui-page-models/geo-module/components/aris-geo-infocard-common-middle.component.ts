import { Component, OnInit, Input } from '@angular/core';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoService } from '../services/aris-geo.service';

@Component({
  selector: 'aris-infocard-middle-section',
  template: `<aris-dynamic-infocard-template [componentData]="componentData"></aris-dynamic-infocard-template>`
})
export class ArisInfocardCommonMiddleComponent implements OnInit {
  componentData: any = {};
  mapLayer: any;
  layerTypes: any;
  middleSection: any;

  constructor(private arisGeoInfoCardService: ArisGeoInfoCardService,
              private arisGeoService: ArisGeoService) {
  }

  ngOnInit() {
    this.initializeInfoCardMiddleComponent();
  }

  initializeInfoCardMiddleComponent() {
    this.mapLayer = this.arisGeoInfoCardService.getMapLayer();
    this.layerTypes = this.arisGeoService.getMapLayersService().getLayerTypes();
    this.middleSection = this.arisGeoInfoCardService.getMiddleSection();
    this.componentData.data = { mapLayer: this.mapLayer, middleSection: this.middleSection };

    if (this.mapLayer && this.mapLayer.middleSectionComponent) {
      this.componentData.component = this.mapLayer.middleSectionComponent;
    } else if (this.mapLayer && this.mapLayer.type) {
      if (this.layerTypes) {
        this.componentData.component = this.layerTypes[this.mapLayer.type].middleSectionComponent;
      }
    }
  }
}
