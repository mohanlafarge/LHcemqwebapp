import { Component, OnInit, Input } from '@angular/core';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoService } from '../services/aris-geo.service';

@Component({
  selector: 'aris-infocard-top-section',
  template: `<aris-dynamic-infocard-template [componentData]="componentData"></aris-dynamic-infocard-template>`
})
export class ArisInfocardCommonTopComponent implements OnInit {
  componentData: any = {};
  mapLayer: any;
  layerTypes: any;
  topSection: any;

  constructor(private arisGeoInfoCardService: ArisGeoInfoCardService,
              private arisGeoService: ArisGeoService) {
  }

  ngOnInit() {
    this.initializeInfoCardTopComponent();
  }

  initializeInfoCardTopComponent() {
    this.mapLayer = this.arisGeoInfoCardService.getMapLayer();
    this.layerTypes = this.arisGeoService.getMapLayersService().getLayerTypes();
    this.topSection = this.arisGeoInfoCardService.getTopSection();
    this.componentData.data = { mapLayer: this.mapLayer, topSection: this.topSection };

    if (this.mapLayer && this.mapLayer.topSectionComponent) {
      this.componentData.component = this.mapLayer.topSectionComponent;
    } else if (this.mapLayer && this.mapLayer.type) {
      if (this.layerTypes) {
        this.componentData.component = this.layerTypes[this.mapLayer.type].topSectionComponent;
      }
    }
  }
}
