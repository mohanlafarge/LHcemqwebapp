import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import 'rxjs/add/observable/of';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
import { ArisModule } from '../../../../aris.module';
import { ArisGeoInfoCardCommonService } from '../services/aris-geo-infocard-common.service';
import { LocalizationModule, TranslationService } from 'angular-l10n';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoService } from '../services/aris-geo.service';
import { ArisGeoInfocardComponent } from './aris-geo-infocard-main.component';
import { ChartModule } from '../../../ui-components/chart-module/aris-chart.module';
import { ArisGeoModule } from '../aris-geo.module';

describe('Component: ArisGeoInfocardComponent', () => {

  let component: ArisGeoInfocardComponent;
  let fixture: ComponentFixture<ArisGeoInfocardComponent>;
  let infoCardElement: DebugElement;
  let infoCardElement2: DebugElement;
  let mockData = { infoCard: {
	mapLayer: {
		id: "monitoredSewerFacilitySummary",
		name: "MAPLAYER_MONITORED_SEWER_FACILITY_SUMMARY",
		type: "marker"
	},
	header: {
		title: "SSOM 8313 Amber Trail",
		fillPerc: 24.79946667,
		value: "",
		fillColor: "#008000"
	},
	topSection: {
		alert: "",
		alertBgColor: "",
		tables: [{
			header: "",
			rows: [{
					title: "MONITOR TYPE",
					value: "Flow an WQ Monitor"
				},
				{
					title: "Pipe Diameter  (meters)",
					value: "18.00"
				}
			]
		}],
		headers: [{
			title: "CURRENT STATE",
			value: "GREEN",
			dtv: 1444149000000,
			valueTextColor: "green"
		}]
	},
	middleSection: {
		tabs: [{
				id: "level",
				text: "Level (meters)",
				chartParams: {
					xAxisAttribute: "dtvLevel",
					yAxisAttribute: "level",
					chartType: "lineChart",
					chartTitle: "Level (meters)"
				}
			},
			{
				id: "velocity",
				text: "Velocity (metres per second (m/s))",
				chartParams: {
					xAxisAttribute: "dtvVelocity",
					yAxisAttribute: "velocity",
					chartType: "lineChart",
					chartTitle: "Velocity (metres per second (m/s))"
				}
			}
		],
		chartData: null,
		longTextFields: [],
		currentDropdownvalue: "",
		currentChartParams: {
			xAxisAttribute: "dtvLevel",
			yAxisAttribute: "level",
			chartType: "lineChart",
			chartTitle: "Level (meters)"
		},
		markerId: "SSOM 8313 Amber Trail",
		currentTimeDurationRange: "6",
		currentTab: "Level (meters)"
	},
	bottomSection: {
		tables: [{
			header: "Site Details",
			rows: [{
					title: "Asset Reference"
				},
				{
					title: "Nearest weather station",
					value: ""
				}
			],
			headerTextColor: "rgb(255, 165, 0)"
		}]
	}
  },
  header: {
    title: "SSOM 8313 Amber Trail",
    fillPerc: 24.79946667,
    value: "",
    fillColor: "#008000"
  }     
};

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      schemas: [],
      imports: [ArisPipesModule, LocalizationModule, ArisModule, ChartModule, ArisGeoModule],
      providers: [ArisGeoService,ArisGeoInfoCardService, HttpClient, HttpHandler, TranslationService, ArisGeoInfoCardCommonService]
    }).compileComponents();
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(ArisGeoInfocardComponent);
    // get test component from the fixture
    component = fixture.componentInstance;
    component.infocardData = mockData;
    component.ngOnInit();
  });

  it('test : ArisGeoInfocardComponent should be created', () => {
    expect(component).toBeTruthy();
  });

  it('test: ngOnInit method checking ', () => {
    expect(component.infoCard.mapLayer.id).toBe("monitoredSewerFacilitySummary");
    expect(component.infoCard.topSection.tables[0].rows[0].title).toBe("MONITOR TYPE");
  });

  it('test: liqFIlledAvaialable method checking ture case ', () => {
    expect(component.liqFIlledAvaialable()).toBe(true);
  });

  it('test: liqFIlledAvaialable method checking flase case ', () => {
    component.header.fillPerc = undefined;
    component.header.value = undefined;
    expect(component.liqFIlledAvaialable()).toBe(false);
  });
});
