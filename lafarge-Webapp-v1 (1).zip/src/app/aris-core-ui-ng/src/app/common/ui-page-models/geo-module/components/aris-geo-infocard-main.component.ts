import { Component, Input, OnInit } from '@angular/core';
import { ArisInfoCardDataComponent } from './aris-infocard-data.component';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoInfoCardCommonService } from '../services/aris-geo-infocard-common.service';

@Component({
  selector: 'aris-geo-infocard',
  templateUrl: './aris-geo-infocard-main.component.html'
})
export class ArisGeoInfocardComponent implements OnInit, ArisInfoCardDataComponent {
  @Input() infocardData: any;
  header: any = {};
  infoCard: any = {};
  showInfoCard: any;
  constructor(private arisGeoInfoCardService: ArisGeoInfoCardService, private arisGeoInfoCardCommonService: ArisGeoInfoCardCommonService) {
    this.showInfoCard = true;
  }
  ngOnInit() {
    this.infoCard = this.infocardData.infoCard;
    this.header = this.infocardData.header;
    this.liqFIlledAvaialable();
  }

  closeInfoTable() {
    // scope.$broadcast("brushOff");
    this.arisGeoInfoCardCommonService.closeInfoCard.next();
    this.arisGeoInfoCardService.clear();
  }

  liqFIlledAvaialable(): boolean {
    let liqFilled = false;
    if (this.header.fillPerc >= 0 || this.header.value) {
      liqFilled = true;
    }
    return liqFilled;
  }
}
