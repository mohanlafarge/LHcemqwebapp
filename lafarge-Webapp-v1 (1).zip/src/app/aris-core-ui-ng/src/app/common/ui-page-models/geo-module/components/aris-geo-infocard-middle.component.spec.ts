import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import 'rxjs/add/observable/of';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
import { ArisModule } from '../../../../aris.module';
import { ArisGeoInfoCardCommonService } from '../services/aris-geo-infocard-common.service';
import { LocalizationModule, TranslationService } from 'angular-l10n';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoService } from '../services/aris-geo.service';
import { ArisGeoInfocardMiddleComponent } from './aris-geo-infocard-middle.component';
import { ChartModule } from '../../../ui-components/chart-module/aris-chart.module';
import { FormsModule } from '@angular/forms';
import { ArisUiComponentsModule } from '../../../ui-components/aris-ui-components.module';
import { Observable } from 'rxjs';

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};
describe('Component: ArisGeoInfocardMiddleComponent', () => {

  let component: ArisGeoInfocardMiddleComponent;
  let fixture: ComponentFixture<ArisGeoInfocardMiddleComponent>;
  let infoCardElement: DebugElement;
  let infoCardElement2: DebugElement;
  let arisGeoInfoCardCommonService: ArisGeoInfoCardCommonService;
  let mockData = {
    mapLayer: {
      id: "monitoredSewerFacilitySummary",
      name: "MAPLAYER_MONITORED_SEWER_FACILITY_SUMMARY",
      type: "marker"
    },
    middleSection: {
      tabs: [{
        id: "level",
        text: "Level (meters)",
        chartParams: {
          xAxisAttribute: "dtvLevel",
          yAxisAttribute: "level",
          chartType: "lineChart",
          chartTitle: "Level (meters)"
        }
      },
        {
          id: "velocity",
          text: "Velocity (metres per second (m/s))",
          chartParams: {
            xAxisAttribute: "dtvVelocity",
            yAxisAttribute: "velocity",
            chartType: "lineChart",
            chartTitle: "Velocity (metres per second (m/s))"
          }
        }
      ],
      chartData: null,
      longTextFields: [],
      currentDropdownvalue: "",
      currentChartParams: {
        xAxisAttribute: "dtvLevel",
        yAxisAttribute: "level",
        chartType: "lineChart",
        chartTitle: "Level (meters)"
      },
      markerId: "SSOM 8313 Amber Trail",
      currentTimeDurationRange: "6",
      currentTab: "Level (meters)"
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisGeoInfocardMiddleComponent],
      schemas: [],
      imports: [ArisPipesModule, LocalizationModule, ArisModule, ChartModule, FormsModule, ArisUiComponentsModule],
      providers: [ArisGeoService, ArisGeoInfoCardService, ArisGeoInfocardMiddleComponent, HttpClient, HttpHandler, { provide: TranslationService, useValue: mockTranslationService }, ArisGeoInfoCardCommonService]
    }).compileComponents();
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(ArisGeoInfocardMiddleComponent);
    arisGeoInfoCardCommonService = fixture.debugElement.injector.get(ArisGeoInfoCardCommonService);
    // get test component from the fixture
    component = fixture.componentInstance;
    component.infocardData = mockData;
    component.ngOnInit();
  });

  it('test : ArisGeoInfocardMiddleComponent should be created', () => {
    expect(component).toBeTruthy();
  });

  it('test: ngOnInit method checking ', () => {
    expect(component.middleSection.tabs[0].id).toBe("level");
    expect(component.middleSection.tabs[1].id).toBe("velocity");
    expect(component.mapLayer.type).toBe("marker");
    expect(component.chartOptions.xAxisAttribute).toBe("dtvLevel");
    expect(component.chartOptions.calc).toBe("sum");
  });

  it('test: refreshChartByTabId method checking ', () => {
    component.refreshChartByTabId('velocity');
    expect(component.chartOptions.xAxisAttribute).toBe("dtvVelocity");
    expect(component.chartOptions.chartTitle).toBe("Velocity (metres per second (m/s))");
  });

  it('test: onTabClick method checking ', () => {
    component.onTabClick('level');
    expect(component.chartOptions.yAxisAttribute).toBe("level");
    expect(component.chartOptions.chartTitle).toBe("Level (meters)");
  });

  it('test: onTabChange method checking ', () => {
    let dummyElement: any = { options : [{ id: "velocity" }], selectedIndex: [0] };
    spyOn(document, 'getElementById').and.callFake(() => dummyElement);
    component.onTabChange(dummyElement);
    expect(component.chartOptions.xAxisAttribute).toBe("dtvLevel");
    expect(component.chartOptions.chartTitle).toBe("Level (meters)");
  });

  it('test: openNewTab method checking ', () => {
    component.openNewTab();
    expect(window.location.href.split('#/page/')).toEqual(['http://localhost:9876/context.html']);
  });

  it('test: ngOnChanges method checking ', () => {
    component.ngOnChanges();
    expect(component.middleSection).toBeDefined();
  });

  it('test: ngOnInit method checking ', () => {
    component.infocardData = { middleSection: { currentChartParams: undefined,
      tabs: [{
        id: "level",
        text: "Level (meters)",
        chartParams: {
          xAxisAttribute: "dtvLevel",
          yAxisAttribute: "level",
          chartType: "lineChart",
          chartTitle: "Level (meters)"
        }
      },
      {
        id: "velocity",
        text: "Velocity (metres per second (m/s))",
        chartParams: {
          xAxisAttribute: "dtvVelocity",
          yAxisAttribute: "velocity",
          chartType: "lineChart",
          chartTitle: "Velocity (metres per second (m/s))"
        }
      }
      ], } };
    component.ngOnInit();
    expect(component.infocardData).toBeDefined();
  });

  it('test: refreshChartByTabId method checking ', () => {
    component.refreshChartByTabId('');
    expect(component.infocardData).toBeDefined();
  });

  it('test: onTimeRangeChange method if checking ', () => {
    component.timeRangeData = [{ key: 'GEO_INFOCARD_1DAY', value: '0' },
     { key: 'GEO_INFOCARD_7DAYS', value: 6 },
     { key: 'GEO_INFOCARD_30DAYS', value: 29 },
     { key: 'GEO_INFOCARD_90DAYS' , value: 89 },
     { key: 'GEO_INFOCARD_1YEAR', value: 364 }];
    component.middleSection = { currentTimeDurationRange: 22, markerId: '0' };
    component.mapLayer = { id: 1 };
    spyOn(arisGeoInfoCardCommonService, 'addChartData').and.callFake(() => {});
    component.onTimeRangeChange('GEO_INFOCARD_7DAYS');
    expect(arisGeoInfoCardCommonService.addChartData).toHaveBeenCalled();
    expect(component.middleSection.currentTimeDurationRange).toEqual(6);
  });

  it('test: onTimeRangeChange method else checking ', () => {
    component.timeRangeData = [{ key: 'GEO_INFOCARD_1DAY', value: '0' },
     { key: 'GEO_INFOCARD_7DAYS', value: 6 },
     { key: 'GEO_INFOCARD_30DAYS', value: 29 },
     { key: 'GEO_INFOCARD_90DAYS' , value: 89 },
     { key: 'GEO_INFOCARD_1YEAR', value: 364 }];
    component.middleSection = { currentTimeDurationRange: 22, markerId: '0' };
    component.mapLayer = { id: 1 };
    spyOn(arisGeoInfoCardCommonService, 'addChartData').and.callFake(() => {});
    component.onTimeRangeChange('GEO_INFOCARD');
    expect(arisGeoInfoCardCommonService.addChartData).toHaveBeenCalled();
    expect(component.middleSection.currentTimeDurationRange).toEqual('');
  });

  it('test: onTabChange method if checking ', () => {
    let dummyElement: any = { options : [{ id: "velocity" }], selectedIndex: [0] };
    // component.middleSection = { currentTimeDurationRange: 22, tabs: [{ id: 1, text: 'dtvLevel' }] };
    component.middleSection = { currentChartParams: undefined,
      tabs: [{
        id: "level",
        text: "Level (meters)",
        chartParams: {
          xAxisAttribute: "dtvLevel",
          yAxisAttribute: "level",
          chartType: "lineChart",
          chartTitle: "Level (meters)"
        }
      },
      {
        id: "velocity",
        text: "Velocity (metres per second (m/s))",
        chartParams: {
          xAxisAttribute: "dtvVelocity",
          yAxisAttribute: "velocity",
          chartType: "lineChart",
          chartTitle: "Velocity (metres per second (m/s))"
        }
      }
      ] };
    spyOn(document, 'getElementById').and.callFake(() => dummyElement);
    component.onTabChange('Level (meters)');
    expect(component).toBeTruthy();
  });
});
