import { Component, Input, OnInit, OnChanges } from '@angular/core';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoInfoCardCommonService } from '../services/aris-geo-infocard-common.service';
import { ArisInfoCardDataComponent } from './aris-infocard-data.component';
import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
import { TranslationService } from 'angular-l10n';

declare global {
  interface Window {
    middleSection: any;
    chartType: any;
    pageName: any;
    opener: any;
    header: any;
    mapLayer: any;
    chartOptions: any;
  }
}
@Component({
  selector: 'aris-infocard-middle',
  templateUrl: './aris-geo-infocard-middle.component.html'
})
export class ArisGeoInfocardMiddleComponent implements OnInit, OnChanges, ArisInfoCardDataComponent {
  @Input() infocardData: any;
  middleSection: any;

  timeRangeData = [];
  timeRangeDataValue = [];
  tabChangeDropdown: any = [];
  chartOptions: any;
  mapLayer: any;
  constructor(
    private arisGeoInfoCardService: ArisGeoInfoCardService,
    private arisGeoInfoCardCommonService: ArisGeoInfoCardCommonService,
    private arisChartCommonService: ArisChartCommonService,
    private translationService: TranslationService
  ) {
    this.timeRangeDataValue = [this.translationService.translate('GEO_INFOCARD_1DAY'), this.translationService.translate('GEO_INFOCARD_7DAYS'),
    this.translationService.translate('GEO_INFOCARD_30DAYS'), this.translationService.translate('GEO_INFOCARD_90DAYS'),
    this.translationService.translate('GEO_INFOCARD_1YEAR')];
    this.timeRangeData = [{ key: this.translationService.translate('GEO_INFOCARD_1DAY'), value: '0' },
    { key: this.translationService.translate('GEO_INFOCARD_7DAYS'), value: 6 },
    { key: this.translationService.translate('GEO_INFOCARD_30DAYS'), value: 29 },
    { key: this.translationService.translate('GEO_INFOCARD_90DAYS'), value: 89 },
    { key: this.translationService.translate('GEO_INFOCARD_1YEAR'), value: 364 }];
  }
  ngOnInit() {
    // this.middleSection = this.arisGeoInfoCardService.getMiddleSection();
    // this.mapLayer = this.arisGeoInfoCardService.getMapLayer();
    this.middleSection = this.infocardData.middleSection;
    for (let i = 0; i < this.middleSection.tabs.length; i += 1) {
      this.tabChangeDropdown.push(this.middleSection.tabs[i].text);
    }
    this.mapLayer = this.infocardData.mapLayer;
    if (this.middleSection.currentChartParams) {
      this.chartOptions = {
        xAxisAttribute: this.middleSection.currentChartParams.xAxisAttribute,
        yAxisAttribute: this.middleSection.currentChartParams.yAxisAttribute,
        calc: 'sum',
        showRangeChart: true,
        scale: 'date',
        numXAxisTicks: 3,
        chartTitle: this.middleSection.currentChartParams.chartTitle,
        hideChartTitle: true,
        openWindow: false,
        timeFormatType: "%b %d",
        exportable: 'true',
        yAxisTickLimit: 2
      };
    }
  }

  ngOnChanges() {
    console.log(this.middleSection.chartData);
  }

  // Handle tab click event.
  onTabClick(tabId) {
    console.log("onTabClick:" + tabId);
    this.refreshChartByTabId(tabId);
  }

  findIdOfSelectedtabChangeDropdown(el) {
    let selectedId = '';
    for (let i = 0; i < this.middleSection.tabs.length; i += 1) {
      if (this.middleSection.tabs[i].text === el) {
        selectedId = this.middleSection.tabs[i].id;
      }
    }
    return selectedId;
  }
  onTabChange(el) {
    // let e: any = document.getElementById(el);
    // let tabId = e.options[e.selectedIndex].id;
    let tabId = this.findIdOfSelectedtabChangeDropdown(el);
    this.refreshChartByTabId(tabId);
  }
  // Handle drop down value change event.
  onTimeRangeChange(selectedvalue) {
    // let e: any = document.getElementById(selectedvalue);
    // let selectedTimeRange = e.options[e.selectedIndex].value;
    console.log(selectedvalue);
    let selectedTimeRange = '';
    for (let i = 0; i < this.timeRangeData.length; i += 1) {
      if (this.timeRangeData[i].key === selectedvalue) {
        selectedTimeRange = this.timeRangeData[i].value;
      }
    }
    this.middleSection.currentTimeDurationRange = selectedTimeRange;
    this.arisGeoInfoCardService.getMiddleSection().chartData = null;
    this.arisGeoInfoCardCommonService.addChartData(this.mapLayer.id, this.middleSection.markerId, this.middleSection, selectedTimeRange);
  }
  // Handle line chart open new tab event .
  openNewTab() {
    console.log("newtab");
    if (this.middleSection.currentTimeDurationRange === "6") {
      this.middleSection.currentTimeDurationRange = this.timeRangeDataValue[1];
    }
    window.middleSection = Object.assign({}, this.middleSection);
    window.header = Object.assign({}, this.arisGeoInfoCardService.getHeader());
    window.mapLayer = Object.assign({}, this.arisGeoInfoCardService.getMapLayer());
    window.chartOptions = Object.assign({}, this.chartOptions);
    window.chartType = 'line';
    const path = window.location.href.split('#/page/');
    window.pageName = path[path.length - 1];
    let chartTitle = this.chartOptions.chartTitle.replace(/[^a-zA-Z0-9]/g, '');
    const randomNum = Math.floor(Math.random() * 1000000000);
    let obj = {
      middleSection: window.middleSection, header: window.header, chartOptions: window.chartOptions, chartData: window.chartData,
      mapLayer: window.mapLayer, chartType: window.chartType, pageName: window.pageName
    };

    // Store the object in the localStorage and open the zoomInInfocardChart
    for (let i = 0; i < window.localStorage.length; i += 1) {
      let key = window.localStorage.key(i);
      if (window.localStorage.key(i) !== 'arisLocalConfig' && window.localStorage.key(i) !== 'arisThemeConfig') {
        localStorage.removeItem(key);
      }
    }
    localStorage.setItem('' + chartTitle + randomNum, JSON.stringify(obj));

    window.open('#/zoomInInfocardChart/' + chartTitle + randomNum, '_blank');

    /* Comment the previous lines and Uncomment this if you prefer pass the information as queryparam
       instead store it in the sessionStorage 
    window.open('#/zoomInInfocardChart/data?chartId=' + chartTitle + randomNum + '&chartData=' + JSON.stringify(obj), '_blank');
    */
  }

  refreshChartByTabId(tabId) {
    if (tabId !== '') {
      let tab: any;
      for (let i = 0; i < this.middleSection.tabs.length; i += 1) {
        if (this.middleSection.tabs[i].id === tabId) {
          tab = this.middleSection.tabs[i];
        }
      }
      this.middleSection.currentChartParams = tab.chartParams;
      this.middleSection.currentTab = tab.text;
      this.chartOptions.xAxisAttribute = this.middleSection.currentChartParams.xAxisAttribute;
      this.chartOptions.yAxisAttribute = this.middleSection.currentChartParams.yAxisAttribute;
      this.chartOptions.chartTitle = this.middleSection.currentChartParams.chartTitle;
      this.arisChartCommonService.chartOptionsChange.next();
    }
  }

}



