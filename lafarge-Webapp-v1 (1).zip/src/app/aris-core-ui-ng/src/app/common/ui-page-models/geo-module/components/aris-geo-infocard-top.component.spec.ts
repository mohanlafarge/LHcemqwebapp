import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import 'rxjs/add/observable/of';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
import { ArisModule } from '../../../../aris.module';
import { ArisGeoInfoCardCommonService } from '../services/aris-geo-infocard-common.service';
import { LocalizationModule, TranslationService } from 'angular-l10n';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoService } from '../services/aris-geo.service';
import { ArisGeoInfocardTopComponent } from './aris-geo-infocard-top.component';

describe('Component: ArisGeoInfocardTopComponent', () => {

  let component: ArisGeoInfocardTopComponent;
  let fixture: ComponentFixture<ArisGeoInfocardTopComponent>;
  let infoCardElement: DebugElement;
  let infoCardElement2: DebugElement;
  let mockData = {
    mapLayer: {
		id: "monitoredSewerFacilitySummary",
		name: "MAPLAYER_MONITORED_SEWER_FACILITY_SUMMARY",
		type: "marker"
	},
	header: {
		title: "SSOM 8313 Amber Trail",
		fillPerc: 24.79946667,
		value: "",
		fillColor: "#008000"
	},
	topSection: {
		alert: "",
		alertBgColor: "",
		tables: [{
			header: "",
			rows: [{
					title: "MONITOR TYPE",
					value: "Flow an WQ Monitor"
				},
				{
					title: "Pipe Diameter  (meters)",
					value: "18.00"
				}
			]
		}],
		headers: [{
			title: "CURRENT STATE",
			value: "GREEN",
			dtv: 1444149000000,
			valueTextColor: "green"
		}]
	}
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisGeoInfocardTopComponent],
      schemas: [],
      imports: [ArisPipesModule, LocalizationModule, ArisModule],
      providers: [ArisGeoService,ArisGeoInfoCardService, ArisGeoInfocardTopComponent, HttpClient, HttpHandler, TranslationService, ArisGeoInfoCardCommonService]
    }).compileComponents();
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(ArisGeoInfocardTopComponent);
    // get test component from the fixture
    component = fixture.componentInstance;
    component.infocardData = mockData;
  });

  it('test : ArisGeoInfocardTopComponent should be created', () => {
    expect(component).toBeTruthy();
  });

  it('test: ngOnInit method checking ', () => {
    component.ngOnInit();
    expect(component.topSection.headers[0].title).toBe("CURRENT STATE");
    expect(component.mapLayer.id).toBe("monitoredSewerFacilitySummary");
    expect(component.mapLayer.type).toBe("marker");
  });
});