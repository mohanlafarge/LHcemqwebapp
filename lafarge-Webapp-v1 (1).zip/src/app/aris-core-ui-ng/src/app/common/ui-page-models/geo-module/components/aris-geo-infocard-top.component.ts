import { Component, Input, OnInit } from '@angular/core';
import { ArisInfoCardDataComponent } from './aris-infocard-data.component';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';

@Component({
  selector: 'aris-infocard-top',
  templateUrl: './aris-geo-infocard-top.component.html'
})
export class ArisGeoInfocardTopComponent implements OnInit, ArisInfoCardDataComponent {
  @Input() infocardData: any;
  topSection: any = {};
  mapLayer: any;
  constructor(private arisGeoInfoCardService: ArisGeoInfoCardService) {}
  ngOnInit() {
    this.topSection = this.infocardData.topSection;
    this.mapLayer = this.infocardData.mapLayer;
  }
}
