import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DebugElement, Injector, EventEmitter } from '@angular/core';
import 'rxjs/add/observable/of';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
import { ArisModule } from '../../../../aris.module';
import { ArisGeoInfoCardCommonService } from '../services/aris-geo-infocard-common.service';
import { LocalizationModule, TranslationService } from 'angular-l10n';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoService } from '../services/aris-geo.service';
import { ArisGeoMaplayerCommonLegendComponent } from './aris-geo-maplayer-common-legend.component';
import { ArisDynamicInfocardComponent } from './aris-dynamic-infocard.component';
import { ChartModule } from '../../../ui-components/chart-module/aris-chart.module';
import { FormsModule } from '@angular/forms';
import { Subscription } from 'rxjs';

describe('Component: ArisGeoMaplayerCommonLegendComponent', () => {

  let component: ArisGeoMaplayerCommonLegendComponent;
  let fixture: ComponentFixture<ArisGeoMaplayerCommonLegendComponent>;
  let infoCardElement: DebugElement;
  let infoCardElement2: DebugElement;
  let arisGeoService: ArisGeoService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisGeoMaplayerCommonLegendComponent, ArisDynamicInfocardComponent],
      schemas: [],
      imports: [ArisPipesModule, LocalizationModule, ArisModule, ChartModule, FormsModule],
      providers: [ArisGeoService, ArisGeoInfoCardService, ArisGeoMaplayerCommonLegendComponent, HttpClient, HttpHandler, TranslationService, ArisGeoInfoCardCommonService,
        Injector]
    }).compileComponents();
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(ArisGeoMaplayerCommonLegendComponent);
    // get test component from the fixture
    arisGeoService = TestBed.get(ArisGeoService);
    component = fixture.componentInstance;
  });

  it('test : ArisGeoMaplayerCommonLegendComponent should be created', () => {
    component.showLegendSubscription = undefined;
    component.ngOnDestroy();
    expect(component).toBeTruthy();
  });

  it('test : ngOnDestroy executed', () => {
    component.showLegendSubscription = new Subscription();
    component.ngOnDestroy();
    expect(component).toBeTruthy();
  });

  it('test : ngOnInit executed', () => {
    let data = { getLayerTypes() {} };
    component.showLegendSubscription = new Subscription();
    spyOn(arisGeoService, 'getMapLayersService').and.returnValue(data);
    spyOn(arisGeoService.getMapLayersService(), 'getLayerTypes').and.returnValue('data');
    component.ngOnInit();
    expect(arisGeoService.getMapLayersService).toHaveBeenCalled();
  });

  it('test : initializeMainInfoCardComponent executed', () => {
    let data = { getLayerTypes() {} };
    let mapLayerData = { legendTemplateComponent: 'val' };
    component.showLegendSubscription = new Subscription();
    component.componentData = { component: 'val' };
    spyOn(arisGeoService, 'getMapLayersService').and.returnValue(data);
    spyOn(arisGeoService.getMapLayersService(), 'getLayerTypes').and.returnValue('data');
    component.initializeMainInfoCardComponent(mapLayerData);
    expect(arisGeoService.getMapLayersService).toHaveBeenCalled();
  });

});
