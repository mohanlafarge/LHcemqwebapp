import { Component, OnInit, Input, OnDestroy, Injector } from '@angular/core';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoService } from '../services/aris-geo.service';
import { ArisGeoInfoCardCommonService } from '../services/aris-geo-infocard-common.service';
import { ArisGeoInfocardComponent } from './aris-geo-infocard-main.component';
import { Subscription } from 'rxjs';
import { ArisGeoMaplayerLegendComponent } from './aris-geo-maplayer-legend.component';


@Component({
  selector: 'aris-geo-maplayer-legend',
  template: `<aris-dynamic-infocard-template [componentData]="componentData"></aris-dynamic-infocard-template>`
})
export class ArisGeoMaplayerCommonLegendComponent implements OnInit, OnDestroy {
  componentData: any = {};
  mapLayer: any;
  layerTypes: any;
  legends: any;
  showLegendSubscription: Subscription;

  constructor(private arisGeoInfoCardService: ArisGeoInfoCardService,
              private arisGeoService: ArisGeoService,
              private arisGeoInfoCardCommonService: ArisGeoInfoCardCommonService,
              private injector: Injector
            ) {
    this.showLegendSubscription =  this.arisGeoService.showLegend.subscribe((mapLayerData) => {
      this.initializeMainInfoCardComponent(mapLayerData);
    });
  }

  ngOnInit() {
    this.legends = [];
    this.initializeMainInfoCardComponent(this.mapLayer);
  }

  ngOnDestroy() {
    if (this.showLegendSubscription) {
      this.showLegendSubscription.unsubscribe();
    }
  }

  initializeMainInfoCardComponent(mapLayerData) {
    let layerService: any;
    this.mapLayer = mapLayerData;
    this.layerTypes = this.arisGeoService.getMapLayersService().getLayerTypes();
    if (this.mapLayer && this.mapLayer.type) {
        layerService = this.injector.get(this.layerTypes[this.mapLayer.type].service);
      }

    if (layerService) {
    this.legends = layerService.getLegends ? layerService.getLegends() : [];
    }

    this.componentData.data = { mapLayer: this.mapLayer, legends: this.legends };

    if (this.mapLayer && this.mapLayer.legendTemplateComponent) {
      this.componentData.component = this.mapLayer.legendTemplateComponent;
      this.arisGeoInfoCardCommonService.componentReload.next();
    } else if (this.mapLayer && this.mapLayer.type) {
      if (this.layerTypes) {
        this.componentData.component = this.layerTypes[this.mapLayer.type].legendTemplateComponent;
        this.arisGeoInfoCardCommonService.componentReload.next();
      }
    } else {
      this.componentData.component = ArisGeoMaplayerLegendComponent;
    }
  }
}