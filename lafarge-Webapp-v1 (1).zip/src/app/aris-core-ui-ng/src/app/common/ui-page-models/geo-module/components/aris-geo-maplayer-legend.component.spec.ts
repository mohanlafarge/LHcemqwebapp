import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DebugElement, Injector } from '@angular/core';
import 'rxjs/add/observable/of';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
import { ArisModule } from '../../../../aris.module';
import { ArisGeoInfoCardCommonService } from '../services/aris-geo-infocard-common.service';
import { LocalizationModule, TranslationService } from 'angular-l10n';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoService } from '../services/aris-geo.service';
import { ArisGeoMaplayerLegendComponent } from './aris-geo-maplayer-legend.component';
import { ChartModule } from '../../../ui-components/chart-module/aris-chart.module';
import { FormsModule } from '@angular/forms';

describe('Component: ArisGeoMaplayerLegendComponent', () => {

  let component: ArisGeoMaplayerLegendComponent;
  let fixture: ComponentFixture<ArisGeoMaplayerLegendComponent>;
  let infoCardElement: DebugElement;
  let infoCardElement2: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisGeoMaplayerLegendComponent],
      schemas: [],
      imports: [ArisPipesModule, LocalizationModule, ArisModule, ChartModule, FormsModule],
      providers: [ArisGeoService, ArisGeoInfoCardService, ArisGeoMaplayerLegendComponent, HttpClient, HttpHandler, TranslationService, ArisGeoInfoCardCommonService,
        Injector]
    }).compileComponents();
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(ArisGeoMaplayerLegendComponent);
    // get test component from the fixture
    component = fixture.componentInstance;
    component.infocardData = { legends: 'legend' };
    component.ngOnInit();
  });

  it('test : ArisGeoMaplayerLegendComponent should be created', () => {
    expect(component).toBeTruthy();
  });
});
