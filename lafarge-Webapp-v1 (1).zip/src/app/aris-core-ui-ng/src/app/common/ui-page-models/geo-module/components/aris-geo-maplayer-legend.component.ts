import { Component, Input, OnInit, Injector, OnChanges, OnDestroy } from '@angular/core';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoService } from '../services/aris-geo.service';
import { Language } from 'angular-l10n';
import { ArisInfoCardDataComponent } from './aris-infocard-data.component';

@Component({
  selector: 'aris-maplayer-legend',
  templateUrl: './aris-geo-maplayer-legend.component.html'
})
export class ArisGeoMaplayerLegendComponent implements OnInit, ArisInfoCardDataComponent  {
  @Input() infocardData: any;
  legends: any;

  @Input() mapLayer: any;
  @Language() lang: string;
  showLegendSubscription: any;

  constructor(private arisGeoService: ArisGeoService, private injector: Injector) {
    this.legends = [];
  }

  ngOnInit() {
    this.legends = this.infocardData.legends;
  }
}
