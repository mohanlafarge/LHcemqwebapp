import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DebugElement, Injector, EventEmitter } from '@angular/core';
import 'rxjs/add/observable/of';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
import { ArisModule } from '../../../../aris.module';
import { ArisGeoInfoCardCommonService } from '../services/aris-geo-infocard-common.service';
import { LocalizationModule, TranslationService } from 'angular-l10n';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';
import { ArisGeoService } from '../services/aris-geo.service';
import { ArisGeoMapLayerComponent } from './aris-geo-maplayer.component';
import { ChartModule } from '../../../ui-components/chart-module/aris-chart.module';
import { FormsModule } from '@angular/forms';

describe('Component: ArisGeoMapLayerComponent', () => {

  let component: ArisGeoMapLayerComponent;
  let fixture: ComponentFixture<ArisGeoMapLayerComponent>;
  let infoCardElement: DebugElement;
  let infoCardElement2: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisGeoMapLayerComponent],
      schemas: [],
      imports: [ArisPipesModule, LocalizationModule, ArisModule, ChartModule, FormsModule],
      providers: [ArisGeoService, ArisGeoInfoCardService, ArisGeoMapLayerComponent, HttpClient, HttpHandler, TranslationService, ArisGeoInfoCardCommonService,
        Injector]
    }).compileComponents();
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(ArisGeoMapLayerComponent);
    // get test component from the fixture
    component = fixture.componentInstance;
  });

  it('test : ArisGeoMapLayerComponent should be created', () => {
    expect(component).toBeTruthy();
  });

  it('test : onMapLayerClick executed', () => {
    let id = { id: 'id' };
    let event = { target: { id: 'id', checked: true } };
    component.mapLayerArray = [id];
    component.onMapLayerClicked = new EventEmitter<any>();
    component.onMapLayerClick(event);
    expect(component.onMapLayerClicked).toBeTruthy();
  });

  it('test : onMapLayerClick else executed', () => {
    let id = { id: 'id' };
    let event = { target: { id: 'id1', checked: true } };
    component.mapLayerArray = [id];
    component.onMapLayerClicked = new EventEmitter<any>();
    component.onMapLayerClick(event);
    expect(component.onMapLayerClicked).toBeTruthy();
  });

  it('test : onFilterClick executed', () => {
    let id = { id: 'id' };
    component.mapLayerArray = [id];
    component.onShowFilterByLayer = new EventEmitter<any>();
    component.onFilterClick('id');
    expect(component.onShowFilterByLayer).toBeTruthy();
  });

  it('test : onFilterClick else executed', () => {
    let id = { id: 'id' };
    component.mapLayerArray = [id];
    component.onShowFilterByLayer = new EventEmitter<any>();
    component.onFilterClick('id1');
    expect(component.onShowFilterByLayer).toBeTruthy();
  });
});
