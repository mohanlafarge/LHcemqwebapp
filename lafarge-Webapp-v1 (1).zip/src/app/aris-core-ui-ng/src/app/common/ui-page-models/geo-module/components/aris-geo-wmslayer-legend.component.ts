import { Component, Input, OnInit } from '@angular/core';
import { ArisGeoInfoCardService } from '../services/aris-geo-infocard.service';

@Component({
  selector: 'aris-geo-wmslayer-legend',
  templateUrl: './aris-geo-wmslayer-legend.component.html'
})
export class ArisGeoWmslayerLegendComponent {

}
