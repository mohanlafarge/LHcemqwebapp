export interface ArisInfoCardDataComponent {
  infocardData: any;
}
