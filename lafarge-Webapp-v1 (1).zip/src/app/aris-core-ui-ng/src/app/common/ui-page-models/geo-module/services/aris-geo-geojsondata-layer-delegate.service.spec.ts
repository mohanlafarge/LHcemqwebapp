import { TestBed } from '@angular/core/testing';

import { HttpClient, HttpHandler } from '@angular/common/http';
import { TranslationService, InjectorRef, TRANSLATION_CONFIG, LocaleService, LOCALE_CONFIG, LocaleStorage, TranslationProvider, TranslationHandler } from 'angular-l10n';
import { ArisPermissionPipe } from '../../../pipes/aris-permission.pipes';
import { Injector, ApplicationRef } from '@angular/core';
import { access } from 'fs';
import { ArisDataSourceService } from '../../../services/aris-datasource.service';
import { ArisGeoInfoCardService } from './aris-geo-infocard.service';
import { ArisGeoService } from './aris-geo.service';
import { ArisPageRefreshService } from '../../../services/aris-page-refresh.service';
import { LowerCasePipe } from '@angular/common';
import { ArisGeoInfoCardCommonService } from './aris-geo-infocard-common.service';
import { ArisLanguageService } from '../../../ui-page-sections/language-selector-module/services/aris-language.service';
import { ArisGeoGeoJsonDataLayerDelegateService } from './aris-geo-geojsondata-layer-delegate.service';
import { ArisConfigService } from '../../../../../../public_api';

describe('ArisGeoGeoJsonDataLayerDelegateService', () => {

  let arisDataSourceService: ArisDataSourceService;
  let arisGeoInfoCardService: ArisGeoInfoCardService;
  let arisGeoService: ArisGeoService;
  let arisPageRefreshService: ArisPageRefreshService;
  let http: HttpClient;
  let lowerCasePipe: LowerCasePipe;
  let translationService: TranslationService;
  let applicationRef: ApplicationRef;
  let arisGeoInfoCardCommonService: ArisGeoInfoCardCommonService;
  let arisLanguageService: ArisLanguageService;
  let arisGeoGeoJsonDataLayerDelegateService: ArisGeoGeoJsonDataLayerDelegateService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      schemas: [],
      imports: [],
      providers: [InjectorRef, Injector, ArisGeoService, ArisGeoInfoCardService, ArisGeoInfoCardCommonService,
        HttpClient, HttpHandler, ArisLanguageService, ArisPageRefreshService,
        TranslationService, ArisPermissionPipe, ArisDataSourceService,
        ArisGeoInfoCardService, ArisGeoGeoJsonDataLayerDelegateService,
        ArisGeoService,
        ArisPageRefreshService,
        HttpClient,
        LowerCasePipe,
        TranslationService,
        ApplicationRef,
        ArisGeoInfoCardCommonService,
        ArisLanguageService, ArisConfigService
        ,  {
          provide: TRANSLATION_CONFIG,
          useValue: null
        }, LocaleService, {
          provide: LOCALE_CONFIG,
          useValue: null
        }, LocaleStorage, TranslationProvider, TranslationHandler, ArisDataSourceService]
      // providers: [TranslatePipe, ArisGeoService, ArisGeoInfoCardService,
      //   ArisGeoInfoCardCommonService, ArisConfigService, HttpClient, HttpHandler,
      //   ArisLanguageService, ArisFooterService, ArisPageRefreshService, TranslationService]
    }).compileComponents();
    lowerCasePipe = new LowerCasePipe();
    arisLanguageService = new ArisLanguageService();
    arisGeoInfoCardCommonService = new ArisGeoInfoCardCommonService(arisPageRefreshService, http, applicationRef);
    arisGeoGeoJsonDataLayerDelegateService = new ArisGeoGeoJsonDataLayerDelegateService(arisGeoService, arisDataSourceService,
        arisGeoInfoCardService);
  });

  afterEach(() => {
    arisGeoGeoJsonDataLayerDelegateService = null;
  });

  it('ArisGeoGeoJsonDataLayerDelegateService object should be created', () => {
    expect(arisGeoGeoJsonDataLayerDelegateService).toBeTruthy();
  });

  it('Function closeToolTip should perform expected function', () => {
    arisGeoGeoJsonDataLayerDelegateService.objectScope.tooltipWindow = {};
    arisGeoGeoJsonDataLayerDelegateService.objectScope.tooltipWindow.close = function () {};
    arisGeoGeoJsonDataLayerDelegateService.closeToolTip();
    expect(arisGeoGeoJsonDataLayerDelegateService.objectScope.tooltipWindow).toEqual(null);
  });

  it('Function setObjectScope should perform expected function', () => {
    arisGeoGeoJsonDataLayerDelegateService.setObjectScope(arisGeoGeoJsonDataLayerDelegateService);
    expect(arisGeoGeoJsonDataLayerDelegateService.objectScope.tooltipWindow).toEqual(null);
    expect(arisGeoGeoJsonDataLayerDelegateService.objectScope.featuresArray).toEqual([]);
  });

  it('Function displayLayerOverlaysOnMap executed', () => {
    let arisGeoGeoJsonDataLayerDelegateService1 = TestBed.get(ArisGeoGeoJsonDataLayerDelegateService);
    let arisDataSourceService1 = TestBed.get(ArisDataSourceService);
    let mapLayer = { id: 1, type: 'geo', getGeoJsonPromise: undefined };
    let map = { data: { setStyle() { }, addListener() {} } };
    let mapBounds = {};
    let filterData = [{ datasource: 1 }];
    let dateRange = 2;
    let refreshPage = false;
    spyOn(arisDataSourceService1, 'getFromDataSource').and.callFake(() => Promise.resolve());
    arisGeoGeoJsonDataLayerDelegateService1.displayLayerOverlaysOnMap (mapLayer, map, mapBounds, filterData, dateRange, refreshPage);
    expect(arisDataSourceService1.getFromDataSource).toHaveBeenCalled();
  });

  it('Function displayLayerOverlaysOnMap refreshPage  undefined executed', () => {
    let arisGeoGeoJsonDataLayerDelegateService1 = TestBed.get(ArisGeoGeoJsonDataLayerDelegateService);
    let arisDataSourceService1 = TestBed.get(ArisDataSourceService);
    let response = { features: "features" };
    let mapLayer = { id: 1, type: 'geo', getGeoJsonPromise() { return Promise.resolve(response); } };
    let map = { data: { setStyle() { }, addListener() {} } };
    let mapBounds = {};
    let dateRange = 2;
    arisGeoGeoJsonDataLayerDelegateService1.displayLayerOverlaysOnMap (mapLayer, map, mapBounds, undefined, dateRange, undefined);
    expect(arisGeoGeoJsonDataLayerDelegateService1.objectScope).toBeDefined();
  });

  // it('Function displayLayerOverlaysOnMap executed with response data', (done) => {
  //   let arisGeoGeoJsonDataLayerDelegateService1 = TestBed.get(ArisGeoGeoJsonDataLayerDelegateService);
  //   let arisDataSourceService1 = TestBed.get(ArisDataSourceService);
  //   arisGeoGeoJsonDataLayerDelegateService1.clickListener = 'val';
  //   let mapLayer = { id: 1, type: 'geo', getGeoJsonPromise: undefined, markerIcon() {}, markerId() {}, markerTooltipTitle() {} };
  //   let map = { data: { setStyle() { }, addListener() {} } };
  //   let mapBounds = {};
  //   let filterData = [{ datasource: 1 }];
  //   let dateRange = 2;
  //   let refreshPage = true;
  //   let response = { features: "features" };
  //   spyOn(arisDataSourceService1, 'getFromDataSource').and.callFake(() => Promise.resolve(response));
  //   arisGeoGeoJsonDataLayerDelegateService1.displayLayerOverlaysOnMap (mapLayer, map, mapBounds, filterData, dateRange, refreshPage);
  //   expect(arisDataSourceService1.getFromDataSource).toHaveBeenCalled();
  // });

  // it('Function processPoints if scenario', () => {
  //   let arisGeoGeoJsonDataLayerDelegateService1 = TestBed.get(ArisGeoGeoJsonDataLayerDelegateService);
  //   let arisDataSourceService1 = TestBed.get(ArisDataSourceService);
  //   let thisArg = {};
  //   let geometry = { getArray() { return [{  }]; } };
  //   // let geometry: () => {};
  //   let callback = { call() {} };
  //   // spyOn(geometry, 'getArray').and.returnValue([{ data: 'data' }]);
  //   arisGeoGeoJsonDataLayerDelegateService1.processPoints(geometry, callback, thisArg);
  //   // expect(arisDataSourceService1.getFromDataSource).toHaveBeenCalled();
  // });
  // it('Function removeLayerOverlaysFromMap if executed', (done) => {
  //   let arisGeoGeoJsonDataLayerDelegateService1 = TestBed.get(ArisGeoGeoJsonDataLayerDelegateService);
  //   arisGeoGeoJsonDataLayerDelegateService1.clickListener = 'val';
  //   arisGeoGeoJsonDataLayerDelegateService1.objectScope = { featuresArray: { 0: '' } };
  //   arisGeoGeoJsonDataLayerDelegateService1.removeLayerOverlaysFromMap(0, 'geo');
  //   expect(arisGeoGeoJsonDataLayerDelegateService1.objectScope).toBeDefined();
  // });

  // it('Function removeLayerOverlaysFromMap else executed', (done) => {
  //   let arisGeoGeoJsonDataLayerDelegateService1 = TestBed.get(ArisGeoGeoJsonDataLayerDelegateService);
  //   let arisGeoService1 = TestBed.get(ArisGeoService);
  //   arisGeoGeoJsonDataLayerDelegateService1.clickListener = 'val';
  //   arisGeoGeoJsonDataLayerDelegateService1.objectScope = { featuresArray: { 0: 'v' } };
  //   spyOn(arisGeoService1, 'getMap').and.returnValue({ data: { remove() {} } });
  //   arisGeoGeoJsonDataLayerDelegateService1.removeLayerOverlaysFromMap(0, 'geo');
  //   expect(arisGeoService1.getMap).toHaveBeenCalled();
  // });

});
