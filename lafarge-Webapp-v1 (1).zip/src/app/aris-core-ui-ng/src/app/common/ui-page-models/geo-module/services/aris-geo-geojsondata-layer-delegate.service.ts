import { Injectable } from '@angular/core';
import { ArisGeoLayerDelegateService } from './aris-geo-layer-delegate.service';
import { ArisGeoInfoCardService } from './aris-geo-infocard.service';
import { ArisDataSourceService } from '../../../services/aris-datasource.service';
import { ArisGeoService } from './aris-geo.service';

declare var google: any;
/**
 * Service to delegate main GeoController's responsibility related to rendering data layer from geo-json.
 *
 */

@Injectable()
export class ArisGeoGeoJsonDataLayerDelegateService extends ArisGeoLayerDelegateService {
  objectScope: any;
  clickListener: any;

  constructor(private arisGeoService: ArisGeoService, private arisDataSourceService: ArisDataSourceService, private arisGeoInfoCardService: ArisGeoInfoCardService) {
    super();
    this.setObjectScope(this);
  }

  setObjectScope(objectScope) {
    this.objectScope = objectScope;
    this.objectScope.featuresArray = [];
    this.objectScope.tooltipWindow = null;
  }

  displayLayerOverlaysOnMap (mapLayer, map, mapBounds, filterData, dateRange, refreshPage) {
    if (this.clickListener) {
      google.maps.event.removeListener(this.clickListener);
    }
    let getGeoJsonPromise =  mapLayer.getGeoJsonPromise ? mapLayer.getGeoJsonPromise() :
                            this.arisDataSourceService.getFromDataSource(mapLayer.id + "GeoJson",
                                filterData, dateRange, 0, 1000, mapBounds, undefined);

    getGeoJsonPromise.then((response) =>  {
      if (!response || !response.features || response.features.length === 0) {
        return;
      }

     // Clear Info Card in case came from 'click event'
     // Avoid clear the infocard in case came from 'refresh page'
      if (refreshPage === false || refreshPage === undefined) {
        this.arisGeoInfoCardService.clear();
        this.closeToolTip();
      }

    //  Every feature must have unique id even if it is for different map layers. Otherwise,
    //  it will replace existing feature instead of duplicating it.
    //  Currently it is ensured by adding unique map layer id as prefix.

      response.features.forEach((value, key) => {
        value.id = mapLayer.id + value.id;
      });

      this.objectScope.featuresArray[mapLayer.id] = map.data.addGeoJson(response);
    });

    map.data.setStyle((feature) => {
      let color = 'gray';
      if (feature.getProperty('Colour')) {
        color = feature.getProperty('Colour');
      }
      return /** @type {google.maps.Data.StyleOptions} */({
        fillColor: color,
        strokeColor: color,
        strokeWeight: 2,
        title: feature.getProperty('id') || null
      });
    });

    // zoom to show all the features
    let bounds = new google.maps.LatLngBounds();
    map.data.addListener('addfeature', (e) => {
      this.processPoints(e.feature.getGeometry(), bounds.extend, bounds);
      if (!bounds.contains(map.getBounds().getNorthEast()) ||
        !bounds.contains(map.getBounds().getSouthWest())) {
        map.fitBounds(bounds);
      }
    });

    // zoom to the clicked feature
    this.clickListener = map.data.addListener('click', (event) => {
      this.closeToolTip();

    // ToDo: Move this customization to layer config service.
      let name = event.feature.getProperty('DMAAREACOD');
      this.objectScope.tooltipWindow = new google.maps.InfoWindow({
        content: "<font color='black'>" + name + "</font>",
        position: event.latLng
      });
      this.objectScope.tooltipWindow.open(map);
    });
  }

  removeLayerOverlaysFromMap (layerId, layerType) {
    google.maps.event.removeListener(this.clickListener);
    if (!this.objectScope.featuresArray[layerId] ||  this.objectScope.featuresArray[layerId].length === 0) {
      return;
    }
    let features = this.objectScope.featuresArray[layerId];
    for (let i = 0; i < features.length; i++) {
      this.arisGeoService.getMap().data.remove(features[i]);
    }
    this.objectScope.featuresArray[layerId] = [];
    this.closeToolTip();
  }

  getLegends() {
    return null; // No legend support.
  }

  clear() {
    this.objectScope.featuresArray = [];
    this.closeToolTip();
  }

  processPoints(geometry, callback, thisArg) {
    if (geometry instanceof google.maps.LatLng) {
      callback.call(thisArg, geometry);
    } else if (geometry instanceof google.maps.Data.Point) {
      callback.call(thisArg, geometry.get());
    } else {
      geometry.getArray().forEach((g) => {
        this.processPoints(g, callback, thisArg);
      });
    }
  }

  closeToolTip() {
    if (this.objectScope.tooltipWindow != null) {
      this.objectScope.tooltipWindow.close();
      this.objectScope.tooltipWindow = null;
    }
  }

}

