import { NgModule, NgZone, ApplicationRef, ComponentFactoryResolver, ChangeDetectorRef } from '@angular/core';
import { TranslationConfig } from 'angular-l10n/src/models/l10n-config';

import { HttpClient, HttpHandler } from "@angular/common/http";
import { TranslationService, LocaleService, LocaleConfig, LocaleStorage, TranslationProvider, TranslationHandler } from 'angular-l10n';
import { FormBuilder } from '@angular/forms';
import { ArisGeoInfoCardCommonService } from './aris-geo-infocard-common.service';
import { ArisPageRefreshService } from '../../../services/aris-page-refresh.service';
import { ArisLanguageService } from '../../../ui-page-sections/language-selector-module/services/aris-language.service';
import { ArisConfigService } from '../../../services/aris-config.service';

describe('Test: Aris Geo Info Card Common Service', () => {
  let handler: HttpHandler;
  let applicationRef: ApplicationRef;
  let http = new HttpClient(handler);
  let  arisLanguageService: ArisLanguageService = new ArisLanguageService();
  let arisConfigService: ArisConfigService = new ArisConfigService(http, arisLanguageService);
  let arisPageRefreshService = new ArisPageRefreshService(arisConfigService);

  const arisGeoInfoCardCommonService = new ArisGeoInfoCardCommonService(arisPageRefreshService, http, applicationRef);
  it('should create ArisGeoInfoCardCommonService', () => {
    expect(arisGeoInfoCardCommonService).toBeTruthy();
  });

  it('test case to check if getRow method is working', () => {
    let data = arisGeoInfoCardCommonService.getRow("WBS", "100", "4327657567", "green", "10");
    expect(data.title).toBe("WBS");
    expect(data.valueTextColor).toBe("green");
  });

  it('test case to check if getRow method is working', () => {
    let data = arisGeoInfoCardCommonService.getRow("WBS", "100", "4327657567", "green", "10");
    expect(data.title).toBe("WBS");
    expect(data.valueTextColor).toBe("green");
  });

  it('test case to check if getTable method is working', () => {
    let data = arisGeoInfoCardCommonService.getTable("header title", ["title", "value"], "RED");
    expect(data.header).toBe("header title");
    expect(data.rows[0]).toBe("title");
    expect(data.rows[1]).toBe("value");
  });

  it('test case to check if getTab method is working', () => {
    let data = arisGeoInfoCardCommonService.getTab("testId", "test title", {});
    expect(data.id).toBe("testId");
    expect(data.chartParams.chartTitle).toBe("test title");
  });

  it('test case to check if getTab method else is working', () => {
    let data = arisGeoInfoCardCommonService.getTab("testId", "test title", undefined);
    expect(data.id).toBe("testId");
  });

  it('test case to check if getLineChartParams method is working', () => {
    let data = arisGeoInfoCardCommonService.getLineChartParams("date", "val");
    expect(data.xAxisAttribute).toBe("date");
    expect(data.chartType).toBe("lineChart");
  });

  it('test case to check if addChartData method is working', () => {
    spyOn(http, 'post').and.callThrough();
    arisGeoInfoCardCommonService.addChartData("S1098E", "WER" , {}, 6);
    expect(http.post).toHaveBeenCalled();
  });

  it('test case to check if addChartData method else is working', () => {
    spyOn(arisPageRefreshService, 'getPageRefreshInExecution').and.returnValue('data');
    spyOn(http, 'post').and.callThrough();
    arisGeoInfoCardCommonService.addChartData("S1098E", "WER" , { currentTimeDurationRange: 1 }, 6);
    expect(arisPageRefreshService.getPageRefreshInExecution).toHaveBeenCalled();
  });

  it('test case to check if addChartData method dataTimeDuration if scenario is working', () => {
    spyOn(arisPageRefreshService, 'getPageRefreshInExecution').and.returnValue(undefined);
    spyOn(http, 'post').and.callThrough();
    arisGeoInfoCardCommonService.addChartData("S1098E", "WER" , { currentTimeDurationRange: 1, tabs: 'len' }, false);
    expect(arisPageRefreshService.getPageRefreshInExecution).toHaveBeenCalled();
  });

  it('test case to check if addChartData method inner ifs else scenario is working', () => {
    spyOn(arisPageRefreshService, 'getPageRefreshInExecution').and.returnValue(undefined);
    spyOn(http, 'post').and.callThrough();
    arisGeoInfoCardCommonService.addChartData("S1098E", "WER" , { currentTimeDurationRange: 1, tabs: '' }, false);
    expect(arisPageRefreshService.getPageRefreshInExecution).toHaveBeenCalled();
  });

  it('test case to check if addChartData method inner ifs else scenario is working', () => {
    spyOn(arisPageRefreshService, 'getPageRefreshInExecution').and.returnValue(undefined);
    spyOn(http, 'post').and.callThrough();
    arisGeoInfoCardCommonService.addChartData("S1098E", "WER" , { currentTimeDurationRange: 1, tabs: '' }, true);
    expect(arisPageRefreshService.getPageRefreshInExecution).toHaveBeenCalled();
  });
});

