import { Injectable, Injector, ApplicationRef } from '@angular/core';
import { ArisPageRefreshService } from '../../../services/aris-page-refresh.service';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { defaultTimeRangeDuration, chartTypes } from '../aris-geo-constants';
import { Subject } from 'rxjs/Subject';


@Injectable()
export class ArisGeoInfoCardCommonService {
  onInfoCardDataChange: Subject<Object> = new Subject<Object>();
  componentReload: Subject<Object> = new Subject<Object>();
  closeInfoCard: Subject<Object> = new Subject<Object>();
  public dataTimeDuration: any = null;
  constructor(private arisPageRefreshService: ArisPageRefreshService, private http: HttpClient,
  private applicationRef: ApplicationRef) { }
  /**
   * Get new Row object.
   */
  getRow (title, value, dtv, valueTextColor, hrsValue) {
    return { title , value , dtv , valueTextColor, hrsValue };
  }
  /**
   * Get new Table object.
   */
  getTable (header, rows, headerTextColor) {
    return { header , rows , headerTextColor };
  }
  /**
   * Get new Tab object.
   */
  getTab (id, text, chartParams) {
    if (chartParams) {
      chartParams.chartTitle = text;
    }
    return { id , text , chartParams };
  }
 /**
  * Get Line chart parameters
  */
  getLineChartParams(xAxisAttribute, yAxisAttribute) {
    return { xAxisAttribute, yAxisAttribute, chartType: chartTypes.LINE_CHART };
    // return { chartType: chartTypes.LINE_CHART, xAxisAttribute: '{xAxisAttribute}', yAxisAttribute : '{yAxisAttribute}' };
  }

  /**
    * Add chart data to middle section for given map layer.
    * param mapLayerId id of the map layer.
    * param markerId unique id of the marker.
    * param middleSection middle section of the map layer.
    */
  addChartData (mapLayerId, markerId, middleSection, timeRangeDuration) {
    this.dataTimeDuration = timeRangeDuration;
    if (this.arisPageRefreshService.getPageRefreshInExecution() === undefined ||
        this.arisPageRefreshService.getPageRefreshInExecution() === false) {
      if (!this.dataTimeDuration) {
        this.dataTimeDuration = defaultTimeRangeDuration;
        middleSection.currentTimeDurationRange = defaultTimeRangeDuration;
        if (middleSection.tabs.length > 0) {
          middleSection.currentTab = middleSection.tabs[0].text;
        }
      }
    } else {
      this.dataTimeDuration = middleSection.currentTimeDurationRange;
    }
    let chartRequest = [];
    chartRequest.push({ name: 'markerId', values: [markerId], op: 'eq', dbtype: 'String' });
    const url =  'rest/getFromDataSource/' + mapLayerId + 'InfoCardLineChart?offset=0&limit=1000&groupedDuration=' + this.dataTimeDuration ;
    this.http.post(url, chartRequest).toPromise()
    .then((data: any) => {
      console.log("geo infocard linechart data updated", data);
      middleSection.chartData  = data;
      this.applicationRef.tick();
    },
    function (err) {
      this.promise.reject(err);
    });
  }
}
