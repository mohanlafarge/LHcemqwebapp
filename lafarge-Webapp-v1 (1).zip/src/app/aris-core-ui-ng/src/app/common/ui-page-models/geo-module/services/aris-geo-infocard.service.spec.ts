import { NgModule, NgZone, ApplicationRef, ComponentFactoryResolver, ChangeDetectorRef, Injector } from '@angular/core';
import { TranslationConfig } from 'angular-l10n/src/models/l10n-config';

import { HttpClient, HttpHandler } from "@angular/common/http";
import { TranslationService, LocaleService, LocaleConfig, LocaleStorage, TranslationProvider, TranslationHandler, LocalizationModule, InjectorRef } from 'angular-l10n';
import { FormBuilder } from '@angular/forms';
import { ArisGeoInfoCardCommonService } from './aris-geo-infocard-common.service';
import { ArisPageRefreshService } from '../../../services/aris-page-refresh.service';
import { ArisLanguageService } from '../../../ui-page-sections/language-selector-module/services/aris-language.service';
import { ArisConfigService } from '../../../services/aris-config.service';
import { ArisGeoInfoCardService } from './aris-geo-infocard.service';
import { ArisGeoService } from './aris-geo.service';
import { ArisGeoInfoCardWorkOrdersService } from '../../../../prototypes/geo-module/services/aris-geo-infocard-workorders.service';
import { TestBed } from '@angular/core/testing';
import { ArisGeoModule } from '../aris-geo.module';
import { ArisModule } from '../../../../aris.module';
import { CommonModule } from '@angular/common';
import { ArisGeoMapLayersService } from './aris-geo-maplayers.service';

describe('Test: Aris Geo Info Card Service', () => {
  const configMockData = {
    arisConfig: [{
      assetAttributeName: 'Map Initial Zoom',
      value: '10',
    }, {
      assetAttributeName: 'Map Initial Latitude',
      value: '33.758199',
    }, {
      assetAttributeName: 'Map Initial Longitude',
      value: '-84.425731',
    }],
  };
  let testMapLayerData = {
    id:  "monitoredSewerFacilitySummary",
    name:  "MAPLAYER_MONITORED_SEWER_FACILITY_SUMMARY",
    type:  "marker"
  };
  let testData = {
    mapLayer: {
      id: "monitoredSewerFacilitySummary",
      name: "MAPLAYER_MONITORED_SEWER_FACILITY_SUMMARY",
      type: "marker"
    },
    header: {
      title: "SSOM 8313 Amber Trail",
      fillPerc: 24.79946667,
      value: "",
      fillColor: "#008000"
    },
    topSection: {
      alert: "",
      alertBgColor: "",
      tables: [{
        header: "",
        rows: [{
          title: "MONITOR TYPE",
          value: "Flow an WQ Monitor"
        },
          {
            title: "Pipe Diameter  (meters)",
            value: "18.00"
          }
        ]
      }],
      headers: [{
        title: "CURRENT STATE",
        value: "GREEN",
        dtv: 1444149000000,
        valueTextColor: "green"
      }]
    },
    middleSection: {
      tabs: [{
        id: "level",
        text: "Level (meters)",
        chartParams: {
          xAxisAttribute: "dtvLevel",
          yAxisAttribute: "level",
          chartType: "lineChart",
          chartTitle: "Level (meters)"
        }
      },
        {
          id: "velocity",
          text: "Velocity (metres per second (m/s))",
          chartParams: {
            xAxisAttribute: "dtvVelocity",
            yAxisAttribute: "velocity",
            chartType: "lineChart",
            chartTitle: "Velocity (metres per second (m/s))"
          }
        }
      ],
      chartData: null,
      longTextFields: [],
      currentDropdownvalue: "",
      currentChartParams: {
        xAxisAttribute: "dtvLevel",
        yAxisAttribute: "level",
        chartType: "lineChart",
        chartTitle: "Level (meters)"
      },
      markerId: "SSOM 8313 Amber Trail",
      currentTimeDurationRange: "6",
      currentTab: "Level (meters)"
    },
    bottomSection: {
      tables: [{
        header: "Site Details",
        rows: [{
          title: "Asset Reference"
        },
          {
            title: "Nearest weather station",
            value: ""
          }
        ],
        headerTextColor: "rgb(255, 165, 0)"
      }]
    }
  };

  beforeEach(() => TestBed.configureTestingModule({
    imports: [ArisGeoModule, ArisModule, CommonModule, LocalizationModule],
    providers: [ArisGeoService,
      ArisConfigService,
      ArisGeoInfoCardService,
      Injector,
      HttpHandler,
      HttpClient,
      ArisLanguageService,
      ArisGeoMapLayersService,
      TranslationService,
      InjectorRef
    ]
  }));
  it('should create ArisGeoInfoCardService', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    expect(arisGeoInfoCardService).toBeTruthy();
  });

  it('test case to check if getMapLayer method is working', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    arisGeoInfoCardService.infocard = testData;
    let mapLayerData = arisGeoInfoCardService.getMapLayer();
    expect(mapLayerData.id).toBe('monitoredSewerFacilitySummary');
    expect(mapLayerData.type).toBe('marker');
  });

  it('test case to check if getHeader method is working', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    arisGeoInfoCardService.infocard = testData;
    let headerData = arisGeoInfoCardService.getHeader();
    expect(headerData.title).toBe('SSOM 8313 Amber Trail');
    expect(headerData.fillPerc).toBe(24.79946667);
  });

  it('test case to check if getTopSection method is working', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    arisGeoInfoCardService.infocard = testData;
    let topSectionData = arisGeoInfoCardService.getTopSection();
    expect(topSectionData.tables[0].rows[0].title).toBe('MONITOR TYPE');
    expect(topSectionData.tables[0].rows[1].value).toBe("18.00");
    expect(topSectionData.headers[0].title).toBe("CURRENT STATE");
  });

  it('test case to check if getMiddleSection method is working', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    arisGeoInfoCardService.infocard = testData;
    let middleSectionData = arisGeoInfoCardService.getMiddleSection();
    expect(middleSectionData.tabs[0].id).toBe('level');
    expect(middleSectionData.tabs[0].chartParams.xAxisAttribute).toBe('dtvLevel');
  });

  it('test case to check if getBottomSection method is working', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    arisGeoInfoCardService.infocard = testData;
    let bottomSectionrData = arisGeoInfoCardService.getBottomSection();
    expect(bottomSectionrData.tables[0].header).toBe('Site Details');
    expect(bottomSectionrData.tables[0].rows[1].title).toBe('Nearest weather station');
    expect(bottomSectionrData.tables[0].headerTextColor).toBe('rgb(255, 165, 0)');
  });

  it('test case to check if getInfoCard method is working', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    arisGeoInfoCardService.infocard = testData;
    let infocardData = arisGeoInfoCardService.getInfoCard();
    expect(infocardData.mapLayer.id).toBe('monitoredSewerFacilitySummary');
    expect(infocardData.header.title).toBe('SSOM 8313 Amber Trail');
    expect(infocardData.topSection.alert).toBe('');
    expect(infocardData.middleSection.tabs[0].id).toBe('level');
  });

  it('test case to check if reset method is working', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    arisGeoInfoCardService.infocard = testData;
    const asrisGeoService = TestBed.get(ArisGeoService);
    const arisConfigService = TestBed.get(ArisConfigService);
    arisConfigService.setArisConfig(configMockData.arisConfig);
    asrisGeoService.setProperties();
    arisGeoInfoCardService.reset();
    let infocardData = arisGeoInfoCardService.getInfoCard();
    expect(infocardData.header.title).toBe('');
  });

  it('test case to check if reset method else scenario is working', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    arisGeoInfoCardService.infocard = { mapLayer:
      { setInfoCardData: true, type: 'geo' },
      header: { title: '', fillPerc: '', value: '', fillColor: '' },
      topSection: { alert: '', alertBgColor: '', tables: '', headers: '' },
      middleSection: { tabs: '', chartData: '', longTextFields: '', currentDropdownvalue: '' },
      bottomSection: { tables: '' }
    };
    const asrisGeoService = TestBed.get(ArisGeoService);
    const arisConfigService = TestBed.get(ArisConfigService);
    arisConfigService.setArisConfig(configMockData.arisConfig);
    asrisGeoService.setProperties();
    arisGeoInfoCardService.reset();
    let infocardData = arisGeoInfoCardService.getInfoCard();
    expect(infocardData.header.title).toBe('');
  });

  it('test case to check if reset method first if scenario is working', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    arisGeoInfoCardService.infocard = { mapLayer:
      { setInfoCardData: true, type: 'geo', clearInfoCardData() {} },
      header: { title: '', fillPerc: '', value: '', fillColor: '' },
      topSection: { alert: '', alertBgColor: '', tables: '', headers: '' },
      middleSection: { tabs: '', chartData: '', longTextFields: '', currentDropdownvalue: '' },
      bottomSection: { tables: '' }
    };
    const asrisGeoService = TestBed.get(ArisGeoService);
    const arisConfigService = TestBed.get(ArisConfigService);
    arisConfigService.setArisConfig(configMockData.arisConfig);
    asrisGeoService.setProperties();
    arisGeoInfoCardService.reset();
    let infocardData = arisGeoInfoCardService.getInfoCard();
    expect(infocardData.header.title).toBe('');
  });

  it('test case to check if fromJson first If', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    let mapLayer = { setInfoCardData() {} };
    arisGeoInfoCardService.infocard = { mapLayer:
      { setInfoCardData: true, type: 'geo' },
      header: { title: '', fillPerc: '', value: '', fillColor: '' },
      topSection: { alert: '', alertBgColor: '', tables: '', headers: '' },
      middleSection: { tabs: '', chartData: '', longTextFields: '', currentDropdownvalue: '' },
      bottomSection: { tables: '' }
    };
    const asrisGeoService = TestBed.get(ArisGeoService);
    const arisConfigService = TestBed.get(ArisConfigService);
    arisConfigService.setArisConfig(configMockData.arisConfig);
    asrisGeoService.setProperties();
    spyOn(asrisGeoService, 'getMapLayersService').and.returnValue({ getLayerTypes() {} });
    spyOn(asrisGeoService.getMapLayersService(), 'getLayerTypes').and.returnValue(undefined);
    arisGeoInfoCardService.fromJson(mapLayer, 'json');
    expect(arisGeoInfoCardService).toBeTruthy();
  });
  it('test case to check if fromJson else If', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    let mapLayer = { type: 'type' };
    arisGeoInfoCardService.infocard = { mapLayer:
      { setInfoCardData: true, type: 'geo' },
      header: { title: '', fillPerc: '', value: '', fillColor: '' },
      topSection: { alert: '', alertBgColor: '', tables: '', headers: '' },
      middleSection: { tabs: '', chartData: '', longTextFields: '', currentDropdownvalue: '' },
      bottomSection: { tables: '' }
    };
    const asrisGeoService = TestBed.get(ArisGeoService);
    const arisConfigService = TestBed.get(ArisConfigService);
    arisConfigService.setArisConfig(configMockData.arisConfig);
    asrisGeoService.setProperties();
    spyOn(asrisGeoService, 'getMapLayersService').and.returnValue({ getLayerTypes() {} });
    spyOn(asrisGeoService.getMapLayersService(), 'getLayerTypes').and.returnValue({ type: { defaultSetInfoCardData() {} } });
    arisGeoInfoCardService.fromJson(mapLayer, 'json');
    expect(arisGeoInfoCardService).toBeTruthy();
  });

  it('test case to check if fromJson else If defaultSetInfoCardData undefined', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    let mapLayer = { type: 'type' };
    arisGeoInfoCardService.infocard = { mapLayer:
      { setInfoCardData: true, type: 'geo' },
      header: { title: '', fillPerc: '', value: '', fillColor: '' },
      topSection: { alert: '', alertBgColor: '', tables: '', headers: '' },
      middleSection: { tabs: '', chartData: '', longTextFields: '', currentDropdownvalue: '' },
      bottomSection: { tables: '' }
    };
    const asrisGeoService = TestBed.get(ArisGeoService);
    const arisConfigService = TestBed.get(ArisConfigService);
    arisConfigService.setArisConfig(configMockData.arisConfig);
    asrisGeoService.setProperties();
    spyOn(asrisGeoService, 'getMapLayersService').and.returnValue({ getLayerTypes() {} });
    spyOn(asrisGeoService.getMapLayersService(), 'getLayerTypes').and.returnValue({ type: { defaultSetInfoCardData: undefined } });
    arisGeoInfoCardService.fromJson(mapLayer, 'json');
    expect(arisGeoInfoCardService).toBeTruthy();
  });

  it('test case to check if fromJson else If layerTypes  undefined', () => {
    const arisGeoInfoCardService = TestBed.get(ArisGeoInfoCardService);
    let mapLayer = { type: 'type' };
    arisGeoInfoCardService.infocard = { mapLayer:
      { setInfoCardData: true, type: 'geo' },
      header: { title: '', fillPerc: '', value: '', fillColor: '' },
      topSection: { alert: '', alertBgColor: '', tables: '', headers: '' },
      middleSection: { tabs: '', chartData: '', longTextFields: '', currentDropdownvalue: '' },
      bottomSection: { tables: '' }
    };
    const asrisGeoService = TestBed.get(ArisGeoService);
    const arisConfigService = TestBed.get(ArisConfigService);
    arisConfigService.setArisConfig(configMockData.arisConfig);
    asrisGeoService.setProperties();
    spyOn(asrisGeoService, 'getMapLayersService').and.returnValue({ getLayerTypes() {} });
    spyOn(asrisGeoService.getMapLayersService(), 'getLayerTypes').and.returnValue(undefined);
    arisGeoInfoCardService.fromJson(mapLayer, 'json');
    expect(arisGeoInfoCardService).toBeTruthy();
  });
});

