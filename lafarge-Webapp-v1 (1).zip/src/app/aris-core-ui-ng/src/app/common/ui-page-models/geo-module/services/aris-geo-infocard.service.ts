import { Injectable, ApplicationRef  } from '@angular/core';
import { ArisGeoService } from './aris-geo.service';
declare var $: any;

@Injectable()
export class ArisGeoInfoCardService {

  public infocard: any = {};
  constructor(private arisGeoService: ArisGeoService, private applicationRef: ApplicationRef) {
    this.infocard.mapLayer = {};
    this.infocard.header = {};
    this.infocard.topSection = {};
    this.infocard.middleSection = {};
    this.infocard.bottomSection = {};
  }

  /**
   * Get MapLayer object.
   */
  getMapLayer() {
    return this.infocard.mapLayer;
  }

  /**
   * Get Header object.
   */
  getHeader() {
    return this.infocard.header;
  }

  /**
   * Get TopSection object.
   */

  getTopSection() {
    return this.infocard.topSection;
  }
  /**
   * Get MiddleSection object.
   */

  getMiddleSection() {
    return this.infocard.middleSection;
  }

 /**
  * Get BottomSection object.
  */
  getBottomSection() {
    return this.infocard.bottomSection;
  }

  getInfoCard() {
    return this.infocard;
  }
 /**
  * Make all objects empty.
  */
  clear () {
    this.reset();
  }
  /**
	 * Convert json data to POJO objects which will be used in infocard.
	 * param layerId map layer id.
	 * param layerId map layer type.
	 * param json data in json format.
	 */
  fromJson(mapLayer, json) {
    // angular.copy(mapLayer, this.infocard.mapLayer);
    $.extend(this.infocard.mapLayer, mapLayer);
    this.infocard.header.fillPerc = -1;
    if (mapLayer.setInfoCardData) {
      mapLayer.setInfoCardData(this.infocard, json);
      this.applicationRef.tick();
    } else {
      // Call layer type's default implementation, if available.
      let layerTypes = this.arisGeoService.getMapLayersService().getLayerTypes();
      if (layerTypes) {
        let defaultSetInfoCardData = layerTypes[mapLayer.type].defaultSetInfoCardData;
        if (defaultSetInfoCardData) {
          defaultSetInfoCardData(this.infocard, json);
        }
      }

    }
  }

  /**
	 * Reset all POJO objects.
	 */
  reset() {
    if (this.infocard.mapLayer.clearInfoCardData) {
      this.infocard.mapLayer.clearInfoCardData(this.infocard);
    } else {
      // If layer type's setInfoCardData() is used then defaultClearInfoCardData() should be called.
      if (!this.infocard.mapLayer.setInfoCardData && this.infocard.mapLayer.type) {
        this.arisGeoService.getMapLayersService().getLayerTypes();
      }
    }

    // Delete all members of infocard.mapLayer, instead of deleting itself.
    // digest cycle will not work if mapLayer itself is deleted and recreated.
    for (let member in this.infocard.mapLayer) {
      if (this.infocard.mapLayer.hasOwnProperty(member)) {
        delete this.infocard.mapLayer[member];
      }
    }

    this.infocard.header.title = "";
    this.infocard.header.fillPerc = "";
    this.infocard.header.value = "";
    this.infocard.header.fillColor = "";

    this.infocard.topSection.alert = "";
    this.infocard.topSection.alertBgColor = "";
    this.infocard.topSection.tables = [];
    this.infocard.topSection.headers = [];

    this.infocard.middleSection.tabs = [];
    this.infocard.middleSection.chartData = null; // It must always be null.
    this.infocard.middleSection.longTextFields = [];
    this.infocard.middleSection.currentDropdownvalue = "";
    this.infocard.bottomSection.tables = [];
    this.applicationRef.tick();
  }
}
