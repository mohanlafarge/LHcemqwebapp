import { TestBed } from '@angular/core/testing';

import { HttpClient } from '@angular/common/http';
import { ArisGeoLayerDelegateService } from './aris-geo-layer-delegate.service';
import { TranslationService } from 'angular-l10n/src/services/translation.service';
import { ArisPermissionPipe } from '../../../pipes/aris-permission.pipes';
import { Injector } from '@angular/core';
import { access } from 'fs';


describe('ArisGeoLayerDelegateService', () => {

  let injector: Injector;
  let translationService: TranslationService;
  let arisPermissionPipe: ArisPermissionPipe;
  let arisGeoLayerDelegateService: ArisGeoLayerDelegateService;

  beforeEach(() => {
    arisGeoLayerDelegateService = new ArisGeoLayerDelegateService();
  });

  afterEach(() => {
    arisGeoLayerDelegateService = null;
  });

  it('ArisGeoLayerDelegateService object should be created', () => {
    let result = arisGeoLayerDelegateService.getLegends();
    expect(result).toEqual(null);
  });

  it('Function getObjectScope should return given value', () => {
    let result = arisGeoLayerDelegateService.getObjectScope(true);
    expect(result).toEqual(true);
  });

  it('Function getObjectScope else scenario should return given value', () => {
    let result = arisGeoLayerDelegateService.getObjectScope(undefined);
    expect(result).toBeDefined();
  });


});
