import { Injectable } from '@angular/core';

/**
 * Abstract Service to delegate main GeoController's responsibility related to rendering particular layer type.
 *
 */

@Injectable()
export class ArisGeoLayerDelegateService {

  /*
     * Replace overlay object for layer.
     * @param filterData value of geo filters
     * @param dataRange value of date filter
     * @param mapBounds value of  map
     * @param mapLayer value of each mapLayer data
     * @param map value of current maplayer
  */
  displayLayerOverlaysOnMap (mapLayer, map, mapBounds, filterData, dateRange, refreshPage) {
  }

  /*
    * Remove all overlay objects for layer.
    * @param layerId - Map Layer Id.
    * @param layerType - Map Layer Type.
  */
  removeLayerOverlaysFromMap (layerId, layerType) {
  }

  /**
    *  Get legends model.
  */
  getLegends () {
    return null; // No legend support.
  }

  /**
    * Clear service singleton.
  */
  clear () {

  }

  getObjectScope (objectScope) {
    return objectScope ? objectScope : this;
  }
}
