import { TestBed } from '@angular/core/testing';

import { HttpClient } from '@angular/common/http';
import { ArisGeoMapLayersService } from './aris-geo-maplayers.service';
import { TranslationService } from 'angular-l10n/src/services/translation.service';
import { ArisPermissionPipe } from '../../../pipes/aris-permission.pipes';
import { ArisPermissionService } from '../../../../common/services/aris-permission.service';
import { Injector } from '@angular/core';
import { access } from 'fs';


describe('ArisGeoMapLayersService', () => {

  let injector: Injector;
  let translationService: TranslationService;
  let arisPermissionService = new ArisPermissionService();
  let arisPermissionPipe = new ArisPermissionPipe(arisPermissionService);
  let arisGeoMapLayersService: ArisGeoMapLayersService;

  beforeEach(() => {
    arisGeoMapLayersService = new ArisGeoMapLayersService(translationService, arisPermissionPipe, injector);
  });

  afterEach(() => {
    arisGeoMapLayersService = null;
  });

  it('ArisGeoMapLayersService object should be created', () => {
    expect(arisGeoMapLayersService).toBeTruthy();
  });

  it('Function getRawData should return given value', () => {
    let expectedObj = {
      demo:
      {
        id: "demo",
        name: "MAPLAYER_GROUP_UC1",
        permission: "PERM_VIEW_UC1",
        layers: [
          "workOrders"
        ]
      },
      demo2:
      {
        id: "demo2",
        name: "MAPLAYER_GROUP_UC1",
        permission: "PERM_VIEW_UC2",
        layers: [
          "SewerPipes",
          "spillIncident",
          "monitoredSewerFacilitySummary"
        ]
      }
    };

    expect(arisGeoMapLayersService.getRawData({})).toEqual(expectedObj);
  });

  it('Function setLayerTypes should return given value', () => {
    let expectedArr = ["marker", "cluster", "shape", "geojsondata"];
    expect(Object.keys(arisGeoMapLayersService.setLayerTypes(arisGeoMapLayersService))).toEqual(expectedArr);
  });

  it('Function getLayerTypes should return given value', () => {
    spyOn(arisGeoMapLayersService, "setLayerTypes").and.callThrough();
    let actualArr = arisGeoMapLayersService.getLayerTypes(undefined);
    expect(arisGeoMapLayersService.setLayerTypes).toHaveBeenCalled();
    let expectedArr = ["marker", "cluster", "shape", "geojsondata"];
    expect(Object.keys(actualArr)).toEqual(expectedArr);
  });

  it('Function getLayerTypes else scenario', () => {
    spyOn(arisGeoMapLayersService, "getScope").and.returnValue({ layerTypes: true });
    let actualArr = arisGeoMapLayersService.getLayerTypes(undefined);
    expect(actualArr).toEqual(true);
  });

  it('Function getMapLayerById should return given value', () => {
    arisGeoMapLayersService.mapLayers = [
      { id: "demo", name: "MAPLAYER_GROUP_UC1", isGroup: true },
      {
        id: "workOrders",
        name: "MAPLAYER_WORK_ORDERS",
        type: "cluster",
        hasFilter: true,
        hasLegend: true
      },
      {
        id: "monitoredSewerFacilitySummary",
        name: "MAPLAYER_MONITORED_SEWER_FACILITY_SUMMARY",
        type: "marker"
      }
    ];

    let actualObj = arisGeoMapLayersService.getMapLayerById("monitoredSewerFacilitySummary", undefined);
    expect(actualObj.id).toEqual("monitoredSewerFacilitySummary");

  });

  it('Function hasPermission should return given value', () => {
    expect(arisGeoMapLayersService.hasPermission(undefined)).toEqual(true);
  });

  it('Function hasPermission If Scenario', () => {
    spyOn(arisPermissionPipe, 'transform').and.callThrough();
    arisGeoMapLayersService.hasPermission('permission');
    expect(arisPermissionPipe.transform).toHaveBeenCalled();
  });

  it('Function getScope should return given value', () => {
    let expectedArr = ["translationService", "arisPermissionPipe", "injector", "geoProperties"];
    expect(Object.keys(arisGeoMapLayersService.getScope(undefined))).toEqual(expectedArr);
  });

  it('Function getLayers should return given value', () => {
    arisGeoMapLayersService.mapLayers = {};
    expect(arisGeoMapLayersService.getLayers(undefined)).toEqual({});
  });

  it('Function setLayers ', () => {
    let scope = { val: 'val' };
    let data = { mapLayers: [], getRawData() {} };
    let groups = { group: { permission: false, layers: { permission: false } } };
    spyOn(arisGeoMapLayersService, 'getScope').and.returnValue(data);
    spyOn(data, 'getRawData').and.returnValue(groups);
    spyOn(arisGeoMapLayersService, 'hasPermission').and.returnValue(false);
    arisGeoMapLayersService.setLayers(scope);
    expect(arisGeoMapLayersService.getScope).toHaveBeenCalled();
  });


});
