import { Injectable , Injector } from '@angular/core';
import { ArisGeoService } from './aris-geo.service';
import { ArisGeoInfocardComponent } from '../components/aris-geo-infocard-main.component';
import { ArisGeoInfocardTopComponent } from '../components/aris-geo-infocard-top.component';
import { ArisGeoInfocardBottomComponent } from '../components/aris-geo-infocard-bottom.component';
import { ArisGeoInfocardMiddleComponent } from '../components/aris-geo-infocard-middle.component';
import { TranslationService } from 'angular-l10n';
import { ArisPermissionPipe } from '../../../pipes/aris-permission.pipes';
import { ArisGeoMarkerClustersDelegateService } from './aris-geo-markerclusters-layer-delegate.service';
import { ArisGeoShapeLayerDelegateService } from './aris-geo-shape-layer-delegate.service';
import { ArisGeoGeoJsonDataLayerDelegateService } from './aris-geo-geojsondata-layer-delegate.service';
import { ArisGeoMaplayerLegendComponent } from '../components/aris-geo-maplayer-legend.component';

declare var $: any;

@Injectable()
export class ArisGeoMapLayersService {

  public mapLayers: any;
  public geoProperties: any;
  public layerTypes: any;

  constructor(protected translationService: TranslationService,
    protected arisPermissionPipe: ArisPermissionPipe, protected injector: Injector) {
    this.geoProperties = window.app.config.geo;
  }

  getRawData (scope) {
    let funcScope = this.getScope(scope);
    let groups = {};

    let group = { id: '', name: '', permission: '', layers: [] };
    group.id = 'demo';
    group.name = 'MAPLAYER_GROUP_UC1';
    group.permission = 'PERM_VIEW_UC1';
    group.layers = ['workOrders'];
    groups[group.id] = group;

    group = { id: '', name: '', permission: '', layers: [] };
    group.id = 'demo2';
    group.name = 'MAPLAYER_GROUP_UC1';
    group.permission = 'PERM_VIEW_UC2';
    group.layers = ['SewerPipes', 'spillIncident', 'monitoredSewerFacilitySummary'];
    groups[group.id] = group;

    return groups;
  }

  setLayerTypes (scope) {
    let funcScope = this.getScope(scope);
    funcScope.layerTypes = {};
    let layerType = { service: {}, mainSectionComponent: {}, topSectionComponent: {},
      middleSectionComponent: {}, bottomSectionComponent: {},
      legendTemplateComponent: {} };

    // Marker
    let layerTypeId = 'marker';
    layerType.service = ArisGeoMarkerClustersDelegateService;
    layerType.mainSectionComponent = ArisGeoInfocardComponent;
    layerType.topSectionComponent = ArisGeoInfocardTopComponent;
    layerType.middleSectionComponent = ArisGeoInfocardMiddleComponent;
    layerType.bottomSectionComponent = ArisGeoInfocardBottomComponent;
    layerType.legendTemplateComponent = ArisGeoMaplayerLegendComponent;
    funcScope.layerTypes[layerTypeId] = layerType;

    // Cluster
    layerType = { service: {}, mainSectionComponent: {}, topSectionComponent: {},
      middleSectionComponent: {}, bottomSectionComponent: {},
      legendTemplateComponent: {} };
    layerTypeId = 'cluster';
    layerType.service = ArisGeoMarkerClustersDelegateService;
    layerType.mainSectionComponent = ArisGeoInfocardComponent;
    layerType.topSectionComponent = ArisGeoInfocardTopComponent;
    layerType.middleSectionComponent = ArisGeoInfocardMiddleComponent;
    layerType.bottomSectionComponent = ArisGeoInfocardBottomComponent;
    layerType.legendTemplateComponent = ArisGeoMaplayerLegendComponent;
    funcScope.layerTypes[layerTypeId] = layerType;

        // Shape
    layerType = { service: '', mainSectionComponent: {}, topSectionComponent: {},
      middleSectionComponent: {}, bottomSectionComponent: {},
      legendTemplateComponent: {} };

    layerTypeId = 'shape';
    layerType.service = ArisGeoShapeLayerDelegateService;
    layerType.mainSectionComponent = ArisGeoInfocardComponent;
    layerType.topSectionComponent = ArisGeoInfocardTopComponent;
    layerType.legendTemplateComponent = ArisGeoMaplayerLegendComponent;
    funcScope.layerTypes[layerTypeId] = layerType;

    // GeoJson Data
    layerType = { service: '', mainSectionComponent: '', topSectionComponent: '',
      middleSectionComponent: '', bottomSectionComponent: '',
      legendTemplateComponent: '' };
    layerTypeId = 'geojsondata';
    layerType.service = ArisGeoGeoJsonDataLayerDelegateService;
    layerType.legendTemplateComponent = ArisGeoMaplayerLegendComponent;
    funcScope.layerTypes[layerTypeId] = layerType;

    return funcScope.layerTypes;
  }

  getLayerTypes (scope) {
    let funcScope = this.getScope(scope);
    if (!funcScope.layerTypes) {
      funcScope.setLayerTypes(funcScope);
    }

    return funcScope.layerTypes;
  }
    /**
     * Initialize map layer array.
     */
  setLayers (scope) {
    let funcScope = this.getScope(scope);
    funcScope.mapLayers = [];

    let groups = funcScope.getRawData();
    for (let group in groups) {
      if (this.hasPermission(groups[group].permission)) {
        let layers = [];
        let layerService = null;

        groups[group].layers.forEach((layer, index) => {
          if (this.hasPermission(layer.permission)) {
            layerService = this.injector.get(this.geoProperties.mapLayersInjectorServices[layer]);
            if (layerService) {
              let mapLayer = layerService.getMapLayer();
              // translate name
              mapLayer.name = mapLayer.name;
              layers.push(mapLayer);
            }
          }
        });

        if (layers.length > 0) {
          let groupLayer = { id: '', name: '', isGroup: false };
          groupLayer.id = groups[group].id;
          groupLayer.name = groups[group].name;
          groupLayer.isGroup = true;
          funcScope.mapLayers.push(groupLayer);
          funcScope.mapLayers = funcScope.mapLayers.concat(layers);
        }
      }

    }
  }
    /**
     * Get map layer array.
     */
  getLayers (scope) {
    let funcScope = this.getScope(scope);
    return funcScope.mapLayers;
  }

    /**
     * Initialize map layer array.
     */
  getMapLayerById (layerId, scope) {
    let funcScope = this.getScope(scope);
    let result: any;
    $.grep(funcScope.mapLayers, (v) => {
      if (v.id === layerId) {
        result = v;
      }
    });
    return result;
  }

  getScope (scope) {
    return scope ? scope : this;
  }

  hasPermission(permission) {
    return permission ? this.arisPermissionPipe.transform(permission) : true;
  }
}
