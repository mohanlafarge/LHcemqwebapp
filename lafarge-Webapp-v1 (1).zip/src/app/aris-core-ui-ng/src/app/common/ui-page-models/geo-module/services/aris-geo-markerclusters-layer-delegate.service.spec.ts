import { TestBed } from '@angular/core/testing';

import { HttpClient, HttpHandler } from '@angular/common/http';
import { TranslationService, InjectorRef, TRANSLATION_CONFIG, LOCALE_CONFIG, TranslationHandler, TranslationProvider, LocaleStorage, LocaleService } from 'angular-l10n';
import { ArisPermissionPipe } from '../../../pipes/aris-permission.pipes';
import { Injector, ApplicationRef } from '@angular/core';
import { access } from 'fs';
import { ArisGeoMarkerClustersDelegateService } from './aris-geo-markerclusters-layer-delegate.service';
import { ArisDataSourceService } from '../../../services/aris-datasource.service';
import { ArisGeoInfoCardService } from './aris-geo-infocard.service';
import { ArisGeoService } from './aris-geo.service';
import { ArisPageRefreshService } from '../../../services/aris-page-refresh.service';
import { LowerCasePipe } from '@angular/common';
import { ArisGeoInfoCardCommonService } from './aris-geo-infocard-common.service';
import { ArisLanguageService } from '../../../ui-page-sections/language-selector-module/services/aris-language.service';
import { ArisConfigService } from '../../../../common/services/aris-config.service';

describe('ArisGeoMarkerClustersDelegateService', () => {

  let arisDataSourceService: ArisDataSourceService;
  let arisGeoInfoCardService: ArisGeoInfoCardService;
  let arisGeoService: ArisGeoService;
  let arisPageRefreshService: ArisPageRefreshService;
  let http: HttpClient;
  let lowerCasePipe: LowerCasePipe;
  let translationService: TranslationService;
  let applicationRef: ApplicationRef;
  let arisGeoInfoCardCommonService: ArisGeoInfoCardCommonService;
  let arisLanguageService: ArisLanguageService;
  let arisGeoMarkerClustersDelegateService: ArisGeoMarkerClustersDelegateService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      schemas: [],
      imports: [],
      providers: [InjectorRef, Injector, ArisGeoService, ArisGeoInfoCardService, ArisGeoInfoCardCommonService,
        HttpClient, HttpHandler, ArisLanguageService, ArisPageRefreshService,
        TranslationService, ArisPermissionPipe, ArisDataSourceService,
        ArisGeoInfoCardService,
        ArisGeoService,
        ArisPageRefreshService,
        HttpClient,
        LowerCasePipe,
        TranslationService,
        ApplicationRef,
        ArisGeoInfoCardCommonService,
        ArisLanguageService, ArisConfigService
        ,  {
          provide: TRANSLATION_CONFIG,
          useValue: null
        }, LocaleService, {
          provide: LOCALE_CONFIG,
          useValue: null
        }, LocaleStorage, TranslationProvider, TranslationHandler, ArisGeoMarkerClustersDelegateService, ArisDataSourceService]
      // providers: [TranslatePipe, ArisGeoService, ArisGeoInfoCardService,
      //   ArisGeoInfoCardCommonService, ArisConfigService, HttpClient, HttpHandler,
      //   ArisLanguageService, ArisFooterService, ArisPageRefreshService, TranslationService]
    }).compileComponents();

    lowerCasePipe = new LowerCasePipe();
    arisLanguageService = new ArisLanguageService();
    arisDataSourceService = new ArisDataSourceService(http);
    arisGeoInfoCardCommonService = new ArisGeoInfoCardCommonService(arisPageRefreshService, http, applicationRef);
    arisGeoMarkerClustersDelegateService = new ArisGeoMarkerClustersDelegateService(arisDataSourceService,
        arisGeoInfoCardService, arisGeoService, arisPageRefreshService, http, lowerCasePipe, translationService,
        applicationRef, arisGeoInfoCardCommonService, arisLanguageService);
    // arisDataSourceService = TestBed.get(ArisDataSourceService);
  });

  afterEach(() => {
    arisGeoMarkerClustersDelegateService = null;
  });

  it('ArisGeoMarkerClustersDelegateService object should be created', () => {
    expect(arisGeoMarkerClustersDelegateService).toBeTruthy();
  });

  it('Function removeLayerOverlaysFromMap should call deleteMarkers', () => {
    spyOn(arisGeoMarkerClustersDelegateService, "deleteMarkers").and.callThrough();
    arisGeoMarkerClustersDelegateService.removeLayerOverlaysFromMap(undefined, undefined);
    expect(arisGeoMarkerClustersDelegateService.deleteMarkers).toHaveBeenCalled();
  });

  it('Function getLegends should return expected value', () => {
    arisGeoMarkerClustersDelegateService.legends = {};
    expect(arisGeoMarkerClustersDelegateService.getLegends()).toEqual({});
  });

//   it('Function clear should return given value', () => {
//     arisGeoMarkerClustersDelegateService.clear();
//     expect(arisGeoMarkerClustersDelegateService.markerClusterArray).toEqual([]);
//     expect(arisGeoMarkerClustersDelegateService.legends.list).toEqual([]);
//   });

  it('Function legend should return expected value', () => {
    let actualOutput = arisGeoMarkerClustersDelegateService.legend(12, "abc");
    expect(actualOutput.desc).toEqual("abc");
    expect(actualOutput.value).toEqual('./app/common/resources/img/marker_' + 12);
  });

  it('Function getMarkerIcon should return expected value', () => {
    let actualOutput1 = arisGeoMarkerClustersDelegateService.getMarkerIcon("yellow", "workOrders", undefined);
    expect(actualOutput1).toEqual("./app/common/resources/img/marker_workorders_yellow.png");

    let actualOutput2 = arisGeoMarkerClustersDelegateService.getMarkerIcon("amber", "spillIncident", undefined);
    expect(actualOutput2).toEqual("./app/common/resources/img/marker_spillincident_amber.png");
  });

  it('Function getLegendIcon should return expected value', () => {
    let actualOutput = arisGeoMarkerClustersDelegateService.getLegendIcon("green", "workOrders", undefined);
    expect(actualOutput).toEqual("app/common/resources/img/marker_workorders_green.png");
  });

  it('Function displayLayerOverlaysOnMap executed', () => {
    let mapLayer = { id: 1, type: 'geo', getMarkersPromise: undefined };
    let map = {};
    let mapBounds = {};
    let filterData = [{ datasource: 1 }];
    let dateRange = 2;
    let refreshPage = false;
    spyOn(arisDataSourceService, 'getFromDataSource').and.callFake(() => Promise.resolve());
    arisGeoMarkerClustersDelegateService.displayLayerOverlaysOnMap (mapLayer, map, mapBounds, filterData, dateRange, refreshPage);
    expect(arisDataSourceService.getFromDataSource).toHaveBeenCalled();
  });

  it('Function displayLayerOverlaysOnMap filterData undefined executed', () => {
    let mapLayer = { id: 1, type: 'geo', getMarkersPromise() { return Promise.reject(403); } };
    let map = {};
    let mapBounds = {};
    let dateRange = 2;
    let refreshPage = false;
    spyOn(arisDataSourceService, 'getFromDataSource').and.callFake(() => Promise.resolve());
    arisGeoMarkerClustersDelegateService.displayLayerOverlaysOnMap (mapLayer, map, mapBounds, undefined, dateRange, refreshPage);
    expect(arisGeoMarkerClustersDelegateService.mapLayerObj).toBe(mapLayer);
  });

  it('Function displayLayerOverlaysOnMap executed with response data', () => {
    let mapLayer = { id: 1, type: 'geo', getMarkersPromise: undefined, markerIcon() {}, markerId() {}, markerTooltipTitle() {} };
    let map = {};
    let mapBounds = {};
    let filterData = [{ datasource: 1 }];
    let dateRange = 2;
    let refreshPage = true;
    let response = [{ latitude: 1, longitude: 1, cluster: 1 }];
    spyOn(arisDataSourceService, 'getFromDataSource').and.callFake(() => Promise.resolve(response));
    arisGeoMarkerClustersDelegateService.displayLayerOverlaysOnMap (mapLayer, map, mapBounds, filterData, dateRange, refreshPage);
    expect(arisDataSourceService.getFromDataSource).toHaveBeenCalled();
  });

  it('Function displayLayerOverlaysOnMap executed mapLayer.id failure with response data', () => {
    let mapLayer = { id: 2, type: 'geo', cluster: false, getMarkersPromise: undefined, markerIcon() {}, markerId() {}, markerTooltipTitle() {} };
    let map = {};
    let mapBounds = {};
    let filterData = [{ datasource: 1 }];
    let dateRange = 2;
    let refreshPage = true;
    let response = [{ latitude: 1, longitude: 1, cluster: false }];
    let arisGeoMarkerClustersDelegateService1 = TestBed.get(ArisGeoMarkerClustersDelegateService);
    let arisDataSourceService1 = TestBed.get(ArisDataSourceService);
    spyOn(arisDataSourceService1, 'getFromDataSource').and.callFake(() => Promise.resolve(response));
    spyOn(mapLayer, 'markerTooltipTitle').and.returnValue('val');
    arisGeoMarkerClustersDelegateService1.displayLayerOverlaysOnMap (mapLayer, map, mapBounds, filterData, dateRange, refreshPage);
    expect(arisDataSourceService1.getFromDataSource).toHaveBeenCalled();
  });

  it('Function displayLayerOverlaysOnMap executed marker passing with response data', () => {
    let mapLayer = { id: 2, type: 'marker', cluster: false, getMarkersPromise: undefined, markerIcon() {}, markerId() {}, markerTooltipTitle() {} };
    let map = {};
    let mapBounds = {};
    let filterData = [{ datasource: 1 }];
    let dateRange = 2;
    let refreshPage = true;
    let response = [{ latitude: 1, longitude: 1, cluster: false }];
    let arisGeoMarkerClustersDelegateService1 = TestBed.get(ArisGeoMarkerClustersDelegateService);
    let arisDataSourceService1 = TestBed.get(ArisDataSourceService);
    spyOn(arisDataSourceService1, 'getFromDataSource').and.callFake(() => Promise.resolve(response));
    spyOn(mapLayer, 'markerTooltipTitle').and.returnValue('val');
    arisGeoMarkerClustersDelegateService1.displayLayerOverlaysOnMap (mapLayer, map, mapBounds, filterData, dateRange, refreshPage);
    expect(arisDataSourceService1.getFromDataSource).toHaveBeenCalled();
  });

  it('Function displayLayerOverlaysOnMap executed cluster true with response data', () => {
    let mapLayer = { id: 2, type: 'marker', cluster: true, getMarkersPromise: undefined, markerIcon() {}, markerId() {}, markerTooltipTitle() {}, clusterIcon() {} };
    let map = {};
    let mapBounds = {};
    let filterData = [{ datasource: 1 }];
    let dateRange = 2;
    let refreshPage = true;
    let response = [{ latitude: 1, longitude: 1, cluster: true }];
    let arisGeoMarkerClustersDelegateService1 = TestBed.get(ArisGeoMarkerClustersDelegateService);
    let arisDataSourceService1 = TestBed.get(ArisDataSourceService);
    spyOn(arisDataSourceService1, 'getFromDataSource').and.callFake(() => Promise.resolve(response));
    spyOn(mapLayer, 'markerTooltipTitle').and.returnValue('val');
    arisGeoMarkerClustersDelegateService1.displayLayerOverlaysOnMap (mapLayer, map, mapBounds, filterData, dateRange, refreshPage);
    expect(arisDataSourceService1.getFromDataSource).toHaveBeenCalled();
  });

  it('Function deleteMarkers executed for Marker true condition', () => {
    arisGeoMarkerClustersDelegateService.markerClusterArray = [{ layerId: 'val' }];
    arisGeoMarkerClustersDelegateService.deleteMarkers (0, 'marker');
    expect(arisGeoMarkerClustersDelegateService.markerClusterArray).toBeDefined();
  });
  it('Function deleteMarkers executed for Marker failure condition', () => {
    arisGeoMarkerClustersDelegateService.markerClusterArray = [{ clearMarkers() {} }];
    arisGeoMarkerClustersDelegateService.deleteMarkers (0, 'MARK');
    expect(arisGeoMarkerClustersDelegateService.markerClusterArray).toBeDefined();
  });

  it('Function deleteMarkers executed for markerClusterArray undefined', () => {
    arisGeoMarkerClustersDelegateService.markerClusterArray = [{ clearMarkers: undefined }];
    arisGeoMarkerClustersDelegateService.deleteMarkers (0, 'MARK');
    expect(arisGeoMarkerClustersDelegateService.markerClusterArray).toBeDefined([]);
  });

  it('Function attachMarkerInfoCard executed ', () => {
    let pageRefreshService = TestBed.get(ArisPageRefreshService);
    let arisGeoMarkerClustersDelegateService1 = TestBed.get(ArisGeoMarkerClustersDelegateService);
    arisGeoMarkerClustersDelegateService1.lastMapLayerId = 1;
    arisGeoMarkerClustersDelegateService1.lastMarkerId = 1;
    spyOn(pageRefreshService, 'getPageRefreshInExecution').and.returnValue(true);
    spyOn(arisGeoMarkerClustersDelegateService1, 'getInfoCardPromiseData').and.callFake(() => Promise.resolve([{ data: 'data' }]));
    arisGeoMarkerClustersDelegateService1.attachMarkerInfoCard ({ id: 1 }, { id: 1 });
    expect(pageRefreshService.getPageRefreshInExecution).toHaveBeenCalled();
  });

  it('Function attachMarkerInfoCard else executed ', () => {
    let pageRefreshService = TestBed.get(ArisPageRefreshService);
    let arisGeoMarkerClustersDelegateService1 = TestBed.get(ArisGeoMarkerClustersDelegateService);
    arisGeoMarkerClustersDelegateService1.lastMapLayerId = 2;
    arisGeoMarkerClustersDelegateService1.lastMarkerId = 2;
    spyOn(pageRefreshService, 'getPageRefreshInExecution').and.returnValue(true);
    arisGeoMarkerClustersDelegateService1.attachMarkerInfoCard ({ id: 1 }, { id: 1 });
    expect(pageRefreshService.getPageRefreshInExecution).toHaveBeenCalled();
  });

  it('Function updateInfoCardContent executed ', () => {
    let pageRefreshService = TestBed.get(ArisPageRefreshService);
    let arisGeoMarkerClustersDelegateService1 = TestBed.get(ArisGeoMarkerClustersDelegateService);
    arisGeoMarkerClustersDelegateService1.lastMapLayerId = 1;
    arisGeoMarkerClustersDelegateService1.lastMarkerId = 1;
    spyOn(pageRefreshService, 'getPageRefreshInExecution').and.returnValue(true);
    spyOn(arisGeoMarkerClustersDelegateService1, 'getInfoCardPromiseData').and.callFake(() => Promise.resolve(''));
    arisGeoMarkerClustersDelegateService1.updateInfoCardContent ({ id: 1 }, { id: 1 }, undefined);
    expect(arisGeoMarkerClustersDelegateService1.lastMapLayerId).toEqual(1);
  });

  it('Function updateInfoCardContent getInfoCardPromise() executed ', () => {
    let pageRefreshService = TestBed.get(ArisPageRefreshService);
    let arisGeoMarkerClustersDelegateService1 = TestBed.get(ArisGeoMarkerClustersDelegateService);
    arisGeoMarkerClustersDelegateService1.lastMapLayerId = 1;
    arisGeoMarkerClustersDelegateService1.lastMarkerId = 1;
    arisGeoMarkerClustersDelegateService1.mapLayerObj = { getInfoCardPromise () { return Promise.resolve(); } };
    spyOn(pageRefreshService, 'getPageRefreshInExecution').and.returnValue(true);
    arisGeoMarkerClustersDelegateService1.updateInfoCardContent ({ id: 1 }, { id: 1 }, undefined);
    expect(arisGeoMarkerClustersDelegateService1.lastMapLayerId).toEqual(1);
  });

  it('Function showInfoCard if executed ', () => {
    let pageRefreshService = TestBed.get(ArisPageRefreshService);
    let arisGeoCardService = TestBed.get(ArisGeoInfoCardService);
    let arisGeoMarkerClustersDelegateService1 = TestBed.get(ArisGeoMarkerClustersDelegateService);
    spyOn(pageRefreshService, 'getPageRefreshInExecution').and.returnValue(false);
    spyOn(arisGeoCardService, 'fromJson').and.callThrough();
    arisGeoMarkerClustersDelegateService1.showInfoCard ({ setInfoCardData() {} }, { id: 1 });
    expect(pageRefreshService.getPageRefreshInExecution).toHaveBeenCalled();
  });

  it('Function removeLegend if executed ', () => {
    let pageRefreshService = TestBed.get(ArisPageRefreshService);
    let arisGeoMarkerClustersDelegateService1 = TestBed.get(ArisGeoMarkerClustersDelegateService);
    arisGeoMarkerClustersDelegateService1.legends = { list: [{ id: 1 }] };
    arisGeoMarkerClustersDelegateService1.removeLegend(1);
    expect(arisGeoMarkerClustersDelegateService1).toBeTruthy();
  });

  it('Function removeLegend else executed ', () => {
    let pageRefreshService = TestBed.get(ArisPageRefreshService);
    let arisGeoMarkerClustersDelegateService1 = TestBed.get(ArisGeoMarkerClustersDelegateService);
    arisGeoMarkerClustersDelegateService1.legends = { list: [{ id: 2 }] };
    arisGeoMarkerClustersDelegateService1.removeLegend(1);
    expect(arisGeoMarkerClustersDelegateService1).toBeTruthy();
  });

  it('Function addLegends if executed ', () => {
    let pageRefreshService = TestBed.get(ArisPageRefreshService);
    let arisGeoMarkerClustersDelegateService1 = TestBed.get(ArisGeoMarkerClustersDelegateService);
    arisGeoMarkerClustersDelegateService1.legends = { list: [{ id: 1 }] };
    let maplayer = { legends() {}, id: 1, preFix: '/' };
    spyOn(maplayer, 'legends').and.returnValue([{ value: '.' }]);
    arisGeoMarkerClustersDelegateService1.addLegends(maplayer);
    expect(arisGeoMarkerClustersDelegateService1.legends).toBeDefined();
  });

  it('Function addLegends else executed ', () => {
    let pageRefreshService = TestBed.get(ArisPageRefreshService);
    let arisGeoMarkerClustersDelegateService1 = TestBed.get(ArisGeoMarkerClustersDelegateService);
    arisGeoMarkerClustersDelegateService1.legends = { list: [{ id: 1 }] };
    let maplayer = { legends() {}, id: 2, preFix: '/' };
    spyOn(maplayer, 'legends').and.returnValue([{ value: '.' }]);
    arisGeoMarkerClustersDelegateService1.addLegends(maplayer);
    expect(arisGeoMarkerClustersDelegateService1.legends).toBeDefined();
  });

  it('Function getMarkerIcon If executed ', () => {
    let pageRefreshService = TestBed.get(ArisPageRefreshService);
    let arisGeoMarkerClustersDelegateService1 = TestBed.get(ArisGeoMarkerClustersDelegateService);
    arisGeoMarkerClustersDelegateService1.legends = { list: [{ id: 1 }] };
    let maplayer = { legends() {}, id: 2, preFix: '/' };
    spyOn(maplayer, 'legends').and.returnValue([{ value: '.' }]);
    let result = arisGeoMarkerClustersDelegateService1.getMarkerIcon('.', 1, '/');
    expect(result).toBe('.');
  });

});
