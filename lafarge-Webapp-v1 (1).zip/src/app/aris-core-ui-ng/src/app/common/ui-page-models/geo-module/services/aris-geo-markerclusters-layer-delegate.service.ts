import { Injectable, ApplicationRef } from '@angular/core';
import { ArisDataSourceService } from '../../../services/aris-datasource.service';
import { ArisGeoInfoCardService } from './aris-geo-infocard.service';
import { ArisGeoService } from './aris-geo.service';
import { mapLayerTypes } from '../aris-geo-constants';
import { ArisPageRefreshService } from '../../../services/aris-page-refresh.service';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { LowerCasePipe } from '@angular/common';
import { TranslationService } from 'angular-l10n';
import { ArisGeoInfoCardCommonService } from './aris-geo-infocard-common.service';
import { ArisLanguageService } from '../../../ui-page-sections/language-selector-module/services/aris-language.service';

declare var google: any;
declare var MarkerClusterer: any;
let gMarkersArray: any = [];

@Injectable()
export class ArisGeoMarkerClustersDelegateService {
// Markers or Markers cluster for each map layer of type MARKER/CLUSTER.
  public markerClusterArray = [];
  // Legends for each map layer.
  public legends: any = {};
  public mapLayerObj: any = {}; // public gMarker;
  // public gMarkersArray: any = [];
  public lastMapLayerId: any = '';
  public lastMarkerId: any = '';
  public lastMaplayer: any;
  constructor(
    private arisDataSourceService: ArisDataSourceService,
    private arisGeoInfoCardService: ArisGeoInfoCardService,
    private arisGeoService: ArisGeoService,
    private arisPageRefreshService: ArisPageRefreshService,
    private http: HttpClient,
    private lowerCasePipe: LowerCasePipe,
    private translationService: TranslationService,
    private applicationRef: ApplicationRef,
    private arisGeoInfoCardCommonService: ArisGeoInfoCardCommonService,
    private arisLanguageService: ArisLanguageService
  ) {
    this.legends.list = [];
    this.arisLanguageService.languageChange.subscribe((data) => {
      if (this.lastMarkerId && this.lastMarkerId !== '') {
        this.updateInfoCardContent(this.lastMaplayer, this.lastMarkerId, false);
      }
    });
    this.arisGeoInfoCardCommonService.closeInfoCard.subscribe((data) => {
      if (this.lastMarkerId && this.lastMarkerId !== '') {
        this.lastMarkerId = '';
      }
    });
    // TODO TO DO : Uncomment this to can execute the protractor tests 
    window.selectMarker = function (markerId) {
      console.log(gMarkersArray);
      gMarkersArray.forEach((v, k) => {
        if (v.id === markerId) {
          google.maps.event.trigger(v, 'click');
        }
      });
    };
  }

  // Service export functions
  /**
   * Replace markerCluster.
   * param filterData value of geo filters
   * param dataRange value of date filter
   * param mapBounds value of  map
   * param mapLayer value of each mapLayer data
   * param map value of current maplayer
    */
  displayLayerOverlaysOnMap (mapLayer, map, mapBounds, filterData, dateRange, refreshPage) {
    this.mapLayerObj = mapLayer;
    console.log(mapBounds);
    let filterDataArray: any;
    if (filterData) {
      for (let i = 0; i < filterData.length; i += 1) {
        if (filterData[i].datasource === mapLayer.id) {
          filterDataArray = filterData[i];
          break;
        }
      }
    }

    let getMarkersPromise =  mapLayer.getMarkersPromise ? mapLayer.getMarkersPromise() :
    this.arisDataSourceService.getFromDataSource(mapLayer.id + 'Markers', filterDataArray, dateRange, 0, 1000, mapBounds, undefined);
    getMarkersPromise.then((response: any) => {
      if (refreshPage === false || refreshPage === undefined) {
        this.arisGeoInfoCardService.clear();
      }
     // Remove Current Markers;
      this.deleteMarkers(mapLayer.id, mapLayer.type);
      console.log(response);
     // Add Legends
      this.addLegends(mapLayer);
    // Get markers
      let marker;
      let markersArray = [];

      for (let i = 0; i < response.length; i += 1) {
        let latitude = response[i].latitude;
        let longitude = response[i].longitude;
        mapLayer.cluster = response[i].cluster;
        let markerIcon = mapLayer.markerIcon(response[i]);
        marker = new google.maps.Marker({
          map,
          position: new google.maps.LatLng(latitude, longitude),
          icon: this.getMarkerIcon(markerIcon, mapLayer.id, mapLayer.preFix),
          id: mapLayer.markerId(response[i]),
          title: mapLayer.markerTooltipTitle(response[i]).toString()
        });

        this.attachMarkerInfoCard(mapLayer, marker);
        markersArray.push(marker);
      }
      gMarkersArray = markersArray;

      if (mapLayer.type === mapLayerTypes.MARKER && (mapLayer.cluster === undefined || mapLayer.cluster === false)) {
        this.markerClusterArray[mapLayer.id] = markersArray;
      } else {
      // set marker cluster for map layer.
        // let clusterIcon = mapLayer.clusterIcon ? mapLayer.clusterIcon() : 'https://raw.githubusercontent.com/googlearchive/js-marker-clusterer/gh-pages/images/m';
        //window.app.config.geo.mapLayerClusterIconUrl = window.app.config.geo.mapLayerClusterIconUrl ? window.app.config.geo.mapLayerClusterIconUrl : 'https://raw.githubusercontent.com/googlemaps/js-marker-clusterer/gh-pages/images/m';
        window.app.config.geo.mapLayerClusterIconUrl = window.app.config.geo.mapLayerClusterIconUrl ? window.app.config.geo.mapLayerClusterIconUrl : 'app/common/resources/img/m';
        let clusterIcon = mapLayer.clusterIcon ? mapLayer.clusterIcon() : window.app.config.geo.mapLayerClusterIconUrl;
        let mcOptions;
        if (mapLayer.cluster === true) {
          mcOptions = {minimumClusterSize: 2,
            imagePath:   clusterIcon};
        } else {
          mcOptions = {minimumClusterSize: this.arisGeoService.getProperties().minimumClusterSize,
            imagePath:   clusterIcon};
        }
        this.markerClusterArray[mapLayer.id] = new MarkerClusterer(map, markersArray, mcOptions);
      }
    });
  }

 /**
 * Remove all markers.
  * @param layerId - Map Layer Id.
  * @param layerType - Map Layer Type.
  */
  removeLayerOverlaysFromMap (layerId, layerType) {
    this.deleteMarkers(layerId, layerType);
  }

  /**
   * Get legends model.
   */
  getLegends() {
    return this.legends;
  }
  /**
   * Clear info card data.
   */
  /**
   * Clear service singleton.
   */
  clear  () {
    this.markerClusterArray = [];
    this.legends.list = [];
    this.arisGeoInfoCardService.clear();
  }

  /**
   * Legend class.
   *
   * param value value of legend.
   *param desc description of legend.
   */
  legend(value, desc) {
    return { desc, value: './app/common/resources/img/marker_' + value };
  }

  getMarkerIcon(markerIcon, layerId, preFix) {
    let imagePathPreFix = preFix ? preFix : './';

    if (!markerIcon) {
      return imagePathPreFix + 'app/common/resources/img/marker_blue.png';
    }
    if (markerIcon.indexOf('.') >= 0) {
      return markerIcon;
    }
    return imagePathPreFix + 'app/common/resources/img/marker_' + this.lowerCasePipe.transform(layerId + '_' + markerIcon) + '.png';
  }

  getLegendIcon(legendIcon, layerId, preFix) {
    let legendPathPreFix = preFix ? preFix : '';

    if (legendIcon.indexOf('.') >= 0) {
      return legendIcon;
    }
    return legendPathPreFix + 'app/common/resources/img/marker_' +  this.lowerCasePipe.transform(layerId + '_' + legendIcon) + '.png';
  }

  /**
   * add Legends model for given map layer.
   *
   * param mapLayerId map layer id.
   * param mapLayerName map layer name.
   */
  addLegends(mapLayer) {
    if (!mapLayer.legends) {
      return;
    }

    let list = this.legends.list;
    let legendAux: any;
    for (let i = 0; i < list.length; i += 1) {
      if (list[i] !== undefined && list[i].id === mapLayer.id) {
        legendAux = list[i];
      }
    }
    if  (legendAux && legendAux.length > 0) {
      return;
    }

    let legendsArray = [];

    mapLayer.legends().forEach((legend, index) => {
      legend.value = this.getLegendIcon(legend.value, mapLayer.id, mapLayer.preFix);
      legendsArray.push(legend);
    });
    this.legends.list.push({ id: mapLayer.id, data : legendsArray, name: mapLayer.name });
  }

  /**
   * Remove legend from legend list.
   *
   * param mapLayerId id of the map layer.
   */
  removeLegend(mapLayerId) {
    let list = this.legends.list;
    let legend: any;
    for (let i = 0; i < list.length; i += 1) {
      if (list[i] !== undefined && list[i].id === mapLayerId) {
        legend = list[i];
      }
    }
    // let legend = $filter('filter')(list, { id: mapLayerId });
    if (legend && Object.keys(legend).length > 0) {
      this.legends.list.forEach((data, key) => {
        if (data['id'] === legend.id) {
          delete this.legends.list[key];
        }
      });
      console.log(this.legends);
      // list.splice(list.indexOf(legend[0]), 1);
    }
  }

  /**
   * Show infocard.
    *
    * param mapLayerId map layer id.
    * param mapLayerType map layer type.
    * param infoCardData infoCard data in json format.
    */
  showInfoCard(mapLayer, infoCardData) {
    // Covert json to generic POJO infocard data objects.
    if (this.arisPageRefreshService.getPageRefreshInExecution() === undefined ||
    this.arisPageRefreshService.getPageRefreshInExecution() === false) {
      this.arisGeoInfoCardService.fromJson(mapLayer, infoCardData);
      this.arisGeoInfoCardCommonService.onInfoCardDataChange.next();
      this.applicationRef.tick();
    }
  }

  /**
	  * attach infocard to marker.
	  *
	  * param mapLayerId map layer id.
	  * param mapLayerType map layer type.
	  * param marker Google Marker Object.
	  */
  attachMarkerInfoCard(mapLayer, marker) {
    google.maps.event.addListener(marker, 'click', () => {
      this.arisPageRefreshService.setPageRefreshInExecution(false);
      this.updateInfoCardContent(mapLayer, marker.id, false);
    });

    if (this.arisPageRefreshService.getPageRefreshInExecution() === true
    && mapLayer.id === this.lastMapLayerId
    && marker.id === this.lastMarkerId) {
      this.updateInfoCardContent(mapLayer, marker.id, true);
    }
  }

  getInfoCardPromiseData(dataSource, postParams) {
    return this.http.post(dataSource, postParams).toPromise();
  }

  updateInfoCardContent(newMapLayer, newMarkerId, refreshPage) {
    this.lastMaplayer = newMapLayer;
    this.lastMapLayerId = newMapLayer.id;
    this.lastMarkerId = newMarkerId;
    let dataSource = 'rest/getFromDataSource/' + newMapLayer.id + 'InfoCard' + '?offset=0&limit=1000';
    let postParams = [{ name: 'markerId' , values: [newMarkerId], op: 'eq', dbtype: 'String' }];
    if (refreshPage === false || refreshPage === undefined) {
      this.arisGeoInfoCardService.clear();
    }
    let getInfoCardPromise =  this.mapLayerObj.getInfoCardPromise ? this.mapLayerObj.getInfoCardPromise(postParams) : this.getInfoCardPromiseData(dataSource, postParams);

    getInfoCardPromise.then((response: any) => {
      if (response.length === 1) {
        this.showInfoCard(newMapLayer, response[0]);
      } else {
        console.error('response doesn\'t contain one record:' + newMarkerId);
      }
    });
  }

/**
  * Delete all markers.
  * param layerId - Map Layer Id.
  * param layerType - Map Layer Type.
  */
  deleteMarkers(layerId, layerType) {
    console.log('RemoveMarkers :' + layerId + ' marker');
    if (typeof this.markerClusterArray[layerId] !== 'undefined') {
      if (layerType === mapLayerTypes.MARKER) {
        console.log('RemoveMarkers 1:' + layerId + ' marker');
        for (let i = 0; i < this.markerClusterArray[layerId].length; i += 1) {
          this.markerClusterArray[layerId][i].setMap(null);
        }
      } else {
        if (this.markerClusterArray[layerId] !== undefined &&
            this.markerClusterArray[layerId].clearMarkers !== undefined) {
          this.markerClusterArray[layerId].clearMarkers();
        }
      }
      this.markerClusterArray[layerId] = [];
      this.removeLegend(layerId);
    }
  }

}
