import { TestBed } from '@angular/core/testing';

import { HttpClient, HttpHandler } from '@angular/common/http';
import { TranslationService, InjectorRef, TRANSLATION_CONFIG, LocaleService, LOCALE_CONFIG, TranslationHandler, TranslationProvider, LocaleStorage } from 'angular-l10n';
import { ArisPermissionPipe } from '../../../pipes/aris-permission.pipes';
import { Injector, ApplicationRef } from '@angular/core';
import { access } from 'fs';
import { ArisDataSourceService } from '../../../services/aris-datasource.service';
import { ArisGeoInfoCardService } from './aris-geo-infocard.service';
import { ArisGeoService } from './aris-geo.service';
import { ArisPageRefreshService } from '../../../services/aris-page-refresh.service';
import { LowerCasePipe } from '@angular/common';
import { ArisGeoInfoCardCommonService } from './aris-geo-infocard-common.service';
import { ArisLanguageService } from '../../../ui-page-sections/language-selector-module/services/aris-language.service';
import { ArisGeoShapeLayerDelegateService } from './aris-geo-shape-layer-delegate.service';
import { ArisConfigService } from '../../../../common/services/aris-config.service';

describe('ArisGeoShapeLayerDelegateService', () => {

  let arisDataSourceService: ArisDataSourceService;
  let arisGeoInfoCardService: ArisGeoInfoCardService;
  let arisGeoService: ArisGeoService;
  let arisPageRefreshService: ArisPageRefreshService;
  let http: HttpClient;
  let lowerCasePipe: LowerCasePipe;
  let translationService: TranslationService;
  let applicationRef: ApplicationRef;
  let arisGeoInfoCardCommonService: ArisGeoInfoCardCommonService;
  let arisLanguageService: ArisLanguageService;
  let arisGeoShapeLayerDelegateService: ArisGeoShapeLayerDelegateService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      schemas: [],
      imports: [],
      providers: [InjectorRef, Injector, ArisGeoService, ArisGeoInfoCardService, ArisGeoInfoCardCommonService,
        HttpClient, HttpHandler, ArisLanguageService, ArisPageRefreshService,
        TranslationService, ArisPermissionPipe, ArisDataSourceService,
        ArisGeoInfoCardService, ArisGeoShapeLayerDelegateService,
        ArisGeoService,
        ArisPageRefreshService,
        HttpClient,
        LowerCasePipe,
        TranslationService,
        ApplicationRef,
        ArisGeoInfoCardCommonService,
        ArisLanguageService, ArisConfigService
        ,  {
          provide: TRANSLATION_CONFIG,
          useValue: null
        }, LocaleService, {
          provide: LOCALE_CONFIG,
          useValue: null
        }, LocaleStorage, TranslationProvider, TranslationHandler, ArisDataSourceService]
      // providers: [TranslatePipe, ArisGeoService, ArisGeoInfoCardService,
      //   ArisGeoInfoCardCommonService, ArisConfigService, HttpClient, HttpHandler,
      //   ArisLanguageService, ArisFooterService, ArisPageRefreshService, TranslationService]
    }).compileComponents();
    lowerCasePipe = new LowerCasePipe();
    arisLanguageService = new ArisLanguageService();
    arisGeoInfoCardCommonService = new ArisGeoInfoCardCommonService(arisPageRefreshService, http, applicationRef);
    arisGeoShapeLayerDelegateService = new ArisGeoShapeLayerDelegateService(arisDataSourceService,
        arisGeoInfoCardService, arisGeoService, http);
  });

  afterEach(() => {
    arisGeoShapeLayerDelegateService = null;
  });

  it('ArisGeoShapeLayerDelegateService object should be created', () => {
    expect(arisGeoShapeLayerDelegateService).toBeTruthy();
  });

  it('Function degreeToMeter should return expected value', () => {
    expect(arisGeoShapeLayerDelegateService.degreeToMeter(-118.828125, 34.30714385628804)).toEqual([-13227886.365078125, 4070118.8815625]);
  });

  it('Function getRadius should return expected value', () => {
    expect(arisGeoShapeLayerDelegateService.getRadius(22)).toEqual(0.000004);
  });

  it('Function displayLayerOverlaysOnMap executed', () => {
    let arisGeoService1 = TestBed.get(ArisGeoService);
    let arisGeoShapeLayerDelegateService1 = TestBed.get(ArisGeoShapeLayerDelegateService);
    let mapLayer = { id: 1, type: 'geo', getMarkersPromise: undefined };
    let map = { overlayMapTypes: new Array() };
    let mapBounds = {};
    let filterData = [{ datasource: 1 }];
    let dateRange = 2;
    let refreshPage = false;
    spyOn(arisGeoService1, 'getMap').and.returnValue({ overlayMapTypes: [{ name: 'geo:1' }], removeAt() {} });
    spyOn(arisGeoService1, 'getProperties').and.returnValue({ geoServerWSName: 'geo' });
    arisGeoShapeLayerDelegateService1.displayLayerOverlaysOnMap (mapLayer, map, mapBounds, filterData, dateRange, refreshPage);
    expect(arisGeoService1.getMap).toHaveBeenCalled();
  });

  it('Function displayLayerOverlaysOnMap else executed', () => {
    let arisGeoService1 = TestBed.get(ArisGeoService);
    let arisGeoShapeLayerDelegateService1 = TestBed.get(ArisGeoShapeLayerDelegateService);
    let mapLayer = { id: "mapLayersService", type: 'geo', getMarkersPromise: undefined };
    let map = { overlayMapTypes: new Array(), setCenter() {}, setZoom() {} };
    let mapBounds = {};
    let filterData = [{ datasource: 1 }];
    let dateRange = 2;
    let refreshPage = false;
    spyOn(arisGeoService1, 'getMap').and.returnValue({ overlayMapTypes: [{ name: 'geo:1' }], removeAt() {} });
    spyOn(arisGeoService1, 'getProperties').and.returnValue({ geoServerWSName: 'leo' });
    arisGeoShapeLayerDelegateService1.displayLayerOverlaysOnMap (mapLayer, map, mapBounds, filterData, dateRange, refreshPage);
    expect(arisGeoService1.getMap).toHaveBeenCalled();
  });

  it('Function updateInfocardData if executed', () => {
    let arisGeoService1 = TestBed.get(ArisGeoService);
    let arisGeoShapeLayerDelegateService1 = TestBed.get(ArisGeoShapeLayerDelegateService);
    let mapLayer = { id: "mapLayersService", type: 'geo', getMarkersPromise: undefined };
    let map = { overlayMapTypes: { getLength() {}, getAt() { return { mapLayer: { id: 1, setInfoCardData() {} } }; } }, getZoom() {}, setZoom() {},
      getProjection() { return { fromLatLngToPoint() { return { x: 1, y: 1 }; } }; }, getBounds() { return { getNorthEast() {}, getSouthWest() { return { x: 1 }; } }; } };
    let latLng = { lat() { return 1.1; }, lng() { return 1.1; } };
    let filterData = [{ datasource: 1 }];
    let dateRange = 2;
    let refreshPage = false;
    spyOn(map.overlayMapTypes, 'getLength').and.returnValue(2);
    spyOn(arisGeoService1, 'getProperties').and.returnValue({ geoServerWSName: 'leo' });
    spyOn(map.getProjection(), 'fromLatLngToPoint').and.returnValue({ x: 1, y: 1 });
    spyOn(arisGeoShapeLayerDelegateService1, 'getInfocardData').and.callFake(() => Promise.resolve({ data: { features: 'len' } }));
    arisGeoShapeLayerDelegateService1.updateInfocardData(map, latLng);
    expect(arisGeoService1.getProperties).toHaveBeenCalled();
  });

  it('Function updateInfocardData else executed', () => {
    let arisGeoService1 = TestBed.get(ArisGeoService);
    let arisGeoShapeLayerDelegateService1 = TestBed.get(ArisGeoShapeLayerDelegateService);
    let mapLayer = { id: "mapLayersService", type: 'geo', getMarkersPromise: undefined };
    let map = { overlayMapTypes: { getLength() {}, getAt() { return { mapLayer: { id: 1, setInfoCardData() {} } }; } }, getZoom() {}, setZoom() {},
      getProjection() { return { fromLatLngToPoint() { return { x: 1, y: 1 }; } }; }, getBounds() { return { getNorthEast() {}, getSouthWest() { return { x: 1 }; } }; } };
    let latLng = { lat() { return 1.1; }, lng() { return 1.1; } };
    let filterData = [{ datasource: 1 }];
    let dateRange = 2;
    let refreshPage = false;
    spyOn(map.overlayMapTypes, 'getLength').and.returnValue(2);
    spyOn(arisGeoService1, 'getProperties').and.returnValue({ geoServerWSName: 'leo' });
    spyOn(map.getProjection(), 'fromLatLngToPoint').and.returnValue({ x: 1, y: 1 });
    spyOn(arisGeoShapeLayerDelegateService1, 'getInfocardData').and.callFake(() => Promise.resolve({ data: { features: undefined } }));
    arisGeoShapeLayerDelegateService1.updateInfocardData(map, latLng);
    expect(arisGeoService1.getProperties).toHaveBeenCalled();
  });

});
