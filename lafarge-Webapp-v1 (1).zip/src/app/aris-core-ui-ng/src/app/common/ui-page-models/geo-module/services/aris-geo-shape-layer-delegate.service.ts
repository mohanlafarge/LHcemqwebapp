import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/toPromise';
// import { environment } from '../../../../../environments/environment';

import { ArisGeoLayerDelegateService } from './aris-geo-layer-delegate.service';
import { ArisGeoInfoCardService } from './aris-geo-infocard.service';
import { ArisDataSourceService } from '../../../services/aris-datasource.service';
import { ArisGeoService } from './aris-geo.service';


declare let google: any;
/**
 * Service to delegate main GeoController's responsibility related to rendering data layer from geo-json.
 *
 */

@Injectable()
export class ArisGeoShapeLayerDelegateService extends ArisGeoLayerDelegateService {
  objectScope: any;
//   clickListener: any;

  constructor(private arisDataSourceService: ArisDataSourceService, private arisGeoInfoCardService: ArisGeoInfoCardService, 
                private arisGeoService: ArisGeoService, private http: HttpClient) {
    super();
    this.setObjectScope(this);
  }

  setObjectScope(objectScope) {
    this.objectScope = objectScope;
    this.objectScope.featuresArray = [];
    this.objectScope.tooltipWindow = null;
  }

/*
	 * show shape layer on map.
	 * @param data value of geo filters
	 * @param dataRange value of date filter
	 * @param mapBounds value of  map
	 * @param mapLayer value of each mapLayer data
	 * @param map value of current maplayer
	 */

  displayLayerOverlaysOnMap (mapLayer, map, mapBounds, filterData, dateRange, refreshPage) {
    let indexVal = -1;
    let layerId = mapLayer.id;
    let layerType = mapLayer.type;
    this.removeLayerOverlaysFromMap(layerId, layerType);
    console.log(this.arisGeoService.getProperties().geoServerWSName);

    if (indexVal === -1) {
      let SLPLayer = this.createGeoJsonLayer(mapLayer, map);
      map.overlayMapTypes.push(SLPLayer);
      this.arisGeoService.setMap(map);
    }
    if (window.app.config.geo[layerId]) {
      map.setCenter(new google.maps.LatLng(window.app.config.geo[layerId].latitude, window.app.config.geo[layerId].longitude));
      map.setZoom(window.app.config.geo.zoom);
    }

    this.attachedLayerInfocard(this.arisGeoService.getMap());
  }

  /*
	 * Remove shape layer from map.
	 * @param layerId - Map Layer Id.
	 * @param layerType - Map Layer Type.
    */

  removeLayerOverlaysFromMap (layerId, layerType) {
    let map =  this.arisGeoService.getMap();
    let indexVal = -1;
    let geoLayer = this.arisGeoService.getProperties().geoServerWSName + ':' + layerId;
    map.overlayMapTypes.forEach((d, i) => {
      if (d.name === geoLayer) {
        indexVal = i;
      }
    });
    if (indexVal > -1 && map.overlayMapTypes.removeAt) {
      map.overlayMapTypes.removeAt(indexVal);
    }
  }

/*
* Clear info card data.
*/
/*
* Clear service singleton.
*/
  clear() {
    this.arisGeoInfoCardService.clear();
  }

/* functions */
/*
    * Convert lat-long to google mercator (EPSG:4326 to EPSG:900913)
    * Reference: https://gist.github.com/springmeyer/871897
    *
    * @param lon - longitude.
    * @param lat - lattitude.
    * @return array containing google mercator position [x, y].
    */

  degreeToMeter(lon, lat) {
    let x = lon * 20037508.34 / 180;
    let y = Math.log(Math.tan((90 + lat) * Math.PI / 360)) / (Math.PI / 180);
    y = y * 20037508.34 / 180;
    return [x, y];
  }

  createGeoJsonLayer(mapLayer, map) {
    let geoLayer = this.arisGeoService.getProperties().geoServerWSName + ':' + mapLayer.id;
    console.log('shape layer:' + geoLayer);
    let SLPLayer = new google.maps.ImageMapType({
      getTileUrl:  (coord, zoom) => {
        let proj = map.getProjection();
        let zfactor = Math.pow(2, zoom);

        // get Long Lat coordinates
        let top = proj.fromPointToLatLng(new google.maps.Point(coord.x * 256 / zfactor, coord.y * 256 / zfactor));
        let bot = proj.fromPointToLatLng(new google.maps.Point((coord.x + 1) * 256 / zfactor, (coord.y + 1) * 256 / zfactor));

                // convert lat-long to google mercator (EPSG:4326 to EPSG:900913)
        let mercator1 = this.degreeToMeter(top.lng(), top.lat());
        let mercator2 = this.degreeToMeter(bot.lng(), bot.lat());
        // create the Bounding box string
        let bbox =  (mercator1[0]) + ',' +
                    (mercator2[1]) + ',' +
                    (mercator2[0]) + ',' +
                    (mercator1[1]);

        // base WMS URL
        let url = 'geoserver/'+'gwc/service/wms?';
        url += 'REQUEST=GetMap'; // WMS operation
        url += '&SERVICE=WMS';    // WMS service
        url += '&VERSION=1.1.1';  // WMS version
        url += '&LAYERS=' + geoLayer; // WMS layers
        url += '&FORMAT=image/png' ; // WMS format
        url += '&TRANSPARENT=TRUE';
        url += '&SRS=EPSG:900913';     // set google mercator
        url += '&BBOX=' + bbox;      // set bounding box
        url += '&WIDTH=256';         // tile size in google
        url += '&HEIGHT=256';
        return url;                 // return URL for the tile

      },
      tileSize: new google.maps.Size(256, 256),
      isPng: true,
      opacity: mapLayer.shapeLayerOpacity,
      name: geoLayer
    });
    SLPLayer.mapLayer = mapLayer;
    SLPLayer.addListener('places_changed',   (e) => {
      console.log('places_changed event triggered', e);
    });
    return SLPLayer;
  }

  attachedLayerInfocard(map) {
    google.maps.event.addListener(map, 'click', (e) => {
      let length = map.overlayMapTypes.getLength();
      if (length > 0) {
        this.updateInfocardData(map, e.latLng);
      }
    });
  }

  getInfocardData(url) {
    return this.http.get(url).toPromise();
  }

  updateInfocardData(map, latLng) {
    let length = map.overlayMapTypes.getLength();
    let mapLayer = map.overlayMapTypes.getAt(length - 1).mapLayer;
    let geoLayerName = this.arisGeoService.getProperties().geoServerWSName + ':' + mapLayer.id;
    let url = this.getFeatureInfoURL(latLng, geoLayerName, map);
    this.getInfocardData(url).then((d: any) => {
      console.log('new log', d.data.features);
      if (d.data.features !== undefined && d.data.features.length > 0) {
        // Covert json to generic POJO infocard data objects.
        this.arisGeoInfoCardService.fromJson(mapLayer, d.data.features);
      }
    });
  }

  getFeatureInfoURL(latLng, layerName, map) {
    console.log('map value', map);
    let lat = parseFloat(latLng.lat());
    let lng = parseFloat(latLng.lng());

    // console.info('------------------------------')
    let radius_degrees = this.getRadius(map.getZoom());
    let buffer_sw_y_dd = lat - radius_degrees;
    let buffer_sw_x_dd = lng - radius_degrees;
    let buffer_ne_y_dd = lat + radius_degrees;
    let buffer_ne_x_dd = lng + radius_degrees;

    let buffer_sw_dd = new google.maps.LatLng(buffer_sw_y_dd, buffer_sw_x_dd); // decimal degrees
    let buffer_ne_dd = new google.maps.LatLng(buffer_ne_y_dd, buffer_ne_x_dd); // decimal degrees

    let buffer_sw_px: any = this.fromLatLngToPoint(buffer_sw_dd, map); // pixels
    let buffer_ne_px: any = this.fromLatLngToPoint(buffer_ne_dd, map); // pixels

    let buffer_width_px: any = (Math.abs(buffer_ne_px.x - buffer_sw_px.x)).toFixed(0);
    let buffer_height_px: any = (Math.abs(buffer_ne_px.y - buffer_sw_px.y)).toFixed(0);

    let center_x_px = (buffer_width_px / 2).toFixed(0);
    let center_y_px = (buffer_height_px / 2).toFixed(0);

    let url = 'geoserver/' + this.arisGeoService.getProperties().geoServerWSName + '/wms?';
    url += '&SERVICE=WMS';
    url += '&VERSION=1.1.0';
    url += '&REQUEST=GetFeatureInfo';
    url += '&TRANSPARENT=true';
    url += '&QUERY_LAYERS=' + layerName;
    url += '&STYLES';
    url += '&LAYERS=' + layerName;
    url += '&INFO_FORMAT=application/json';      // text/html';
    url += '&SRS=EPSG:4326';
    url += '&FEATURE_COUNT=10';
    url += '&WIDTH=' + buffer_width_px;
    url += '&HEIGHT=' + buffer_height_px;
    url += '&Y=' + center_y_px;
    url += '&X=' + center_x_px;
    url += '&BBOX=' + buffer_sw_x_dd + ',' + buffer_sw_y_dd + ',' + buffer_ne_x_dd + ',' + buffer_ne_y_dd;

    return url;
  }

  fromLatLngToPoint(latLng, map) {
    let topRight = map.getProjection().fromLatLngToPoint(map.getBounds().getNorthEast());
    let bottomLeft = map.getProjection().fromLatLngToPoint(map.getBounds().getSouthWest());
    let scale = Math.pow(2, map.getZoom());
    let worldPoint = map.getProjection().fromLatLngToPoint(latLng);
    return new google.maps.Point((worldPoint.x - bottomLeft.x) * scale, (worldPoint.y - topRight.y) * scale);
  }

  getRadius(zoom) {
    let radius_px = 0.40 / 2;
    let constMetersDegress = 1000; // TODO Verifiy

    let scaled_zooms = {
      22: 0.02,
      21: 0.04,
      20: 0.09,
      19: 0.19,
      18: 0.37,
      17: 0.74,
      16: 1.48,
      15: 3,
      14: 6,
      13: 12,
      12: 24,
      11: 48,
      10: 95,
      9: 190,
      8: 378,
      7: 752,
      6: 1485,
      5: 2909,
      4: 5540,
      3: 10064,
      2: 16355,
      1: 21282,
      0: 30000
    };

    let radius_meters = radius_px * scaled_zooms[zoom];
    let radius_degrees = radius_meters / constMetersDegress;
    return radius_degrees;
  }

}


