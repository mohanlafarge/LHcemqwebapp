import { TestBed, async, fakeAsync, tick } from '@angular/core/testing';
import { ArisGeoService } from './aris-geo.service';
import { ArisConfigService } from '../../../services/aris-config.service';
import { ArisLanguageService } from '../../../ui-page-sections/language-selector-module/services/aris-language.service';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { Injector } from '@angular/core';
import { ArisGeoMapLayersService } from './aris-geo-maplayers.service';
import { TranslationService, InjectorRef, LocalizationModule } from 'angular-l10n';
import { ArisGeoModule } from '../aris-geo.module';
import { ArisModule } from '../../../../aris.module';
import { CommonModule } from '@angular/common';

describe('Test: Aris Geo Service', () => {

  const configMockData = {
    arisConfig: [{
      assetAttributeName: 'Map Initial Zoom',
      value: '10',
    }, {
      assetAttributeName: 'Map Initial Latitude',
      value: '33.758199',
    }, {
      assetAttributeName: 'Map Initial Longitude',
      value: '-84.425731',
    }],
  };
  beforeEach(() => TestBed.configureTestingModule({
    imports: [ArisGeoModule, ArisModule, CommonModule, LocalizationModule],
    providers: [ArisGeoService,
      ArisConfigService,
      Injector,
      HttpHandler,
      HttpClient,
      ArisLanguageService,
      ArisGeoMapLayersService,
      TranslationService,
      InjectorRef
    ]
  }));

  it('checking Geo Properties', () => {
    const asrisGeoService = TestBed.get(ArisGeoService);
    const arisConfigService = TestBed.get(ArisConfigService);
    arisConfigService.setArisConfig(configMockData.arisConfig);
    asrisGeoService.setProperties();
    let geopropeties = asrisGeoService.getProperties();
    expect(geopropeties.latitude).toEqual(33.758199);
    expect(geopropeties.longitude).toEqual(-84.425731);
    expect(geopropeties.zoomLevel).toEqual(10);
    expect(geopropeties.geoServerWSName).toEqual('LA');
    expect(geopropeties.mapLayersService).toEqual(ArisGeoMapLayersService);
  });
});
