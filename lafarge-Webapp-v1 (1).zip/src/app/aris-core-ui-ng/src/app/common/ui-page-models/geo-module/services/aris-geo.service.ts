import { Injectable, Injector } from '@angular/core';
import { ArisConfigService } from '../../../services/aris-config.service';
import { Subject } from 'rxjs/Subject';

declare global {
  interface Window { app: any; selectMarker: any; }
}


@Injectable()
export class ArisGeoService {
  private static geoProperties: any = undefined;

  onMapLayerClick: Subject<Object> = new Subject<Object>();
  onShowFilterByLayer: Subject<Object> = new Subject<Object>();
  showLegend: Subject<Object> = new Subject<Object>();

  map: any;
  mapLayersService: any;

  constructor(private arisConfigService: ArisConfigService, private injector: Injector) { }
  setProperties() {
    ArisGeoService.geoProperties = window.app.config.geo;
    ArisGeoService.geoProperties.latitude = parseFloat(this.arisConfigService.getParameter('Map Initial Latitude'));
    ArisGeoService.geoProperties.longitude = parseFloat(this.arisConfigService.getParameter('Map Initial Longitude'));
    ArisGeoService.geoProperties.zoomLevel = parseInt(this.arisConfigService.getParameter('Map Initial Zoom'), 10);
    ArisGeoService.geoProperties.minimumClusterSize = parseInt(this.arisConfigService.getParameter('Map Minimum Cluster Size'), 10);
    this.mapLayersService = this.injector.get(ArisGeoService.geoProperties.mapLayersService);
  }
  getProperties() {
    return ArisGeoService.geoProperties;
  }
  getMapLayersService() {
    return this.mapLayersService;
  }
  setMap(mapIn) {
    this.map = mapIn;
  }
  getMap()  {
    return this.map;
  }
}
