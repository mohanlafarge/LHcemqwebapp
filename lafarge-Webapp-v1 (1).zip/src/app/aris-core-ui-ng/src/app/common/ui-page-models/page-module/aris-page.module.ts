import { LocalizationModule } from "angular-l10n";
import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule, Routes } from "@angular/router";

import { ArisPageComponent } from "./components/aris-page.component";
import { FilterModule } from "../../ui-page-sections/filter-panel-module/aris-filter.module";
import { ArisSessionService } from "../../services/aris-session.service";
import { ArisHeaderService } from "../../ui-page-sections/header-module/services/aris-header-service";
import { ArisPageService } from "../../services/aris-page-service";
import { ArisPageDashboardService } from "./services/aris-page-dashboard.service";
import { ArisDynamicPageModule } from "../aris-dynamic-page-module/aris-dynamic-page.module";
import { ArisFilterService } from "../../services/aris-filter.service";
import { ArisUiComponentsModule } from "../../ui-components/aris-ui-components.module";

@NgModule({
  declarations: [ArisPageComponent],
  imports: [
    RouterModule,
    LocalizationModule,
    CommonModule,
    ArisDynamicPageModule,
    FilterModule,
    ArisUiComponentsModule
  ],
  providers: [
    ArisSessionService,
    ArisHeaderService,
    ArisPageService,
    ArisPageDashboardService,
    ArisFilterService
  ],
  exports: [ArisPageComponent]
})
export class ArisPageModule {}
