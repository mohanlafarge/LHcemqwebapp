import { TestBed, ComponentFixture } from '@angular/core/testing';
import { DebugElement, ChangeDetectorRef, Type, Injector } from '@angular/core';
import { HttpClientModule, HttpClient, HttpRequest, HttpEvent, HttpHeaders, HttpParams, HttpHandler  } from '@angular/common/http';
import { ReactiveFormsModule, FormControl, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG, LocaleService } from 'angular-l10n';
import { RouterModule, Router, ActivatedRoute, ActivatedRouteSnapshot, UrlSegment, Params, Data, Route, ParamMap } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs/Observable';

import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpObserve } from '@angular/common/http/src/client';
import { ArisPageComponent } from './aris-page.component';
import { ArisDataSourceService } from '../../../services/aris-datasource.service';
import { ArisDynamicPageModule } from '../../aris-dynamic-page-module/aris-dynamic-page.module';
import { FilterModule } from '../../../ui-page-sections/filter-panel-module/aris-filter.module';
import { ArisSessionService } from '../../../services/aris-session.service';
import { ArisHeaderService } from '../../../ui-page-sections/header-module/services/aris-header-service';
import { ArisPageDashboardService } from '../services/aris-page-dashboard.service';
import { ArisPageService } from '../../../services/aris-page-service';
import { ArisFilterService } from '../../../services/aris-filter.service';
import { ArisLanguageService } from '../../../ui-page-sections/language-selector-module/services/aris-language.service';
import { ArisPageSectionObservableEventService } from '../../../ui-page-sections/services/aris-page-section-observable-event.service';
import { ArisPermissionService } from '../../../services/aris-permission.service';
import { ArisConfigService } from '../../../services/aris-config.service';
import { ArisNotificationBoxService } from '../../../ui-page-sections/error-module/services/aris-notification-box.service';
import { ArisFooterService } from '../../../ui-page-sections/footer-module/services/aris-footer-service';
import { ArisLoginService } from '../../../services/aris-login.service';
import { ArisUiComponentsModule } from '../../../ui-components/aris-ui-components.module';
import { ArisWebSocketService } from '../../../services/aris-websocket.service';

export class MockActivatedRoute implements ActivatedRoute {
  snapshot: ActivatedRouteSnapshot;
  url: Observable<UrlSegment[]>;
  params: Observable<Params>;
  queryParams: Observable<Params>;
  fragment: Observable<string>;
  data: Observable<Data>;
  outlet: string;
  component: Type<any>|string;
  routeConfig: Route;
  root: ActivatedRoute;
  parent: ActivatedRoute;
  firstChild: ActivatedRoute;
  children: ActivatedRoute[];
  pathFromRoot: ActivatedRoute[];
  paramMap: Observable<ParamMap>;
  queryParamMap: Observable<ParamMap>;
  toString(): string {
    return "";
  }
}

export class MockHttpClient extends HttpClient {
}

class PageModel {
  layout: any[] = new Array();
  pageService: any;
  name: any;
}
let mockRouter = {
  navigate: jasmine.createSpy('navigate')
};
describe('Test: Aris Page Component', () => {

  let component: ArisPageComponent;
  let fixture: ComponentFixture<ArisPageComponent>;
  let arisPageComponent:  ArisPageComponent;
  let arisPageComponent1:  ArisPageComponent;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;
  let pageModel = new PageModel();
  let newPageModel = new PageModel();
  let newPageModel1 = new PageModel();
  newPageModel1.name = "tiles";
  newPageModel.name = undefined;
  pageModel.layout = ['layoutIndex', { dataSourceId: 1 }];
  pageModel.name = "";
  pageModel.pageService = undefined;
  let data = {
    oldFilterData:  ['seven'],
    filterData: [
      {criterias:
                 ['four']
      }
    ],
    dsList: ['id', 'ten'],
    criterias: ['one'],
    dateRange: [],
    refreshPage: true
  };

  let data1 = {
    oldFilterData:  ['seven'],
    filterData: [
      {criterias:
                 ['four']
      }
    ],
    dsList: ['id', 'ten'],
    criterias: ['one'],
    dateRange: [],
    refreshPage: false
  };
  let filterCategories = [
    { oldFilterData:  { criterias: ['four'] } },
    { dsList: ['id', 'ten'] },
    { dsList: ['id', 'ten'] }
  ];
  let promise1 = new Promise<Object>(Object);
  let dataSource: any = {id: 'id', url: 'http://localhost:8080/', endPoint: 'http://localhost:8080/',
    promise: promise1, toPromise() {}, customDataHandler() {}};
  let dataSource1: any = {id: 'id', url: 'http://localhost:8080/', endPoint: 'http://localhost:8080/',
    promise: promise1, toPromise() {}, fetchResponseData() {}};
  let dataSource2: any = {id: 'id', url: 'http://localhost:8080/', endPoint: 'http://localhost:8080/',
    promise: promise1, toPromise() {}, responseDataFormat: 'csv'};
  let dataSource3: any = {id: 'id', url: 'http://localhost:8080/', endPoint: 'http://localhost:8080/',
    promise: promise1, toPromise() {}, responseDataFormat: 'tsv'};
  let dataSources = new Map<string, any>();
  dataSources.set('id1', dataSource);
  dataSources.set('id', dataSource);
  let refreshPage = true;
  let arisDataSourceService: ArisDataSourceService;
  let http: HttpClient;
  let filterData = { criterias:  ['four'] };
  let dateRange: any = {};
  let arisPageDashboardService: ArisPageDashboardService;
  let permissionService: ArisPermissionService;
  let arisPageService: ArisPageService;
  let footerService: ArisFooterService;
  let arisWebSocketService: ArisWebSocketService;
  let injector: Injector;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        ArisPageComponent
      ],
      imports: [
        RouterModule,
        LocalizationModule,
        CommonModule,
        ArisDynamicPageModule,
        FilterModule,
        HttpClientTestingModule,
        ArisUiComponentsModule
      ],
      providers: [
        ArisSessionService,
        ArisHeaderService,
        ArisPageService,
        ArisPageDashboardService,
        ArisFilterService, ArisLoginService,
        InjectorRef, Injector, ArisFooterService,
        { provide: Router, useValue: mockRouter }, { provide: HttpClient, useClass: MockHttpClient }, { provide: ActivatedRoute, useValue: {
          params: Observable.of({ geoLayerName: "destPage" })
        } }, { provide: ArisNotificationBoxService },
        ArisDataSourceService, ArisPageSectionObservableEventService, ArisPermissionService, ArisConfigService,
        ArisLanguageService, { provide: ToastrService }, { provide: LocaleService }, { provide: TranslationService },
        ArisWebSocketService
      ]
    }).compileComponents();

    afterAll(() => {
      component = null;
      arisPageComponent = null;
      arisPageComponent1 = null;
        });
    // create component and test fixture
    fixture = TestBed.createComponent(ArisPageComponent);

    // get test component from the fixture
    component = fixture.componentInstance;
    // component.pageModel = pageModel;
    component.filterCategoriesConfig = filterCategories;
    component.dataSources = dataSources;
    arisPageComponent1 = fixture.componentInstance;
    arisDataSourceService = TestBed.get(ArisDataSourceService);
    arisPageDashboardService = TestBed.get(ArisPageDashboardService);
    permissionService = TestBed.get(ArisPermissionService);
    arisPageService = TestBed.get(ArisPageService);
    footerService = TestBed.get(ArisFooterService);
    arisWebSocketService = TestBed.get(ArisWebSocketService);
    injector = TestBed.get(Injector);
    component.ngOnInit();
  });
  afterEach(() => {
    arisDataSourceService = null;
    arisPageDashboardService = null;
    permissionService = null;
    arisPageService = null;
    footerService = null;
    injector = null;
    component = null;
    arisPageComponent1 = null;
  });

  it('updateDataSourceList executed', () => {
    arisPageComponent = fixture.componentInstance;
    arisPageComponent.pageModel = newPageModel;
    arisPageComponent.filterCategoriesConfig = filterCategories;
    arisPageComponent.dataSources = dataSources;
    arisDataSourceService = TestBed.get(ArisDataSourceService);

    arisPageComponent.ngOnInit();
    spyOn(arisPageComponent, 'refreshAllDataSources').and.callThrough();
    arisPageComponent.updateDataSourceList();
    expect(arisPageComponent.refreshAllDataSources).toHaveBeenCalled();
  });

  it('updateDataSources executed', () => {
    component.activatedRouteSubscription = undefined;
    component.ngOnDestroy();
    component.updateDataSources(data);
    expect(component.oldDateRange).toEqual([]);
  });

  it('updateDataSources refreshPage is false executed', () => {
    component.activatedRouteSubscription = undefined;
    component.ngOnDestroy();
    component.updateDataSources(data1);
    expect(component.oldDateRange).toEqual([]);
  });

  it('updateDataSources else executed', () => {
    component.updateDataSources(null);
    expect(component.dataSources).toEqual(new Map());
  });

  it('refreshAllDataSources executed', () => {
    component.refreshAllDataSources();
    expect(component.dataSources).toBeDefined();
  });

  it('fetchJsonResponseData executed', () => {
    spyOn(component, 'getUrl').and.callThrough();
    spyOn(arisDataSourceService, 'getFromDataSource').and.callThrough();
    component.fetchJsonResponseData(dataSource, refreshPage, filterData, dateRange);
    expect(component.getUrl).toHaveBeenCalled();
  });

  it('fetchJsonResponseData else scenario executed', () => {
    let dataSourceObj = { url: undefined, endPoint: undefined, promise: undefined };
    spyOn(component, 'getUrl').and.callThrough();
    spyOn(arisDataSourceService, 'getFromDataSource').and.callThrough();
    component.fetchJsonResponseData(dataSourceObj, refreshPage, filterData, dateRange);
    expect(component).toBeTruthy();
  });

  it('angularEquals executed', () => {
    let result = component.angularEquals(data, filterCategories);
    expect(result).toBeFalsy();
  });

  it('onResponseError executed', () => {
    let dataSources1 = new Map<string, any>();
    dataSources1.set('id1', dataSource);
    dataSources1.set('id', dataSource);
    component = fixture.componentInstance;
    component.pageModel = pageModel;
    component.filterCategoriesConfig = filterCategories;
    component.dataSources = dataSources1;
    component.onResponseError(dataSource);
    expect(component.dataSources.get(dataSource.id).data).toEqual([]);
  });

  it('onResponseData executed', () => {
    let dataSources1 = new Map<string, any>();
    dataSources1.set('id1', dataSource);
    dataSources1.set('id', dataSource);
    component = fixture.componentInstance;
    component.pageModel = pageModel;
    component.filterCategoriesConfig = filterCategories;
    component.dataSources = dataSources1;
    spyOn(component, 'resetData').and.callThrough();
    component.onResponseData(dataSource, data, refreshPage);
    expect(component.resetData).toHaveBeenCalled();
  });

  it('onResponseData else scenario executed', () => {
    let dataSources1 = new Map<string, any>();
    dataSources1.set('id1', dataSource);
    dataSources1.set('id', dataSource);
    component = fixture.componentInstance;
    component.pageModel = pageModel;
    component.filterCategoriesConfig = filterCategories;
    component.dataSources = dataSources1;
    let dataSourceVal = { customDataHandler: undefined, id: 'id' };
    component.onResponseData(dataSourceVal, data, false);
    expect(component).toBeTruthy();
  });

  it('resetData else executed', () => {
    component.dataSources = undefined;
    component.resetData(undefined);
    expect(component.dataSources).toBeUndefined();
  });

  it('onFilterLoaded executed', () => {
    spyOn(component, 'updateDataSources').and.callThrough();
    component.onFilterLoaded(data);
    expect(component.updateDataSources).toHaveBeenCalled();
  });

  it('onFilterChange executed', () => {
    spyOn(component, 'updateDataSources').and.callThrough();
    component.onFilterChange(data);
    expect(component.updateDataSources).toHaveBeenCalled();
  });

  it('onPageRefresh executed', () => {
    spyOn(component, 'updateDataSources').and.callThrough();
    component.onPageRefresh(data);
    expect(component.updateDataSources).toHaveBeenCalled();
  });

  // it('fetchCsvResponseData executed', () => {
  //   spyOn(component, 'onResponseError').and.callThrough();
  //   component.fetchCsvResponseData(dataSource, refreshPage);
  //   expect(this.onResponseError).toBeUndefined();
  // });

  it('getDataFromService if executed for fetchResponseData', () => {
    let dataSources1 = new Map<string, any>();
    dataSources1.set('id1', dataSource);
    dataSources1.set('id', dataSource);
    component = fixture.componentInstance;
    component.pageModel = pageModel;
    component.filterCategoriesConfig = filterCategories;
    component.dataSources = dataSources1;
    spyOn(component, 'resetData').and.callThrough();
    component.getDataFromService(dataSource1, refreshPage);
    expect(component.resetData).toHaveBeenCalled();
  });

  it('getDataFromService refreshPage true executed for fetchResponseData', () => {
    let dataSources1 = new Map<string, any>();
    dataSources1.set('id1', dataSource);
    dataSources1.set('id', dataSource);
    component = fixture.componentInstance;
    component.pageModel = pageModel;
    component.filterCategoriesConfig = filterCategories;
    component.dataSources = dataSources1;
    component.getDataFromService(dataSource1, undefined, undefined, true);
    expect(component).toBeTruthy();
  });

  it('getDataFromService else executed for fetchCsvResponseData', () => {
    let dataSources1 = new Map<string, any>();
    dataSources1.set('id1', dataSource);
    dataSources1.set('id', dataSource);
    component = fixture.componentInstance;
    component.pageModel = pageModel;
    component.filterCategoriesConfig = filterCategories;
    component.dataSources = dataSources1;
    spyOn(component, 'fetchCsvResponseData').and.callThrough();
    component.getDataFromService(dataSource2, refreshPage);
    expect(component.fetchCsvResponseData).toHaveBeenCalled();
  });

  it('getDataFromService else executed for fetchTsvResponseData', () => {
    let dataSources1 = new Map<string, any>();
    dataSources1.set('id1', dataSource);
    dataSources1.set('id', dataSource);
    component = fixture.componentInstance;
    component.pageModel = pageModel;
    component.filterCategoriesConfig = filterCategories;
    component.dataSources = dataSources1;
    spyOn(component, 'fetchTsvResponseData').and.callThrough();
    component.getDataFromService(dataSource3, refreshPage);
    expect(component.fetchTsvResponseData).toHaveBeenCalled();
  });

  // it('fetchTsvResponseData executed', () => {
  //   spyOn(component, 'onResponseError').and.callThrough();
  //   component.fetchTsvResponseData(dataSource, refreshPage);
  //   expect(this.onResponseError).toBeUndefined();
  // });

  it('ngOnInit getPermissions returns undefined scenario', () => {
    arisPageComponent1.pageModel = newPageModel1;
    // arisPageComponent1.pageModel.pageService = arisPageService;
    arisPageComponent1.filterCategoriesConfig = filterCategories;
    arisPageComponent1.dataSources = dataSources;
    let dataObj = { filterCategories: 'filterCategories', jsonConfig: { filterCategoriesConfig: 'filterCategoriesConfig' },
      pageConfig: { permission: true }, pageModel: { name: 'name' } };
    spyOn(permissionService, 'hasPermission').and.returnValue(true);
    spyOn(permissionService, 'getPermissions').and.returnValue(undefined);
    spyOn(injector, 'get').and.returnValue('ArisPageService');
    spyOn(arisPageDashboardService, 'getPage').and.returnValue(dataObj);
    spyOn(arisWebSocketService, 'disconnectAll').and.callThrough();
    arisPageComponent1.ngOnInit();
    expect(arisPageComponent1.showLoader).toBeTruthy();
  });

  it('ngOnInit if scenario for permisssion service negation scenario to be Truthy executed', () => {
    arisPageComponent1.pageModel = newPageModel1;
    arisPageComponent1.filterCategoriesConfig = filterCategories;
    arisPageComponent1.dataSources = dataSources;
    spyOn(injector, 'get').and.returnValue('ArisPageService');
    arisPageComponent1.ngOnInit();
    expect(arisPageComponent1.dataSources).toBeDefined();
  });

  it('ngOnInit getPermissions returns a value scenario', () => {
    arisPageComponent1.pageModel = newPageModel;
    arisPageComponent1.filterCategoriesConfig = filterCategories;
    arisPageComponent1.dataSources = dataSources;
    let dataObj = { filterCategories: 'filterCategories', jsonConfig: { filterCategoriesConfig: 'filterCategoriesConfig' },
      pageConfig: { permission: true }, pageModel: { name: 'name' } };
    spyOn(permissionService, 'hasPermission').and.returnValue(true);
    spyOn(permissionService, 'getPermissions').and.returnValue(dataObj);
    spyOn(footerService, 'getFooterInfo').and.returnValue(undefined);
    spyOn(arisPageService, 'setPageName').and.returnValue('filterCategories');
    spyOn(injector, 'get').and.returnValue('ArisPageService');
    spyOn(arisPageDashboardService, 'getPage').and.returnValue(dataObj);
    arisPageComponent1.ngOnInit();
    expect(arisPageComponent1.showLoader).toBeFalsy();
  });

  it('ngOnInit footerInfo if condition scenario', () => {
    component.pageModel = newPageModel1;
    component.filterCategoriesConfig = filterCategories;
    component.dataSources = dataSources;
    let dataObj = { filterCategories: 'filterCategories', jsonConfig: { filterCategoriesConfig: 'filterCategoriesConfig' },
      pageConfig: { permission: true }, pageModel: { name: 'name' } };
    let footerData = { UIElements: { editLayout: true, All: true } };
    let promiseData = { content: '["val"]' };
    spyOn(permissionService, 'hasPermission').and.returnValue(true);
    spyOn(permissionService, 'getPermissions').and.returnValue(dataObj);
    spyOn(footerService, 'getFooterInfo').and.returnValue(footerData);
    spyOn(arisPageService, 'setPageName').and.returnValue('filterCategories');
    spyOn(injector, 'get').and.returnValue('ArisPageService');
    spyOn(arisPageDashboardService, 'getPage').and.returnValue(dataObj);
    spyOn(arisPageDashboardService, 'getPageModel').and.callFake(() => Promise.resolve(promiseData));
    component.ngOnInit();
    expect(component.showLoader).toBeTruthy();
    expect(arisPageService.setPageName).toHaveBeenCalled();
  });

  it('ngOnInit getPageModel else condition scenario', () => {
    component.pageModel = newPageModel1;
    component.filterCategoriesConfig = filterCategories;
    component.dataSources = dataSources;
    let dataObj = { filterCategories: 'filterCategories', jsonConfig: { filterCategoriesConfig: 'filterCategoriesConfig' },
      pageConfig: { permission: true }, pageModel: { name: 'name' } };
    let footerData = { UIElements: { editLayout: true, All: true } };
    let promiseData = { content: '' };
    spyOn(permissionService, 'hasPermission').and.returnValue(true);
    spyOn(permissionService, 'getPermissions').and.returnValue(dataObj);
    spyOn(footerService, 'getFooterInfo').and.returnValue(footerData);
    spyOn(arisPageService, 'setPageName').and.returnValue('filterCategories');
    spyOn(injector, 'get').and.returnValue('ArisPageService');
    spyOn(arisPageDashboardService, 'getPage').and.returnValue(dataObj);
    spyOn(arisPageDashboardService, 'getPageModel').and.callFake(() => Promise.resolve(promiseData));
    component.ngOnInit();
    expect(component.showLoader).toBeTruthy();
    expect(arisPageService.setPageName).toHaveBeenCalled();
  });

});
