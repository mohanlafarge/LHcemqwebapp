import { Component, OnInit, Injector, Input, OnDestroy } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/switchMap';
import * as d3_ from 'd3';
let d3: any = (<any>d3_).default || d3_;

import { ArisFilterService } from '../../../services/aris-filter.service';
import { ArisPermissionService } from '../../../services/aris-permission.service';
import { ArisHeaderService } from '../../../ui-page-sections/header-module/services/aris-header-service';
import { ArisFooterService } from '../../../ui-page-sections/footer-module/services/aris-footer-service';
import { ArisDataSourceService } from '../../../services/aris-datasource.service';
import { ArisLoginService } from '../../../services/aris-login.service';
import { ArisPageDashboardService } from '../services/aris-page-dashboard.service';
import { ArisPageService } from '../../../services/aris-page-service';

@Component({
  selector: 'aris-page',
  template: `<ng-template #x><div class="view-wrapper container-fluid">
	<div class="aris-page s-mrL2 s-mrR2">
    <div class="clearfix row row-margin">
      <div *ngIf="pageModel===undefined">
        <ng-content></ng-content>
      </div>
      <div *ngIf="pageModel!==undefined">
        <!-- Loader -->
			<div *ngIf="showLoader" style="height:100%;width:100%;text-align: center;position: absolute;margin-top: 120px;"> <aris-loading></aris-loading> </div>

			<div *ngIf="!showLoader && !pageModel">
				<router-outlet></router-outlet>
			</div>

			<div *ngIf="!showLoader && pageModel">
				<aris-dynamic-page [pageModel]="pageModel"></aris-dynamic-page>
				<!-- Filter layout -->
				<aris-filter [pageType]="pageModel.type"
										filterPanelCategoryTab="filterPanelCategoryTab"
										[pageName]="pageModel.name"
										(onPageRefresh)="onPageRefresh($event)"
										(onFilterChange)="onFilterChange($event)"
										(onFilterLoaded)="onFilterLoaded($event)"
										[showRefreshData]="showRefreshData">
				</aris-filter>
        </div>
      </div>
		</div>
	</div>
</div></ng-template>
<ng-container *ngTemplateOutlet="x"></ng-container>
`
})
export class ArisPageComponent implements OnInit, OnDestroy {

  // console.log("pageId:")
  // console.log($routeParams.pageId);
  // if(!$routeParams.pageId){
  //   return;
  // }

  showLoader = true;
  // Chart options for each chart tile.
  chartOptions: Map<string, any>= new Map();
  // Different datasource used in the page
  dataSources: Map<string, any>= new Map();
  // Old date range in filter
  oldDateRange = {};
  // PageService
  // arisPageService;
  @Input() pageModel: any;
  destinationPage: string;

  activatedRouteSubscription: any;

  filterCategoriesConfig: any;

  showRefreshData: Subject<any> = new Subject();

  constructor(private router: Router,
              private injector: Injector,
              private http: HttpClient,
              private activateRoute: ActivatedRoute,
              private arisDataSourceService: ArisDataSourceService,
              private arisFilterService: ArisFilterService,
              private headerService: ArisHeaderService,
              private footerService: ArisFooterService,
              private permissionsService: ArisPermissionService,
              private arisLoginService: ArisLoginService,
              private arisPageService: ArisPageService,
              private arisPageDashboardService: ArisPageDashboardService) { }

  ngOnInit(): void {
    this.activatedRouteSubscription = this.activateRoute.params.subscribe(params =>
        this.destinationPage = params['destPage']
      );
    this.showLoader = true;

/*      if (this.destinationPage !== null) {
        this.arisPageService.initPage('path', this.destinationPage);
      } else {
        this.arisPageService.initPage('path', 'ARIS-UI');
      }

      if (this.destinationPage === undefined || this.destinationPage === '' || window.app.config[this.destinationPage] === undefined) {
        this.showLoader = false;
        return;
      }*/
    // if (this.destinationPage !== null && window.app.config[this.destinationPage] !== undefined) {
    //     this.pageModel = window.app.config[this.destinationPage];
    // }

    if (this.pageModel === undefined || this.pageModel.name === undefined) {
      this.showLoader = false;
      return;
    }

    if (this.pageModel.pageService !== undefined) {
      this.arisPageService = this.injector.get(this.pageModel.pageService);
    }

    if (window.app.config[this.pageModel.name] === undefined) {
      this.showLoader = false;
      return;
    }
    let pageLayoutObj = Object.assign({}, window.app.config[this.pageModel.name]);

    this.arisPageDashboardService.setPage(this, pageLayoutObj);

    let page = this.arisPageDashboardService.getPage();
    let pageModel = page.pageModel;

    this.filterCategoriesConfig = page.filterCategories;
    let pageConfig = page.pageConfig;
    let headerConfig = page.headerConfig;
    let footerConfig = page.footerConfig;

    if (page.filterCategories) {
      this.arisFilterService.setFilterConfig(page.jsonConfig.filterCategoriesConfig);
    } else {
      this.arisFilterService.setFilterConfig(null);
    }

      // var footerConfig = app.config.footerTypes.footerTypes[footerService.getFooterVariable()];

// Unnecessary Code - This is controller in 'aris-route.module.ts'
/*
    if (!this.permissionsService.hasPermission(pageConfig.permission)) {
      let commInfo: any = {};
      commInfo.status = '401';
      commInfo.title = 'CLI_ERR_TIT_ACCES_DENIED';
      commInfo.message = 'CLI_ERR_DESC_PERMISSION_AREA_DENIED';
      this.router.navigate(['/error/' + JSON.stringify(commInfo)]);
      return;
    }
*/
    this.headerService.setHeaderMap(headerConfig);

    this.footerService.setFooterInfo(footerConfig);

    let footerInfo = this.footerService.getFooterInfo();

      // This needs to be set because filter uses these params. If we wait till response is recieved from web-service, filter directive will take unset values.
// TO DO : WHY is it necessary the next line??
      // this.pageModel = {'name': pageModel.name, 'type': pageModel.type};

    let permissions = this.permissionsService.getPermissions();

    if (permissions === undefined || Object.keys(permissions).length === 0) {
      this.arisLoginService.logout();
    } else {
      this.arisPageService.setPageName(pageModel.name);
      if (footerInfo && (footerInfo.UIElements.editLayout || footerInfo.UIElements.All)) {
        // ToDo-If page is saved in server and UI is modified(pageModel content), it will not be reflected.
        // Hence during development, it is recommented to comment $http.get() call and use explicity model from source
        // by uncommenting next two commented lines
        this.arisPageDashboardService.getPageModel(pageModel.name).then((response: any) => {
          if (response !== null && response !== undefined &&
              response.content !== undefined &&
              response.content.length > 0) {
              /* Pages personalize
                * Paint page using page model recovered of DB
                */
            page.jsonConfig.layout = JSON.parse(response.content).layout;
//                  this.pageModel.jsonConfig = Object.assign(window.app.config[this.pageModel.name], );
              // Refresh the page layout with DB
            this.arisPageDashboardService.setPageLayouts(this, page);
            this.updateDataSourceList();
          } else {
              /* Pages standard
                * Paint page using page model controller
                */
            this.pageModel = pageModel;
            this.updateDataSourceList();
          }
        }).catch((err: any) => {
          /* Pages standard
          * Paint page using page model controller
          */
          this.pageModel = pageModel;
          this.updateDataSourceList();
        });
      } else {
        this.pageModel = pageModel;
        this.updateDataSourceList();
      }
    } // permissions


/*** TO DO
          // Update data sources based on changed filters.
          if (footerInfo && (footerInfo.UIElements.filter || footerInfo.UIElements.All) && destinationPage !== 'chartGallery') {
            $scope.$on('onFilterLoaded', function(event, data) {
                this.updateDataSources(data);
            });
            $scope.$on('onFilterChange', function(event, data) {
                this.updateDataSources(data);
            });
          }
*******/
  }

  ngOnDestroy() {
    if (this.activatedRouteSubscription) {
      this.activatedRouteSubscription.unsubscribe();
    }
  }

  updateDataSourceList() {
    this.showLoader = false;
    let pageLayouts = this.pageModel.layout;
    let dataSourceList = {};
    for (let layoutIndex = 0; layoutIndex < pageLayouts.length ; ++layoutIndex) {
      for (let tileIndex = 0; tileIndex < pageLayouts[layoutIndex].length ; ++tileIndex) {
        if (pageLayouts[layoutIndex][tileIndex] && pageLayouts[layoutIndex][tileIndex].dataSourceId) {
          let tile = pageLayouts[layoutIndex][tileIndex];
          if (!dataSourceList[tile.dataSourceId]) {
            dataSourceList[tile.dataSourceId] = true;
          }
        }
      }
    }
      // function updateDateSource(dataSourceList, tile) {
      //   if (!dataSourceList[tile.dataSourceId]){
      //     dataSourceList[tile.dataSourceId] = true;
      //   }
      // }
    this.dataSources.forEach((dataSource, dataSourceId) => {
      if (!dataSourceList[dataSourceId]) {
        // delete this.dataSources[dataSourceId];
        this.dataSources.delete(dataSourceId);
      }
    });

      // TODO: If one page has filter, the refresh must be applied after load the filter preferences
      // when filterPanel will be compoused aris-page-controller will receive the evet 'onFilterLoaded'
    this.refreshAllDataSources();
  }


  resetData(dataSource) {
    if (this.dataSources && this.dataSources.get(dataSource.id).hasOwnProperty('data')) {
      this.dataSources.get(dataSource.id).data = null;
    }
  }

  updateDataSources(data) {
    let dataSourcesList: Map<string, any> = new Map();
    this.dataSources.forEach((datasource, index) => {
      dataSourcesList.set(index, datasource);
    });

    if (data && data.filterData) {
      data.filterData.forEach((v) => {
        let filterCategoryConfig;
              /* TEST - $.grep(this.filterCategoriesConfig, function(obj) {
                  if (this.angularEquals(v.datasource, obj.datasource)) {
                    filterCategoryConfig = obj;
                  }
              });*/
        this.filterCategoriesConfig.forEach((obj, index) => {
          if (this.angularEquals(v.datasource, obj.datasource)) {
            filterCategoryConfig = obj;
          }
        });

        if ((filterCategoryConfig.oldFilterData && this.angularEquals(filterCategoryConfig.oldFilterData.criterias, v.criterias)) ||
                  this.angularEquals(this.oldDateRange, data.dateRange)) {
          delete dataSourcesList[filterCategoryConfig.dsList[0]];
        //  dataSourcesList.delete(filterCategoryConfig.dsList[0]);
        }

        if ((data.refreshPage === true) || (!filterCategoryConfig.oldFilterData) ||
                  (filterCategoryConfig.oldFilterData && !this.angularEquals(filterCategoryConfig.oldFilterData.criterias, v.criterias)) ||
                  (!this.angularEquals(this.oldDateRange, data.dateRange))) {

                  /* TEST - $.grep(this.filterCategoriesConfig, function(obj) {
                      if (this.angularEquals(v.datasource, obj.datasource)) {
                        obj.oldFilterData = this.angularCopy(v);
                      }
                  }); */
          this.filterCategoriesConfig.forEach((obj) => {
            if (this.angularEquals(v.datasource, obj.datasource)) {
              obj.oldFilterData = JSON.parse(this.angularCopy(v));
            }
          });

          filterCategoryConfig.dsList.forEach((filterDataSource) => {
            // DS let dataSource = this.dataSources[filterDataSource];
            let dataSource = this.dataSources.get(filterDataSource);
            if (dataSource) {
              this.getDataFromService(dataSource, v, data.dateRange, data.refreshPage);
              dataSourcesList.delete(dataSource.endPoint);
              // delete dataSourcesList[dataSource.endPoint];
            }
          });
        }
      });
      if (data.refreshPage) {
        dataSourcesList.forEach((datasource) => {
          this.getDataFromService(datasource);
        });
      }
      if(data.dateRange !== null && data.dateRange !== undefined) {
        this.oldDateRange = JSON.parse(this.angularCopy(data.dateRange));
      }
    } else {
      this.refreshAllDataSources();
    }
  }

  angularCopy(obj: any): any {
    return JSON.stringify(obj);
    // return Object.assign({}, obj);
  }

  angularEquals(obj1: any, obj2: any): boolean {
    return (JSON.stringify(obj1) === JSON.stringify(obj2));
  }

  refreshAllDataSources() {
    this.dataSources.forEach((dataSource) => {
      this.getDataFromService(dataSource, dataSource.filterData, dataSource.dateRange, undefined);
    });
  }

  getDataFromService(dataSource, filterData?: any, dateRange?: any, refreshPage?: any) {
    if (refreshPage !== true) {
      this.resetData(dataSource);
    }

    if (dataSource.fetchResponseData) {
      dataSource.fetchResponseData(this, dataSource, refreshPage);
    } else {
      switch (dataSource.responseDataFormat) {
        case 'csv': {
          this.fetchCsvResponseData(dataSource, refreshPage);
        }
          break;
        case 'tsv': {
          this.fetchTsvResponseData(dataSource, refreshPage);
        }
          break;
        default: {
          this.fetchJsonResponseData(dataSource, refreshPage, filterData, dateRange);
        }
          break;
      }
    }
  }

  fetchJsonResponseData(dataSource, refreshPage, filterData, dateRange) {
    let promise: Promise<Object>;
    if (dataSource.url) {
      promise = this.http.get(this.getUrl(dataSource.url)).toPromise();
    }
    if (dataSource.endPoint) {
      promise = this.arisDataSourceService.getFromDataSource('' + dataSource.endPoint, filterData, dateRange, undefined, undefined, undefined, (dataSource.restPrefix !== undefined) ? true : false, dataSource.restPrefix);
    }
    if (dataSource.promise) {
      promise = dataSource.toPromise(this, this.http);
    }
    if (promise === undefined) {
      return;
    }

    promise.then((response) => {
      this.onResponseData(dataSource, response, refreshPage);
    }).catch((response) => {
      this.onResponseError(dataSource);
    }); // promise
  }

  fetchCsvResponseData(dataSource, refreshPage) {
    // tslint:disable-next-line:no-this-assignment
    let self = this;
    (<any>d3).csv(this.getUrl(dataSource.url), (error, data) => {
      if (error) {
        self.onResponseError(dataSource);
      } else {
        self.onResponseData(dataSource, data, refreshPage);
      }
    });
  }

  fetchTsvResponseData(dataSource, refreshPage) {
    // tslint:disable-next-line:no-this-assignment
    let self = this;
    (<any>d3).tsv(this.getUrl(dataSource.url), (error, data) => {
      if (error) {
        self.onResponseError(dataSource);
      } else {
        self.onResponseData(dataSource, data, refreshPage);
      }
    });
  }

  getUrl(url) {
    let newUrl = url.substring(url.lastIndexOf('./'));
    return (typeof newUrl === 'function') ? url(this) : newUrl;
  }

  onResponseData(dataSource, data, refreshPage) {
    let newData = data;
    if (refreshPage === true) {
      this.resetData(dataSource);
    }

    if (dataSource.customDataHandler) {
      newData = dataSource.customDataHandler(this, newData);
    }
    this.dataSources.get(dataSource.id).data = newData;
  }

  onResponseError(dataSource) {
    this.dataSources.get(dataSource.id).data = [];
  }

  /*
   * Apply the filter just after load the page
   * Using information customized by the user
   */
  onFilterLoaded(data) {
    if (data && data.filterData) {
      this.updateDataSources(data);
    }
  }

  /*
   * 'Apply' button in panel filter
   */
  onFilterChange(data) {
    if (data && data.filterData) {
      this.updateDataSources(data);
    }
  }

  /*
   * 'RESET' button in panel filter and 'REFRESH PAGE' event
   */
  onPageRefresh(data) {
    this.updateDataSources(data);
  }
}
