import { TestBed, ComponentFixture } from '@angular/core/testing';
import { DebugElement, ChangeDetectorRef, Type, NgZone, Injector } from '@angular/core';
import { HttpClientModule, HttpClient, HttpRequest, HttpEvent, HttpHeaders, HttpParams, HttpHandler  } from '@angular/common/http';
import { ReactiveFormsModule, FormControl, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG, LocaleService, LocaleConfig, LocaleStorage, TranslationHandler, TranslationProvider, TranslationConfig } from 'angular-l10n';
import { RouterModule, Router, ActivatedRoute, ActivatedRouteSnapshot, UrlSegment, Params, Data, Route, ParamMap } from '@angular/router';
import { ToastrService, GlobalConfig, ToastToken, Overlay } from 'ngx-toastr';
import { Observable } from 'rxjs/Observable';

import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpObserve } from '@angular/common/http/src/client';
import { DomSanitizer } from '@angular/platform-browser';
import { ArisPageComponent } from '../components/aris-page.component';
import { ArisChartService } from '../../../ui-components/chart-module/services/aris-chart.service';
import { ArisPageService } from '../../../services/aris-page-service';
import { ArisPageDashboardService } from './aris-page-dashboard.service';
import { ArisDynamicPageModule } from '../../aris-dynamic-page-module/aris-dynamic-page.module';
import { FilterModule } from '../../../ui-page-sections/filter-panel-module/aris-filter.module';
import { ArisSessionService } from '../../../services/aris-session.service';
import { ArisHeaderService } from '../../../ui-page-sections/header-module/services/aris-header-service';
import { ArisDataSourceService } from '../../../services/aris-datasource.service';
import { ArisFilterService } from '../../../services/aris-filter.service';
import { ArisLanguageService } from '../../../ui-page-sections/language-selector-module/services/aris-language.service';
import { ArisPageSectionObservableEventService } from '../../../ui-page-sections/services/aris-page-section-observable-event.service';
import { ArisPermissionService } from '../../../services/aris-permission.service';
import { ArisConfigService } from '../../../services/aris-config.service';
import { ArisNotificationBoxService } from '../../../ui-page-sections/error-module/services/aris-notification-box.service';
import { ArisLoginService } from '../../../services/aris-login.service';
import { ArisUiComponentsModule } from '../../../ui-components/aris-ui-components.module';
import { ArisWebSocketService } from '../../../services/aris-websocket.service';

export class MockActivatedRoute implements ActivatedRoute {
  snapshot: ActivatedRouteSnapshot;
  url: Observable<UrlSegment[]>;
  params: Observable<Params>;
  queryParams: Observable<Params>;
  fragment: Observable<string>;
  data: Observable<Data>;
  outlet: string;
  component: Type<any>|string;
  routeConfig: Route;
  root: ActivatedRoute;
  parent: ActivatedRoute;
  firstChild: ActivatedRoute;
  children: ActivatedRoute[];
  pathFromRoot: ActivatedRoute[];
  paramMap: Observable<ParamMap>;
  queryParamMap: Observable<ParamMap>;
  toString(): string {
    return "";
  }
}

export class MockHttpClient extends HttpClient {
}

class PageModel {
  layout: any[] = new Array();
}

export class MockObjectScope {
  jsonConfig: any =  {};
  pageModel: { layout: any, name: any, type: any };
  pageConfig: any =  {};

  headerConfig: any =  {};
  footerConfig: any =  {};
  filterCategories: any =  {};
  plugin: any = { plugin: [] };

  setPageConfig(scope, objectScope) {}
  setHeaderConfig(scope, objectScope) {}
  setFooterConfig(scope, objectScope) {}
  setPageModel(scope, objectScope) {}
  setPageLayouts(scope, objectScope) {}
  setFilterCategoriesConfig(scope, objectScope) {}
  getTileTitleWithDesc(title, desc) {
    return desc;
  }
  getChartTile(tile, scope, objectScope) {
    return tile.size;
  }
  getTile(tile, scope, objectScope) {
    return this.plugin;
  }
}

export class MockObjectScopeFake {
  jsonConfig: any =  {};
  pageModel: { layout: any, name: any, type: any };
  pageConfig = undefined;
  layout = undefined;
  headerConfig = undefined;
  footerConfig = undefined;
  filterCategories: any =  {};
  plugin: any = { plugin: [] };

  setPageConfig(scope, objectScope) {}
  setHeaderConfig(scope, objectScope) {}
  setFooterConfig(scope, objectScope) {}
  setPageModel(scope, objectScope) {}
  setPageLayouts(scope, objectScope) {}
  setFilterCategoriesConfig(scope, objectScope) {}
  getTileTitleWithDesc(title, desc) {
    return desc;
  }
  getChartTile(tile, scope, objectScope) {
    return tile.size;
  }
  getTile(tile, scope, objectScope) {
    return this.plugin;
  }
}

export class MockScope {
  chartOptions: any = { develop: {}, set() {}, get() {} };
  dataSources: any = { get() {}, set() {} };
}

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};

describe('Test: Aris Page Dashboard Service', () => {

  let component: ArisPageComponent;
  let fixture: ComponentFixture<ArisPageComponent>;
  let arisPageComponent:  ArisPageComponent;
  let pageModel = new PageModel();
  pageModel.layout = ['pagemodel'];
  let data = {
    compid:  1,
    rows: 2,
    maxlength: 9,
    editable: true
  };
  let dataSource = "develop";
  let refreshPage = true;
  let dateRange: any = {};

  let arisChartService: ArisChartService;
  let arisPageService: ArisPageService;
  let service: ArisPageDashboardService;
  let arisWebSocketService: ArisWebSocketService;
  let jsonConfig = { name: [], type: [], filterCategoriesConfig: [], pageConfig: [],
    headerConfig: [], footerConfig: [], layout: [[{  tileId: ['one'] , value1: ['two'] }]] };
  let scope = new MockScope();
  let objectScope = new MockObjectScope();
  let size = 1;
  let newTitle = 'newTitle';
  let buttons = "buttons";
  let headerConfig = "headerConfig";
  let tile = { tileId: 'TILE_TYPE_TITLE_WITH_DESC', title: 'title', desc: 'desc' };
  let tile1 = { tileId: 'TILE_TYPE_CHART', size: 1, dataSource: 'dataSource', chartType: 'chartType',
    chartOptions: 'chartOptions'};
  let chartType = "pie";
  let options: any = { dataSource: [], crossfilter: [] };
  let tile2 = {};
  let tileName = "tileName";
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        ArisPageComponent
      ],
      imports: [
        RouterModule,
        LocalizationModule,
        CommonModule,
        ArisDynamicPageModule,
        FilterModule,
        HttpClientTestingModule,
        ArisUiComponentsModule
      ],
      providers: [
        ArisSessionService,
        ArisHeaderService,
        ArisPageService,
        ArisPageDashboardService,
        ArisFilterService,
        InjectorRef, ArisLoginService, ArisWebSocketService,
        { provide: Router }, { provide: HttpClient, useClass: MockHttpClient }, { provide: ActivatedRoute, useClass: MockActivatedRoute }, { provide: ArisNotificationBoxService },
        ArisDataSourceService, ArisPageSectionObservableEventService, ArisPermissionService, ArisConfigService,
        ArisLanguageService, { provide: ToastrService }, { provide: LocaleService }, { provide: TranslationService, useValue: mockTranslationService  }
      ]
    }).compileComponents();

    afterAll(() => {
      component = null;
        });
    // create component and test fixture
    fixture = TestBed.createComponent(ArisPageComponent);

    // get test component from the fixture
    component = fixture.componentInstance;
    service = TestBed.get(ArisPageDashboardService);
    // component.ngOnInit();
  });

  it('getPage executed', () => {
    spyOn(service, 'getObjectScope').and.callThrough();
    service.getPage();
    expect(service.getObjectScope).toHaveBeenCalled();
  });

  it('setPage executed', () => {
    spyOn(service, 'getObjectScope').and.callThrough();
    service.setPage(scope, jsonConfig, objectScope);
    expect(service.getObjectScope).toHaveBeenCalled();
  });

  it('setPage failure scenario executed', () => {
    spyOn(service, 'getObjectScope').and.callThrough();
    service.setPage(scope, undefined, objectScope);
    expect(service.getObjectScope).toHaveBeenCalled();
  });

  it('setPageModel executed', () => {
    spyOn(service, 'getObjectScope').and.callThrough();
    service.setPageModel(scope, objectScope);
    expect(service.getObjectScope).toHaveBeenCalled();
  });

  it('setFilterCategoriesConfig executed', () => {
    spyOn(service, 'getObjectScope').and.callThrough();
    service.setFilterCategoriesConfig(scope, objectScope);
    expect(service.getObjectScope).toHaveBeenCalled();
  });

  it('setPageConfig executed', () => {
    spyOn(service, 'getObjectScope').and.callThrough();
    service.setPageConfig(scope, objectScope);
    expect(service.getObjectScope).toHaveBeenCalled();
  });

  it('setPageConfig failure scenario executed', () => {
    let valScope = new MockObjectScopeFake();
    spyOn(service, 'getObjectScope').and.callThrough();
    service.setPageConfig(scope, valScope);
    expect(service.getObjectScope).toHaveBeenCalled();
  });

  it('setHeaderConfig executed', () => {
    spyOn(service, 'getObjectScope').and.callThrough();
    service.setHeaderConfig(scope, objectScope);
    expect(service.getObjectScope).toHaveBeenCalled();
  });

  it('setHeaderConfig failure scenario executed', () => {
    let valScope = new MockObjectScopeFake();
    spyOn(service, 'getObjectScope').and.callThrough();
    service.setHeaderConfig(scope, valScope);
    expect(service.getObjectScope).toHaveBeenCalled();
  });

  it('setFooterConfig executed', () => {
    spyOn(service, 'getObjectScope').and.callThrough();
    service.setFooterConfig(scope, objectScope);
    expect(service.getObjectScope).toHaveBeenCalled();
  });

  it('setFooterConfig failure scenario executed', () => {
    let valScope = new MockObjectScopeFake();
    spyOn(service, 'getObjectScope').and.callThrough();
    service.setFooterConfig(scope, valScope);
    expect(service.getObjectScope).toHaveBeenCalled();
  });

  it('getObjectScope executed', () => {
    let object = service.getObjectScope(objectScope);
    expect(object).toEqual(objectScope);
  });

  it('getTileYammer executed', () => {
    let object = service.getTileYammer(size, newTitle);
    expect(object.size).toEqual(size);
  });

  it('getTileTitleWithButtons executed', () => {
    let object = service.getTileTitleWithButtons(size, buttons);
    expect(object.static).toBeTruthy();
  });

  it('getTileTitleWithDesc executed', () => {
    let object = service.getTileTitleWithDesc(size, buttons);
    expect(object.static).toBeTruthy();
  });

  it('getOverviewTile executed', () => {
    let object = service.getOverviewTile(size, data, headerConfig);
    expect(object.size).toEqual(size);
  });

  it('getTile for title with description executed', () => {
    let object = service.getTile(tile, data, objectScope);
    expect("desc").toEqual(tile.desc);
  });

  it('getTile for title type chart executed', () => {
    let object = service.getTile(tile1, scope, objectScope);
    expect(1).toEqual(tile1.size);
  });

  it('getChartTile for title type chart executed', () => {
    let object = service.getChartTile(scope, size, dataSource, chartType, options);
    expect(object.dataSourceId).toEqual("develop");
  });

  it('getChartTile for datasource.id equality scenario executed', () => {
    spyOn(scope.dataSources, 'get').and.returnValue(1);
    let object = service.getChartTile(scope, size, { id: 1 }, chartType, options);
    expect(object.dataSourceId).toEqual(1);
  });

  it('getChartTile for title type chart if executed', () => {
    let object = service.getChartTile(scope, size, "abc/", chartType, options);
    expect(object.dataSourceId).toEqual("abc");
  });

  it('getChartTile for datasource and options failure scenario is executed', () => {
    let options1: any = { dataSource: [] };
    let object = service.getChartTile(scope, size, 1, chartType, options1);
    expect(object.dataSourceId).toBeUndefined();
  });

  it('setPageLayouts executed', () => {
    spyOn(service, 'getObjectScope').and.callThrough();
    service.setPageLayouts(scope, objectScope);
    expect(service.getObjectScope).toHaveBeenCalled();
  });

  it('getTile null scenario executed', () => {
    let object = service.getTile(tile2, scope, objectScope);
    expect(null).toBeNull();
  });

  it('getChartTile else scenario executed', () => {
    let object = service.getChartTile(scope, size, null, chartType, options);
    expect(object.plugin).toEqual("TILE_TYPE_CHART");
  });

  it('getTemplateTile else scenario executed', () => {
    let object = service.getTemplateTile(size, tileName, headerConfig, null, scope);
    expect(object.size).toEqual(size);
  });

  it('getTemplateTile if scenario executed', () => {
    let object = service.getTemplateTile(size, tileName, headerConfig, 'abc/', scope);
    expect(object.size).toEqual(size);
  });

  it('getTemplateTile else of inner if scenario executed', () => {
    let object = service.getTemplateTile(size, tileName, headerConfig, 'abc', scope);
    expect(object.size).toEqual(size);
  });

  it('getTemplateTile tileName empty scenario executed', () => {
    let object = service.getTemplateTile(size, undefined, headerConfig, null, scope);
    expect(object.size).toEqual(size);
  });

  it('getTemplateTile dataSource.id not equal scenario executed', () => {
    spyOn(scope.dataSources, 'get').and.returnValue(1);
    let object = service.getTemplateTile(size, 'TILE_TYPE_TITLE_WITH_DESC:', headerConfig, { id: 1 }, scope);
    expect(object.size).toEqual(size);
  });

  it('setPageLayouts complete execution', () => {
    spyOn(service, 'getObjectScope').and.callThrough();
    service.setPageLayouts(scope, objectScope);
    expect(service.getObjectScope).toHaveBeenCalled();
  });

  it('setPageLayouts layout undefined scenario', () => {
    let valScope = new MockObjectScopeFake();
    spyOn(service, 'getObjectScope').and.callThrough();
    service.setPageLayouts(scope, valScope);
    expect(service.getObjectScope).toHaveBeenCalled();
  });

  it('setPageLayouts layout undefined scenario', () => {
    objectScope.pageModel = { layout: [], name: [], type: [] };
    objectScope.jsonConfig = { layout: [{ forEach() { return { chartType: 'val' }; } }] };
    spyOn(service, 'getObjectScope').and.callThrough();
    service.setPageLayouts(scope, objectScope);
    expect(service.getObjectScope).toHaveBeenCalled();
  });

});
