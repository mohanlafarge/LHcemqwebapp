import { Injectable } from '@angular/core';

import { ArisPageService } from '../../../services/aris-page-service';
import { ArisChartService } from '../../../ui-components/chart-module/services/aris-chart.service';
import { ArisTileCustomTemplateComponent } from '../../../ui-tiles-templates/aris-tile-custom-template.component';
import { HttpClient } from '@angular/common/http';
import { TranslationService } from 'angular-l10n';

@Injectable()
export class ArisPageDashboardService {
  private arisConfigUrl = 'rest/config';

  private arisSessionConfig = {};
  private arisLocalConfig = {};
  private changedLang = '';

  constructor(protected arisChartService: ArisChartService, private arisPageService: ArisPageService,
    private http: HttpClient, private transService: TranslationService) {
  }


  // public method
  getPage(objectScope?: any) {
    objectScope = this.getObjectScope(objectScope);
    return objectScope;
  }

  // Overriden methods
  setPage(scope, jsonConfig, objectScope?: any) {
    objectScope = this.getObjectScope(objectScope);
    if (jsonConfig !== undefined) {
      objectScope.jsonConfig = jsonConfig;
      objectScope.pageModel = {};
      objectScope.pageConfig = {};
      objectScope.headerConfig = {};
      objectScope.footerConfig = {};
      objectScope.pageModel.layout = [];

      objectScope.filterCategories = {};

      objectScope.setPageConfig(scope, objectScope);
      objectScope.setHeaderConfig(scope, objectScope);
      objectScope.setFooterConfig(scope, objectScope);
      objectScope.setPageModel(scope, objectScope);
      objectScope.setPageLayouts(scope, objectScope);
      objectScope.setFilterCategoriesConfig(scope, objectScope);
    }
  }

  setPageModel (scope, objectScope) {
    objectScope = this.getObjectScope(objectScope);

    objectScope.pageModel.name = objectScope.jsonConfig.name;
    objectScope.pageModel.type = objectScope.jsonConfig.type;
    objectScope.pageModel.avoidSynchTilesHeigthPerRow = objectScope.jsonConfig.avoidSynchTilesHeigthPerRow;
  }

  setPageLayouts (scope, objectScope) {

    objectScope = this.getObjectScope(objectScope);
    if (objectScope.jsonConfig.layout === undefined) {
      return;
    }

    // Reset the initial layout associated to the objectScope
    objectScope.pageModel.layout = [];
    // For each set of layoutTiles (or rows) defined in PageModel.layout
    objectScope.jsonConfig.layout.forEach((layoutTiles) => {
      let layout = [];
      // For each 'tile' defined inside of the 'layoutTiles'
      layoutTiles.forEach((tile) => {
        let tileAux: any;
        if (tile.tileId) {
          tileAux = objectScope.getTile(tile, scope, objectScope);
        } else {
          if (tile.chartType) {
            tileAux = objectScope.getChartTile(scope, tile.size, tile.dataSource,
              tile.chartType, tile.chartOptions);
          } else if (tile.plugin === 'TILE_TYPE_CUSTOM_TEMPLATE') {
            tileAux = objectScope.getTemplateTile (tile.size, tile.tileName,
              tile.headerConfig, tile.dataSource, scope);
          } else {
            if (typeof tile.getTile === 'function') {
              tileAux = tile.getTile(scope, objectScope, tile.size);
            } else if (objectScope[tile.getTile] !== undefined) {
              tileAux = objectScope[tile.getTile](scope, objectScope, tile.size);
            } else {
              tileAux = tile;
            }// getTile not function
          } // chart type
        }// no tileId

        if (window.app.config.tiles[tileAux.plugin] !== undefined) {
          tileAux.component = window.app.config.tiles[tileAux.plugin];
        }
        layout.push(tileAux);
      });
      if (layout.length > 0) {
        objectScope.pageModel.layout.push(layout);
      }
    });

    this.arisChartService.setSharedCrossFiltersForChartTiles(scope);
  }

  setFilterCategoriesConfig (scope, objectScope) {
    objectScope = this.getObjectScope(objectScope);

    objectScope.filterCategories = objectScope.jsonConfig.filterCategoriesConfig;
  }

  setPageConfig (scope, objectScope) {
    objectScope = this.getObjectScope(objectScope);

    if (objectScope.jsonConfig.pageConfig) {
      objectScope.pageConfig = objectScope.jsonConfig.pageConfig;
    }
  }

  setHeaderConfig (scope, objectScope) {
    objectScope = this.getObjectScope(objectScope);

    if (objectScope.jsonConfig.headerConfig) {
      objectScope.headerConfig = objectScope.jsonConfig.headerConfig;
    }
  }

  setFooterConfig (scope, objectScope) {
    objectScope = this.getObjectScope(objectScope);

    if (objectScope.jsonConfig.footerConfig) {
      objectScope.footerConfig = objectScope.jsonConfig.footerConfig;
    }
  }

  getTile (tile, scope, objectScope) {
    objectScope = this.getObjectScope(objectScope);
    switch (tile.tileId) {
      case 'TILE_TYPE_TITLE_WITH_DESC':
        return objectScope.getTileTitleWithDesc(this.transService.translate(tile.title), this.transService.translate(tile.desc));
      case 'TILE_TYPE_CHART':
        return objectScope.getChartTile(scope, tile.size, tile.dataSource,
            tile.chartType, tile.chartOptions, tile.title);
      default:
        return null;
    }
  }

  getChartTile (scope, size, dataSource, chartType, options, title?) {
    let chartOptionsVar: any;
    let tile: any = {};
    tile.size = size;
    tile.plugin = 'TILE_TYPE_CHART';
    tile.title = title;
    tile.dataSource = dataSource;
    tile.chartType = chartType;
    tile.chartOptions = options;

    if (dataSource) {
      if (typeof dataSource === 'string') {
        let dsName = dataSource;
        dataSource = undefined;
        if (dsName.indexOf('/') !== -1) {
          dataSource = {'id': this.getScopeDataVarForDataSource(dsName), 'url': dsName};
        } else {
          dataSource = {'id': this.getScopeDataVarForDataSource(dsName), 'endPoint': dsName};
        }
      }
      tile.dataSourceId = dataSource.id;

      options.dataSource = dataSource;

      // if crossfilter should be shared, set crossfilter to dataSource Id to be used
      // to fetch data in order to create crossfilter object.
      if (options.crossfilter) {
        options.crossfilter = dataSource.id;
      }

      // if multiple charts from same source, add postFix to chartOptions
      chartOptionsVar = dataSource.id;
      let postFix = 0;
      while (scope.chartOptions[chartOptionsVar]) {
        chartOptionsVar = dataSource.id + postFix;
        postFix++;
      }
      scope.chartOptions.set(chartOptionsVar, options);

      if (!scope.dataSources.get(dataSource.id)) {
        scope.dataSources.set(dataSource.id, dataSource);
      }
    } else {
      dataSource = {};
    }

    tile.input = {
      type: chartType,
      chartData: scope.dataSources.get(dataSource.id),
      options: scope.chartOptions.get(chartOptionsVar)
    };

    return tile;
  }

  getTemplateTile (size, tileName, headerConfig, dataSource, scope) {
    let tile: any = {};
    tile.size = size;
    if (tileName) {tile.tileName = tileName; } // In case undefined we don´t want to create this tile attribute
    if (dataSource) {tile.dataSource = dataSource; } // In case undefined we don´t want to create this tile attribute

    if (typeof dataSource === 'string') {
      let dsName = dataSource;
      dataSource = undefined;
      if (dsName.indexOf('/') !== -1) {
        dataSource = {'id': this.getScopeDataVarForDataSource(dsName), 'url': dsName};
      } else {
        dataSource = {'id': this.getScopeDataVarForDataSource(dsName), 'endPoint': dsName};
      }
    }
    if (dataSource) {
      tile.dataSourceId = dataSource.id;

      if (!scope.dataSources.get(dataSource.id)) {
        scope.dataSources.set(dataSource.id, dataSource);
      }
    }

    tile.plugin = 'TILE_TYPE_CUSTOM_TEMPLATE';
    tile.component = ArisTileCustomTemplateComponent;

    if (window.app.config.tiles[tileName] === undefined) {
      console.error('ArisTileTemplateWithIsolatedScopeComponent cannot find the component associated to "'
                    + tileName + '" \nCheck if it is defined in the configuration file "Tile.ts"');
    }

    if (dataSource) {
      tile.input = {
        headerConfig,
        internalInput: {
          templateData: scope.dataSources.get(dataSource.id)
        },
        internalComponent: window.app.config.tiles[tileName]
      };
    } else {
      tile.input = {
        headerConfig,
        internalComponent: window.app.config.tiles[tileName]
      };
    }

    return tile;
  }

  getOverviewTile (size, data, headerConfig) {
    let tile: any = {};
    tile.size = size;
    tile.plugin = 'TILE_TYPE_OVERVIEW_EDIT';
    tile.headerConfig = headerConfig;
    tile.input = {
      compid: data.compid,
      rows: data.rows,
      maxlength: data.maxlength,
      editable: data.editable
    };

    return tile;
  }

  getTileTitleWithDesc (newTitle, newDesc) {
    let tile: any = {};
    tile.size = 'col-xs-12 col-sm-12 col-md-12';
    tile.plugin = 'TILE_TYPE_TITLE_WITH_DESC';
    tile.input = {
      desc: newDesc,
      title: newTitle
    };
    tile.static = true;

    return tile;
  }

  getTileTitleWithButtons (title, buttons) {
    let tile: any = {};
    tile.size = 'col-xs-12 col-sm-12 col-md-12';
    tile.plugin = 'TILE_TYPE_TITLE_WITH_BUTTONS';
    tile.input = {
      buttons: buttons,
      title: title
    };
    tile.static = true;

    return tile;
  }

  getTileYammer (size, newTitle) {
    let tile: any = {};
    tile.size = size;
    tile.plugin = 'TILE_TYPE_YAMMER';
    tile.input = {
      title: newTitle
    };

    return tile;
  }

  getObjectScope (objectScope?: any) {
    return objectScope ? objectScope : this;
  }

  private getScopeDataVarForDataSource(dataSource) {
    let key = dataSource.split('/').join('');
    key = key.split('.').join('');

    return key;
  }

  getPageModel(pageModelName) {
    return this.http.get('rest/pagelayout/self/byname/' +  pageModelName, {
      headers: { 'Cache-Control' : 'no-cache' }
      // , responseType: 'text'
    }).toPromise();
  }
} // object
