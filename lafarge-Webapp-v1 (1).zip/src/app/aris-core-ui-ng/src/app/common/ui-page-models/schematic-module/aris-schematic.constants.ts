export const defaultTimeRangeDuration = "6";
