import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule, UpperCasePipe } from "@angular/common";
import { arisSchematicRoutes } from "./aris-schematic.routes";
import { RouterModule } from "@angular/router";
import { SchematicPrototypesModule } from "../../../prototypes/schematic-module/schematic-module.module";
import { ArisScematicInfocardComponent } from "./components/aris-schematic-infocard.component";
import { ArisPipesModule } from "../../pipes/aris-pipes.module";
import { ChartModule } from "../../ui-components/chart-module/aris-chart.module";
import { ArisNoDataPipe } from "../../pipes/aris-nodata.pipes";
import { ArisDateTimePipe } from "../../pipes/aris-datetime.pipes";
import { LocalizationModule } from "angular-l10n";
import { ArisSchematicComponent } from "./components/aris-schematic.component";
import { ArisSchematicMaintenanceComponent } from "./components/aris-schematic-maintenance.component";
import { ArisschematicMarkersPositions } from "./services/aris-schematic-markers-positions.service";
import { ArisSchematicDefaultInfocardComponent } from "./components/aris-schematic-default-infocard.component";
import { ArisUiComponentsModule } from "../../ui-components/aris-ui-components.module";
import { ArisSchematicInfocardDynamicComponent } from "./components/aris-schematic-infocard-dynamic.component";
import { ArisSchematicConfig } from "./services/aris-schematic-config.service";
import { ArisValueTypeCheckPipe } from "../../pipes/aris-value-type-check-pipe";
import { ArisPageModule } from "../page-module/aris-page.module";


@NgModule({
  declarations: [
    ArisSchematicComponent,
    ArisSchematicDefaultInfocardComponent,
    ArisSchematicMaintenanceComponent,
    ArisScematicInfocardComponent,
    ArisSchematicInfocardDynamicComponent
  ],
  imports: [
    arisSchematicRoutes,
    SchematicPrototypesModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    ArisPipesModule,
    ChartModule,
    LocalizationModule,
    ArisUiComponentsModule,
    ArisPageModule
  ],
  providers: [
    ArisSchematicConfig,
    UpperCasePipe,
    ArisNoDataPipe,
    ArisDateTimePipe,
    ArisValueTypeCheckPipe,
    ArisschematicMarkersPositions
  ],
  exports: [
    ArisSchematicComponent,
    ArisSchematicDefaultInfocardComponent,
    ArisSchematicMaintenanceComponent,
    ArisScematicInfocardComponent,
    ArisSchematicInfocardDynamicComponent
  ],
  entryComponents: [
    ArisSchematicDefaultInfocardComponent
  ]
})
export class ArisSchematicModule {
}
