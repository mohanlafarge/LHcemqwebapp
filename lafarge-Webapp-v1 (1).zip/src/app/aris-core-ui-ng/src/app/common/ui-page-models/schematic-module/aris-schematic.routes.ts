import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ArisSchematicComponent } from './components/aris-schematic.component';
import { ArisSchematicMaintenanceComponent } from './components/aris-schematic-maintenance.component';


const routes: Routes = [
  { path: ':geoLayerName', component: ArisSchematicComponent },
  { path: '', component: ArisSchematicMaintenanceComponent }
];

export const arisSchematicRoutes: ModuleWithProviders = RouterModule.forChild(routes);
