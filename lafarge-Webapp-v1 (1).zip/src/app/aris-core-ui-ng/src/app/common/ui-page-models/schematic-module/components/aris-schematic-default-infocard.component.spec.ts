/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import 'rxjs/add/observable/of';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { ArisSchematicDefaultInfocardComponent } from './aris-schematic-default-infocard.component';
import { LocalizationModule, TranslationService } from 'angular-l10n';
import { CommonModule } from '@angular/common';
import { ArisSchematicModule } from '../aris-schematic.module';
import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
import { ChartModule } from '../../../ui-components/chart-module/aris-chart.module';
import { ArisModule } from '../../../../aris.module';
import { ArisSchematicConfig } from '../services/aris-schematic-config.service';
import { ArisUiComponentsModule } from '../../../ui-components/aris-ui-components.module';
import { Observable } from 'rxjs';

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};
describe('Component: ArisSchematicDefaultInfocardComponent', () => {

  let component: ArisSchematicDefaultInfocardComponent;
  let fixture: ComponentFixture<ArisSchematicDefaultInfocardComponent>;
  let infoCardElement: DebugElement;
  let infoCardElement2: DebugElement;
  let http: HttpClient;

  let testData = {
    apiData: {
      currentLayer: "serviceReservoirs",
      header: {
        title: "SOUTHDOWN HALFWAY HOUSES WSR",
        fillPerc: 48
      },
      topSection: {
        alert: null,
        alertBgColor: null,
        headers: [
          {
            title: "Current Volume (MI)",
            value: 6.73
          },
          {
            title: "Hours of Supply:",
            value: 7.39,
            dtv: 1453189500000
          },
          {
            title: "Current Level (%)",
            value: 48,
            dtv: 1453189500000
          }
        ]
      },
      bottomSection: {
        table: {
          header: "Site Details",
          rows: [
            {
              label: "Asset Reference",
              val: "SOUT"
            },
            {
              label: "Reservoir Capacity MI:",
              val: "13.6Mld"
            }
          ]
        },
        tables: [
          {
            header: "SOUTHDOWN HALFWAY HOUSES 1 WSR",
            rows: [
              {
                label: "Status",
                val: "OPERATIONAL"
              },
              {
                label: "Cell Level (m)",
                val: 2.859999895,
                dtv: 1445193000000
              },
              {
                label: "Cell Level (%)"
              }
            ]
          },
          {
            header: "SOUTHDOWN HALFWAY HOUSES 2 WSR",
            rows: [
              {
                label: "Status",
                val: "OPERATIONAL"
              },
              {
                label: "Cell Level (m)",
                val: 2.762500048,
                dtv: 1445193000000
              },
              {
                label: "Cell Level (%)"
              }
            ]
          }
        ]
      },
      middleSection: {
        currentTimeDurationRange: "6",
        currentTab: "Level (meters)",
        currentChartParams: {
          chartType: "line",
          xAxisAttribute: "dtvCurrentFillPercentage",
          yAxisAttribute: "currentFillPercentage",
          chartTitle: "Level"
        },
        longTextFields: [],
        tabs: [
          {
            id: "level",
            title: "Level (meters)",
            chartParams: {
              chartType: "lineChart",
              xAxisAttribute: "dtvCurrentFillPercentage",
              yAxisAttribute: "currentFillPercentage",
              chartTitle: "Level"
            }
          },
          {
            id: "flow",
            title: "Flow (litres/sec)",
            chartParams: {
              chartType: "lineChart",
              xAxisAttribute: "dtvFlowOut",
              yAxisAttribute: "flowOut",
              chartTitle: "Flow"
            }
          },
          {
            id: "hoursOfSupply",
            title: "Hours of Supply",
            chartParams: {
              chartType: "lineChart",
              xAxisAttribute: "dtvHoursOfSupplyRemainingToLowLowAlarm",
              yAxisAttribute: "hoursOfSupplyRemainingToLowLowAlarm",
              chartTitle: "Hours of Supply"
            }
          }
        ]
      },
      infocardAdditionalAPI: {}
    },
    isInfocardVisisble: true
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisSchematicDefaultInfocardComponent],
      schemas: [],
      imports: [ArisPipesModule, LocalizationModule, ChartModule, ArisModule, ArisUiComponentsModule],
      providers: [ArisSchematicConfig, HttpClient, HttpHandler, { provide: TranslationService, useValue: mockTranslationService }, ArisChartCommonService]
    }).compileComponents();
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(ArisSchematicDefaultInfocardComponent);
    // get test component from the fixture
    component = fixture.componentInstance;
    component.schematicInfocardData = testData;
    http = TestBed.get(HttpClient);
    component.ngOnInit();

  });

  it('ArisSchematicDefaultInfocardComponent should be created', () => {
    expect(component).toBeTruthy();
  });

  it('ArisSchematicDefaultInfocardComponent: checnking closeSchematicInfocard() method', () => {
    component.closeSchematicInfocard();
    let isInfocardClose = component.isSchematicInfocardVisible;
    expect(isInfocardClose).toBe(false);
  });

  it('ArisSchematicDefaultInfocardComponent: checnking refreshChartByTabId(tabId) method', () => {
    let tabId = "flow";
    component.refreshChartByTabId(tabId);
    let xAxisAttribute = component.infocardData.middleSection.currentChartParams.xAxisAttribute;
    let yAxisAttribute = component.infocardData.middleSection.currentChartParams.yAxisAttribute;
    expect(xAxisAttribute).toBe("dtvFlowOut");
    expect(yAxisAttribute).toBe("flowOut");
  });

  it('ArisSchematicDefaultInfocardComponent: checnking onTabClick(tabId) method', () => {
    let tabId = "hoursOfSupply";
    component.onTabClick(tabId);
    let xAxisAttribute = component.infocardData.middleSection.currentChartParams.xAxisAttribute;
    let yAxisAttribute = component.infocardData.middleSection.currentChartParams.yAxisAttribute;
    expect(xAxisAttribute).toBe("dtvHoursOfSupplyRemainingToLowLowAlarm");
    expect(yAxisAttribute).toBe("hoursOfSupplyRemainingToLowLowAlarm");
  });

  it('ArisSchematicDefaultInfocardComponent: checking onTabChange(tabId) method', () => {
    let dummyElement: any = { options : [{ id: "flow" }], selectedIndex: [0] };
    spyOn(document, 'getElementById').and.callFake(() => dummyElement);
    component.onTabChange(dummyElement);
    let xAxisAttribute = component.infocardData.middleSection.currentChartParams.xAxisAttribute;
    let yAxisAttribute = component.infocardData.middleSection.currentChartParams.yAxisAttribute;
    expect(xAxisAttribute).toBe("dtvHoursOfSupplyRemainingToLowLowAlarm");
    expect(yAxisAttribute).toBe("hoursOfSupplyRemainingToLowLowAlarm");
  });

  it('ArisSchematicDefaultInfocardComponent: checking onTimeRangeChange(selectedvalue) method', () => {
    let dummyElement: any = { options : [{ value: "flow" }], selectedIndex: [0] };
    spyOn(document, 'getElementById').and.callFake(() => dummyElement);
    spyOn(http, 'post').and.callThrough();
    component.onTimeRangeChange(dummyElement);
    expect(http.post).toHaveBeenCalled();
  });

  it('ArisSchematicDefaultInfocardComponent: checking openNewTab() method', () => {
    component.openNewTab();
    expect(window.location.href.split('#/page/')).toEqual(['http://localhost:9876/context.html']);
  });

  it('ArisSchematicDefaultInfocardComponent: checnking refreshChartByTabId(undefined) method', () => {
    component.refreshChartByTabId('');
    expect(component).toBeTruthy();
  });

  // it('ArisSchematicDefaultInfocardComponent: checnking ngOnInit() method', () => {
  //   component.schematicInfocardData = { apiData: { currentLayer: 'val', middleSection: {  tabs: [{ id: "level", title: "Level (meters)" },
  //   { id: "flow", title: "Flow (Instant) (litres/sec)" },
  //   { id: "hoursOfSupply", title: "Hours of Supply" }] } }, isInfocardVisisble: true };
  //   component.infocardData = { middleSection: { tabs: [{ id: "level", title: "Level (meters)" },
  //   { id: "flow", title: "Flow (Instant) (litres/sec)" },
  //   { id: "hoursOfSupply", title: "Hours of Supply" }] } } ;
  //   component.ngOnInit();
  //   expect(component).toBeTruthy();
  // });

});
