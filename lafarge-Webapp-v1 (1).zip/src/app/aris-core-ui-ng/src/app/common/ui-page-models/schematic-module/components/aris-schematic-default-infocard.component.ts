import { Component, Input, OnInit, OnChanges, ChangeDetectionStrategy } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Language, TranslationService } from 'angular-l10n';

import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
import { ArisSchematicInfoCardInterfaceComponent } from './aris-schematic-infocard-interface.component';

@Component({
  selector: 'aris-schematic-default-infocard',
  templateUrl: './aris-schematic-default-infocard.component.html'
})
export class ArisSchematicDefaultInfocardComponent implements OnInit, OnChanges, ArisSchematicInfoCardInterfaceComponent {
  @Input() schematicInfocardData: any;
  isSchematicInfocardVisible: any;
  infocardData: any;
  chartOptions: any;
  sletectedlayer: any;
  mapLayer: any = {};
  tab = {};
  timeRangeData = [];
  timeRangeDataValue = [];
  tabChangeDropdown: any = [];
  @Language() lang;

  constructor(private arisChartCommonService: ArisChartCommonService, private http: HttpClient, private translationService: TranslationService) {
    this.timeRangeDataValue = [this.translationService.translate('GEO_INFOCARD_1DAY'), this.translationService.translate('GEO_INFOCARD_7DAYS'),
      this.translationService.translate('GEO_INFOCARD_30DAYS'), this.translationService.translate('GEO_INFOCARD_90DAYS'),
      this.translationService.translate('GEO_INFOCARD_1YEAR')];
    this.timeRangeData = [{ key: this.translationService.translate('GEO_INFOCARD_1DAY'), value: '0' },
       { key: this.translationService.translate('GEO_INFOCARD_7DAYS'), value: 6 },
       { key: this.translationService.translate('GEO_INFOCARD_30DAYS'), value: 29 },
       { key: this.translationService.translate('GEO_INFOCARD_90DAYS') , value: 89 },
       { key: this.translationService.translate('GEO_INFOCARD_1YEAR'), value: 364 }];
  }
  ngOnInit() {
    if(this.schematicInfocardData) {
      this.infocardData = this.schematicInfocardData.apiData;
      this.isSchematicInfocardVisible = this.schematicInfocardData.isInfocardVisisble;
      this.sletectedlayer = this.infocardData.currentLayer;
      if (this.infocardData.middleSection) {
        for (let i = 0; i < this.infocardData.middleSection.tabs.length; i += 1) {
          this.tabChangeDropdown.push(this.infocardData.middleSection.tabs[i].title);
        }
          this.mapLayer.id = this.infocardData.currentLayer;
          this.infocardData.middleSection.markerId = this.infocardData.header.title;
          this.chartOptions = {
            xAxisAttribute: this.infocardData.middleSection.currentChartParams.xAxisAttribute,
            yAxisAttribute: this.infocardData.middleSection.currentChartParams.yAxisAttribute,
            calc: 'sum',
            showRangeChart: true,
            scale: 'date',
            numXAxisTicks: 3,
            chartTitle: this.infocardData.middleSection.currentChartParams.chartTitle,
            hideChartTitle: true,
            openWindow: false,
            timeFormatType: "%b %d",
            exportable: true
          };
        }
    }
   
  }
  ngOnChanges() {
    if (this.infocardData.middleSection) {
    for (let i = 0; i < this.infocardData.middleSection.tabs.length; i += 1) {
      this.tabChangeDropdown.push(this.infocardData.middleSection.tabs[i].title);
    }
    
      this.mapLayer.id = this.infocardData.currentLayer;
      this.infocardData.middleSection.markerId = this.infocardData.header.title;
      this.chartOptions = {
        xAxisAttribute: this.infocardData.middleSection.currentChartParams.xAxisAttribute,
        yAxisAttribute: this.infocardData.middleSection.currentChartParams.yAxisAttribute,
        calc: 'sum',
        showRangeChart: true,
        scale: 'date',
        numXAxisTicks: 3,
        chartTitle: this.infocardData.middleSection.currentChartParams.chartTitle,
        hideChartTitle: true,
        openWindow: false,
        timeFormatType: "%b %d",
        exportable: true
      };
    }
  }
  closeSchematicInfocard() {
    this.isSchematicInfocardVisible = false;
  }

  onTabClick(tabId) {
    console.log("onTabClick:" + tabId);
    this.refreshChartByTabId(tabId);
  }
  onTabChange(el) {
    let tabId = this.findIdOfSelectedtabChangeDropdown(el);
    this.refreshChartByTabId(tabId);
  }

  findIdOfSelectedtabChangeDropdown(el) {
    let selectedId = '';
    for (let i = 0; i < this.infocardData.middleSection.tabs.length; i += 1) {
      if (this.infocardData.middleSection.tabs[i].title === el) {
        selectedId = this.infocardData.middleSection.tabs[i].id;
      }
    }
    return selectedId;
  }
  onTimeRangeChange(selectedvalue) {
    // let e: any = document.getElementById(selectedvalue);
    // let selectedTimeRange = e.options[e.selectedIndex].value;
    let selectedTimeRange = selectedvalue;
    for (let i = 0; i < this.timeRangeData.length; i += 1) {
      if (this.timeRangeData[i].key === selectedvalue) {
        selectedTimeRange = this.timeRangeData[i].value;
      }
    }
    console.log(selectedTimeRange);
    this.infocardData.middleSection.currentTimeDurationRange = selectedTimeRange;
    this.infocardData.middleSection.chartData = null;
    let filterStr = [{ name: "markerId", values: [this.infocardData.header.title], op: "eq", dbtype: "String" }];
    this.http.post("rest/getFromDataSource/" + this.sletectedlayer + 'InfoCardLineChart?offset=0&limit=1000&groupedDuration=' + selectedTimeRange, filterStr).toPromise().then((response) => {
      this.infocardData.middleSection.chartData = response;
    });
  }
  openNewTab() {
    console.log("newtab");
    window.middleSection = Object.assign({}, this.infocardData.middleSection);
    window.header = Object.assign({}, this.infocardData.header);
    window.mapLayer = Object.assign({}, this.mapLayer);
    window.chartOptions = Object.assign({}, this.chartOptions);
    window.chartType = 'line';
    const path = window.location.href.split('#/page/');
    window.pageName = path[path.length - 1 ];
    let chartTitle = this.chartOptions.chartTitle.replace(/[^a-zA-Z0-9]/g, '');
    const randomNum = Math.floor(Math.random() * 1000000000);
    let obj = {middleSection: window.middleSection, header: window.header,  chartOptions: window.chartOptions, chartData: window.chartData,
      mapLayer: window.mapLayer, chartType: window.chartType, pageName: window.pageName};
    for (let i = 0; i < window.localStorage.length; i += 1) {
      let key = window.localStorage.key(i);
      if (window.localStorage.key(i) !== 'arisLocalConfig' && window.localStorage.key(i) !== 'arisThemeConfig') {
        localStorage.removeItem(key);
      }
    }
    localStorage.setItem('' + chartTitle + randomNum, JSON.stringify(obj));
    window.open('#/zoomInInfocardChart/' + chartTitle + randomNum, '_blank');

    /* Comment the previous lines and Uncomment this if you prefer pass the information as queryparam
       instead store it in the sessionStorage 
    window.open('#/zoomInInfocardChart/data?chartId=' + chartTitle + randomNum + '&chartData=' + JSON.stringify(obj), '_blank');
    */
  }
  refreshChartByTabId(tabId) {
    if (tabId !== '') {
      let tab: any ;
      for (let i = 0; i < this.infocardData.middleSection.tabs.length; i += 1) {
        if (this.infocardData.middleSection.tabs[i].id === tabId) {
          tab = this.infocardData.middleSection.tabs[i];
        }
      }
      this.infocardData.middleSection.currentChartParams = tab.chartParams;
      this.infocardData.middleSection.currentTab = tab.title;
      this.chartOptions.xAxisAttribute = this.infocardData.middleSection.currentChartParams.xAxisAttribute;
      this.chartOptions.yAxisAttribute = this.infocardData.middleSection.currentChartParams.yAxisAttribute;
      this.chartOptions.chartTitle = this.infocardData.middleSection.currentChartParams.chartTitle;
      this.arisChartCommonService.chartOptionsChange.next();
    }
  }
}
