/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA, Input, Component, ComponentFactoryResolver } from '@angular/core';
import 'rxjs/add/observable/of';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { LocalizationModule, TranslationService } from 'angular-l10n';
import { CommonModule } from '@angular/common';
import { ArisSchematicModule } from '../aris-schematic.module';
import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
import { ChartModule } from '../../../ui-components/chart-module/aris-chart.module';
import { ArisModule } from '../../../../aris.module';
import { ArisScematicInfocardComponent } from './aris-schematic-infocard.component';
import { ArisSchematicDefaultInfocardComponent } from './aris-schematic-default-infocard.component';
import { ArisSchematicComponent } from './aris-schematic.component';
import { ArisSchematicInfocardDynamicComponent } from './aris-schematic-infocard-dynamic.component';
import { ArisSchematicConfig } from '../services/aris-schematic-config.service';
import { FormsModule } from '@angular/forms';
import { DynamicComponentDirective } from '../../../directives/dynamic-component.directive';

export class MockDynamicComponentDirective {
  static componentRef = { instance: { schematicInfocardData: '' } };
  viewContainerRef: any = { clear() { } , createComponent(value: any) { return MockDynamicComponentDirective.componentRef; } };
}
describe('Component: ArisDynamicSchematicInfocardComponent', () => {

  let component: ArisSchematicInfocardDynamicComponent;
  let fixture: ComponentFixture<ArisSchematicInfocardDynamicComponent>;
  let componentFactoryResolver: ComponentFactoryResolver;
  let infoCardElement: DebugElement;
  let infoCardElement2: DebugElement;
  let arisDynamicDirective: DynamicComponentDirective;
  let componentData = { component: "component", data: "data" };

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisSchematicInfocardDynamicComponent],
      schemas: [],
      imports: [ArisPipesModule, LocalizationModule, ChartModule, ArisModule, FormsModule],
      providers: [ArisSchematicConfig, HttpClient, HttpHandler, TranslationService, { provide: DynamicComponentDirective,
        useClass: MockDynamicComponentDirective }]
    }).compileComponents();
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(ArisSchematicInfocardDynamicComponent);
    componentFactoryResolver = TestBed.get(ComponentFactoryResolver);
    arisDynamicDirective = TestBed.get(DynamicComponentDirective);
    // get test component from the fixture
    component = fixture.componentInstance;
  });

  it('ArisDynamicSchematicInfocardComponent should be created', () => {
    expect(component).toBeTruthy();
  });

  it('ArisDynamicSchematicInfocardComponent ngOnInit executed', () => {
    component.componentData = { component: "ArisSchematicInfoCardInterfaceComponent()", data: "data" };
    spyOn(componentFactoryResolver, 'resolveComponentFactory').and.returnValue('ArisSchematicInfoCardInterfaceComponent');
    component.arisDynamicDirective = arisDynamicDirective;
    component.ngOnInit();
    expect(componentFactoryResolver.resolveComponentFactory).toBeTruthy();
  });

  it('ArisDynamicSchematicInfocardComponent ngOnDestroy executed', () => {
    component.ngOnDestroy();
    expect(component).toBeTruthy();
  });

});

