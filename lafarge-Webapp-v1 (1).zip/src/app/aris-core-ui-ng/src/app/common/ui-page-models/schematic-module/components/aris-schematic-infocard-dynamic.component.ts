import { Component, Input, AfterViewInit, ViewChild, ComponentFactoryResolver, OnDestroy, OnInit } from '@angular/core';
import { DynamicComponentDirective } from '../../../directives/dynamic-component.directive';
import { ArisGeoInfoCardCommonService } from '../../geo-module/services/aris-geo-infocard-common.service';
import { ArisSchematicInfoCardInterfaceComponent } from './aris-schematic-infocard-interface.component';
import { ArisSchematicConfig } from '../services/aris-schematic-config.service';

@Component({
  selector: 'aris-dynamic-schematic-infocard',
  template: `<ng-template arisDynamicDirective></ng-template>`
})
export class ArisSchematicInfocardDynamicComponent implements OnInit, OnDestroy {
  @Input() componentData: any;
  @ViewChild(DynamicComponentDirective) arisDynamicDirective: DynamicComponentDirective;
  subscription: any;
  interval: any;
  componentReloadSubscription: any;

  constructor(private componentFactoryResolver: ComponentFactoryResolver,
    private arisSchematicConfig: ArisSchematicConfig) {
  }

  ngOnInit() {
    this.componentReloadSubscription = this.arisSchematicConfig.componentReload.subscribe((data) => {
      this.loadComponent();
    });
    this.loadComponent();
  }

  ngOnDestroy() {
    if (this.componentReloadSubscription) {
      this.componentReloadSubscription.unsubscribe();
    }
  }

  loadComponent() {
    let componentFactory = this.componentFactoryResolver.resolveComponentFactory(this.componentData.component);

    let viewContainerRef = this.arisDynamicDirective.viewContainerRef;
    viewContainerRef.clear();

    let componentRef = viewContainerRef.createComponent(componentFactory);
    (<ArisSchematicInfoCardInterfaceComponent>componentRef.instance).schematicInfocardData = this.componentData.data;
  }
}
