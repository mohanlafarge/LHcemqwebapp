export interface ArisSchematicInfoCardInterfaceComponent {
  schematicInfocardData: any;
}
