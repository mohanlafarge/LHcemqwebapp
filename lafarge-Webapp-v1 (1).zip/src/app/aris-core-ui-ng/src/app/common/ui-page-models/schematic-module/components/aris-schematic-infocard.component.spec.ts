/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import 'rxjs/add/observable/of';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { LocalizationModule, TranslationService } from 'angular-l10n';
import { CommonModule } from '@angular/common';
import { ArisSchematicModule } from '../aris-schematic.module';
import { ArisChartCommonService } from '../../../ui-components/chart-module/services/aris-chart-common.service';
import { ChartModule } from '../../../ui-components/chart-module/aris-chart.module';
import { ArisModule } from '../../../../aris.module';
import { ArisScematicInfocardComponent } from './aris-schematic-infocard.component';
import { ArisSchematicDefaultInfocardComponent } from './aris-schematic-default-infocard.component';
import { ArisSchematicComponent } from './aris-schematic.component';
import { ArisSchematicConfig } from '../services/aris-schematic-config.service';
import { ArisSchematicInfocardDynamicComponent } from './aris-schematic-infocard-dynamic.component';
import { Subscription, Observable, Subject } from 'rxjs';

describe('Component: ArisScematicInfocardComponent', () => {

  let component: ArisScematicInfocardComponent;
  let fixture: ComponentFixture<ArisScematicInfocardComponent>;
  let infoCardElement: DebugElement;
  let infoCardElement2: DebugElement;
  let arisSchematicConfig: ArisSchematicConfig;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisScematicInfocardComponent, ArisSchematicInfocardDynamicComponent],
      schemas: [],
      imports: [ArisPipesModule, LocalizationModule, ChartModule, ArisModule],
      providers: [ArisSchematicConfig, HttpClient, HttpHandler, TranslationService, ArisChartCommonService]
    }).compileComponents();
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(ArisScematicInfocardComponent);
    // get test component from the fixture
    component = fixture.componentInstance;
    component.hideInfocardSubsciption = new Subscription();
    arisSchematicConfig = TestBed.get(ArisSchematicConfig);
    spyOn(arisSchematicConfig, 'refreshSchematicInfocard').and.returnValue(Observable.of('value'));
  });

  it('ArisScematicInfocardComponent should be created', () => {
    component.hideInfocardSubsciption = undefined;
    component.refreshSchematicInfocardSubscription = undefined;
    component.ngOnDestroy();
    expect(component).toBeTruthy();
    expect(component.isInfocardVisisble).toBe(false);
  });

  it('ArisScematicInfocardComponent: checnking ngOninit() method', () => {
    component.ngOnInit();
    expect(component.componentData.component).toBe(ArisSchematicDefaultInfocardComponent);
  });

  it('ArisScematicInfocardComponent: checnking initializeSchematicInfoCardComponent() method infocardComponent have data', () => {
    component.infocardComponent = ArisSchematicComponent;
    component.initializeSchematicInfoCardComponent();
    expect(component.componentData.component).toBe(ArisSchematicComponent);
  });
  it('ArisScematicInfocardComponent: checnking initializeSchematicInfoCardComponent() method infocardComponent undefined', () => {
    component.infocardComponent = undefined;
    component.initializeSchematicInfoCardComponent();
    expect(component.componentData.component).toBe(ArisSchematicDefaultInfocardComponent);
  });
});
