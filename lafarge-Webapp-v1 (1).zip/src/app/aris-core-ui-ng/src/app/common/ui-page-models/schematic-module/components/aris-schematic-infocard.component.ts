import { Component, OnInit, Input, OnDestroy } from "@angular/core";
import { ArisGeoInfocardComponent } from "../../geo-module/components/aris-geo-infocard-main.component";
import { ArisSchematicDefaultInfocardComponent } from "./aris-schematic-default-infocard.component";
import { ArisGeoInfoCardCommonService } from "../../geo-module/services/aris-geo-infocard-common.service";
import { ArisSchematicConfig } from "../services/aris-schematic-config.service";
import { Subscription } from "rxjs/Subscription";

@Component({
  selector: "aris-schematic-infocard",
  template: `
    <aris-dynamic-schematic-infocard
      [componentData]="componentData"
    ></aris-dynamic-schematic-infocard>
  `
})
export class ArisScematicInfocardComponent implements OnInit, OnDestroy {
  componentData: any = {};
  public infocardComponent: any;
  public isInfocardVisisble = false;
  public infocardData: any;
  hideInfocardSubsciption: Subscription;
  refreshSchematicInfocardSubscription: Subscription;
  constructor(private arisSchematicConfig: ArisSchematicConfig) {
    this.infocardData = {};
    this.refreshSchematicInfocardSubscription = this.arisSchematicConfig.refreshSchematicInfocard.subscribe(
      feature => {
        this.infocardComponent = this.arisSchematicConfig.getInfocardComponent(
          feature
        );
        this.arisSchematicConfig
          .fireInfocardAPIs(this.infocardData, feature)
          .then(data => {
            this.infocardData = data;
            this.isInfocardVisisble = true;
            this.initializeSchematicInfoCardComponent();
          });
        this.hideInfocardSubsciption = this.arisSchematicConfig.hideInfocard.subscribe(
          data => {
            this.isInfocardVisisble = false;
            this.initializeSchematicInfoCardComponent();
          }
        );
      }
    );
  }

  ngOnInit() {
    this.initializeSchematicInfoCardComponent();
  }

  ngOnDestroy() {
    if (this.hideInfocardSubsciption) {
      this.hideInfocardSubsciption.unsubscribe();
    }
    if (this.refreshSchematicInfocardSubscription) {
      this.refreshSchematicInfocardSubscription.unsubscribe();
    }
  }

  initializeSchematicInfoCardComponent() {
    this.componentData.data = {
      apiData: this.infocardData,
      isInfocardVisisble: this.isInfocardVisisble
    };
    if (this.infocardComponent) {
      this.componentData.component = this.infocardComponent;
    } else {
      this.componentData.component = ArisSchematicDefaultInfocardComponent;
    }
    this.arisSchematicConfig.componentReload.next();
  }
}
