/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject, async } from '@angular/core/testing';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';
import { HttpClient, HttpHandler } from '@angular/common/http';

import { ArisModule } from '../../../../aris.module';
import { ArisSchematicModule } from '../aris-schematic.module';
// import { ArisSchematicConfig } from '../services/aris-schematic.config.service';
import { ArisSchematicMaintenanceComponent } from './aris-schematic-maintenance.component';
import { LocalizationModule, TranslationService } from 'angular-l10n';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ArisschematicMarkersPositions } from '../services/aris-schematic-markers-positions.service';
import { ArisSchematicConfig } from '../services/aris-schematic-config.service';
import { Subject, Observable } from 'rxjs';
import { ArisUiComponentsModule } from '../../../ui-components/aris-ui-components.module';

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};

describe('Component: ArisSchematicMaintenanceComponent', () => {

  let component: ArisSchematicMaintenanceComponent;
  let fixture: ComponentFixture<ArisSchematicMaintenanceComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;
//   let authService: AuthService;
  let arisSchematicConfig: ArisSchematicConfig;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisSchematicMaintenanceComponent],
      schemas: [],
      imports: [ArisModule, CommonModule, LocalizationModule, ArisPipesModule, FormsModule, ReactiveFormsModule, ArisUiComponentsModule],
      providers: [HttpClient, HttpHandler, ArisSchematicConfig, ArisschematicMarkersPositions,
        { provide: TranslationService, useValue: mockTranslationService }]
    }).compileComponents();
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(ArisSchematicMaintenanceComponent);
    arisSchematicConfig = fixture.debugElement.injector.get(ArisSchematicConfig);
    // get test component from the fixture
    component = fixture.componentInstance;
    component.originalAssetInfo = '[{"id":1,"assetName":"Power Unit","xCoordinate":80.947265625,"yCoordinate":17.2265625}]';
  });

  it('setAssetInfo executed', () => {
    component.assetInfo = [{ assetName: 'assetName' }];
    let data = [{ getGeometry() {} }];
    component.layer = 'plantScematicLayer';
    component.setAssetInfo(data);
    expect(component).toBeTruthy();
  });

  it('setAssetInfo else for empty data executed', () => {
    component.setAssetInfo(undefined);
    expect(component).toBeTruthy();
  });

  it('setAssetInfo else for empty assetInfo executed', () => {
    component.assetInfo = undefined;
    let data = [{ getGeometry() {} }];
    component.layer = 'plantScematicLayer';
    component.setAssetInfo(data);
    expect(component).toBeTruthy();
  });

  it('ArisSchematicMaintenanceComponent test: checking getMapLayerName method  whether its giving proper map layer name or not', () => {
    const selectedLayer = 'plantScematicLayer';
    const result = component.getMapLayerName(selectedLayer);
    expect(' plant Scematic Layer').toBe(result);
  });

  it('ArisSchematicMaintenanceComponent test: checking getMapLayerName method  else scenario', () => {
    component.getMapLayerName(undefined);
    expect(component).toBeTruthy();
  });

  it('ArisSchematicMaintenanceComponent test: checking onTextfieldChange method  whether its property "changesDone" is changed or not', () => {
    let assests = {
      assetName: 'Power Unit',
      changesDone: false,
      xCoordinate: 80.94726562,
      yCoordinate: 17.2265625
    };
    component.onTextfieldChange(assests);
    expect(assests.changesDone).toBe(true);
  });

  it('ArisSchematicMaintenanceComponent test: checking onTextfieldChange method  else scenario', () => {
    let assests = {
      assetName: 'Power Unit Value',
      changesDone: false,
      xCoordinate: 80.94726562,
      yCoordinate: 17.2265625
    };
    component.onTextfieldChange(assests);
    expect(assests.changesDone).toBe(false);
  });

  it('ArisSchematicMaintenanceComponent test: checking cancelCoordinates method  whether its property "changesDone" is changed or not', () => {
    let assests = {
      assetName: 'Power Unit',
      changesDone: true,
      xCoordinate: 80.94726562,
      yCoordinate: 17.2265625
    };
    component.cancelCoordinates(assests);
    expect(component).toBeTruthy();
  });

  it('ArisSchematicMaintenanceComponent test: checking cancelCoordinates method   else scenario', () => {
    let assests = {
      assetName: 'Power Unit Value',
      changesDone: true,
      xCoordinate: 80.94726562,
      yCoordinate: 17.2265625
    };
    component.cancelCoordinates(assests);
    expect(component).toBeTruthy();
  });

  it('ArisSchematicMaintenanceComponent test: checking saveCoordinates method error scenario', () => {
    let assests = {
      assetName: 'Power Unit',
      changesDone: true,
      xCoordinate: 80.94726562,
      yCoordinate: 17.2265625
    };
    const selectedLayer = 'plantScematicLayer';
    component.selectedLayer = selectedLayer;
    let arisMarkersPositions = TestBed.get(ArisschematicMarkersPositions);
    spyOn(arisMarkersPositions, 'saveMarkerPositionsForAssetType').and.callThrough();
    component.saveCoordinates(assests);
    expect(arisMarkersPositions.saveMarkerPositionsForAssetType).toHaveBeenCalledWith(selectedLayer, assests);
  });

  it('ArisSchematicMaintenanceComponent test: checking saveCoordinates method that with 2 parameter this is firing ajax call or not', () => {
    let data = '{"data": "data"}';
    let assests = {
      assetName: 'Power Unit',
      changesDone: true,
      xCoordinate: 80.94726562,
      yCoordinate: 17.2265625
    };
    const selectedLayer = 'plantScematicLayer';
    component.selectedLayer = selectedLayer;
    let arisMarkersPositions = TestBed.get(ArisschematicMarkersPositions);
    spyOn(arisMarkersPositions, 'saveMarkerPositionsForAssetType').and.callFake(() => Promise.resolve(data));
    component.saveCoordinates(assests);
    expect(arisMarkersPositions.saveMarkerPositionsForAssetType).toHaveBeenCalledWith(selectedLayer, assests);
  });

  it('ArisSchematicMaintenanceComponent test: checking saveCoordinates method else scenario', () => {
    let data = '{"data": "data"}';
    let assests = {
      assetName: 'Power Unit Value',
      changesDone: true,
      xCoordinate: 80.94726562,
      yCoordinate: 17.2265625
    };
    const selectedLayer = 'plantScematicLayer';
    component.selectedLayer = selectedLayer;
    let arisMarkersPositions = TestBed.get(ArisschematicMarkersPositions);
    spyOn(arisMarkersPositions, 'saveMarkerPositionsForAssetType').and.callFake(() => Promise.resolve(data));
    component.saveCoordinates(assests);
    expect(arisMarkersPositions.saveMarkerPositionsForAssetType).toHaveBeenCalledWith(selectedLayer, assests);
  });

  it('ArisSchematicMaintenanceComponent test: checking onAssetNameChange method that with 1 parameter this is firing ajax call or not', () => {
    let data = '{"data": "data"}';
    const selectedLayer = 'plantScematicLayer';
    component.selectedLayer = selectedLayer;
    let arisMarkersPositions = TestBed.get(ArisschematicMarkersPositions);
    spyOn(arisMarkersPositions, 'getMarkerPositionsForAssetType').and.callFake(() => Promise.resolve(data));
    component.onAssetNameChange(selectedLayer);
    expect(arisMarkersPositions.getMarkerPositionsForAssetType).toHaveBeenCalledWith(selectedLayer);
  });

  it('ArisSchematicMaintenanceComponent test: checking onAssetNameChange method error scenario', () => {
    const selectedLayer = 'plantScematicLayer';
    component.selectedLayer = selectedLayer;
    let arisMarkersPositions = TestBed.get(ArisschematicMarkersPositions);
    spyOn(arisMarkersPositions, 'getMarkerPositionsForAssetType').and.callThrough();
    component.onAssetNameChange(selectedLayer);
    expect(arisMarkersPositions.getMarkerPositionsForAssetType).toHaveBeenCalledWith(selectedLayer);
  });

  it('ArisSchematicMaintenanceComponent test: checking showTables method if scenario ', () => {
    component.showUserTable = false;
    component.showTables();
    expect(component.originalRefreshStatus).toBeTruthy();
  });

  it('ArisSchematicMaintenanceComponent test: checking showTables method else scenario ', () => {
    component.showUserTable = true;
    component.showTables();
    expect(component.showUserTable).toBeFalsy();
  });

  it('ArisSchematicMaintenanceComponent test: checking ngOnInit ', () => {
    component.layer = "layer";
    component.ngOnInit();
    expect(component.layerDetail).toEqual(['0', '1', '2', '3', '4']);
  });
});
