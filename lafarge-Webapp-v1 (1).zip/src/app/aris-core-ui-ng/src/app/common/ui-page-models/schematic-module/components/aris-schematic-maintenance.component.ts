import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { TranslationService, Language } from 'angular-l10n';
import { AfterViewInit, OnChanges, OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { Subscription } from 'rxjs/Subscription';
import { ArisschematicMarkersPositions } from '../services/aris-schematic-markers-positions.service';
import { ArisPageRefreshService } from '../../../services/aris-page-refresh.service';
import { ArisNotificationBoxService } from '../../../ui-page-sections/error-module/services/aris-notification-box.service';
import { ArisSchematicConfig } from '../services/aris-schematic-config.service';
declare var $: any;

@Component({
  selector: 'aris-schematic-maintenance',
  templateUrl: './aris-schematic-maintenance.component.html',
  styleUrls: []
})
export class ArisSchematicMaintenanceComponent implements OnInit, OnDestroy  {
  @Input() layer: any;
  @Output() moveMarkersNow: EventEmitter<any> = new EventEmitter<any>();
  @Output() updateCoordinates: EventEmitter<any> = new EventEmitter<any>();
  @Output() onlyLayerRelatedMoveMarkers: EventEmitter<any> = new EventEmitter<any>();

  @Language() lang: string;
  public showUserTable = false;
  private paramsSubscription: Subscription;
  public layerDetail: any;
  public selectedLayer: any;
  public selectAssetName: any;
  public assetInfo: any;
  public originalAssetInfo: any;
  public originalRefreshStatus: any;
  public mapLayerName: any;
  constructor(private arisSchematicConfig: ArisSchematicConfig,
              private arisschematicMarkersPositions: ArisschematicMarkersPositions,
              private arisPageRefreshService: ArisPageRefreshService,
              private notificationService: ArisNotificationBoxService) {}
  ngOnDestroy() {
    this.paramsSubscription.unsubscribe();
  }
  ngOnInit() {
    this.layerDetail = Object.keys(this.layer);
    this.originalRefreshStatus = this.arisPageRefreshService.isEnable();
    /**
     *  this functionionality is work while user move marker then
     *  on run time you may see changes on cordinates in cordinate maintenance table
     */
    this.paramsSubscription = this.arisSchematicConfig.markerMoved.subscribe((data) => {
      this.setAssetInfo(data);
    });
  }

  setAssetInfo(data) {
    if (data) {
      if (this.assetInfo) {
        this.assetInfo.forEach((assests) => {
          if (data[0] === assests.assetName) {
            assests.xCoordinate =  data[1].getGeometry().getCoordinates()[0];
            assests.yCoordinate =  data[1].getGeometry().getCoordinates()[1];
            assests.changesDone = true;
            assests.geometry = data[1];
          }
        });
      }
    }
  }

  showTables() {
    this.updatePageRefresh();
  }
  updatePageRefresh() {
    this.showUserTable = !this.showUserTable;
    if (this.showUserTable === true) {
      this.originalRefreshStatus = this.arisPageRefreshService.isEnable();
      this.arisPageRefreshService.enable(false);
    } else {
      $('#select').prop('selectedIndex', 0);
      this.assetInfo = [];
      this.mapLayerName = '';
      this.arisPageRefreshService.enable(this.originalRefreshStatus);
    }
    this.moveMarkersNow.next(this.showUserTable);
  }
  /**
   * this function for making of map layer name from Layer Id
   * @param selectedLayer = take layer name
   */
  getMapLayerName(selectedLayer) {
    if (selectedLayer) {
      let name = '';
      let layerName =  selectedLayer.match(/[A-Z]?[a-z]+/g);
      layerName.forEach((data) => {
        name = name + " " + data;
      });
      return name;
    }
  }
  /**
   * this function run while user select layer from dropdown
   * @param selectedLayer = selected layer name from dropdown
   */
  onAssetNameChange(selectedLayer) {
    this.selectedLayer = selectedLayer;
    this.mapLayerName = this.getMapLayerName(selectedLayer);
    this.arisschematicMarkersPositions.getMarkerPositionsForAssetType(this.selectedLayer).then((response) => {
      this.originalAssetInfo = JSON.stringify(response);
      this.assetInfo =  Object.assign([], response);
      this.onlyLayerRelatedMoveMarkers.next(this.selectedLayer);
    }, (err) => {
      console.log(err);
    });
  }
/**
 * while u change any input firld inside table
 * @param assests = inputfield name
 */
  onTextfieldChange(assests) {
    let oldValue = JSON.parse(this.originalAssetInfo);
    oldValue.forEach((oldData, oldKeys) => {
      if (oldData.assetName === assests.assetName) {
        assests.changesDone = true;
      }
    });
  }
/**
 * save marker position layer wise
 * @param assests = marker pos as per the layer name
 */
  saveCoordinates(assests) {
    this.arisschematicMarkersPositions.saveMarkerPositionsForAssetType(this.selectedLayer, assests).then((response) => {
      let oldValue = JSON.parse(this.originalAssetInfo);
      oldValue.forEach((oldData, oldKeys) => {
        if (oldData.assetName === assests.assetName) {
          oldData.xCoordinate = assests.xCoordinate;
          oldData.yCoordinate = assests.yCoordinate;
          setTimeout(() => {
            this.updateCoordinates.next([assests, this.selectedLayer]);
            setTimeout(() => {
              assests.changesDone = false;
            }, 300);
          }, 300);
        }
      });
      const successMessage = { status: '200', title: 'CLI_MSG_TIT_OPERATION_SUCCESS', message: 'CLI_MSG_DESC_OPERATION_SUCCESS' };
      this.notificationService.showNotification(successMessage, 'right', 'success');
    }, (err) => {
      this.notificationService.showNotification(err, 'right', 'error');
    });
  }
  cancelCoordinates(assests) {
    let oldValue = JSON.parse(this.originalAssetInfo);
    oldValue.forEach((oldData, oldKeys) => {
      if (oldData.assetName === assests.assetName) {
        assests.xCoordinate =  oldData.xCoordinate;
        assests.yCoordinate =  oldData.yCoordinate;
        setTimeout(() => {
          this.updateCoordinates.next([assests, this.selectedLayer]);
          setTimeout(() => {
            assests.changesDone = false;
          }, 300);
        }, 300);
      }
    });
  }
}
