/* tslint:disable:no-unused-variable */
import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { ArisSchematicComponent } from './aris-schematic.component';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { DatePipe } from '@angular/common';
import { By } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { ArisPermissionPipe } from '../../../pipes/aris-permission.pipes';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { ArisPermissionService } from '../../../services/aris-permission.service';
import { ArisSchematicConfig } from '../services/aris-schematic-config.service';
import { PlantSchematicLayerService } from '../../../../prototypes/schematic-module/services/plant-schematic-layer.service';
import { ArisFooterService } from '../../../ui-page-sections/footer-module/services/aris-footer-service';
import { ArisPageSectionObservableEventService } from '../../../ui-page-sections/services/aris-page-section-observable-event.service';
import { ArisThemeService } from '../../../services/aris-theme.service';


class MockDataElement { 
  set(key: string, val: any) {  }
}

describe('Component: ArisSchematicComponent', () => {

  let component: ArisSchematicComponent;
  let fixture: ComponentFixture<ArisSchematicComponent>;
  let componentDiv: DebugElement;
  let componentEl: DebugElement;
  let arisSchematicConfig: ArisSchematicConfig;
  
//   let authService: AuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisSchematicComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [ArisPipesModule],
      providers: [{
        provide: ActivatedRoute,
        useValue: {
          params: Observable.of({ geoLayerName: "LA:arislngschematic" })
        }
      }, ArisSchematicConfig, ArisThemeService, {
        provide: Router,
        useClass: class { navigate = jasmine.createSpy("navigate"); }
      }, HttpClient, HttpHandler, PlantSchematicLayerService, ArisPermissionPipe, ArisPermissionService, ArisFooterService, ArisPageSectionObservableEventService]
    }).compileComponents();
  });

  beforeEach(() => {
      // create component and test fixture
    fixture = TestBed.createComponent(ArisSchematicComponent);

    // get test component from the fixture
    component = fixture.componentInstance;

  });

  it('open layers canvas element is created', () => {
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('#schematicDiag'));
    console.log(component);
    expect(componentEl.nativeElement.querySelector('.ol-viewport')).toBeTruthy();
    expect(componentEl.nativeElement.querySelector('canvas.ol-unselectable')).toBeTruthy();
  });

  it('ngOnInit created', () => {
    let config = TestBed.get(ArisSchematicConfig);
    window.app.config.schematic.footerConfig = undefined;
    spyOn(config, 'getSchematicPageConfig').and.returnValue('white');
    component.ngOnInit();
    componentEl = fixture.debugElement.query(By.css('#schematicDiag'));
    console.log(component);
    expect(componentEl.nativeElement.querySelector('.ol-viewport')).toBeTruthy();
    expect(componentEl.nativeElement.querySelector('canvas.ol-unselectable')).toBeTruthy();
  });

  it('colorFinder executed', () => {
    let expected = component.colorFinder('AMBER');
    expect(expected).toEqual('amber');
  });

  it('showHideLayer executed', () => {    
    let data = { isChecked: true, mapLayer: { name: 'name', id: 0, hasFilter: true, service: 'MockService' } };
    component.markerLayersAndFeatures = [new MockDataElement(), new MockDataElement()];
    component.showHideLayer(data);
    expect(component.markerLayersAndFeatures).toBeDefined();
  });

  it('showHideLayer else scenario executed', () => {
    let data = { isChecked: false, mapLayer: { name: 'name', id: 0, hasFilter: true, service: 'MockService' } };
    component.markerLayersAndFeatures = [new MockDataElement(), new MockDataElement()];
    component.showHideLayer(data);
    expect(component.markerLayersAndFeatures).toBeDefined();
  });

  it('createMarkerPoint executed', () => {
    let obj = { ragStatus: 'AMBER' };
    let vectorSrc = { addFeature(val: any) {} };
    component.createMarkerPoint(obj, 'layerId', vectorSrc, null);
    expect(component.iconFeature).toBeDefined();
  });

  it('createMarkerPoint else scenario executed', () => {
    let obj = { ragStatus: 'AMBER' };
    let vectorSrc = { addFeature(val: any) {} };
    spyOn(component, 'colorFinder').and.returnValue(null);
    component.createMarkerPoint(obj, 'layerId', vectorSrc, null);
    expect(component.iconFeature).toBeDefined();
  });

  it('moveMarkersNow executed', () => {
    component.moveableMarkersArray = ['AMBER'];
    component.map = { removeInteraction(val: any) { } };
    component.moveMarkersNow(undefined);
    expect(component.map.removeInteraction).toBeDefined();
  });

  it('moveMarkersNow if scenario executed', () => {
    component.moveableMarkersArray = ['AMBER'];
    component.map = { removeInteraction(val: any) { } };
    component.moveMarkersNow('value');
    expect(component.map.removeInteraction).toBeDefined();
  });

  it('getSingleLayerInformation string value executed', () => {
    let data = { val: 'val' };
    arisSchematicConfig = TestBed.get(ArisSchematicConfig);
    component.layers = { layerId: { markerAPI: 'value', colorFinder() {} } };
    component.moveableMarkersArray = ['AMBER'];
    component.map = { addLayer(val: any) { } };
    spyOn(arisSchematicConfig, 'getDataFormarkerApi').and.callFake(() => Promise.resolve(data));
    component.getSingleLayerInformation('layerId');
    expect(arisSchematicConfig.getDataFormarkerApi).toHaveBeenCalled();
  });

  it('getSingleLayerInformation string value else scenario executed', () => {
    let data = { val: 'val' };
    arisSchematicConfig = TestBed.get(ArisSchematicConfig);
    component.layers = { layerId: { markerAPI: 'value', colorFinder: undefined } };
    component.moveableMarkersArray = ['AMBER'];
    component.markerLayersAndFeatures = { layerId: 'val' };
    component.map = { addLayer(val: any) { } };
    spyOn(arisSchematicConfig, 'getDataFormarkerApi').and.callFake(() => Promise.resolve(data));
    component.getSingleLayerInformation('layerId');
    expect(arisSchematicConfig.getDataFormarkerApi).toHaveBeenCalled();
  });

  it('getSingleLayerInformation function value executed', () => {
    let data = ['value', 'layerId'];
    component.layers = { layerId: { markerAPI() {}, colorFinder() {} } };
    component.moveableMarkersArray = ['AMBER'];
    component.map = { addLayer(val: any) { } };
    spyOn(component.layers.layerId, 'markerAPI').and.callFake(() => Promise.resolve(data));
    component.getSingleLayerInformation('layerId');
    expect(component.layers.layerId.markerAPI).toHaveBeenCalled();
  });

  it('onlyLayerRelatedMoveMarkers executed', () => {
    let data1 = ['val', 'value'];
    let data = { getFeatures() { return this.data1; } };
    component.markerLayersAndFeatures = { layerId: { getSource() {} } };
    spyOn(component.markerLayersAndFeatures.layerId, 'getSource').and.returnValue(data);
    spyOn(component.markerLayersAndFeatures.layerId.getSource(), 'getFeatures').and.returnValue(data1);
    component.map = { addInteraction(val: any) { } };
    component.markerModifyObj = { modifyObj: 'value' };
    spyOn(component, 'makeMovable').and.returnValue('');
    component.onlyLayerRelatedMoveMarkers('layerId');
    expect(component.makeMovable).toHaveBeenCalled();
  });

  it('updateCoordinates executed', () => {
    let event = [{ assetName: 'value' }, 'layerId'];
    let data1 = [{ get(name: any) { return 'values'; } }];
    let data = { getFeatures() { return this.data1; } };
    component.markerLayersAndFeatures = { layerId: { getSource() {} } };
    spyOn(component.markerLayersAndFeatures.layerId, 'getSource').and.returnValue(data);
    spyOn(component.markerLayersAndFeatures.layerId.getSource(), 'getFeatures').and.returnValue(data1);
    component.map = { addInteraction(val: any) { } };
    component.markerModifyObj = { modifyObj: 'value' };
    component.updateCoordinates(event);
    expect(component.markerLayersAndFeatures.layerId.getSource).toHaveBeenCalled();
  });

});
