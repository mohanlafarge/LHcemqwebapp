import { Component, OnInit, AfterContentInit, OnDestroy, ViewEncapsulation, ElementRef, NgZone } from "@angular/core";
// // import * as $ from 'jquery';
import { ActivatedRoute, Router } from "@angular/router";
import { Subscription } from "rxjs/Subscription";
import { ChangeDetectorRef } from "@angular/core/src/change_detection/change_detector_ref";
import { RouteReuseStrategy, DetachedRouteHandle } from "@angular/router/src/route_reuse_strategy";
import { OutletContext } from "@angular/router/src/router_outlet_context";
// import { environment } from "../../../../../environments/environment";

import { ArisSchematicConfig } from "../services/aris-schematic-config.service";
import { ArisFooterService } from "../../../ui-page-sections/footer-module/services/aris-footer-service";
import { ArisThemeService } from "../../../services/aris-theme.service";


declare var $: any;
declare var ol: any;
@Component({
  selector: 'aris-schematic',
  templateUrl: './aris-schematic.component.html',
  styleUrls: ['../css/aris-schematic-module.css'],
  encapsulation: ViewEncapsulation.None
})
export class ArisSchematicComponent implements OnInit, OnDestroy {
  public schematic_config: any = window.app.config.schematic;
  public pageTitle = String;
  public geoLayerName: any;
  public layers: any;
  public layerArray: any;
  public markerLayersAndFeatures: any = {};
  public map: any;
  private stroke: any;
  public markerModifyObj: any = {};
  public moveableMarkersArray = [];
  public layerList = [];
  private schematicPageProps = {};
  paramsSubscription: Subscription;
  layerKeys: any;
  public iconFeature: any;
  public showMapLayer = false;
  public themeConfig: any = '';
  constructor(private route: ActivatedRoute,
    private arisSchematicConfig: ArisSchematicConfig,
    private router: Router,
    private footerService: ArisFooterService,
    private ngZone: NgZone) {

    // This block code for used for protactor scripts
    window.selectMarker = ((layer, markerId) => {
      let features = this.markerLayersAndFeatures[layer].getSource().getFeatures();
      for (let i = 0; i < features.length; i++) {
        if (features[i]. getProperties().name === markerId) {
          let feature = features[i];
          this.onOpenLayerFeatureClick(feature, this);
        }
      }
    });
  }

  ngOnDestroy() {
    this.paramsSubscription.unsubscribe();
  }
  ngOnInit() {
    if (window.navigator.userAgent === "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E; .NET CLR 2.0.50727; .NET CLR 3.0.30729; .NET CLR 3.5.30729; gdn/adcp; managedpc; rv:11.0) like Gecko" ||
       navigator.appName === 'Microsoft Internet Explorer' ||  !!(navigator.userAgent.match(/Trident/) || navigator.userAgent.match(/rv:11/))) {
      if ($('#schematicDiag').hasClass("s-flex1")) {
        $('#schematicDiag').removeClass("s-flex1");
      }
    }
    if (window.app.config.schematic.footerConfig !== undefined) {
      console.log(window.app.config.schematic.footerConfig);
      this.footerService.setFooterInfo(window.app.config.schematic.footerConfig);
    } else {
      this.footerService.setFooterInfo("onlyRefreshPage");
    }

    this.paramsSubscription = this.route.params.subscribe((params) => {
      // if (this.geoLayerName !== null && this.geoLayerName !==  params.geoLayerName) {
      //   window.location.reload();
      // }
      this.geoLayerName =  params.geoLayerName;
      let workSpaceName = ((params.geoLayerName).split(":"))[0];

      this.schematicPageProps = this.arisSchematicConfig.getSchematicPageConfig(params.geoLayerName);
      if (this.schematicPageProps.hasOwnProperty('pageTitle')) {
        this.pageTitle = this.schematicPageProps['pageTitle'];
      }

      let mousePositionControl = new ol.control.MousePosition({
        className: 'custom-mouse-position',
        target: document.getElementById('mousepos'),
        coordinateFormat: ol.coordinate.createStringXY(5),
        undefinedHTML: '&nbsp;'
      });

      this.stroke = new ol.style.Stroke({ color: 'black', width: 1 });
      let vectorSource = new ol.source.Vector({
        // features: [rome, london, madrid, iconFeature]
      });

      let vectorLayer = new ol.layer.Vector({
        source: vectorSource
      });

      this.map = new ol.Map({
        controls: ol.control.defaults({
              attribution: false
            }).extend([mousePositionControl,
            ]),
        layers: [
          new ol.layer.Tile({
            source: new ol.source.TileWMS({
              attributions: [new ol.Attribution({
                html: '&copy; ' +
                    '<a href="http://www.geo.admin.ch/internet/geoportal/' +
                    'en/home.html">'
              })],
              crossOrigin: 'anonymous',
              params: {
                LAYERS: params.geoLayerName,
                FORMAT: 'image/jpeg'
              },
              url: 'geoserver/' + workSpaceName + '/wms',
              serverType: 'geoserver'
            }),
            extent: [-180.0000, -90.0000, 180.0000, 90.0000]
          }),
          vectorLayer
        ],
        target: 'schematicDiag',
        view: new ol.View({
          projection: 'EPSG:4326',
         // center: ol.extent.getCenter(extent),
          center: [0, 0],
          extent: [-180.0000, -90.0000, 180.0000, 90.0000],
          zoom: 3
        })
      });
    });
    let that: any;
    that = this;
    this.map.on('pointermove', (e) => {
      if (e.dragging) {
        return;
      }
      let pixel = that.map.getEventPixel(e.originalEvent);
      let hit = that.map.hasFeatureAtPixel(pixel);
      if (this.map.getTargetElement() .style) {
        this.map.getTargetElement().style.cursor = hit ? 'pointer' : '';
      }
    });
    this.ngZone.run(() => {
      this.map.on('click', (evt: any) => {

        let feature = that.map.forEachFeatureAtPixel(evt.pixel, (features) => {
          return features;
        });
        this.onOpenLayerFeatureClick(feature, that);
      });
    });

    this.initLayers();
  }

  onOpenLayerFeatureClick(feature, that) {
    if (feature) {
      let layerId = feature.get('layerId');
      if (that.layers[layerId].featureClickHandler !== null && typeof that.layers[layerId].featureClickHandler === 'function') {
        that.layers[layerId].featureClickHandler(feature);
      } else {
        let markerHyperLink: any;
        if (that.schematicPageProps['markerHyperLinks'] !== undefined) {
          markerHyperLink = that.schematicPageProps['markerHyperLinks'][feature.get('name')];
        }
        if (markerHyperLink) {
          let _that = that;
          _that.router.navigate([
            '/page/schematicdiag',
            markerHyperLink.split("/").pop()
          ]);
        } else {
          console.log("showing Infocard");
          this.arisSchematicConfig.refreshSchematicInfocard.next(feature);
        }
      }
    }
  }

  onMapLayerClick(data) {
    this.showHideLayer(data);
  }

  initLayers() {
    let schematicLayerPromise = this.arisSchematicConfig.getSchematicLayers(this.geoLayerName);
    this.layers = schematicLayerPromise;
    this.layerKeys = Object.keys(this.layers);

    for (let layerId in schematicLayerPromise) {
      if (schematicLayerPromise.hasOwnProperty(layerId)) {
        this.layerList.push(schematicLayerPromise[layerId]);
        this.markerLayersAndFeatures[layerId] = [];
        this.getSingleLayerInformation(layerId);
      }
    }
    $("#schematicDiag").css("height", $("#schematicDiag").outerHeight() - 1);
  }
  colorFinder(colName) {
    let colList = { AMBER: 'amber', RED: 'red', GREEN: 'green', BLUE: 'blue', YELLOW: 'yellow' };
    return colList[colName];
  }
  createMarkerPoint(obj, layerid, vectorSrc, col) {
    let cols = col;
    if (cols === null) {
      cols = this.colorFinder(obj.ragStatus);
    }

    if (cols !== null) {
      cols = cols.toLowerCase();
    }
    this.iconFeature = new ol.Feature({
      geometry: new ol.geom.Point([obj.xCoordinate, obj.yCoordinate]),
      name: obj.assetName,
      latitude: obj.latitude,
      longitude: obj.longitude,
      layerId: layerid,
      xCoordinate: obj.xCoordinate,
      yCoordinate: obj.yCoordinate,
      color: cols
    });

    let iconStyle = new ol.style.Style({
      image: new ol.style.Icon({
        // color: col,
        anchor: [0.5, 1],
        anchorOrigin: 'top-left',
        anchorXUnits: 'fraction',
        anchorYUnits: 'fraction',
        opacity: 0.8,
        fill: new ol.style.Fill({ color: cols }),
        stroke: this.stroke,
        // points: 1,
        // radius: 5,

        src: './app/common/resources/img/marker_' + layerid.toLowerCase() + '_' + cols + ".png"
      })

    });
    this.iconFeature.setStyle(iconStyle);
    vectorSrc.addFeature(this.iconFeature);
  }
  getSingleLayerInformation(layerId) {
    let promise: any;
    let color;
    if (this.layers[layerId].markerAPI !== undefined && typeof this.layers[layerId].markerAPI === 'function') {
      promise = this.layers[layerId].markerAPI();
    } else if (this.layers[layerId].markerAPI !== undefined && typeof this.layers[layerId].markerAPI === 'string') {
      let withMarkerurl = 'rest/getFromDataSource/' + this.layers[layerId].markerAPI + '?offset=0&limit=1000';
      promise = this.arisSchematicConfig.getDataFormarkerApi(withMarkerurl);
    } else {
      let url = 'rest/getFromDataSource/' + layerId + 'Markers?offset=0&limit=1000';
      promise = this.arisSchematicConfig.getDataFormarkerApi(url);
    }
    promise.then((d) => {
      let vector_layer = new ol.layer.Vector({
        source: new ol.source.Vector({
          features: [],
          wrapX: false
        })
      });
      this.map.addLayer(vector_layer);

      if (this.markerLayersAndFeatures[layerId] === undefined) {
        this.markerLayersAndFeatures[layerId] = [];
      }
      this.markerLayersAndFeatures[layerId] = vector_layer;
      d.forEach((iv, idx) => {
        color = null;
        if (this.layers[layerId].colorFinder !== undefined && $.type(this.layers[layerId].colorFinder) === 'function') {
          color = this.layers[layerId].colorFinder(iv);
        }
        this.createMarkerPoint(iv, layerId, vector_layer.getSource(), color);
      });
    });
  }

  showHideLayer(data) {
    // this.isSchematicInfocardVisible = false;
    this.arisSchematicConfig.hideInfocard.next();
    if (data.isChecked === true) {
      this.markerLayersAndFeatures[data.mapLayer.id].set('visible', true);
    } else {
      this.markerLayersAndFeatures[data.mapLayer.id].set('visible', false);
    }
  }
  /** function to make Marker movable */
  makeMovable(feature) {

    this.markerModifyObj.modifyObj = new ol.interaction.Modify({
      features: new ol.Collection([feature])
    });
    this.moveableMarkersArray.push(this.markerModifyObj.modifyObj);
    /** when you move marker it will get coordinate */
    feature.on('change', (e) => {
      this.arisSchematicConfig.markerMoved.next([e.target.get('name'), e.target]);
    }, feature);
    return this.markerModifyObj.modifyObj;
  }

  moveMarkersNow(event) {
    if (event) {
      // this.map.addInteraction(this.makeMovable(this.iconFeature));
    } else {
      for (let i = 0 ; i < this.moveableMarkersArray.length; i++) {
        this.map.removeInteraction(this.moveableMarkersArray[i]);
      }
    }
  }

  updateCoordinates(event) {
    let aux = this.markerLayersAndFeatures[event[1]].getSource().getFeatures();
    aux.forEach((item) => {
      if (item.get("name") === event[0].assetName) {
        item.get("geometry").setCoordinates([event[0].xCoordinate, event[0].yCoordinate]);
      }
    }, (err) => {
      console.log(err);
    });
  }
  onlyLayerRelatedMoveMarkers(event) {
    let aux = this.markerLayersAndFeatures[event].getSource().getFeatures();
    for (let i = 0; i < aux.length; i++) {
      this.map.addInteraction(this.makeMovable(aux[i]));
    }
  }


}

