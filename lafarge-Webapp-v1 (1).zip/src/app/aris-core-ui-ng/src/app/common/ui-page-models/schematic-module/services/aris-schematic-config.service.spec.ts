import { HttpClient, HttpHandler, HttpClientModule } from '@angular/common/http';
import { Injector } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { ArisSchematicModule } from '../aris-schematic.module';
import { ArisModule } from '../../../../aris.module';
import { CommonModule } from '@angular/common';
import { ArisSchematicConfig } from './aris-schematic-config.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

export class MockHttpClient extends HttpClient {
}
export class MockHandler {
  handle() {}
}
describe('Test: Aris Schematic Config Service', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [ArisSchematicModule, ArisModule, CommonModule, HttpClientModule,
      HttpClientTestingModule],
    providers: [
      ArisSchematicConfig,
      Injector,
      { provide: HttpHandler, useClass: MockHandler },
      { provide: HttpClient, useClass: MockHttpClient },
    ]
  }));
  it('ArisSchematicConfigService test: checking if getDataFormarkerApi is called or not', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    spyOn(schematicConfigService, 'getDataFormarkerApi').and.callThrough();
    expect(schematicConfigService.getDataFormarkerApi).not.toHaveBeenCalled();
  });

  it('ArisSchematicConfigService test: checking getSchematicProperties have schematicPageConfig or not', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let config = schematicConfigService.getSchematicProperties();
    expect(true).toBe(config.hasOwnProperty('schematicPageConfig'));
  });

  it('ArisSchematicConfigService test: checking getSchematicLayers type is availble or not', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    const geoLayerName = 'LA:arislngschematic';
    let result = schematicConfigService.getSchematicLayers(geoLayerName);
    expect(true).toBe(result.hasOwnProperty('plantSchematicLayer'));
  });

  it('ArisSchematicConfigService test: checking getSchematicPageConfig return type is availble or not', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    const geoLayerName = 'LA:arislngschematic';
    let result = schematicConfigService.getSchematicPageConfig(geoLayerName);
    expect(true).toBe(result.hasOwnProperty('pageTitle'));
  });
  it('ArisSchematicConfigService test: checking getSchematicLayers type is availble or not', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    const geoLayerName = 'LA:powerunit';
    let result = schematicConfigService.getSchematicLayers(geoLayerName);
    expect(true).toBe(result.hasOwnProperty('powerUnitLayer'));
  });
  it('ArisSchematicConfigService test: checking getVal method return data', () => {
    let objectData: any = {};
    objectData.InfoCard = [
      {
        assetId: 1,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit"
      }
    ];
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let path1 = "InfoCard[0].assetName";
    let data1 = schematicConfigService.getVal(path1, objectData);
    let path2 = "InfoCard[0].equipmentName";
    let data2 = schematicConfigService.getVal(path2, objectData);
    let path3 = "InfoCard[0].unitName";
    let data3 = schematicConfigService.getVal(path3, objectData);
    expect(data1).toBe("Boiler");
    expect(data2).toBe("BO100101");
    expect(data3).toBe("Power Unit");
  });
  it('ArisSchematicConfigService test: checking populateRecursive method proccessed data based mock data inputs', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let infocardData: any = {};
    let data: any = {};
    let currentLayerTransformer: any = {};
    infocardData.topSection = {};
    currentLayerTransformer.headers = [
      { title: "POWER_UNIT_INFOCARD_CURRENT_STATE", value: '$.InfoCard[0].currentStatus', dtv: '$.InfoCard[0].dtvCurrentStatus' },
      { title: "POWER_UNIT_INFOCARD_EQUIPMENT_NUMBER", value: '$.InfoCard[0].assetName' },
      { title: "POWER_UNIT_INFOCARD_SELF_FOULING", value: '$.InfoCard[0].selfFouling', dtv: '$.InfoCard[0].dtvSelfFouling' },
      { title: "POWER_UNIT_INFOCARD_PH", value: '$.InfoCard[0].ph', dtv: '$.InfoCard[0].dtvPh' },
      { title: "POWER_UNIT_INFOCARD_TURBIDITY_FNU", value: '$.InfoCard[0].turbidity', dtv: '$.InfoCard[0].dtvTurbidity' },
      { title: "POWER_UNIT_INFOCARD_CONDUCTVITY", value: '$.InfoCard[0].conductivity', dtv: '$.InfoCard[0].dtvConductivity' },
      { title: "POWER_UNIT_INFOCARD_ORP_MV", value: '$.InfoCard[0].orp', dtv: '$.InfoCard[0].dtvOrp' }
    ];
    data.InfoCard = [
      {
        assetId: 1,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];

    schematicConfigService.populateRecursive(infocardData.topSection, currentLayerTransformer, data);
    expect(infocardData.topSection.headers[0].value).toBe("RED");
    expect(infocardData.topSection.headers[0].title).toBe("POWER_UNIT_INFOCARD_CURRENT_STATE");
    expect(infocardData.topSection.headers[0].dtv).toBe(1487375100000);
    expect(infocardData.topSection.headers[1].value).toBe("Boiler");
    expect(infocardData.topSection.headers[1].title).toBe("POWER_UNIT_INFOCARD_EQUIPMENT_NUMBER");
  });

  it('ArisSchematicConfigService test: checking populateRecursive method proccessed data based mock data inputs @for', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let infocardData: any = {};
    let data: any = {};
    let currentLayerTransformer: any = {};
    infocardData.topSection = {};
    currentLayerTransformer = { '@for':
    { header: "POWER_UNIT_INFOCARD_CURRENT_STATE" ,
      rows:
      { val: "POWER_UNIT_INFOCARD_CURRENT_STATE",
        dtv: "POWER_UNIT_INFOCARD_EQUIPMENT_NUMBER" },
    },
    };
    data.InfoCard = [
      {
        assetId: 1,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];
    data.undefined = [
      {
        assetId: 2,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];

    schematicConfigService.populateRecursive(infocardData.topSection, currentLayerTransformer, data);
    expect(infocardData.topSection.undefined[0].header).toEqual('POWER_UNIT_INFOCARD_CURRENT_STATE');
  });

  it('ArisSchematicConfigService test: checking populateRecursive method proccessed data based String input if condition', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let infocardData: any = {};
    let data: any = {};
    let currentLayerTransformer: any = {};
    infocardData.topSection = {};
    currentLayerTransformer.headers = "$headers";
    data.InfoCard = [
      {
        assetId: 1,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];

    schematicConfigService.populateRecursive(infocardData.topSection, currentLayerTransformer, data);
    expect(infocardData.topSection.headers).toBeUndefined();
    expect(data.InfoCard[0].assetId).toEqual(1);
  });

  it('ArisSchematicConfigService test: checking populateRecursive method proccessed data based String input else condition', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let infocardData: any = {};
    let data: any = {};
    let currentLayerTransformer: any = {};
    infocardData.topSection = {};
    currentLayerTransformer.headers = "headers";
    data.InfoCard = [
      {
        assetId: 1,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];

    schematicConfigService.populateRecursive(infocardData.topSection, currentLayerTransformer, data);
    expect(infocardData.topSection.headers).toEqual('headers');
    expect(data.InfoCard[0].assetId).toEqual(1);
  });

  it('ArisSchematicConfigService test: checking populateRecursive method proccessed data based Object input', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let infocardData: any = {};
    let data: any = {};
    let currentLayerTransformer: any = {};
    infocardData.topSection = {};
    currentLayerTransformer.headers = {};
    data.InfoCard = [
      {
        assetId: 1,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];

    schematicConfigService.populateRecursive(infocardData.topSection, currentLayerTransformer, data);
    expect(data.InfoCard[0].assetId).toEqual(1);
  });

  it('ArisSchematicConfigService test: checking populateRecursive method proccessed data based function input', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let infocardData: any = {};
    let data: any = {};
    let currentLayerTransformer: any = {};
    infocardData.topSection = {};
    currentLayerTransformer.headers = () => {};
    data.InfoCard = [
      {
        assetId: 1,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];

    schematicConfigService.populateRecursive(infocardData.topSection, currentLayerTransformer, data);
    expect(data.InfoCard[0].assetId).toEqual(1);
  });

  it('ArisSchematicConfigService test: checking defaultTransformer method  proccessed data based mock data inputs', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let that: any = {};
    that.infocardData = {};
    that.datasources = {};
    that.datasources.powerUnitLayer = { InfoCard: 'val' };
    that.currentLayer = "powerUnitLayer";
    that.datasources.powerUnitLayer.InfoCard = [
      {
        assetId: 1,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];
    that.currentLayerTransformer = {
      header: {
        title: "$.InfoCard[0].assetName"
      },
      topSection : {
        headers: [
                { title: "POWER_UNIT_INFOCARD_CURRENT_STATE", value: '$.InfoCard[0].currentStatus', dtv: '$.InfoCard[0].dtvCurrentStatus' },
                { title: "POWER_UNIT_INFOCARD_EQUIPMENT_NUMBER", value: '$.InfoCard[0].assetName' },
                { title: "POWER_UNIT_INFOCARD_SELF_FOULING", value: '$.InfoCard[0].selfFouling', dtv: '$.InfoCard[0].dtvSelfFouling' },
                { title: "POWER_UNIT_INFOCARD_PH", value: '$.InfoCard[0].ph', dtv: '$.InfoCard[0].dtvPh' },
                { title: "POWER_UNIT_INFOCARD_TURBIDITY_FNU", value: '$.InfoCard[0].turbidity', dtv: '$.InfoCard[0].dtvTurbidity' },
                { title: "POWER_UNIT_INFOCARD_CONDUCTVITY", value: '$.InfoCard[0].conductivity', dtv: '$.InfoCard[0].dtvConductivity' },
                { title: "POWER_UNIT_INFOCARD_ORP_MV", value: '$.InfoCard[0].orp', dtv: '$.InfoCard[0].dtvOrp' }
        ]
      }
    };

    schematicConfigService.defaultTransformer(that);
    expect(that.infocardData.header.title).toBe("Boiler");
    expect(that.infocardData.topSection.headers[0].value).toBe("RED");
    expect(that.infocardData.topSection.headers[0].title).toBe("POWER_UNIT_INFOCARD_CURRENT_STATE");
    expect(that.infocardData.topSection.headers[0].dtv).toBe(1487375100000);
  });

  it('ArisSchematicConfigService test: checking getInfocardComponent method  ', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);

    let feature = new Map();
    feature.set('layerId', 'value');
    schematicConfigService.layers = { value: { directiveHtmlTemplateOverride: 'val' } };
    let expected = schematicConfigService.getInfocardComponent(feature);
    expect(expected).toEqual("val");
  });

  it('ArisSchematicConfigService test: checking getInfocardComponent method else scenario ', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);

    let feature = new Map();
    feature.set('layerId', 'value');
    schematicConfigService.layers = { value: { directiveHtmlTemplateOverride: undefined } };
    let expected = schematicConfigService.getInfocardComponent(feature);
    expect(expected).toEqual(undefined);
  });

  it('ArisSchematicConfigService test: checking defaultTransformer method  proccessed data based mock data inputs for InfoCardLineChart', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let that: any = {};
    that.infocardData = {};
    that.currentLayer = "powerUnitLayer";
    that.datasources = { powerUnitLayer: { InfoCard: 'val' } };
    that.datasources.powerUnitLayer = {};
    that.datasources.powerUnitLayer.InfoCardLineChart = [
      {
        assetId: 1,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];
    that.currentLayerTransformer = {
      header: {
        title: () => {}
      },
      topSection : {
        headers: [
                { title: "POWER_UNIT_INFOCARD_CURRENT_STATE", value: '$.InfoCard[0].currentStatus', dtv: '$.InfoCard[0].dtvCurrentStatus' },
                { title: "POWER_UNIT_INFOCARD_EQUIPMENT_NUMBER", value: '$.InfoCard[0].assetName' },
                { title: "POWER_UNIT_INFOCARD_SELF_FOULING", value: '$.InfoCard[0].selfFouling', dtv: '$.InfoCard[0].dtvSelfFouling' },
                { title: "POWER_UNIT_INFOCARD_PH", value: '$.InfoCard[0].ph', dtv: '$.InfoCard[0].dtvPh' },
                { title: "POWER_UNIT_INFOCARD_TURBIDITY_FNU", value: '$.InfoCard[0].turbidity', dtv: '$.InfoCard[0].dtvTurbidity' },
                { title: "POWER_UNIT_INFOCARD_CONDUCTVITY", value: '$.InfoCard[0].conductivity', dtv: '$.InfoCard[0].dtvConductivity' },
                { title: "POWER_UNIT_INFOCARD_ORP_MV", value: '$.InfoCard[0].orp', dtv: '$.InfoCard[0].dtvOrp' }
        ]
      }
    };

    schematicConfigService.defaultTransformer(that);
    expect(schematicConfigService).toBeTruthy();
  });

  it('ArisSchematicConfigService test: checking defaultTransformer method  proccessed data based mock data inputs for InfoCard and  InfoCardChild', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let that: any = {};
    that.infocardData = {};
    that.datasources = {};
    that.datasources.powerUnitLayer = {};
    that.currentLayer = "powerUnitLayer";
    that.datasources.powerUnitLayer.InfoCardChild = [
      {
        assetId: 1,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];
    that.datasources.powerUnitLayer.InfoCard = [
      {
        assetId: 2,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];
    that.currentLayerTransformer = {
      header: {
        title: 'value()'
      },
      topSection : {
        headers: [
                { title: "POWER_UNIT_INFOCARD_CURRENT_STATE", value: '$.InfoCard[0].currentStatus', dtv: '$.InfoCard[0].dtvCurrentStatus' },
                { title: "POWER_UNIT_INFOCARD_EQUIPMENT_NUMBER", value: '$.InfoCard[0].assetName' },
                { title: "POWER_UNIT_INFOCARD_SELF_FOULING", value: '$.InfoCard[0].selfFouling', dtv: '$.InfoCard[0].dtvSelfFouling' },
                { title: "POWER_UNIT_INFOCARD_PH", value: '$.InfoCard[0].ph', dtv: '$.InfoCard[0].dtvPh' },
                { title: "POWER_UNIT_INFOCARD_TURBIDITY_FNU", value: '$.InfoCard[0].turbidity', dtv: '$.InfoCard[0].dtvTurbidity' },
                { title: "POWER_UNIT_INFOCARD_CONDUCTVITY", value: '$.InfoCard[0].conductivity', dtv: '$.InfoCard[0].dtvConductivity' },
                { title: "POWER_UNIT_INFOCARD_ORP_MV", value: '$.InfoCard[0].orp', dtv: '$.InfoCard[0].dtvOrp' }
        ]
      }
    };

    schematicConfigService.defaultTransformer(that);
    expect(schematicConfigService).toBeTruthy();
  });

  it('ArisSchematicConfigService test: checking defaultTransformer method  proccessed data based mock data inputs for InfoCard and  infocardAdditionalAPI', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let that: any = {};
    that.infocardData = {};
    that.datasources = {};
    that.datasources.powerUnitLayer = {};
    that.currentLayer = "powerUnitLayer";
    that.datasources.powerUnitLayer.infocardAdditionalAPI = [
      {
        assetId: 1,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];
    that.datasources.powerUnitLayer.InfoCard = [
      {
        assetId: 2,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];
    that.currentLayerTransformer = {
      header: {
        title: 'value()'
      },
      topSection : {
        headers: [
                { title: "POWER_UNIT_INFOCARD_CURRENT_STATE", value: '$.InfoCard[0].currentStatus', dtv: '$.InfoCard[0].dtvCurrentStatus' },
                { title: "POWER_UNIT_INFOCARD_EQUIPMENT_NUMBER", value: '$.InfoCard[0].assetName' },
                { title: "POWER_UNIT_INFOCARD_SELF_FOULING", value: '$.InfoCard[0].selfFouling', dtv: '$.InfoCard[0].dtvSelfFouling' },
                { title: "POWER_UNIT_INFOCARD_PH", value: '$.InfoCard[0].ph', dtv: '$.InfoCard[0].dtvPh' },
                { title: "POWER_UNIT_INFOCARD_TURBIDITY_FNU", value: '$.InfoCard[0].turbidity', dtv: '$.InfoCard[0].dtvTurbidity' },
                { title: "POWER_UNIT_INFOCARD_CONDUCTVITY", value: '$.InfoCard[0].conductivity', dtv: '$.InfoCard[0].dtvConductivity' },
                { title: "POWER_UNIT_INFOCARD_ORP_MV", value: '$.InfoCard[0].orp', dtv: '$.InfoCard[0].dtvOrp' }
        ]
      }
    };

    schematicConfigService.defaultTransformer(that);
    expect(schematicConfigService).toBeTruthy();
  });

  it('ArisSchematicConfigService test: checking getDataFormarkerApi method', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    const http = TestBed.get(HttpClient);
    spyOn(http, 'post').and.callThrough();
    schematicConfigService.getDataFormarkerApi("/rest/login");
    expect(http.post).toHaveBeenCalled();
    expect(schematicConfigService).toBeTruthy();
  });

  it('ArisSchematicConfigService test: checking fireInfocardAPIs method  proccessed data based mock data inputs for verrideAPI default APIs', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let handler: HttpHandler;
    let http = new HttpClient(handler);
    let feature = new Map();
    feature.set('layerId', 'powerUnitLayers');
    feature.set('name', 'name');
    let data = { val: 'val' };
    schematicConfigService.layers = { powerUnitLayers:
    { transformTemplate: 'val', infocardOverrideAPI(infocardData: any, assetName: any) {},
      infocardAdditionalAPI: 'api', infocardAPI: "infocardAPI" } };
    let that: any = {};
    that.infocardData = {};
    that.datasources = {};
    that.datasources.powerUnitLayer = {};
    that.currentLayer = "powerUnitLayer";
    that.datasources.powerUnitLayer.infocardAdditionalAPI = [
      {
        assetId: 1,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];
    that.datasources.powerUnitLayer.InfoCard = [
      {
        assetId: 2,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];
    that.currentLayerTransformer = {
      header: {
        title: 'value()'
      },
      topSection : {
        headers: [
                { title: "POWER_UNIT_INFOCARD_CURRENT_STATE", value: '$.InfoCard[0].currentStatus', dtv: '$.InfoCard[0].dtvCurrentStatus' },
                { title: "POWER_UNIT_INFOCARD_EQUIPMENT_NUMBER", value: '$.InfoCard[0].assetName' },
                { title: "POWER_UNIT_INFOCARD_SELF_FOULING", value: '$.InfoCard[0].selfFouling', dtv: '$.InfoCard[0].dtvSelfFouling' },
                { title: "POWER_UNIT_INFOCARD_PH", value: '$.InfoCard[0].ph', dtv: '$.InfoCard[0].dtvPh' },
                { title: "POWER_UNIT_INFOCARD_TURBIDITY_FNU", value: '$.InfoCard[0].turbidity', dtv: '$.InfoCard[0].dtvTurbidity' },
                { title: "POWER_UNIT_INFOCARD_CONDUCTVITY", value: '$.InfoCard[0].conductivity', dtv: '$.InfoCard[0].dtvConductivity' },
                { title: "POWER_UNIT_INFOCARD_ORP_MV", value: '$.InfoCard[0].orp', dtv: '$.InfoCard[0].dtvOrp' }
        ]
      }
    };
    spyOn(http, 'post').and.callFake(() => Promise.resolve(data));
    spyOn(schematicConfigService.layers.powerUnitLayers, 'infocardOverrideAPI').and.callFake(() => Promise.resolve(data));
    schematicConfigService.fireInfocardAPIs(that, feature);
    expect(schematicConfigService.layers.powerUnitLayers.infocardOverrideAPI).toHaveBeenCalled();
  });

  it('ArisSchematicConfigService test: checking fireInfocardAPIs method  proccessed data based mock data inputs for InfoCard and  infocardAdditionalAPI', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let handler: HttpHandler;
    let http = new HttpClient(handler);
    let httpClient = TestBed.get(HttpClient);
    let feature = new Map();
    feature.set('layerId', 'powerUnitLayers');
    feature.set('name', 'name');
    let data = { val: 'val' };
    schematicConfigService.layers = { powerUnitLayers:
    { transformTemplate: 'val', infocardOverrideAPI: 'val',
      infocardAdditionalAPI(infocardData: any, assetName: any) {}, infocardAPI: "infocardAPI" } };
    let that: any = {};
    that.infocardData = {};
    that.datasources = {};
    that.datasources.powerUnitLayer = {};
    that.currentLayer = "powerUnitLayer";
    that.datasources.powerUnitLayer.infocardAdditionalAPI = [
      {
        assetId: 1,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];
    that.datasources.powerUnitLayer.InfoCard = [
      {
        assetId: 2,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];
    that.currentLayerTransformer = {
      header: {
        title: 'value()'
      },
      topSection : {
        headers: [
                { title: "POWER_UNIT_INFOCARD_CURRENT_STATE", value: '$.InfoCard[0].currentStatus', dtv: '$.InfoCard[0].dtvCurrentStatus' },
                { title: "POWER_UNIT_INFOCARD_EQUIPMENT_NUMBER", value: '$.InfoCard[0].assetName' },
                { title: "POWER_UNIT_INFOCARD_SELF_FOULING", value: '$.InfoCard[0].selfFouling', dtv: '$.InfoCard[0].dtvSelfFouling' },
                { title: "POWER_UNIT_INFOCARD_PH", value: '$.InfoCard[0].ph', dtv: '$.InfoCard[0].dtvPh' },
                { title: "POWER_UNIT_INFOCARD_TURBIDITY_FNU", value: '$.InfoCard[0].turbidity', dtv: '$.InfoCard[0].dtvTurbidity' },
                { title: "POWER_UNIT_INFOCARD_CONDUCTVITY", value: '$.InfoCard[0].conductivity', dtv: '$.InfoCard[0].dtvConductivity' },
                { title: "POWER_UNIT_INFOCARD_ORP_MV", value: '$.InfoCard[0].orp', dtv: '$.InfoCard[0].dtvOrp' }
        ]
      }
    };
    spyOn(schematicConfigService.layers.powerUnitLayers, 'infocardAdditionalAPI').and.callFake(() => Promise.resolve(data));
    spyOn(http, 'post').and.callFake(() => Promise.resolve(data));
    schematicConfigService.fireInfocardAPIs(that, feature);
    expect(schematicConfigService.layers.powerUnitLayers.infocardAdditionalAPI).toHaveBeenCalled();
  });

  it('ArisSchematicConfigService test: checking fireInfocardAPIs method  proccessed data based mock data inputs for infocardAPI not a string and  infocardAdditionalAPI', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let handler: HttpHandler;
    let http = new HttpClient(handler);
    let httpClient = TestBed.get(HttpClient);
    let feature = new Map();
    feature.set('layerId', 'powerUnitLayers');
    feature.set('name', 'name');
    let data = { val: 'val' };
    schematicConfigService.layers = { powerUnitLayers:
    { transformTemplate: 'val', infocardOverrideAPI: 'val',
      infocardAdditionalAPI(infocardData: any, assetName: any) {}, infocardAPI: 1 } };
    let that: any = {};
    that.infocardData = {};
    that.datasources = {};
    that.datasources.powerUnitLayer = {};
    that.currentLayer = "powerUnitLayer";
    that.datasources.powerUnitLayer.infocardAdditionalAPI = [
      {
        assetId: 1,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];
    that.datasources.powerUnitLayer.InfoCard = [
      {
        assetId: 2,
        assetName: "Boiler",
        equipmentName: "BO100101",
        unitName: "Power Unit",
        plantName: "Freeport LNG Plant",
        upstreamFeed: "Feed Pump",
        downstreamFeed: "Fin Fans Array",
        location: "Freeport",
        turnaroundPriority: "High",
        currentStatus: "RED",
        dtvCurrentStatus: 1487375100000,
        selfFouling: 6,
        dtvSelfFouling: 1487375100000,
        ph: 9.6,
        dtvPh: 1487375100000,
        turbidity: 11.37,
        dtvTurbidity: 1487375100000,
        conductivity: 1000,
        dtvConductivity: 1487375100000,
        orp: 467,
        dtvOrp: 1487375100000,
        modelLastRunDtv: 1487029500000,
        modelAccuracy: 99.89,
        xCoordinate: -58.96762,
        yCoordinate: 5.42559,
        actualCorrosionRate: 0,
        normalizedTrendingCorrosionRate: 0,
        baselineCorrosionRate: 0.25,
        targetCorrosionRate: 0.15,
        predictedCorrosionRate: 0.26,
        dtvCorrosion: 1487433600000
      }
    ];
    that.currentLayerTransformer = {
      header: {
        title: 'value()'
      },
      topSection : {
        headers: [
                { title: "POWER_UNIT_INFOCARD_CURRENT_STATE", value: '$.InfoCard[0].currentStatus', dtv: '$.InfoCard[0].dtvCurrentStatus' },
                { title: "POWER_UNIT_INFOCARD_EQUIPMENT_NUMBER", value: '$.InfoCard[0].assetName' },
                { title: "POWER_UNIT_INFOCARD_SELF_FOULING", value: '$.InfoCard[0].selfFouling', dtv: '$.InfoCard[0].dtvSelfFouling' },
                { title: "POWER_UNIT_INFOCARD_PH", value: '$.InfoCard[0].ph', dtv: '$.InfoCard[0].dtvPh' },
                { title: "POWER_UNIT_INFOCARD_TURBIDITY_FNU", value: '$.InfoCard[0].turbidity', dtv: '$.InfoCard[0].dtvTurbidity' },
                { title: "POWER_UNIT_INFOCARD_CONDUCTVITY", value: '$.InfoCard[0].conductivity', dtv: '$.InfoCard[0].dtvConductivity' },
                { title: "POWER_UNIT_INFOCARD_ORP_MV", value: '$.InfoCard[0].orp', dtv: '$.InfoCard[0].dtvOrp' }
        ]
      }
    };
    spyOn(schematicConfigService.layers.powerUnitLayers, 'infocardAdditionalAPI').and.callFake(() => Promise.resolve(data));
    spyOn(http, 'post').and.callFake(() => Promise.resolve(data));
    schematicConfigService.fireInfocardAPIs(that, feature);
    expect(schematicConfigService.layers.powerUnitLayers.infocardAdditionalAPI).toHaveBeenCalled();
  });

  it('ArisSchematicConfigService test: checking fireInfocardAPIs failure scenario for infocardAPI and infocardLineChartAPI and infocardChildAPI and infocardAdditionalAPI ', () => {
    const schematicConfigService = TestBed.get(ArisSchematicConfig);
    let handler: HttpHandler;
    let http = new HttpClient(handler);
    let httpClient = TestBed.get(HttpClient);
    let feature = new Map();
    feature.set('layerId', 'powerUnitLayers');
    feature.set('name', 'name');
    let data = { val: 'val' };
    schematicConfigService.layers = { powerUnitLayers:
    { transformTemplate: 'val', infocardOverrideAPI: 'val', infocardAPI: false, infocardLineChartAPI: false, infocardChildAPI: false } };
    let that: any = {};
    that.infocardData = {};
    that.datasources = {};
    that.datasources.powerUnitLayer = {};
    that.currentLayer = "powerUnitLayer";
    that.currentLayerTransformer = {
      header: {
        title: 'value()'
      },
      topSection : {
        headers: [
                { title: "POWER_UNIT_INFOCARD_CURRENT_STATE", value: '$.InfoCard[0].currentStatus', dtv: '$.InfoCard[0].dtvCurrentStatus' },
                { title: "POWER_UNIT_INFOCARD_EQUIPMENT_NUMBER", value: '$.InfoCard[0].assetName' },
                { title: "POWER_UNIT_INFOCARD_SELF_FOULING", value: '$.InfoCard[0].selfFouling', dtv: '$.InfoCard[0].dtvSelfFouling' },
                { title: "POWER_UNIT_INFOCARD_PH", value: '$.InfoCard[0].ph', dtv: '$.InfoCard[0].dtvPh' },
                { title: "POWER_UNIT_INFOCARD_TURBIDITY_FNU", value: '$.InfoCard[0].turbidity', dtv: '$.InfoCard[0].dtvTurbidity' },
                { title: "POWER_UNIT_INFOCARD_CONDUCTVITY", value: '$.InfoCard[0].conductivity', dtv: '$.InfoCard[0].dtvConductivity' },
                { title: "POWER_UNIT_INFOCARD_ORP_MV", value: '$.InfoCard[0].orp', dtv: '$.InfoCard[0].dtvOrp' }
        ]
      }
    };
    spyOn(http, 'post').and.callFake(() => Promise.resolve(data));
    schematicConfigService.fireInfocardAPIs(that, feature);
    expect(schematicConfigService.layers).toBeDefined();
  });

});
