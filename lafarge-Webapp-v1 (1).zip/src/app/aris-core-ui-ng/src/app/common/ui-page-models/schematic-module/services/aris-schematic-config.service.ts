import { Injectable, Injector } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Subject } from "rxjs/Subject";
import { Observable } from "rxjs/Rx";
import { resolve } from "url";
declare var $: any;
@Injectable()
export class ArisSchematicConfig {
  public schematicConfig: any = {};
  public layers: any = {};
  markerMoved = new Subject(); // for use of broadcast
  refreshSchematicInfocard = new Subject();
  componentReload = new Subject();
  hideInfocard = new Subject();
  public directiveHtmlTemplateOverride: any;
  constructor(private injector: Injector, private http: HttpClient) {}

  getInfocardComponent(feature) {
    if (
      this.layers[feature.get("layerId")].directiveHtmlTemplateOverride !==
      undefined
    ) {
      this.directiveHtmlTemplateOverride = this.layers[
        feature.get("layerId")
      ].directiveHtmlTemplateOverride;
    } else {
      this.directiveHtmlTemplateOverride = undefined;
    }
    return this.directiveHtmlTemplateOverride;
  }
  populateRecursive(retVal, template, data) {
    let mapperFn = (v, j) => {
      let objMapper = {};
      let valPercentageCal = v.valPercentageCal;
      $.each(v, (idx, val) => {
        if ($.type(val) === "string") {
          if (val.charAt(0) === "$") {
            if (valPercentageCal && idx === 'val') {
              objMapper[idx] = this.getVal(val.substr(2), data) * 100;
            } else {
              objMapper[idx] = this.getVal(val.substr(2), data);
            }
            // objMapper[idx] = this.$eval(val.substr(2), data);
          } else {
            objMapper[idx] = val;
          }
        } else if ($.type(val) === "function") {
          objMapper[idx] = val(data);
        } else if ($.type(val) === "array") {
          objMapper[idx] = [];
          $.map(val, (mapValue, mapKey) => {
            objMapper[idx][mapKey] = {};
            this.populateRecursive(objMapper[idx][mapKey], mapValue, data);
          });
        }
      });
      return objMapper;
    };

    let obj: any;
    let splits: any;
    let InfoCardChild: any;
    let resultProp: any;
    let totalCount: any;
    let $index: any;
    for (let i in template) {
      if (i.indexOf("@for") > -1) {
        splits = i.match(/\S+/g) || []; // ["@for", "$index", "in", "InfoCardChild", "as", "tables"]
        $index = splits[1];
        InfoCardChild = splits[3];
        resultProp = splits[5];
        totalCount = data[InfoCardChild].length;
        retVal[resultProp] = [];
        for (let tempVar = 0; tempVar < totalCount; tempVar++) {
          retVal[resultProp][tempVar] = {};
          data[$index] = tempVar;
          let templateData = JSON.parse(JSON.stringify(template[i]));
          if (templateData.header && $.type(templateData.header) === "string") {
            templateData.header = templateData.header.replace(
              "$index",
              tempVar
            );
          }
          for (let z = 0; z < templateData.rows.length; z++) {
            if (
              templateData.rows[z].val &&
              $.type(templateData.rows[z].val) === "string"
            ) {
              templateData.rows[z].val = templateData.rows[z].val.replace(
                "$index",
                tempVar
              );
            }
            if (
              templateData.rows[z].dtv &&
              $.type(templateData.rows[z].dtv) === "string"
            ) {
              templateData.rows[z].dtv = templateData.rows[z].dtv.replace(
                "$index",
                tempVar
              );
            }
          }
          this.populateRecursive(
            retVal[resultProp][tempVar],
            templateData,
            data
          );
        }
        // output retVal[i]
      } else if ($.type(template[i]) === "string") {
        if (template[i].charAt(0) === "$") {
          console.log(template[i].substr(2));
          retVal[i] = this.getVal(template[i].substr(2), data);
          // retVal[i] = this.getVal(template[i].substr(2), data);
        } else {
          retVal[i] = template[i];
        }
      } else if ($.type(template[i]) === "object") {
        retVal[i] = {};
        this.populateRecursive(retVal[i], template[i], data);
      } else if ($.type(template[i]) === "function") {
        retVal[i] = template[i](data);
      } else if ($.type(template[i]) === "array") {
        retVal[i] = $.map(template[i], mapperFn);
      }
    }
  }
  getVal(ObjPath, infocardData) {
    let path = ObjPath;
    let data = infocardData;
    path = path.replace(/\[(\w+)\]/g, ".$1"); // convert indexes to properties
    path = path.replace(/^\./, ""); // strip a leading dot
    let a = path.split(".");
    for (let i = 0, n = a.length; i < n; ++i) {
      let k = a[i];
      if (k in data) {
        data = data[k];
      } else {
        return;
      }
    }
    return data;
  }

  defaultTransformer(that) {
    // Top
    let curDSInfoCard = that.datasources[that.currentLayer]; // ['InfoCard'];
    let i;
    // header
    that.infocardData.header = {};
    for (i in that.currentLayerTransformer.header) {
      if (
        $.type(that.currentLayerTransformer.header[i]) === "string" &&
        that.currentLayerTransformer.header[i].charAt(0) === "$"
      ) {
        that.infocardData.header[i] = this.getVal(
          that.currentLayerTransformer.header[i].substr(2),
          curDSInfoCard
        );
        // that.infocardData.header[i] = eval(that.currentLayerTransformer.header[i].substr(2), curDSInfoCard);
      } else if (
        $.type(that.currentLayerTransformer.header[i]) === "function"
      ) {
        if (curDSInfoCard.InfoCard) {
          that.infocardData.header[i] = that.currentLayerTransformer.header[i](
            curDSInfoCard
          );
        }
      }
    }
    // headers
    that.infocardData.topSection = {};
    if (that.datasources[that.currentLayer]["InfoCard"]) {
      this.populateRecursive(
        that.infocardData.topSection,
        that.currentLayerTransformer.topSection,
        curDSInfoCard
      );
    }
    // Top End

    // Bottom
    that.infocardData.bottomSection = {};
    if (
      that.datasources[that.currentLayer]["InfoCard"] &&
      that.datasources[that.currentLayer]["InfoCardChild"]
    ) {
      this.populateRecursive(
        that.infocardData.bottomSection,
        that.currentLayerTransformer.bottomSection,
        curDSInfoCard
      );
    } else if (that.bottomSectionWithOutChildApi) {
      this.populateRecursive(
        that.infocardData.bottomSection,
        that.currentLayerTransformer.bottomSection,
        curDSInfoCard
      );
    }
    // Bottom End

    // Middle
    that.infocardData.middleSection = {};
    $.extend(
      that.infocardData.middleSection,
      that.currentLayerTransformer.middleSection
    );
    if (that.datasources[that.currentLayer]["InfoCardLineChart"]) {
      that.infocardData.middleSection.chartData =
        that.datasources[that.currentLayer]["InfoCardLineChart"];
    }
    // Middle End

    // infocardAdditionalAPI
    that.infocardData.infocardAdditionalAPI = {};
    if (
      that.datasources[that.currentLayer]["InfoCard"] &&
      that.datasources[that.currentLayer]["infocardAdditionalAPI"]
    ) {
      this.populateRecursive(
        that.infocardData.infocardAdditionalAPI,
        that.currentLayerTransformer.infocardAdditionalAPI,
        curDSInfoCard
      );
    }
    // infocardAdditionalAPI End
  } // defaultTransformer() End

  fireInfocardAPIs(that, feature) {
    let layerId = (that.currentLayer = feature.get("layerId"));
    let assetName = feature.get("name");
    that.infocardData = {};
    that.infocardData.currentLayer = layerId;
    that.datasources = [];
    that.currentLayerTransformer = this.layers[layerId].transformTemplate;
    that.bottomSectionWithOutChildApi = this.layers[
      layerId
    ].bottomSectionWithOutChildApi;

    // Since this is overrideAPI default APIs will not get called
    if (
      this.layers[layerId].infocardOverrideAPI !== null &&
      $.type(this.layers[layerId].infocardOverrideAPI) === "function"
    ) {
      this.layers[layerId]
        .infocardOverrideAPI(that.infocardData, assetName)
        .then(data => {
          that.infocardData = data;
        });
      return;
    }

    let filterStr = [
      { name: "markerId", values: [assetName], op: "eq", dbtype: "String" }
    ];
    // let filterStr = JSON.stringify(filter);
    let promise1: any;
    let promise2: any;
    let promise3: any;
    // var deferred1 = $q.defer();
    // var deferred2 = $q.defer();
    // var deferred3 = $q.defer();
    if (
      !(
        this.layers[layerId].infocardAPI !== null &&
        this.layers[layerId].infocardAPI === false
      )
    ) {
      let apiId = layerId + "InfoCard";
      if (typeof this.layers[layerId].infocardAPI === "string") {
        apiId = this.layers[layerId].infocardAPI;
      }
      promise1 = new Promise((resolve, reject) => {
        this.http
          .post(
            "rest/getFromDataSource/" + apiId + "?offset=0&limit=1000",
            filterStr
          )
          .toPromise()
          .then((data: any) => {
            // let data = d.data;
            if (that.datasources[layerId] === undefined) {
              that.datasources[layerId] = [];
            }
            that.datasources[layerId]["InfoCard"] = data;
            that.datasources[layerId]["InfoCard"].new = true;
            this.defaultTransformer(that);
            // deferred1.resolve(data);
            resolve(data);
          })
          .catch(err => {
            reject(err);
          });
      });
    } else {
      // this.promise1.resolve();
    }

    if (
      !(
        this.layers[layerId].infocardLineChartAPI !== null &&
        this.layers[layerId].infocardLineChartAPI === false
      )
    ) {
      promise2 = new Promise((resolve, reject) => {
        this.http
          .post(
            "rest/getFromDataSource/" +
              layerId +
              "InfoCardLineChart?offset=0&limit=1000&groupedDuration=6",
            filterStr
          )
          .toPromise()
          .then((data: any) => {
            // let data = d.data;
            if (that.datasources[layerId] === undefined) {
              that.datasources[layerId] = [];
            }
            that.datasources[layerId]["InfoCardLineChart"] = data;
            that.datasources[layerId]["InfoCardLineChart"].new = true;
            this.defaultTransformer(that);
            that.chartOptions = {
              xAxisAttribute:
                that.infocardData.middleSection.currentChartParams
                  .xAxisAttribute,
              yAxisAttribute:
                that.infocardData.middleSection.currentChartParams
                  .yAxisAttribute,
              calc: "sum",
              exportable: true,
              showRangeChart: true,
              scale: "date",
              timeFormatType: "%b %Y",
              numXAxisTicks: 3,
              chartTitle:
                that.infocardData.middleSection.currentChartParams.chartTitle,
              hideChartTitle: true
            };
            resolve(data);
          })
          .catch(err => {
            reject(err);
          });
      });
    } else {
      // this.promise2.resolve();
    }
    if (
      !(
        this.layers[layerId].infocardChildAPI !== null &&
        this.layers[layerId].infocardChildAPI === false
      )
    ) {
      promise3 = new Promise((resolve, reject) => {
        this.http
          .post(
            "rest/getFromDataSource/" +
              layerId +
              "InfoCardChild?offset=0&limit=1000",
            filterStr
          )
          .toPromise()
          .then((data: any) => {
            if (that.datasources[layerId] === undefined) {
              that.datasources[layerId] = [];
            }
            that.datasources[layerId]["InfoCardChild"] = data;
            that.datasources[layerId]["InfoCardChild"].new = true;
            this.defaultTransformer(that);
            resolve(data);
          })
          .catch(err => {
            reject(err);
          });
      });
    } else {
      // this.promise3.resolve();
    }
    if (
      this.layers[layerId].infocardAdditionalAPI !== null &&
      $.type(this.layers[layerId].infocardAdditionalAPI) === "function"
    ) {
      this.layers[layerId]
        .infocardAdditionalAPI(that.infocardData, assetName)
        .then(data => {
          that.datasources[layerId]["infocardAdditionalAPI"] = data;
        });
    }

    return Promise.all([promise1, promise2, promise3]).then(values => {
      if (
        this.layers[layerId].infocardAdditionalAPI !== null &&
        $.type(this.layers[layerId].infocardAdditionalAPI) === "function"
      ) {
        this.layers[layerId]
          .infocardAdditionalAPI(that.infocardData, assetName)
          .then(data => {
            that.datasources[layerId]["infocardAdditionalAPI"] = data;
          });
      }
      return that.infocardData;
    });

    // Since this is additionalAPI, option will be there to modify existing data.
    // $q.all([deferred1.promise, deferred2.promise, deferred3.promise]). then (function(promiseValues){
    //   console.log('** all infocard apis resolved');

    //   if(this.layers[layerId].infocardAdditionalAPI !== null && $.type(this.layers[layerId].infocardAdditionalAPI) === 'function') {
    //     this.layers[layerId].infocardAdditionalAPI(that.infocardData, assetName).then(function(data) {
    //       that.datasources[layerId]['infocardAdditionalAPI'] = data;
    //     });
    //   }

    //   if(this.layers[layerId].transformTemplateOverrideFn !== null && $.type(this.layers[layerId].transformTemplateOverrideFn) === 'function') {
    //     this.layers[layerId].transformTemplateOverrideFn(promiseValues).then(function(data) {
    //       that.datasources[layerId] = data;
    //     });
    //   }
    // });
    // return that.infocardData;
  }

  getSchematicProperties() {
    return window.app.config.schematic;
  }
  getSchematicPageConfig(geoLayerName) {
    let response = this.getSchematicProperties();
    return response.schematicPageConfig[geoLayerName];
  }
  getSchematicLayers(geoLayerName) {
    let response = this.getSchematicProperties();
    let schematicLayers =
      response.schematicPageConfig[geoLayerName].layers || [];
    let injectschematicLayers =
      response.schematicPageConfig[geoLayerName].mapLayersInjectorServices ||
      [];
    this.layers = {};
    injectschematicLayers.forEach((data, index) => {
      schematicLayers.forEach((schematicdata, schematicIndex) => {
        if (data[schematicdata] !== undefined) {
          let serviceData = this.injector.get(data[schematicdata]);
          this.layers[schematicdata] = serviceData.getConfig();
          this.layers[schematicdata]["checked"] = true;
        }
      });
    });
    return this.layers;
  }
  getDataFormarkerApi(urls) {
    let url = urls;
    return this.http.post(url, []).toPromise();
  }
}
