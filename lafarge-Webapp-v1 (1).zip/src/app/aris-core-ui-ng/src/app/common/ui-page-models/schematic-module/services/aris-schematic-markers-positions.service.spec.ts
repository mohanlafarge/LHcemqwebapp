// import { ArisschematicMarkersPositions } from './aris-schematic-markers-positions.service';
// import { HttpClient, HttpHandler } from '@angular/common/http';

// describe('Test: ArisschematicMarkersPositions', () => {
//   let handler: HttpHandler;
//   const httpclient = new HttpClient(handler);
//   const arisSchematicMarker = new ArisschematicMarkersPositions(httpclient);

//   it('ArisschematicMarkersPositions test: checking if saveMarkerPositionsForAssetType is called or not', () => {
//     const mapLayerDsName = 'plantSchematicLayer';
//     const asset = { id: 1, assetName: 'name', xCoordinate: 1, yCoordinate: 1 };
//     spyOn(httpclient, 'post').and.callThrough();
//     arisSchematicMarker.saveMarkerPositionsForAssetType(mapLayerDsName, asset);
//     expect(httpclient.post).toHaveBeenCalled();
//   });

//   it('ArisschematicMarkersPositions test: checking if getMarkerPositionsForAssetType is called or not', () => {
//     const selectedLayer = 'plantScematicLayer';
//     let assests = {
//       assetName: "Power Unit",
//       changesDone: true,
//       xCoordinate: 80.94726562,
//       yCoordinate: 17.2265625
//     };
//     spyOn(httpclient, 'get').and.callThrough();
//     arisSchematicMarker.getMarkerPositionsForAssetType('plantScematicLayer');
//     expect(httpclient.get).toHaveBeenCalled();
//   });

// });
