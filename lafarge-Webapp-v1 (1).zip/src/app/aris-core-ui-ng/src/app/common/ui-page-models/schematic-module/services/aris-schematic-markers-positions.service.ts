import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";

@Injectable()
export class ArisschematicMarkersPositions {
  constructor(private http: HttpClient) {}
  getMarkerPositionsForAssetType (mapLayerDsName) {
    let assetTypeUrl = "rest/schematicasset/coordinates/" + mapLayerDsName;
    return this.http.get(assetTypeUrl, { responseType: 'json' }).toPromise();
  }

  saveMarkerPositionsForAssetType (mapLayerDsName, asset) {
    let assetTypeUrl = 'rest/schematicasset/savecoordinates/' + mapLayerDsName;
    let data = JSON.stringify({
      id: asset.id,
      assetName: asset.assetName,
      xCoordinate: asset.xCoordinate,
      yCoordinate: asset.yCoordinate
    });
    return this.http.post(assetTypeUrl, data, { headers: new HttpHeaders().set('Content-Type', 'application/json') }).toPromise();
  }
}
