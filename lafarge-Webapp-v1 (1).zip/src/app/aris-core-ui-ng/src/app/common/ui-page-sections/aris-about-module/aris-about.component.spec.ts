import { TestBed, ComponentFixture } from '@angular/core/testing';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';
import { TranslationService, LocaleService, LocalizationModule, InjectorRef } from 'angular-l10n';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClientModule } from '@angular/common/http';
import { ArisDynamicPageModule } from '../../ui-page-models/aris-dynamic-page-module/aris-dynamic-page.module';
import { FilterModule } from '../filter-panel-module/aris-filter.module';
import { ArisAboutComponent } from './aris-about.component';
import { ArisModalHeaderComponent } from '../../ui-components/aris-modal-module/aris-modal-header/components/aris-modal-header.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { ArisUiComponentsModule } from '../../ui-components/aris-ui-components.module';

export class MockTranslationService {
  translate() {}
}

describe('Test: ArisAboutComponent', () => {

  let component: ArisAboutComponent;
  let fixture: ComponentFixture<ArisAboutComponent>;
  let modalRef = new BsModalRef();

  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [ArisAboutComponent],
      imports: [RouterModule,
        LocalizationModule,
        CommonModule,
        ArisDynamicPageModule,
        FilterModule,
        HttpClientModule,
        HttpClientTestingModule,
        FormsModule,
        ReactiveFormsModule,
        NgSelectModule,
        ArisUiComponentsModule],
      providers: [InjectorRef, BsModalService,
         { provide: TranslationService, useClass: MockTranslationService }, { provide: LocaleService }]
    });

    // create component and test fixture
    fixture = TestBed.createComponent(ArisAboutComponent);

    // get test component from the fixture
    component = fixture.componentInstance;
    component.modalRef = modalRef;

  });

  it('Component execution for ngAfterViewInit', () => {
    component.changeTemplate = component.aboutTemplate;
    component.ngAfterViewInit();
    expect(component).toBeTruthy();
  });

  it('Component execution for closeBox', () => {
    component.ngAfterViewInit();
    spyOn(component, 'closeBox').and.callThrough();
    component.closeBox();
    expect(component.closeBox).toHaveBeenCalled();
  });

});
