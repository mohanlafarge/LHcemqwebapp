import { Component, Input, Output, AfterViewInit, ElementRef, ViewChild, OnDestroy, EventEmitter } from "@angular/core";
import { BsModalRef, BsModalService } from "ngx-bootstrap";
import { TranslationService, Language } from "angular-l10n";
import { ArisSvgService } from "../../services/aris-svg.service";

@Component({
  selector: 'aris-about',
  templateUrl: './aris-about.component.html'
})
export class ArisAboutComponent implements AfterViewInit {
  @Input() closeDialog: any;
  @Input() currentVersion: string;
  @Input() changeTemplate: any;
  @Language() lang: string;
  @Output() close: EventEmitter<any> = new EventEmitter();
  @Output() cancel: EventEmitter<any> = new EventEmitter();

  @ViewChild('template') aboutTemplate: ElementRef;

  modalRef: BsModalRef;
  closeMessage: string;
  cancelText: string;
  closeText: string;

  config = {
    animated: true,
    keyboard: true,
    backdrop: true,
    ignoreBackdropClick: true
  };

  constructor(private modalService: BsModalService, private translationService: TranslationService, private arisSvgService: ArisSvgService) {}

  ngAfterViewInit() {
    this.modalRef = this.modalService.show(this.changeTemplate ? this.changeTemplate :  this.aboutTemplate, this.config);
  }

  closeBox() {
    this.modalRef.hide();
    this.close.emit(null);
  }
}
