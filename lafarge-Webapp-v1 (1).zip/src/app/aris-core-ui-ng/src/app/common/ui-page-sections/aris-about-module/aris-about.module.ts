import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import { NgSelectModule } from "@ng-select/ng-select";
import { LocalizationModule } from "angular-l10n";
import { ArisSvgService } from "../../services/aris-svg.service";
import { ArisAboutComponent } from "./aris-about.component";
import { ArisUiComponentsModule } from "../../ui-components/aris-ui-components.module";

@NgModule({
  declarations: [
    ArisAboutComponent
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    NgSelectModule,
    LocalizationModule,
    ArisUiComponentsModule
  ],
  providers: [
    ArisSvgService
  ],
  exports: [
    ArisAboutComponent
  ]
})
export class ArisAboutModule {

}
