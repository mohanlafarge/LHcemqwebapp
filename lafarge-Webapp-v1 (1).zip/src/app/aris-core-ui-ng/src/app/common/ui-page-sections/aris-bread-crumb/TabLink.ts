export interface TabLink {
  linkName: string;
  href: string;
}
