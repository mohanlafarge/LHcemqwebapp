import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArisBreadCrumbComponent } from './aris-bread-crumb.component';
import { TranslationService, LocalizationModule } from 'angular-l10n';
import { Observable } from 'rxjs';
import { ArisModule } from '../../../aris.module';
import { CommonModule } from '@angular/common';
import { ArisPipesModule } from '../../pipes/aris-pipes.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ArisUiComponentsModule } from '../../ui-components/aris-ui-components.module';
import { NavigationEnd, Router, RouterModule } from '@angular/router';

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};
class MockServices {
  // Router
  public events = Observable.of(new NavigationEnd(0, '/page/geopage', '/page/geopage'));
  navigateByUrl(url: string) { return url; }
  navigate(commands: any[], extras?: any) { return commands; }
}
describe('ArisBreadCrumbComponent', () => {
  let component: ArisBreadCrumbComponent;
  let fixture: ComponentFixture<ArisBreadCrumbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [RouterModule, ArisModule, CommonModule, LocalizationModule, ArisPipesModule, FormsModule, ReactiveFormsModule, ArisUiComponentsModule],
      providers: [{ provide: Router, useClass: MockServices },
        { provide: TranslationService, useValue: mockTranslationService },
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArisBreadCrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('ngOnInit should create', () => {
    component.ngOnInit();
    expect(component.breadCrumbs).toBeDefined();
  });

  it('ngOnInit if executed', () => {
    component.link = '/page/geopage';
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  it('breadCrumbClick if executed', () => {
    component.breadCrumbClick('/page/geopage');
    expect(component).toBeTruthy();
  });

  it('breadCrumbClick else executed', () => {
    component.breadCrumbClick('page/geopage');
    expect(component).toBeTruthy();
  });
});
