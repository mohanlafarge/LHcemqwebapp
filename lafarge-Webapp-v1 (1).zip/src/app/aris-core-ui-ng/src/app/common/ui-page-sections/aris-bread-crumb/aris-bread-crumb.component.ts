import { Component, OnInit, Input } from '@angular/core';
import { Location } from '@angular/common';
import * as _ from 'lodash';
import { TabLink } from './TabLink';
import { Router, NavigationEnd } from '@angular/router';
import { Language } from 'angular-l10n';

@Component({
  selector: 'app-bread-crumb',
  templateUrl: './aris-bread-crumb.component.html'
})
export class ArisBreadCrumbComponent implements OnInit {
  private _link: string;
  private _connectTabLink: TabLink;
  public doNotShowBreadCrumb = true;
  public breadCrumbs = window.app.config.breadCrumConfig;
  @Language() lang: string;
  @Input()
  public set connectTabLink(tablink: TabLink) {
    this._connectTabLink = tablink;
    this.update();
  }

  public get connectTabLink(): TabLink {
    return this._connectTabLink;
  }

  @Input()
  public set link(link: string) {
    this._link = link;
    this.update();
  }

  public get link(): string {
    return this._link;
  }

  public breadCrumbsForPath: TabLink[];
  constructor(private location: Location,
    private router: Router) {
    let _this = this;
    router.events.forEach((event) => {
      if (event instanceof NavigationEnd) {
        if (_this.breadCrumbs[_this.location.path()]) {
          _this.doNotShowBreadCrumb = true;
          _this.breadCrumbsForPath = _this.breadCrumbs[_this.location.path()];
        } else if(_this.breadCrumbs[_this.location.path().split('/').slice(0, -1).join("/") +"/**"]) {
          _this.doNotShowBreadCrumb = true;
          let newBreadCumb = _this.breadCrumbs[_this.location.path().split('/').slice(0, -1).join("/") +"/**"];
          for(let i= 0; i < newBreadCumb.length; i+=1) {
            if(newBreadCumb[i].href === _this.location.path().split('/').slice(0, -1).join("/") +"/**"){
              newBreadCumb[i].linkName =  newBreadCumb[i].linkName;
              newBreadCumb[i].href = _this.location.path();
            } 
          }
          _this.breadCrumbsForPath = newBreadCumb;
         } else {
          _this.doNotShowBreadCrumb = false;
        }
      }
    });
  }

  public breadCrumbClick(href: any) {
    let hrefAux = href;
    if (hrefAux.startsWith('/')) {
      hrefAux = hrefAux.substr(1);
    }
    this.router.navigate(['' + hrefAux]);
  }

  ngOnInit() {
    this.update();
  }

  private update(): void {
    if (this.link) {
      this.breadCrumbsForPath = _.cloneDeep(this.breadCrumbs[this.link]);
      if (this.connectTabLink) {
        this.breadCrumbsForPath.push(this.connectTabLink);
      }
    } else {
      try {
        if (this.breadCrumbs[this.location.path()]) {
          this.breadCrumbsForPath = this.breadCrumbs[this.location.path()]; 
        }
        else {
          this.doNotShowBreadCrumb = false;
        }
      } catch (e) {
        console.log(e);
      }
    }
  }
}
