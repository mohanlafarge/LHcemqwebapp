import { NgModule } from '@angular/core';
import { LocalizationModule } from 'angular-l10n';
import { ArisBreadCrumbComponent } from './aris-bread-crumb.component';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';


@NgModule({
  declarations: [
    ArisBreadCrumbComponent
  ],
  imports: [
    CommonModule,
    LocalizationModule,
    RouterModule,
  ],
  exports: [ArisBreadCrumbComponent],
})

export class ArisBreadCrumbModule { }