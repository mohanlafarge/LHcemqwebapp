import { TestBed, ComponentFixture } from '@angular/core/testing';
import { DebugElement, ChangeDetectorRef } from '@angular/core';
import { HttpClientModule, HttpClient  } from '@angular/common/http';
import { ReactiveFormsModule, FormControl, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';

import { NgSelectModule } from '@ng-select/ng-select';

import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from 'angular-l10n';
import { ArisI18nModule } from '../../../translation/aris-i18n.module';
import { ArisLogoutComponent } from './aris-logout.component';
import { ArisLoginService } from '../../services/aris-login.service';
import { ArisSessionService } from '../../services/aris-session.service';
import { ArisConfigService } from '../../services/aris-config.service';
import { ArisLanguageService } from '../language-selector-module/services/aris-language.service';
import { Router } from '@angular/router';
import { ArisWebSocketService } from '../../services/aris-websocket.service';
import { ArisNotificationBoxService } from '../error-module/services/aris-notification-box.service';
import { ToastrService } from 'ngx-toastr';

export class MockHttp extends HttpClient {

}
let mockRouter = {
  navigate: jasmine.createSpy('navigate')
};

let mockToastrService = {
  toastrConfig: jasmine.createSpy("toastrConfig"),
  toasts: jasmine.createSpy("toasts"),
  overlayContainer: jasmine.createSpy("overlayContainer")
};

describe('Test: ArisLogoutComponent', () => {

  let component: ArisLogoutComponent;
  let fixture: ComponentFixture<ArisLogoutComponent>;
  let arisWebSocketService: ArisWebSocketService;
  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [ArisLogoutComponent],
      imports: [ReactiveFormsModule, HttpClientModule, NgSelectModule, CommonModule, ArisI18nModule, LocalizationModule],
      providers: [{ provide: HttpClient,
        useClass: MockHttp }, { provide: Router, useValue: mockRouter },
        { provide: ToastrService, useValue: mockToastrService }, TranslationService, InjectorRef,
        ArisLoginService, ArisSessionService, ArisConfigService, ArisLanguageService, ArisWebSocketService, ArisNotificationBoxService]
    }).compileComponents();

    // create component and test fixture
    fixture = TestBed.createComponent(ArisLogoutComponent);

    // get test component from the fixture
    component = fixture.componentInstance;
  });

  it('Component to be defined', () => {
    expect(component).toBeDefined();
  });

  it('logout executed', () => {
    let arisLoginService = TestBed.get(ArisLoginService);
    spyOn(arisLoginService, 'logout').and.callThrough();
    component.logout();
    expect(arisLoginService.logout).toHaveBeenCalled();
  });

});
