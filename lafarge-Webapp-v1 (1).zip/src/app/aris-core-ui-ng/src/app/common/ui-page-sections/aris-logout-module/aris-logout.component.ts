import { Component, OnInit } from '@angular/core';
import { Language } from 'angular-l10n';
import { ArisLoginService } from '../../services/aris-login.service';

@Component({
  selector: 'aris-logout',
  templateUrl: './aris-logout.component.html'
})

export class ArisLogoutComponent implements OnInit {

  @Language() lang: string;

  constructor(private arisLoginService: ArisLoginService) {
  }

  ngOnInit() { }

  logout() {
    this.arisLoginService.logout();
  }
}
