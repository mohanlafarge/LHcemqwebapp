import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { DatePipe, CommonModule } from '@angular/common';
import { NgSelectModule } from "@ng-select/ng-select";
import { LocalizationModule } from "angular-l10n";

// ARIS MODULES & COMPONENTS
import { ArisPageComponent } from "../../ui-page-models/page-module/components/aris-page.component";
import { ArisUiComponentsModule } from "../../ui-components/aris-ui-components.module";
import { ArisNotificationListComponent } from './components/aris-notification-list.component';
import { ArisNotificationBellComponent } from "./components/aris-notifications-bell.component";
import { ArisPipesModule } from "../../pipes/aris-pipes.module";


@NgModule({
  declarations: [
    ArisNotificationBellComponent,
    ArisNotificationListComponent
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    NgSelectModule,
    LocalizationModule,
    ArisPipesModule,
    ArisUiComponentsModule
  ],
  providers:    [
    ArisPageComponent,
    DatePipe
  ],
  exports: [
    ArisNotificationBellComponent,
    ArisNotificationListComponent
  ]
})
export class ArisNotificationModule { }
