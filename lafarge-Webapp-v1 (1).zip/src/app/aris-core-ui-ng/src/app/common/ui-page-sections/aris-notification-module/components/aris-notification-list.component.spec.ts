import { ArisNotificationListComponent } from "./aris-notification-list.component";
import { BsModalService, BsModalRef } from "ngx-bootstrap";
import { Observable } from "rxjs/Observable";
import { ArisNotificationBoxServiceMock } from "../../../../mocks/services/mock-aris-notification-box.services";
import { ArisNotificationServiceMock } from "../../../../mocks/services/mock-aris-notification.services";
import { TestBed } from "@angular/core/testing";
import { ElementRef, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { ArisNotificationBoxService } from "../../../../aris-core-ui-ng";
import { ArisNotificationService } from "../../../services/aris-notification.service";
import { MockElementRef } from "../../../../mocks/services/mock-element-ref.service";
import { mockPipe } from "../../../../mocks/pipes/mock-pipe";
import { InjectorRef, LocalizationModule, TranslationService } from "angular-l10n";

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};

let mockBsModalService = {
  config: jasmine.createSpy('config'),
  show: jasmine.createSpy('show').and.callFake(() => {
    return {};
  })
};

describe("ArisNotificationListComponent", () => {
  let component: ArisNotificationListComponent;
  let arisNotificationBoxServiceMock: ArisNotificationBoxService;
  let arisNotificationServiceMock: ArisNotificationService;

  beforeEach(() => {
    arisNotificationBoxServiceMock = new ArisNotificationBoxServiceMock();
    arisNotificationServiceMock = new  ArisNotificationServiceMock();

    TestBed.configureTestingModule({
      declarations: [
        ArisNotificationListComponent,
        mockPipe({ name: 'arisnodata' })
      ],
      imports: [
        LocalizationModule
      ],
      providers: [
        InjectorRef,
        { provide: ElementRef, useClass: MockElementRef },
        { provide: ArisNotificationService, useValue: arisNotificationServiceMock },
        { provide: BsModalService, useValue: mockBsModalService },
        { provide: ArisNotificationBoxService, useValue: arisNotificationBoxServiceMock },
        { provide: TranslationService, useValue: mockTranslationService }
      ],
      schemas: [NO_ERRORS_SCHEMA , CUSTOM_ELEMENTS_SCHEMA]
    });
    const fixture = TestBed.createComponent(ArisNotificationListComponent);
    component = fixture.componentInstance;
  });
  it("should define component", () => {
    expect(component).toBeDefined();
  });

  describe("ngOnInit function", () => {
    it("should call getNotifications function", () => {
      spyOn(component, 'getNotifications');
      component.ngOnInit();
      expect(component.getNotifications).toHaveBeenCalled();
    });
  });

  describe("ngAfterViewInit function", () => {
    it("should define modalRef", () => {
      component.ngAfterViewInit();
      expect(component.modalRef).toBeDefined();
    });
  });

  describe("getNotifications function", () => {
    it("should call arisNotificationService upgradeCounterOfAlerts", () => {
      spyOn(arisNotificationServiceMock, 'upgradeCounterOfAlerts');
      component.getNotifications();
      arisNotificationServiceMock.getNotifications().then((res) => {
        expect(arisNotificationServiceMock.upgradeCounterOfAlerts).toHaveBeenCalled();
      });
    });
    it("should throw error", () => {
      spyOn(arisNotificationServiceMock, 'getNotifications').and.returnValue(Promise.reject('error'));
      component.getNotifications();
      arisNotificationServiceMock.getNotifications().then((res) => {
        expect(res).toEqual('error');
      });
    });
  });

  describe("expandAlertContent function", () => {
    beforeEach(() => {
      component.expandedArray = [1];
    });
    it('should filter expandedArray according to parameter passed', () => {
      component.expandAlertContent(1);
      expect(component.expandedArray.length).toEqual(0);
    });
    it('should push new entry to expandedArray', () => {
      component.expandAlertContent(2);
      expect(component.expandedArray.length).toEqual(2);
    });
  });

  describe("isExpanded function", () => {
    beforeEach(() => {
      component.expandedArray = [1];
    });
    it('should return false', () => {
      let val = component.isExpanded(2);
      expect(val).toBeFalsy();
    });
    it('should return true', () => {
      let val = component.isExpanded(1);
      expect(val).toBeTruthy();
    });
  });

  describe("changeUserNotificationStatusByIdToAcknowledged function", () => {
    beforeEach(() => {
      component.notifications = [{ id: 1 }];
    });
    it("should define arisNotificationService upgradeCounterOfAlerts", () => {
      spyOn(arisNotificationServiceMock, 'upgradeCounterOfAlerts');
      spyOn(arisNotificationBoxServiceMock, 'showNotification');
      component.changeUserNotificationStatusByIdToAcknowledged(0);
      arisNotificationServiceMock.changeUserNotificationStatusByIdToAcknowledged(1).then((res) => {
        expect(arisNotificationServiceMock.upgradeCounterOfAlerts).toHaveBeenCalled();
      });
    });
    it("should throw error", () => {
      spyOn(arisNotificationServiceMock, 'changeUserNotificationStatusByIdToAcknowledged').and.returnValue(Promise.reject('error'));
      component.changeUserNotificationStatusByIdToAcknowledged(0);
      arisNotificationServiceMock.changeUserNotificationStatusByIdToAcknowledged(1).then((res) => {
        expect(res).toEqual('error');
      });
    });
  });

  describe("changeAllUserNotificationStatusToAcknowledged function", () => {
    it("should define arisNotificationService upgradeCounterOfAlerts", () => {
      spyOn(arisNotificationServiceMock, 'upgradeCounterOfAlerts');
      spyOn(arisNotificationBoxServiceMock, 'showNotification');
      component.changeAllUserNotificationStatusToAcknowledged();
      arisNotificationServiceMock.changeAllUserNotificationStatusToAcknowledged().then((res) => {
        expect(arisNotificationServiceMock.upgradeCounterOfAlerts).toHaveBeenCalled();
      });
    });
    it("should throw error", () => {
      spyOn(arisNotificationServiceMock, 'changeAllUserNotificationStatusToAcknowledged').and.returnValue(Promise.reject('error'));
      component.changeAllUserNotificationStatusToAcknowledged();
      arisNotificationServiceMock.changeAllUserNotificationStatusToAcknowledged().then((res) => {
        expect(res).toEqual('error');
      });
    });
  });

  describe("removeAll function", () => {
    it("should define arisNotificationService upgradeCounterOfAlerts", () => {
      spyOn(arisNotificationServiceMock, 'upgradeCounterOfAlerts');
      spyOn(arisNotificationBoxServiceMock, 'showNotification');
      component.removeAll();
      arisNotificationServiceMock.removeAll().then((res) => {
        expect(arisNotificationServiceMock.upgradeCounterOfAlerts).toHaveBeenCalled();
      });
    });
    it("should throw error", () => {
      spyOn(arisNotificationServiceMock, 'removeAll').and.returnValue(Promise.reject('error'));
      component.removeAll();
      arisNotificationServiceMock.removeAll().then((res) => {
        expect(res).toEqual('error');
      });
    });
  });

  describe("removeNotification function", () => {
    beforeEach(() => {
      component.notifications = [{ id: 1 }];
    });
    it("should define arisNotificationService upgradeCounterOfAlerts", () => {
      spyOn(arisNotificationServiceMock, 'upgradeCounterOfAlerts');
      spyOn(arisNotificationBoxServiceMock, 'showNotification');
      component.removeNotification(0);
      arisNotificationServiceMock.removeNotification(1).then((res) => {
        expect(arisNotificationServiceMock.upgradeCounterOfAlerts).toHaveBeenCalled();
      });
    });
    it("should throw error", () => {
      spyOn(arisNotificationServiceMock, 'removeNotification').and.returnValue(Promise.reject('error'));
      component.removeNotification(0);
      arisNotificationServiceMock.removeNotification(1).then((res) => {
        expect(res).toEqual('error');
      });
    });
  });

  describe("getNotificationStatusColor function", () => {
    it("should return default value as red when notificationStatus is null", () => {
      let val = component.getNotificationStatusColor(null);
      expect(val).toEqual('red');
    });
    it("should return red when notificationStatus is new", () => {
      let val = component.getNotificationStatusColor('new');
      expect(val).toEqual('red');
    });
    it("should return goldenrod when notificationStatus is ASSIGNED", () => {
      let val = component.getNotificationStatusColor('ASSIGNED');
      expect(val).toEqual('goldenrod');
    });
    it("should return goldenrod when notificationStatus is IN PROGRESS", () => {
      let val = component.getNotificationStatusColor('IN PROGRESS');
      expect(val).toEqual('goldenrod');
    });
    it("should return green when notificationStatus is RESOLVED", () => {
      let val = component.getNotificationStatusColor('RESOLVED');
      expect(val).toEqual('green');
    });
    it("should return default value as red", () => {
      let val = component.getNotificationStatusColor('ABC');
      expect(val).toEqual('red');
    });
  });

  describe("getUserStatusColor function", () => {
    it("should return default value as red when userStatus is null", () => {
      let val = component.getUserStatusColor(null);
      expect(val).toEqual('red');
    });
    it("should return green when userStatus is ACKNOWLEDGED", () => {
      let val = component.getUserStatusColor('ACKNOWLEDGED');
      expect(val).toEqual('green');
    });
    it("should return red when userStatus is UNACKNOWLEDGED", () => {
      let val = component.getUserStatusColor('UNACKNOWLEDGED');
      expect(val).toEqual('red');
    });
    it("should return default value as red", () => {
      let val = component.getUserStatusColor('ABC');
      expect(val).toEqual('red');
    });
  });

  describe("getSeverityColor function", () => {
    it("should return default value as goldenrod when severity is null", () => {
      let val = component.getSeverityColor(null);
      expect(val).toEqual('goldenrod');
    });
    it("should return green when severity is SUCCESS", () => {
      let val = component.getSeverityColor('SUCCESS');
      expect(val).toEqual('green');
    });
    it("should return green when severity is INFO", () => {
      let val = component.getSeverityColor('INFO');
      expect(val).toEqual('green');
    });
    it("should return red when severity is ALERT", () => {
      let val = component.getSeverityColor('ALERT');
      expect(val).toEqual('red');
    });
    it("should return goldenrod when severity is WARNING", () => {
      let val = component.getSeverityColor('WARNING');
      expect(val).toEqual('goldenrod');
    });
    it("should return default value as goldenrod", () => {
      let val = component.getSeverityColor('ABC');
      expect(val).toEqual('goldenrod');
    });
  });

  describe("closeNotificationPopup function", () => {
    it("should call modalRef hide method", () => {
      component.modalRef = {
        hide: jasmine.createSpy('hide').and.callFake(() => {
          return {};
        })
      };
      component.closeNotificationPopup();
      expect(component.modalRef.hide).toHaveBeenCalled();
    });
  });
});
