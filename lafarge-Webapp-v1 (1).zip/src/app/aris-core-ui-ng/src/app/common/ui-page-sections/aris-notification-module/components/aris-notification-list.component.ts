import { Component, OnInit, AfterViewInit, Input, Output, ViewChild, ElementRef, EventEmitter, ViewEncapsulation } from '@angular/core';
import { Language } from 'angular-l10n';
import { BsModalRef, BsModalService } from "ngx-bootstrap";

import { ArisNotificationService } from '../../../services/aris-notification.service';
import { ArisNotificationBoxService } from '../../error-module/services/aris-notification-box.service';


@Component({
  selector: 'aris-notification-list',
  templateUrl: './aris-notification-list.component.html',
  styleUrls: ['../css/aris-notification-list.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class ArisNotificationListComponent implements OnInit, AfterViewInit {

  @Language() lang: string;
  @Input() changeTemplate: any;
  @Output() closePopup: EventEmitter<boolean> = new EventEmitter<boolean>();
  @ViewChild('templateNotification') notificationTemplate: ElementRef;
  public showLoadingTable = true;

  modalRef: BsModalRef;
  config = {
    animated: true,
    keyboard: false,
    backdrop: 'static',
    ignoreBackdropClick: true,
    class: "modal-lg"
  };

  notifications: any = [];
  expandedArray: any = [];

  constructor(private el: ElementRef,
    private modalService: BsModalService,
    private arisNotificationService: ArisNotificationService,
    private notificationService: ArisNotificationBoxService) {
  }

  ngOnInit() {
    this.getNotifications();
    console.log(this.notifications);
  }

  ngAfterViewInit() {
    this.modalRef = this.modalService.show(this.changeTemplate ? this.changeTemplate :  this.notificationTemplate, this.config);
  }

  getNotifications() {
    this.arisNotificationService.getNotifications().then((result) => {
      this.notifications = result;
      this.showLoadingTable = false;
      this.arisNotificationService.upgradeCounterOfAlerts(this.notifications);
    },
    (error) => {
      this.showLoadingTable = false;
    });
  }

  expandAlertContent(id: Number) {
    if (this.expandedArray.indexOf(id) > -1) {
      this.expandedArray = this.expandedArray.filter(x => x !== id);
    } else {
      this.expandedArray.push(id);
    }
  }

  isExpanded(id: Number) {
    return this.expandedArray.indexOf(id) > -1;
  }

  changeUserNotificationStatusByIdToAcknowledged(index: number) {
    this.showLoadingTable = true;
    let notification = this.notifications[index];
    this.arisNotificationService.changeUserNotificationStatusByIdToAcknowledged(notification.id).then((result) => {
      this.notifications = result;
      this.showLoadingTable = false;
      const successMessage = { status: '200', title: 'CLI_MSG_TIT_OPERATION_SUCCESS', message: 'CLI_MSG_DESC_OPERATION_SUCCESS'  };
      this.notificationService.showNotification(successMessage, 'right', 'success');
      this.arisNotificationService.upgradeCounterOfAlerts(this.notifications);
    },
    (error) => {
      this.showLoadingTable = false;
    });
  }

  changeAllUserNotificationStatusToAcknowledged() {
    this.showLoadingTable = true;
    this.arisNotificationService.changeAllUserNotificationStatusToAcknowledged().then((result) => {
      this.notifications = result;
      this.showLoadingTable = false;
      const successMessage = { status: '200', title: 'CLI_MSG_TIT_OPERATION_SUCCESS', message: 'CLI_MSG_DESC_OPERATION_SUCCESS'  };
      this.notificationService.showNotification(successMessage, 'right', 'success');
      this.arisNotificationService.upgradeCounterOfAlerts(this.notifications);
    },
    (error) => {
      this.showLoadingTable = false;
    });
  }

  removeAll() {
    this.showLoadingTable = true;
    this.arisNotificationService.removeAll().then((result) => {
      this.notifications = result;
      this.showLoadingTable = false;
      const successMessage = { status: '200', title: 'CLI_MSG_TIT_OPERATION_SUCCESS', message: 'CLI_MSG_DESC_OPERATION_SUCCESS'  };
      this.notificationService.showNotification(successMessage, 'right', 'success');
      this.arisNotificationService.upgradeCounterOfAlerts(this.notifications);
    },
    (error) => {
      this.showLoadingTable = false;
    });
  }

  removeNotification(index: number) {
    this.showLoadingTable = true;
    let notification = this.notifications[index];
    this.arisNotificationService.removeNotification(notification.id).then((result) => {
      this.notifications = result;
      this.showLoadingTable = false;
      const successMessage = { status: '200', title: 'CLI_MSG_TIT_OPERATION_SUCCESS', message: 'CLI_MSG_DESC_OPERATION_SUCCESS'  };
      this.notificationService.showNotification(successMessage, 'right', 'success');
      this.arisNotificationService.upgradeCounterOfAlerts(this.notifications);
    },
    (error) => {
      this.showLoadingTable = false;
    });
  }

  getNotificationStatusColor(notificationStatus: string) {
    if (!notificationStatus) {
      return 'red';
    }
    switch (notificationStatus.toUpperCase()) {
      case 'NEW':
        return 'red';
      case 'ASSIGNED':
        return 'goldenrod';
      case 'IN PROGRESS':
        return 'goldenrod';
      case 'RESOLVED':
        return 'green';
      default:
        return 'red';
    }
  }

  getUserStatusColor(userStatus: string) {
    if (!userStatus) {
      return 'red';
    }
    switch (userStatus.toUpperCase()) {
      case 'ACKNOWLEDGED':
        return 'green';
      case 'UNACKNOWLEDGED':
        return 'red';
      default:
        return 'red';
    }
  }

  getSeverityColor(severity: string) {
    if (!severity) {
      return 'goldenrod';
    }
    switch (severity.toUpperCase()) {
      case 'SUCCESS':
        return 'green';
      case 'INFO':
        return 'green';
      case 'ALERT':
        return 'red';
      case 'WARNING':
        return 'goldenrod';
      default:
        return 'goldenrod';
    }
  }


  closeNotificationPopup() {
    this.modalRef.hide();
    this.arisNotificationService.notificationPopupClose.next();
  }
}
