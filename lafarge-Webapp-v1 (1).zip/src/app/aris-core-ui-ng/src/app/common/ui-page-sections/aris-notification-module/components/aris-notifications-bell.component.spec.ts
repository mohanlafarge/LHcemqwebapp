import { TestBed } from "@angular/core/testing";
import { ArisNotificationBellComponent } from "./aris-notifications-bell.component";
import { Router } from "@angular/router";
import { ArisNotificationService } from "../../../services/aris-notification.service";
import { ArisNotificationServiceMock } from "../../../../mocks/services/mock-aris-notification.services";
import { NO_ERRORS_SCHEMA } from "@angular/core";
import { RouterTestingModule } from "@angular/router/testing";
import { of } from "rxjs/observable/of";


describe("ArisNotificationBellComponent", () => {
  let component: ArisNotificationBellComponent;
  let arisNotificationServiceMock: ArisNotificationService;
  beforeEach(() => {
    arisNotificationServiceMock = new  ArisNotificationServiceMock();
    TestBed.configureTestingModule({
      declarations: [ArisNotificationBellComponent],
      imports: [RouterTestingModule.withRoutes([])],
      providers: [{ provide: ArisNotificationService, useValue: arisNotificationServiceMock }],
      schemas: [NO_ERRORS_SCHEMA]
    });
    const fixture = TestBed.createComponent(ArisNotificationBellComponent);
    component = fixture.componentInstance;
  });
  it("should define component", () => {
    expect(component).toBeDefined();
  });

  it('Test if ngOnInit method called', () => {
    const response = 2;
    spyOn(arisNotificationServiceMock, 'notificationSubject').and.returnValue(of(response));
    component.ngOnInit();
    expect(component.ngOnInit).toBeTruthy();
  });

  it('Test if getNotifications method called', () => {
    spyOn(arisNotificationServiceMock, 'getNotifications').and.returnValue(Promise.resolve([{ status: "UnAcknowledged" }]));
    component.getNotifications();
    expect(component.getNotifications).toBeTruthy();
  });

  it('Test if openNotificationsPopup method called', () => {
    component.showNotificationList = false;
    component.openNotificationsPopup();
    expect(component.showNotificationList).toEqual(true);
  });

  it('Test if upgradeCounter method called', () => {
    component.notificationNum = 1;
    let data = [{ name: "Acknowledged" }];
    component.upgradeCounter(data);
    expect(component.notificationNum).toEqual(0);
  });
});
