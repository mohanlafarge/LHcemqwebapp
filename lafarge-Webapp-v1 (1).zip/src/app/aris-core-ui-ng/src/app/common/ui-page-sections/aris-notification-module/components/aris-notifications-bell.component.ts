import { Component, OnInit, ViewEncapsulation } from "@angular/core";
import { TranslationService } from "angular-l10n";
import { Router } from '@angular/router';

import { ArisNotificationService } from "../../../services/aris-notification.service";


@Component({
  selector: "aris-notification-bell",
  templateUrl: "./aris-notifications-bell.component.html",
  styleUrls: ['../css/aris-notifications-bell.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class ArisNotificationBellComponent implements OnInit {

  notificationNum = 0;
  notifications: any = [];
  public showNotificationList = false;
  constructor(private router: Router, private arisNotificationService: ArisNotificationService) {
  }

  ngOnInit() {
    this.getNotifications();
    this.arisNotificationService.notificationSubject.subscribe((data) => {
      if (typeof data === 'number') {
        this.notificationNum = this.notificationNum.valueOf() + data;
      } else if (data !== undefined) {
        this.upgradeCounter(data);
      } else {
        this.getNotifications();
      }
    });
    this.arisNotificationService.notificationPopupClose.subscribe((data) => {
      this.showNotificationList = false;
    });
  }
  getNotifications() {
    this.arisNotificationService.getNotifications().then((result) => {
      this.upgradeCounter(result);
    });
  }

  upgradeCounter (notificationList) {
    this.notifications = notificationList;
    if (this.notifications) {
      let aux = this.notifications.filter(x => x.status === "UnAcknowledged");
      if (aux) {
        this.notificationNum = aux.length;
      } else {
        this.notificationNum = 0;
      }
    }
  }

  openNotificationsPopup() {
    this.showNotificationList = true;
  }
}
