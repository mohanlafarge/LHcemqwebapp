import { TestBed, ComponentFixture } from "@angular/core/testing";
import { ArisPageRefreshComponent } from "./aris-page-refresh.component";
import { Component } from "@angular/compiler/src/core";
import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from "angular-l10n";
import { ArisPageRefreshService } from "../../services/aris-page-refresh.service";
import { ArisConfigService } from "../../services/aris-config.service";
import { HttpClient, HttpHandler, HttpClientModule } from "@angular/common/http";
import { ArisLanguageService } from "../language-selector-module/services/aris-language.service";
import { ArisI18nModule } from "../../../translation/aris-i18n.module";
import { CommonModule } from "@angular/common";
import { NgSelectModule } from "@ng-select/ng-select";
import { ReactiveFormsModule } from "@angular/forms";

describe('Aris Page Refresh Component unit test: ', () => {
  let component: ArisPageRefreshComponent;
  let fixture: ComponentFixture<ArisPageRefreshComponent>;
  let mockPageRefreshService: ArisPageRefreshService;
  beforeEach(async () => {
    TestBed.configureTestingModule({
      imports: [LocalizationModule, ReactiveFormsModule, HttpClientModule, NgSelectModule, CommonModule, ArisI18nModule, LocalizationModule],
      declarations: [ArisPageRefreshComponent],
      providers: [ArisPageRefreshService, InjectorRef, ArisConfigService, ArisLanguageService, TranslationService],
    }).compileComponents();
  });
  it('1. check if the component exists', () => {
    fixture = TestBed.createComponent(ArisPageRefreshComponent);
    component = fixture.componentInstance;
    expect(component).toBeDefined();
  });

  // it('2. check Refresh Timer method if it is returnung the current date', () => {
  //   fixture = TestBed.createComponent(ArisPageRefreshComponent);
  //   component = fixture.componentInstance;
  //   component.refreshTimer();
  //   expect(component.lastRefreshTime).toEqual(new Date());
  // });
  it('3. enable refresh', () => {
    fixture = TestBed.createComponent(ArisPageRefreshComponent);
    component = fixture.componentInstance;
    let refreshService = TestBed.get(ArisPageRefreshService);
    spyOn(refreshService, 'enable').and.callThrough();
    component.enable(true);
    expect(refreshService.enable).toHaveBeenCalled();
  });

  it('4. isEnable executed', () => {
    fixture = TestBed.createComponent(ArisPageRefreshComponent);
    component = fixture.componentInstance;
    let refreshService = TestBed.get(ArisPageRefreshService);
    spyOn(refreshService, 'isEnable').and.returnValue(true);
    let result = component.isEnable();
    expect(result).toBeTruthy();
  });

  it('5. isPageRefreshAvailable executed', () => {
    fixture = TestBed.createComponent(ArisPageRefreshComponent);
    component = fixture.componentInstance;
    let refreshService = TestBed.get(ArisPageRefreshService);
    spyOn(refreshService, 'isPageRefreshAvailable').and.returnValue(true);
    let result = component.isPageRefreshAvailable();
    expect(result).toBeTruthy();
  });
  it('6. enable refresh else', () => {
    fixture = TestBed.createComponent(ArisPageRefreshComponent);
    component = fixture.componentInstance;
    let refreshService = TestBed.get(ArisPageRefreshService);
    spyOn(refreshService, 'enable').and.callThrough();
    component.enable(false);
    expect(refreshService.enable).toHaveBeenCalled();
  });
});
