import { Component, OnInit } from '@angular/core';
import { Language } from 'angular-l10n';
import { ArisPageRefreshService } from '../../services/aris-page-refresh.service';


@Component({
  selector: 'aris-page-refresh',
  templateUrl: './aris-page-refresh.component.html'
})
export class ArisPageRefreshComponent implements OnInit {

  lastRefreshTime: Date;
  @Language() lang: string;
  autoRefreshOn: boolean;
  autoRefreshOff: boolean;
  constructor(private pageRefreshService: ArisPageRefreshService) {
    this.refreshTimer();
    this.autoRefreshOn = true;
    this.autoRefreshOff = false;
    /** This service call automatically when autorefresh call */
    this.pageRefreshService.subscribePageRefresh(
      function() {
        this.refreshTimer();
      }.bind(this)
    );
  }

  ngOnInit() {}

  /** This function is responsible for Showing time on Ui */
  refreshTimer() {
    this.lastRefreshTime = new Date();
  }

  enable(aux) {
    if (aux) {
      this.autoRefreshOn = true;
      this.autoRefreshOff = false;
    } else {
      this.autoRefreshOn = false;
      this.autoRefreshOff = true;
    }
    this.pageRefreshService.enable(aux);
  }

  isEnable() {
    return this.pageRefreshService.isEnable();
  }

  isPageRefreshAvailable() {
    return this.pageRefreshService.isPageRefreshAvailable();
  }
}
