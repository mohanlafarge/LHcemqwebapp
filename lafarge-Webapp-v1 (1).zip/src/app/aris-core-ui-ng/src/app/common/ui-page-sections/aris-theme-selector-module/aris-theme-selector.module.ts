import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { LocalizationModule } from 'angular-l10n';

import { ArisThemeSelectorComponent } from './components/aris-theme-selector.component';



@NgModule({
  declarations: [ArisThemeSelectorComponent],
  providers: [],
  imports: [
    FormsModule,
    CommonModule,
    LocalizationModule
  ],
  exports: [ArisThemeSelectorComponent]
})

export class ArisThemeSelectorModule {
}
