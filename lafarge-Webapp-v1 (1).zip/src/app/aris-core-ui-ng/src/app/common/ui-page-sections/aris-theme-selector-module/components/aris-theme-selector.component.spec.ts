import { ArisThemeService } from "../../../services/aris-theme.service";
import { ArisThemeSelectorComponent } from "./aris-theme-selector.component";
import { ChangeDetectorRef } from "@angular/core";
import { TestBed, ComponentFixture } from '@angular/core/testing';

import { ReactiveFormsModule } from '@angular/forms';
import { TranslationService } from 'angular-l10n';
import { Observable } from 'rxjs/Observable';

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};
describe('Test: ArisThemeSelectorComponent', () => {

  let component: ArisThemeSelectorComponent;
  let fixture: ComponentFixture<ArisThemeSelectorComponent>;

  let arisThemeService: ArisThemeService;

  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [ArisThemeSelectorComponent],
      providers: [{ provide: TranslationService, useValue: mockTranslationService }, ArisThemeService, ChangeDetectorRef],
      imports: [ReactiveFormsModule]
    });

    // create component and test fixture
    fixture = TestBed.createComponent(ArisThemeSelectorComponent);
    // get test component from the fixture
    component = fixture.componentInstance;
    arisThemeService = fixture.debugElement.injector.get(ArisThemeService);
  });

  it('Test compoenent instance should be created.', () => {
    expect(component).toBeTruthy();
  });

  it('Test changeTheme should call changeTheme on ArisThemeService.', () => {
    spyOn(arisThemeService, 'changeTheme').and.callThrough();
    component.changeTheme('orange');
    expect(arisThemeService.changeTheme).toHaveBeenCalled();
  });

  it('test case to check if createThemeSelector method is if working', () => {
    component.themeTypeClass = 't-arisThemeStarwars';
    component.createThemeSelector();
    expect(component.themeConfig).toBeDefined();
  });

  it('test case to check if createThemeSelector method is else working', () => {
    component.themeTypeClass = undefined;
    component.createThemeSelector();
    expect(component.themeConfig).toBeDefined();
  });

  it('test case to check if ngOnInit method is else working', () => {
    component.activeListener = undefined;
    component.ngOnInit();
    expect(component.themeConfig).toBeDefined();
  });

  it('test case to check if ngOnInit method is else working', () => {
    component.activeListener = true;
    spyOn(ArisThemeService, "themeChange").and.callFake(() => { Observable.of("o-arisThemeDark"); });
    component.ngOnInit();
    expect(component.themeConfig).toBeDefined();
  });

  it('test case to check if themeClassSelection method is if working', () => {
    component.activeListener = true;
    component.themeClassSelection();
    expect(component.themeConfig).toBeDefined();
  });

  it('test case to check if themeClassSelection method is else working', () => {
    let themeConfig = {
      defaultType: 't-arisThemeStarwars',
      defaultColor: 'o-arisThemeDark',
      themeList: [
        {
          name: 'Star Wars Theme',
          class: 't-arisThemeStarwars',
          colorList: [
            { name: 'Dark', class: 'o-arisThemeDark', iconColor: 'rgb(12, 43, 47)' },
            { name: 'Light', class: 'o-arisThemeLight', iconColor: 'rgb(17, 245, 255)' }
          ]
        },
        {
          name: 'Classic Theme',
          class: 't-arisThemeClassic',
          colorList: [
            { name: 'Blue', class: 'o-arisThemeBlue', iconColor: '#43809f' },
            { name: 'Red', class: 'o-arisThemeRed', iconColor: '#802929' },
            { name: 'Green', class: 'o-arisThemeGreen', iconColor: 'green' },
            { name: 'Orange', class: 'o-arisThemeOrange', iconColor: 'orange' },
            { name: 'White', class: 'o-arisThemeWhite', iconColor: 'white' }
          ]
        },
      ]
    };
    spyOn(arisThemeService, 'getThemeConfig').and.returnValue(themeConfig);
    component.activeListener = true;
    component.themeClassSelection();
    expect(arisThemeService.getThemeConfig).toHaveBeenCalled();
  });

  it('test case to check if createThemeSelector method is else if working', () => {
    let themeConfig = {
      defaultType: 't-arisThemeStarwars',
      defaultColor: 'o-arisThemeDark',
      themeList: [
        {
          name: 'Star Wars Theme',
          class: 't-arisThemeStarwars',
          colorList: [
            { name: 'Dark', class: 'o-arisThemeDark', iconColor: 'rgb(12, 43, 47)' },
            { name: 'Light', class: 'o-arisThemeLight', iconColor: 'rgb(17, 245, 255)' }
          ]
        },
        {
          name: 'Classic Theme',
          class: 't-arisThemeClassic',
          colorList: [
            { name: 'Blue', class: 'o-arisThemeBlue', iconColor: '#43809f' },
            { name: 'Red', class: 'o-arisThemeRed', iconColor: '#802929' },
            { name: 'Green', class: 'o-arisThemeGreen', iconColor: 'green' },
            { name: 'Orange', class: 'o-arisThemeOrange', iconColor: 'orange' },
            { name: 'White', class: 'o-arisThemeWhite', iconColor: 'white' }
          ]
        },
      ]
    };
    spyOn(arisThemeService, 'getThemeConfig').and.returnValue(themeConfig);
    component.themeTypeClass = undefined;
    component.createThemeSelector();
    expect(arisThemeService.getThemeConfig).toHaveBeenCalled();
  });

});

