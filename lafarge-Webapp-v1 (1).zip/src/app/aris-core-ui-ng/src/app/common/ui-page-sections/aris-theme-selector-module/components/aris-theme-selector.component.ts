import { Component, Input, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { ArisThemeService } from '../../../services/aris-theme.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'aris-theme-selector',
  templateUrl: './aris-theme-selector.component.html',
  styleUrls: ['../css/aris-theme-selector.component.css'],
  providers: [ArisThemeService]
})

export class ArisThemeSelectorComponent implements OnInit, OnDestroy {
  @Input() activeListener = true;
  @Input() themeTypeClass: string;
  public themeConfig: any = '';
  public themeColorList: any = '';
  themeChangeSubscription: Subscription;
  constructor(private arisThemeService: ArisThemeService, private chRef: ChangeDetectorRef) {
    this.themeConfig = window.app.config.application.theme;
    this.themeColorList = window.app.config.application.theme.themeList[0].colorList;
  }

  ngOnInit(): void {
    this.createThemeSelector();
    // let _this = this;
    if (this.activeListener) {
      this.themeChangeSubscription = ArisThemeService.themeChange.subscribe((themeSelected: any) => {
        this.themeClassSelection();
      });
    }

  }

  themeClassSelection() {
    this.themeConfig = this.arisThemeService.getThemeConfig();
    if (this.themeConfig.defaultType !== undefined) {
      for (let i = 0; i < this.themeConfig.themeList.length; i += 1) {
        if (this.themeConfig.defaultType === this.themeConfig.themeList[i].class) {
          this.themeColorList = this.themeConfig.themeList[i].colorList;
          this.themeTypeClass = this.themeConfig.defaultType;
        }
      }
    }
  }

  ngOnDestroy() {
    if (this.themeChangeSubscription !== undefined) {
      this.themeChangeSubscription.unsubscribe();
    }
  }
  createThemeSelector() {
    this.themeConfig = this.arisThemeService.getThemeConfig();
    if (this.themeTypeClass !== undefined) {
      for (let i = 0; i < this.themeConfig.themeList.length; i += 1) {
        if (this.themeTypeClass === this.themeConfig.themeList[i].class) {
          this.themeColorList = this.themeConfig.themeList[i].colorList;
          this.addBorderToThemeSelectedButton(i);
        }
      }
    } else {
      for (let i = 0; i < this.themeConfig.themeList.length; i += 1) {
        if (this.themeConfig.themeList[i].class === this.themeConfig.defaultType) {
          this.themeTypeClass = this.themeConfig.defaultType;
          this.themeColorList = this.themeConfig.themeList[i].colorList;
          this.addBorderToThemeSelectedButton(i);
        }
      }
    }
  }
  private addBorderToThemeSelectedButton(i: number) {
    for (let j = 0; j < this.themeConfig.themeList[i].colorList.length; j += 1) {
      this.themeConfig.themeList[i].colorList[j].border = false;
      if (this.themeConfig.themeList[i].colorList[j].class === this.themeConfig.defaultColor) {
        this.themeConfig.themeList[i].colorList[j].border = true;
      }
    }
  }

  changeTheme(theme: any) {
    this.arisThemeService.changeTheme(theme);
    ArisThemeService.themeChange.next(theme);
    this.createThemeSelector();
  }
}
