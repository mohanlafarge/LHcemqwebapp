import { TestBed, ComponentFixture } from '@angular/core/testing';
import { ArisCookieModal } from './aris-cookie-modal.component';
import { LocalizationModule, TranslationService, InjectorRef } from 'angular-l10n';
import { ArisModule } from '../../../aris.module';
import { ArisLanguageService } from '../language-selector-module/services/aris-language.service';
import { ArisPipesModule } from '../../pipes/aris-pipes.module';
import { ArisUiComponentsModule } from '../../ui-components/aris-ui-components.module';
import { ActivatedRouteSnapshot } from '@angular/router';
import { ArisI18nModule } from '../../../translation/aris-i18n.module';
import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { ArisConfigService } from '../../services/aris-config.service';
import { ArisLoginService } from '../../services/aris-login.service';
import { ArisSessionService } from '../../services/aris-session.service';
import { ArisPermissionPipe } from '../../pipes/aris-permission.pipes';
import { ArisPermissionService } from '../../services/aris-permission.service';
import { CookieLawModule } from 'angular2-cookie-law';

describe('Test: Aris Cookie Modal Component', () => {

  let component: ArisCookieModal;
  let fixture: ComponentFixture<ArisCookieModal>;

  beforeEach(async () => {
    TestBed.configureTestingModule({
      imports: [LocalizationModule, CookieLawModule, ReactiveFormsModule, HttpClientModule, CommonModule, ArisI18nModule, LocalizationModule],
      declarations: [ArisCookieModal],
      providers: [InjectorRef, ArisConfigService, ArisLanguageService, TranslationService, ArisLoginService, ArisSessionService, ArisPermissionPipe, ArisPermissionService],
    }).compileComponents();
  });

  it('Component must be created succesfully', () => {

    fixture = TestBed.createComponent(ArisCookieModal);
    component = fixture.componentInstance;
    component.cookieLawEl = { cookieLawSeen: true };
    component.cookieAgreementText = window.app.config.application.cookieAgreementBox.text;
    component.ngAfterViewInit();
    expect(component).toBeTruthy();
  });

  it('ngOnInit executed succesfully', () => {

    fixture = TestBed.createComponent(ArisCookieModal);
    component = fixture.componentInstance;
    component.cookieLawEl = { cookieLawSeen: true };
    component.cookieAgreementText = window.app.config.application.cookieAgreementBox.text;
    component.ngOnInit();
    expect(component.cookieName).toEqual("arisCookieLaw");
  });

  it('ngOnInit If executed succesfully', () => {

    fixture = TestBed.createComponent(ArisCookieModal);
    component = fixture.componentInstance;
    component.cookieName = "cookieName";
    component.modalPosition = "modalPosition";
    component.fileName  = "fileName";
    component.ngOnInit();
    expect(component.cookieName).toEqual("cookieName");
  });

});
