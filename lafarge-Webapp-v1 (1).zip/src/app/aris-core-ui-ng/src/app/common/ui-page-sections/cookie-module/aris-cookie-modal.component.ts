import { Component, Input, TemplateRef, ViewChild, AfterViewInit, OnInit, ViewEncapsulation, OnChanges, OnDestroy } from '@angular/core';
import { Language, TranslationService } from 'angular-l10n';
import { ArisLanguageService } from '../language-selector-module/services/aris-language.service';

@Component({
  selector: 'aris-cookie-modal',
  templateUrl: './aris-cookie-modal.component.html',
  styleUrls: ['./aris-cookie-modal.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ArisCookieModal implements OnInit, AfterViewInit {

  @ViewChild('cookieLaw') cookieLawEl: any;
  @Input() cookieModalTemplate: TemplateRef<any>;
  @Input() cookieName: string;
  @Input() modalPosition: any;
  @Input() fileName: string;
  @Language() lang: string;

  cookieAgreementText: string;
  cookieLawSeen: boolean;
  constructor(private translation: TranslationService, private arisLang: ArisLanguageService) {
  }

  ngOnInit() {
    setTimeout(() => {
      this.cookieAgreementText = this.translation.translate(window.app.config.application.cookieAgreementBox.text);
    }, 100);

    this.arisLang.languageChange.subscribe(() => {
      this.cookieAgreementText = this.translation.translate(window.app.config.application.cookieAgreementBox.text);
    });

    this.cookieName = this.cookieName ? this.cookieName : window.app.config.application.cookieAgreementBox.name;
    this.modalPosition = this.modalPosition ? this.modalPosition : window.app.config.application.cookieAgreementBox.position;
    this.fileName = this.fileName ? this.fileName : window.app.config.application.cookieAgreementBox.file;  
  }

  downloadPolicy()
  {
      let link = document.createElement('a');
      link.setAttribute('type', 'hidden');
      link.href = this.fileName;
      link.download = 'cookiePolicy.pdf';
      document.body.appendChild(link);
      link.click();
      link.remove();
  }

  ngAfterViewInit() {
    this.cookieLawSeen = this.cookieLawEl.cookieLawSeen;
  }

  dismiss(): void {
    this.cookieLawEl.dismiss();
  }
}
