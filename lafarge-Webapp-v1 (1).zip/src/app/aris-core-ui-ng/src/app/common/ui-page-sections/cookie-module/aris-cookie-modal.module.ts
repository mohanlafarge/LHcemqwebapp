import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ArisCookieModal } from './aris-cookie-modal.component';
import { CookieLawModule } from 'angular2-cookie-law';
import { LocalizationModule } from 'angular-l10n';

@NgModule({
  declarations: [
    ArisCookieModal
  ],
  imports: [
    CommonModule,
    CookieLawModule,
    LocalizationModule    
  ],
  exports: [ArisCookieModal],
})

export class ArisCookieModalModule { }
