import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CookieLawModule } from 'angular2-cookie-law';
import { LocalizationModule } from 'angular-l10n';
import { ArisErrorBoxComponent } from './components/aris-error-box.component';
import { ArisErrorService } from './services/aris-error.service';

@NgModule({
  declarations: [
    ArisErrorBoxComponent
  ],
  providers: [
    ArisErrorService
  ],
  imports: [
    CommonModule,
    CookieLawModule,
    LocalizationModule
  ],
  exports: [ArisErrorBoxComponent],
})

export class ArisErrorModule { }
