import { ArisErrorService } from '../services/aris-error.service';
import { ArisErrorBoxComponent } from "./aris-error-box.component";
import { ArisPermissionService } from '../../../services/aris-permission.service';
import { TestBed, ComponentFixture } from '@angular/core/testing';
import { Observable } from 'rxjs/Observable';
import { Component } from "@angular/compiler/src/core";
import { LocalizationModule, InjectorRef, TranslationService, TRANSLATION_CONFIG } from "angular-l10n";
import { ArisPageRefreshService } from "../../../services/aris-page-refresh.service";
import { ArisConfigService } from "../../../services/aris-config.service";
import { HttpClient, HttpHandler, HttpClientModule } from "@angular/common/http";
import { ArisLanguageService } from "../../language-selector-module/services/aris-language.service";
import { ArisI18nModule } from "../../../../translation/aris-i18n.module";
import { CommonModule } from "@angular/common";
import { NgSelectModule } from "@ng-select/ng-select";
import { ReactiveFormsModule } from "@angular/forms";
import { Subject } from 'rxjs';

describe('Error Box Unit test: ', () => {
  let permService = new ArisPermissionService();
  let errorService = new ArisErrorService(permService);
  let errorBoxComponent = new ArisErrorBoxComponent(errorService);
  let component: ArisErrorBoxComponent;
  let fixture: ComponentFixture<ArisErrorBoxComponent>;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [LocalizationModule, ReactiveFormsModule, HttpClientModule, NgSelectModule, CommonModule, ArisI18nModule, LocalizationModule],
      declarations: [ArisErrorBoxComponent],
      providers: [ArisPageRefreshService, ArisPermissionService, ArisErrorService, InjectorRef, ArisConfigService, ArisLanguageService, TranslationService],
    }).compileComponents();
    fixture = TestBed.createComponent(ArisErrorBoxComponent);
    component = fixture.componentInstance;
  });

  it('1. Test update error message when status = 200', () => {
    const data = {
      status: '200',
      title: 'Success',
      message: 'this message is successfull'
    };
    spyOn(errorService, 'buildCommunicationInfo');
    errorBoxComponent.updateErrorMessage(data);
    expect(errorService.buildCommunicationInfo).toHaveBeenCalled();

  });

  it('2. Test update error message when status != 200', () => {
    const data = '';
    errorBoxComponent.updateErrorMessage(data);
    expect(errorBoxComponent.isThereAnyError).toBeFalsy();

  });

  it('3. check initErrorMessage', () => {
    component.errorMessage = {
      status: '400',
      title: 'Error',
      message: 'this message has error'
    };
    component.ngOnInit();
    component.initErrorMessage();
    expect(component.isThereAnyError).toBe(false);

  });

  it('4. NgOninit excuted', () => {
    component.errorMessage = undefined;
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  it('5. ngOnDestroy excuted', () => {
    component.showArisErrorSubscription = new Subject();
    component.cleanArisErrorSubscription = new Subject();
    component.ngOnDestroy();
    expect(component).toBeTruthy();
  });
});
