import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { ArisErrorService } from '../services/aris-error.service';
import { Language } from 'angular-l10n';

@Component({
  selector: 'aris-error-box',
  templateUrl: './aris-error-box.component.html',
  styleUrls: []
})
export class ArisErrorBoxComponent implements OnInit, OnDestroy {
  message = {};
  msgInfo = false;
  msgError = false;
  isThereAnyError = false;
  @Input() showArisError: boolean;
  @Input() errorMessage: any;
  @Language() lang: string;

  showArisErrorSubscription: any;
  cleanArisErrorSubscription: any;

  constructor(private errorService: ArisErrorService) { }

  ngOnInit() {
    if (this.errorMessage) {
      this.isThereAnyError = true;
      this.message = this.errorMessage;
      this.updateErrorMessage(this.message);
    }
    this.showArisErrorSubscription = this.errorService.showArisError.subscribe(
      (data) => {
        this.isThereAnyError = true;
        if (typeof data === 'string'  || data instanceof String) {
          this.message = JSON.parse(data.toString());
        } else {
          this.message = data;
        }
        this.updateErrorMessage(this.message);
      }
    );

    this.cleanArisErrorSubscription = this.errorService.cleanArisError.subscribe(
      () => this.initErrorMessage()
    );
  }

  ngOnDestroy() {
    if (this.showArisErrorSubscription) {
      this.showArisErrorSubscription.unsubscribe();
    }
    if (this.cleanArisErrorSubscription) {
      this.cleanArisErrorSubscription.unsubscribe();
    }
  }

  updateErrorMessage(data) {
    if (data.status !== undefined && data.status === '200') {
      this.msgInfo = true;
      this.message = this.errorService.buildCommunicationInfo(data);
    } else if (data !== '') {
      console.log(this);
      this.msgError = true;
      this.isThereAnyError = true;
      this.message = this.errorService.buildCommunicationError(data);
    } else {
      this.initErrorMessage();
    }
  }

  initErrorMessage() {
    this.isThereAnyError = false;
    this.msgInfo = false;
    this.msgError = false;
  }

}
