import { ArisPermissionService } from '../../../services/aris-permission.service';
import { ArisErrorService } from './aris-error.service';
import { TestBed } from '@angular/core/testing';

describe('Test: Aris Error Service: ', () => {
  let persmissionService = new ArisPermissionService();
  let errorService = new ArisErrorService(persmissionService);
  const errorData = [{
    status: -1
  }];
  const errorData1 = [{
    error: 'proxy_error'
  }];
  const commError = {
    title: 'LOGIN_ERR_TIT_001',
    message: 'LOGIN_ERR_COD_001',
    status: '503',
  };
  const newError = {
    title: 'newError',
    message: 'newMessage',
    status: 'newStatus'
  };
  it('1. Aris Error Service test: checking if data.status is -1', () => {
    const result = errorService.buildCommunicationError(errorData);
    expect(result).toBeDefined(commError);
  });
  it('2. Aris Error Service test: checking if data.error is proxy_error', () => {
    const result = errorService.buildCommunicationError(errorData1);
    expect(result).toBeDefined(commError);
  });
  it('3. check if the error is present in any of the defined errors', () => {
    const result = errorService.buildCommunicationError(newError);
    expect(result).toBeDefined(commError);
  });
  it('4. check buildCommunicationInfo method', () => {
    let data = {
      status: '503',
      title: 'LOGIN_ERR_TIT_001',
      message: 'LOGIN_ERR_COD_001'
    };
    errorService.commInfo = {
      status: '', title: '', message: ''
    };
    let outputInfo = errorService.buildCommunicationInfo(data);
    expect(outputInfo.title).toEqual(data.title);
  });

  it('5. check buildCommunicationError else if scenario', () => {
    let data = {
      error: 'proxy_error',
      status: '503',
      title: 'LOGIN_ERR_TIT_001',
      message: 'LOGIN_ERR_COD_001'
    };
    let outputInfo = errorService.buildCommunicationError(data);
    expect(outputInfo.title).toEqual(data.title);
  });

  it('6. check buildCommunicationError else scenario', () => {
    let data = {
      status: '503',
      message: 'LOGIN_ERR_COD_001'
    };
    let outputInfo = errorService.buildCommunicationError(data);
    expect(outputInfo.status).toEqual(data.status);
  });
});

