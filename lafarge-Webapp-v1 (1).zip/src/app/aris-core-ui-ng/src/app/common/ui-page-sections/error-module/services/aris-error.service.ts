import { EventEmitter, Injectable, Output } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { ArisPermissionService } from '../../../services/aris-permission.service';

@Injectable()
export class ArisErrorService {
  commInfo: { status: string, title: string, message: string };
  commError: { title: string, message: string, status: string };
  showArisError = new Subject();
  cleanArisError = new Subject();

  constructor(private permissionService: ArisPermissionService) { }

/*  treatRoutingError(location, event, next) {
    // aris notification clase all method
    if (location.path() !== '' &&
            location.path().indexOf('login') === -1 &&
            location.path().indexOf('forgotpassword') === -1 &&
            sessionStorage.getItem('loggedIn') !== 'true') {
      event.preventDefault();
      location.path('/login');
    } else if (sessionStorage.getItem('loggedIn') === 'true') {
      if (location.path() === '/todo' || location.path() === 'todo') {
        this.commInfo = {
          status: '200',
          title: 'CLI_ERR_TIT_PAGE_UNDERCONSTRUCTION',
          message: 'CLI_ERR_DESC_PAGE_UNDER_CONSTRUCTION',
        };
        location.path('/error/' + JSON.stringify(this.commInfo));
      } else if (next.router === undefined) {
        this.commInfo = {
          status: '404',
          title: 'CLI_ERR_TIT_PAGE_NOT_FOUND',
          message: 'CLI_ERR_DESC_PAGE_NOT_FOUND',
        };
        console.warn('Route not found', location.path());
        location.path('/error/' + JSON.stringify(this.commInfo));
      } else if ((next.router.templateUrl !== undefined) &&
                (next.router.templateUrl.toUpperCase().indexOf('PROTOTYPES') !== -1) &&
                (!this.permissionService.hasPermission('PERM_VIEW_TEST_PAGES'))) {
        this.commInfo = {
          status: '404',
          title: 'CLI_ERR_TIT_PAGE_NOT_FOUND',
          message: 'CLI_ERR_DESC_PAGE_NOT_FOUND'
        };
        location.path('/error/' + JSON.stringify(this.commInfo));
      } else if ((next.router.permission !== undefined) &&
                (!this.permissionService.hasPermission(next.router.permission))) {
        this.commInfo = {
          status: '401',
          title: 'CLI_ERR_TIT_ACCES_DENIED',
          message: 'CLI_ERR_DESC_PERMISSION_AREA_DENIED'
        };
        location.path('/error/' + JSON.stringify(this.commInfo));
      }
    }
  }*/

  /*
  * Build a error message
  *  @param data
  *     - status : error status associated to the error
  *     - title : title associated to the error
  *     - message : error message to be displayed
  *  returns
  */
  buildCommunicationError(data) {
    if (!data.status || data.status === -1) {
      this.commError = {
        title: 'LOGIN_ERR_TIT_001',
        message: 'LOGIN_ERR_COD_001',
        status: '503',
      };
    } else {
      if (data !== undefined && data.error === 'proxy_error') {
        this.commError = {
          title: 'LOGIN_ERR_TIT_001',
          message: 'LOGIN_ERR_COD_001',
          status: '503',
        };
      } else {
        if (data.title !== undefined) {
          this.commError = {
            title: data.title,
            message: data.message,
            status: data.status,
          };
        } else {
          this.commError = {
            title: 'LOGIN_ERR_TIT_002',
            message: data.message,
            status: data.status,
          };
        }
      }
    }
    console.log('Error Message: ' + JSON.stringify(this.commError));
    return this.commError;
  }

    /*
    * Build a Info message
    *  @param data
    *     - status : info status associated to the info message
    *     - title : title associated to the info message
    *     - message : info message to be displayed
    *  returns
    */
  buildCommunicationInfo(data) {
    this.commInfo = {
      status: data.status,
      title: data.title,
      message: data.message
    };
    console.log('Informative Message: ' + JSON.stringify(this.commInfo));
    return this.commInfo;
  }
}
