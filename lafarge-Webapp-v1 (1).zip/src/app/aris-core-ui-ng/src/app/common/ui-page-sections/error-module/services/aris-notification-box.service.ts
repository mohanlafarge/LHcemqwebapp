import { ToastrService } from 'ngx-toastr';
import { Injectable } from '@angular/core';
import { LocaleService, TranslationService } from 'angular-l10n';

@Injectable()
export class ArisNotificationBoxService {

  statusTitle = '';
  statusMessage = '';
  constructor(private toastr: ToastrService, private localeService: LocaleService, private transalation: TranslationService) {
    this.toastr.toastrConfig.timeOut = window.app.config.application.notifications.timeVisible;
    this.toastr.toastrConfig.closeButton = window.app.config.application.notifications.closeButton;
    this.toastr.toastrConfig.maxOpened = window.app.config.application.notifications.maxNumVisible;
    this.toastr.toastrConfig.preventDuplicates = window.app.config.application.notifications.preventDuplicates;
  }

  showNotification(statusMessage: any, positionOfStatus: string, status: string) {
    const currentLanguage = this.localeService.getCurrentLanguage();
    this.toastr.toastrConfig.positionClass = this.getPosition(positionOfStatus);
    this.statusTitle = this.transalation.translate(statusMessage.title.trim(), currentLanguage);
    this.statusMessage = this.transalation.translate(statusMessage.message.trim(), currentLanguage);
    if (status === 'success') {
      this.toastr.success(this.statusMessage, '(' + statusMessage.status + ')' + '-' + this.statusTitle);
    } else if (status === 'error') {
      this.toastr.error(this.statusMessage, '(' + statusMessage.status + ')' + '-' + this.statusTitle);
    } else if (status === 'info') {
      this.toastr.info(this.statusMessage, '(' + statusMessage.status + ')' + '-' + this.statusTitle);
    } else if (status === 'warning') {
      this.toastr.warning(this.statusMessage, '(' + statusMessage.status + ')' + '-' + this.statusTitle);
    }
  }

  getPosition(position): string {
    return (position === 'center' ? 'toast-top-center' : '') +
           (position === 'left' ? 'toast-top-left' : '') +
           (position === 'top-right' ? 'toast-top-right' : '') +
           (position === 'right' ? 'toast-top-right' : '') +
           (position === 'bottom-right' ? 'toast-bottom-right' : '') +
           (position === 'bottom-left' ? 'toast-bottom-left' : '');
  }
}
