import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { LocalizationModule } from 'angular-l10n';

import { ArisPageRefreshComponent } from '../aris-page-refresh/aris-page-refresh.component';

import { ArisFiltersComponent } from './components/aris-filter.component';

import { ArisSessionService } from '../../services/aris-session.service';
import { ArisFooterModule } from '../footer-module/aris-footer.module';
import { ArisUiComponentsModule } from '../../ui-components/aris-ui-components.module';
import { ArisCacheLocalService } from '../../services/aris-cache-local.service';
import { ArisNotificationBoxService } from '../error-module/services/aris-notification-box.service';
import { ArisPipesModule } from '../../pipes/aris-pipes.module';


@NgModule({
  declarations: [ArisFiltersComponent],
  imports: [FormsModule,
    ReactiveFormsModule,
    CommonModule,
    LocalizationModule,
    ArisFooterModule,
    ArisUiComponentsModule,
    ArisPipesModule
  ],
  providers: [ArisSessionService, ArisCacheLocalService, ArisNotificationBoxService],
  exports: [ArisFiltersComponent],
})

export class FilterModule { }
