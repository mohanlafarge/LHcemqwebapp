import { ArisFiltersComponent } from './aris-filter.component';
import { ArisNotificationBoxService } from '../../error-module/services/aris-notification-box.service';
import { ArisCacheLocalService } from '../../../services/aris-cache-local.service';
import { ArisFilterService } from '../../../services/aris-filter.service';
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { CommonModule, DatePipe } from '@angular/common';
import { Component, EventEmitter } from '@angular/core';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { ArisPageRefreshService } from '../../../services/aris-page-refresh.service';
import { ArisConfigService } from '../../../services/aris-config.service';
import { ArisModule } from '../../../../aris.module';
import { FilterModule } from '../aris-filter.module';
import { ISubscription, Subscription } from 'rxjs/Subscription';

describe('Test Filter Component', () => {
  let component: ArisFiltersComponent;
  let fixture: ComponentFixture<ArisFiltersComponent>;
  let handler: HttpHandler;
  let http = new HttpClient(handler);
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      schemas: [],
      imports: [ArisModule, CommonModule, FormsModule, FilterModule],
      providers: [DatePipe, HttpClient, HttpHandler, ArisConfigService, ArisFilterService, ArisPageRefreshService, ArisNotificationBoxService,
        ArisCacheLocalService]
    }).compileComponents();
  });

  beforeEach(() => {
    // create component and test fixture
    fixture = TestBed.createComponent(ArisFiltersComponent);
    // get test component from the fixture
    component = fixture.componentInstance;
    const rawData = '[{"pagename":"geopage","submiturl":"/rest/getWorkOrders","datasource":"workOrders","criterias":[{"name":"WORK_ORDER_ID","dsname":"workOrderDistinctId","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"],"val":["WKO-002"]},{"name":"WORK_ORDER_WSZ","dsname":"workOrderDistinctWsz","type":"autocompletefield","dtype":"xx","op":"in","fields":["1","2","3","4","5","6","7"]},{"name":"WORK_ORDER_PRIORITY","type":"checkbox","dtype":"xx","op":"in","fields":["1","2","3"],"val":{"1":false,"2":false,"3":false}},{"name":"WORK_ORDER_STATUS","type":"checkbox","dtype":"xx","op":"in","fields":["Open","Completed","Cancelled","Aborted"],"val":{"Open":true,"Completed":false,"Cancelled":false,"Aborted":false}},{"name":"WORK_ORDER_TYPE","type":"checkbox","dtype":"xx","op":"in","fields":["Reactive","Planned"],"val":{"Reactive":true,"Planned":true}},{"name":"WORK_ORDER_DMA","dsname":"workOrderDistinctDma","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"]},{"name":"WORK_ORDER_DESCRIPTION","dsname":"workOrderDistinctDesc","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"]},{"name":"WORK_ORDER_POSTCODE","dsname":"workOrderDistinctPostcode","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"]}]},{"pagename":"geopage","submiturl":"/rest/getSpillIncident","datasource":"spillIncident","criterias":[{"name":"INCIDENT_PUBLIC_OR_PRIVATE","type":"checkbox","dtype":"xx","op":"in","fields":["PUBLIC","PRIVATE","SSOH"],"val":{"PUBLIC":true,"PRIVATE":false,"SSOH":false}},{"name":"SPILL_SOURCE","type":"checkbox","dtype":"xx","op":"in","fields":["MAIN","LATERAL"],"val":{"MAIN":false,"LATERAL":false}},{"name":"INCIDENT_CAUSE","dsname":"spillIncidentDistinctCause","type":"autocompletefield","dtype":"xx","op":"in","fields":["DEBRIS","COLLAPSE","EQUIPMENT FAILURE","GREASE","RAIN","ROOTS","VANDALISM","OTHER","UNKNOWN"]},{"name":"INCIDENT_CAUSE","type":"checkbox","dtype":"xx","op":"like","fields":["DEBRIS","COLLAPSE","EQUIPMENT FAILURE","GREASE","RAIN","ROOTS","VANDALISM","OTHER","UNKNOWN"],"val":{"DEBRIS":true,"COLLAPSE":false,"EQUIPMENT FAILURE":false,"GREASE":false,"RAIN":false,"ROOTS":false,"VANDALISM":false,"OTHER":false,"UNKNOWN":false}},{"name":"COMMENTS","type":"textfield","dtype":"xx","op":"like","fields":["",""],"val":""},{"name":"SPILL_TO","type":"checkbox","dtype":"xx","op":"in","fields":["LAND","CREEK"],"val":{"LAND":false,"CREEK":false}}]}]';
    component.filterData = JSON.parse(rawData);
    component.dateRange = [];
    component.pageName = 'geo';
    component.onPageRefresh = new EventEmitter();
    component.onFilterChange = new EventEmitter();
  });

  it('SetSubscription executed', () => {
    let data = "workOrderDistinctDma";
    component.filterData = [{ datasource: "workOrderDistinctDma", criterias: [{ type: 'autocompletefield' }] }];
    component.dateRangeAfterFetch = undefined;
    component.setSubscription(data);
    expect(component.onPageRefresh).toBeTruthy();
  });

  it('SetSubscription if scenario executed', () => {
    let data = "workOrderDistinctDma";
    component.dateRange = [{}, { val: 'val' }];
    component.filterData = undefined;
    component.dateRangeAfterFetch = "workOrderDistinctDma";
    component.setSubscription(data);
    expect(component.filterData).toBeUndefined();
  });

  it('sample test to Check showTabsinFilter Method true case', () => {
    component.pageType = 'nongeo';
    component.showTabsinFilter();
    expect(true).toEqual(true);
  });

  it('sample test to Check showTabsinFilter Method false case', () => {
    component.pageType = 'geo';
    component.showTabsinFilter();
    expect(false).toEqual(false);
  });

  it('sample test to Check displayFilterTitle Method', () => {
    let subfilter = {};
    const value = component.displayFilterTitle(subfilter);
    expect(value).toBeFalsy();
  });

  it('sample test to Check displayFilterTitle Method IF Scenario', () => {
    component.pageType = 'geo';
    component.filterPanelCategoryTab = 'datasource';
    let subfilter = { datasource: 'datasource' };
    const value = component.displayFilterTitle(subfilter);
    expect(value).toBeTruthy();
  });

  it('sample test to Check initFilterData Method is returning right result or not', () => {
    let result = component.inputValidator(component.filterData);
    expect("WKO-002").toBe(result[0][0]);
  });

  it('sample test to Check onFilterApply Method functionality that result length is greater then or equal 0', () => {
    component.dateRange[0] = null;
    component.dateRange[1] = null;
    spyOn(component, 'inputValidator').and.returnValue("");
    component.onFilterApply();
    expect(component).toBeTruthy();
  });

  it('sample test to Check onFilterApply Method functionality IF Part', () => {
    component.dateRange[0] = "12/02/14";
    component.dateRange[1] = "12/02/14";
    spyOn(component, 'inputValidator').and.returnValue("data");
    component.onFilterApply();
    expect(component).toBeTruthy();
  });

  // it('sample test to Check onFilterApply Method functionality ELSE Part', () => {
  //   component.dateRange[0] = undefined;
  //   component.dateRange[1] = undefined;
  //   component.dateRange[0] = null;
  //   component.dateRange[1] = null;
  //   component.filterData = null;
  //   spyOn(component, 'inputValidator').and.returnValue("data");
  //   component.onFilterApply();
  //   expect(component).toBeTruthy();
  // });

  it('sample test to Check cleanFilterFields Method Check ELSE PART return type', () => {
    component.cleanFilterFields();
    expect(component.filterData[0].criterias[0].val).toBeUndefined();
  });

  it('sample test to Check cleanFilterFields Method Check IF PART return type', () => {
    component.pageType = 'geo';
    component.cleanFilterFields();
    expect(component.onPageRefresh).toBeTruthy();
  });


  it('sample test to Check inside openFilter Method display filter value changed or not', () => {
    component.displayFilter = false;
    let data = [{ pagename: "geopage" }];
    let arisFilterService = TestBed.get(ArisFilterService);
    spyOn(arisFilterService, 'getDatasourcesFromConfig').and.returnValue(data);
    component.openFilter();
    expect(true).toBe(component.displayFilter);
  });

  it('sample test to Check inside openFilter ELSE Scenario', () => {
    component.displayFilter = false;
    let arisFilterService = TestBed.get(ArisFilterService);
    spyOn(arisFilterService, 'getDatasourcesFromConfig').and.returnValue(undefined);
    component.openFilter();
    expect(true).toBe(component.displayFilter);
  });

  it('sample test to Check changeFooterDisplay Method return type', () => {
    component.displayFilter = true;
    component.changeFooterDisplay();
    expect(component.displayFilter).toBe(false);
  });

  it('sample test to Check saveFilter Method IF PART is getting called or not', () => {
    spyOn(component, 'inputValidator').and.callThrough();
    spyOn(component, 'onFilterApply').and.callThrough();
    spyOn(http, 'post').and.callThrough();
    let filterservice = TestBed.get(ArisFilterService);
    spyOn(filterservice, 'saveFilterData').and.callThrough();
    component.saveFilter();
    expect(filterservice.saveFilterData).toHaveBeenCalled();
  });

  it('sample test to Check saveFilter Method ELSE PART is getting called or not', () => {
    component.dateRange[0] = "12/02/14";
    component.dateRange[1] = "12/02/14";
    let filterservice = TestBed.get(ArisFilterService);
    spyOn(filterservice, 'saveFilterData').and.callFake(() => Promise.resolve());
    component.saveFilter();
    expect(filterservice.saveFilterData).toHaveBeenCalled();
    expect(component).toBeTruthy();
  });

  it('sample test to Check onFilterReset Method error is getting called or not', () => {
    spyOn(http, 'post').and.callThrough();
    let filterservice = TestBed.get(ArisFilterService);
    spyOn(filterservice, 'deleteFilterData').and.callThrough();
    component.onFilterReset();
    expect(filterservice.deleteFilterData).toHaveBeenCalledWith('geo');
  });

  it('sample test to Check onFilterReset Method is getting called or not', () => {
    spyOn(http, 'post').and.callThrough();
    let filterservice = TestBed.get(ArisFilterService);
    let data = "data";
    spyOn(filterservice, 'deleteFilterData').and.callFake(() => Promise.resolve(data));
    component.onFilterReset();
    expect(filterservice.deleteFilterData).toHaveBeenCalledWith('geo');
  });

  it('sample test to Check onFilterReset Method else is getting called or not', () => {
    spyOn(http, 'post').and.callThrough();
    let filterservice = TestBed.get(ArisFilterService);
    spyOn(filterservice, 'deleteFilterData').and.callFake(() => Promise.resolve(0));
    component.onFilterReset();
    expect(filterservice.deleteFilterData).toHaveBeenCalledWith('geo');
  });

  it('sample test to Check fetchFilters Method is getting called or not', () => {
    spyOn(http, 'post').and.callThrough();
    let filterservice = TestBed.get(ArisFilterService);
    spyOn(filterservice, 'getFilterByPageName').and.callThrough();
    component.fetchFilters();
    expect(filterservice.getFilterByPageName).toHaveBeenCalledWith('geo');
  });

  it('sample test to Check checkBoxChange Method IF Part getting called or not', () => {
    let event = {
      target : {
        checked: true
      }
    };
    let obj = {
      value : true
    };
    let value = true;
    component.checkBoxChange(event, value, obj);
    expect(component.saveButtonDisable).toBeTruthy();
  });

  it('sample test to Check checkBoxChange Method ELSE Part getting called or not', () => {
    let event = {
      target : {
        checked: false
      }
    };
    let obj = {
      value : true
    };
    let value = true;
    component.checkBoxChange(event, value, obj);
    expect(component).toBeTruthy();
  });

  it('sample test to Check changeTab Method getting called or not', () => {
    let tab = true;
    component.changeTab(tab);
    expect(component.filterPanelCategoryTab).toBeTruthy();
  });

  it('sample test to Check checkClass Method getting called or not', () => {
    let tabs = {
      datasource: true
    };
    let expected = component.checkClass(tabs);
    expect(expected).toBeFalsy();
  });

  it('sample test to Check onAutocompleteChange Method IF PART getting called or not', () => {
    let changedValue = {
      length: 1
    };

    let subtabs = {
      val: 1
    };

    component.onAutocompleteChange(changedValue, subtabs, "x", 0, 0);
    expect(component.filterData).toBeDefined();
  });

  it('sample test to Check onAutocompleteChange Method ELSE PARTgetting called or not', () => {

    let subtabs = {
      val: 1
    };
    component.onAutocompleteChange(undefined, subtabs, "x", 0, 0);
    expect(component.filterData).toBeDefined();
  });

  it('sample test to Check onDateChange Method IF PARTgetting called or not', () => {


    let datePipe = TestBed.get(DatePipe);
    let data = ['data'];
    let arisConfigService = TestBed.get(ArisConfigService);
    spyOn(arisConfigService, 'getDabaseDateFormat').and.returnValue(data);
    spyOn(datePipe, "transform").and.returnValue(data);
    component.onDateChange("value", "from");
    expect(arisConfigService.getDabaseDateFormat).toHaveBeenCalled();
  });

  it('sample test to Check onDateChange Method ELSE if PARTgetting called or not', () => {
    let datePipe = TestBed.get(DatePipe);
    let data = ['data', 'loc'];
    let arisConfigService = TestBed.get(ArisConfigService);
    spyOn(arisConfigService, 'getDabaseDateFormat').and.returnValue(data);
    spyOn(datePipe, "transform").and.returnValue(data);
    component.onDateChange("value", "to");
    expect(arisConfigService.getDabaseDateFormat).toHaveBeenCalled();
  });

  it('sample test to Check onDateChange Method ELSE PARTgetting called or not', () => {
    let datePipe = TestBed.get(DatePipe);
    let data = ['data', 'loc'];
    let arisConfigService = TestBed.get(ArisConfigService);
    spyOn(arisConfigService, 'getDabaseDateFormat').and.returnValue(data);
    spyOn(datePipe, "transform").and.returnValue(data);
    component.onDateChange("value", "do");
    expect(component).toBeTruthy();
  });

  it('sample test to Check refreshPage Method IF PART getting called or not', () => {
    component.pageType = 'geo';
    component.refreshPage();
    expect(component.onPageRefresh).toBeTruthy();
  });

  it('sample test to Check refreshPage Method IF PART dateRange[1] not undefined getting called or not', () => {
    component.dateRange[0] = "undefined ";
    component.dateRange[1] = "12/02/14";
    component.pageType = 'geo';
    component.refreshPage();
    expect(component.onPageRefresh).toBeTruthy();
  });

  it('sample test to Check refreshPage Method ELSE PART getting called or not', () => {
    component.pageType = 'nongeo';
    component.refreshPage();
    expect(component.onPageRefresh).toBeTruthy();
  });

  it('sample test to Check refreshPage Method ELSE PART dateRange[1] not undefined getting called or not', () => {
    component.dateRange[0] = "undefined ";
    component.dateRange[1] = "12/02/14";
    component.pageType = 'nongeo';
    component.refreshPage();
    expect(component.onPageRefresh).toBeTruthy();
  });

  it('sample test to Check callSuccessPopup Method ELSE PART getting called or not', () => {
    component.callSuccessPopup(component.filterData, "workOrderDistinctDma");
    expect(component.onPageRefresh).toBeTruthy();
  });

  it('sample test to Check callSuccessPopup Method IF PART getting called or not', () => {
    let data = [{ datasource: "workOrderDistinctDma", criterias: [{ type: 'autocompletefield', val: 'val' }] }];
    component.callSuccessPopup(data, "workOrderDistinctDma");
    expect(component.onPageRefresh).toBeTruthy();
  });

  it('sample test to Check callSuccessPopup Method checkdata.val else PART getting called or not', () => {
    let data = [{ datasource: "workOrderDistinctDma", criterias: [{ type: 'autocompletefield' }] }];
    component.callSuccessPopup(data, "workOrderDistinctDma");
    expect(component.onPageRefresh).toBeTruthy();
  });

  it('sample test to Check callSuccessPopup Method IF checkdata.type === checkbox getting called or not', () => {
    let data = [{ datasource: "workOrderDistinctDma", criterias: [{ type: 'checkbox', val: [{ key: true }] }] }];
    component.callSuccessPopup(data, "workOrderDistinctDma");
    expect(component.onPageRefresh).toBeTruthy();
  });

  it('sample test to Check callSuccessPopup Method IF checkdata.type === unknown getting called or not', () => {
    let data = [{ datasource: "workOrderDistinctDma", criterias: [{ type: 'unknown', val: [{ key: true }] }] }];
    component.callSuccessPopup(data, "workOrderDistinctDma");
    expect(component.onPageRefresh).toBeTruthy();
  });

  it('sample test to Check callSuccessPopup Method FilterData undefined', () => {
    component.callSuccessPopup(undefined, "workOrderDistinctDma");
    expect(component.onPageRefresh).toBeTruthy();
  });

  it('sample test to Check displayFilters Method IF PART getting called or not', () => {
    component.pageType = 'nongeo';
    let arisFilterService = TestBed.get(ArisFilterService);
    let data = "data";
    spyOn(arisFilterService, 'getFilterConfig').and.returnValue(data);
    component.displayFilters();
    expect(arisFilterService.getFilterConfig).toHaveBeenCalled();
  });

  it('sample test to Check displayFilters Method getFilterConfig returns blank value', () => {
    component.pageType = 'nongeo';
    let arisFilterService = TestBed.get(ArisFilterService);
    spyOn(arisFilterService, 'getFilterConfig').and.returnValue('');
    component.displayFilters();
    expect(arisFilterService.getFilterConfig).toHaveBeenCalled();
  });

  it('sample test to Check displayFilters Method ELSE PART getting called or not', () => {
    component.filterData = undefined;
    component.pageType = '';
    component.ngOnInit();
    let arisFilterService = TestBed.get(ArisFilterService);
    let data = '{"datasource": "true"}';
    spyOn(arisFilterService, 'getFilter').and.callFake(()  => Promise.resolve(data));
    spyOn(arisFilterService, 'setFilterConfig').and.callFake(() => data);
    component.displayFilters();
    expect(arisFilterService.getFilter).toHaveBeenCalled();
  });

  it('sample test to Check displayFilters Method result IF PART getting called or not', () => {
    component.filterData = undefined;
    component.pageType = '';
    component.initFilterData = function () {};
    component.ngOnInit();
    let arisFilterService = TestBed.get(ArisFilterService);
    let data = '["value"]';
    spyOn(arisFilterService, 'getFilter').and.callFake(()  => Promise.resolve(data));
    spyOn(arisFilterService, 'setFilterConfig').and.callFake(() => data);
    component.displayFilters();
    expect(arisFilterService.getFilter).toHaveBeenCalled();
  });

  it('sample test to Check displayFilters Method filterData has value', () => {
    component.filterData = 'undefined';
    component.pageType = '';
    component.ngOnInit();
    let arisFilterService = TestBed.get(ArisFilterService);
    spyOn(arisFilterService, 'getFilterConfig').and.returnValue('');
    component.displayFilters();
    expect(arisFilterService.getFilterConfig).toHaveBeenCalled();
  });

  it('sample test to Check displayFilters Method ELSE PART getting called or not', () => {
    component.filterData = undefined;
    component.pageType = '';

    let arisFilterService = TestBed.get(ArisFilterService);
    let data = '';
    spyOn(arisFilterService, 'getFilterByPageName').and.callFake(()  => Promise.resolve(data));
    component.fetchFilters();
    expect(arisFilterService.getFilterByPageName).toHaveBeenCalled();
  });

  it('sample test to Check displayFilters Method ELSE PART getting called or not', () => {
    component.filterData = undefined;
    component.pageType = '';
    let arisFilterService = TestBed.get(ArisFilterService);
    let data = '[{"pagename":"geopage","submiturl":"/rest/getWorkOrders","datasource":"workOrders","criterias":[{"name":"WORK_ORDER_ID","dsname":"workOrderDistinctId","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"],"val":["WKO-002"]},{"name":"WORK_ORDER_WSZ","dsname":"workOrderDistinctWsz","type":"autocompletefield","dtype":"xx","op":"in","fields":["1","2","3","4","5","6","7"]},{"name":"WORK_ORDER_PRIORITY","type":"checkbox","dtype":"xx","op":"in","fields":["1","2","3"],"val":{"1":false,"2":false,"3":false}},{"name":"WORK_ORDER_STATUS","type":"checkbox","dtype":"xx","op":"in","fields":["Open","Completed","Cancelled","Aborted"],"val":{"Open":true,"Completed":false,"Cancelled":false,"Aborted":false}},{"name":"WORK_ORDER_TYPE","type":"checkbox","dtype":"xx","op":"in","fields":["Reactive","Planned"],"val":{"Reactive":true,"Planned":true}},{"name":"WORK_ORDER_DMA","dsname":"workOrderDistinctDma","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"]},{"name":"WORK_ORDER_DESCRIPTION","dsname":"workOrderDistinctDesc","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"]},{"name":"WORK_ORDER_POSTCODE","dsname":"workOrderDistinctPostcode","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"]}]},{"pagename":"geopage","submiturl":"/rest/getSpillIncident","datasource":"spillIncident","criterias":[{"name":"INCIDENT_PUBLIC_OR_PRIVATE","type":"checkbox","dtype":"xx","op":"in","fields":["PUBLIC","PRIVATE","SSOH"],"val":{"PUBLIC":true,"PRIVATE":false,"SSOH":false}},{"name":"SPILL_SOURCE","type":"checkbox","dtype":"xx","op":"in","fields":["MAIN","LATERAL"],"val":{"MAIN":false,"LATERAL":false}},{"name":"INCIDENT_CAUSE","dsname":"spillIncidentDistinctCause","type":"autocompletefield","dtype":"xx","op":"in","fields":["DEBRIS","COLLAPSE","EQUIPMENT FAILURE","GREASE","RAIN","ROOTS","VANDALISM","OTHER","UNKNOWN"]},{"name":"INCIDENT_CAUSE","type":"checkbox","dtype":"xx","op":"like","fields":["DEBRIS","COLLAPSE","EQUIPMENT FAILURE","GREASE","RAIN","ROOTS","VANDALISM","OTHER","UNKNOWN"],"val":{"DEBRIS":true,"COLLAPSE":false,"EQUIPMENT FAILURE":false,"GREASE":false,"RAIN":false,"ROOTS":false,"VANDALISM":false,"OTHER":false,"UNKNOWN":false}},{"name":"COMMENTS","type":"textfield","dtype":"xx","op":"like","fields":["",""],"val":""},{"name":"SPILL_TO","type":"checkbox","dtype":"xx","op":"in","fields":["LAND","CREEK"],"val":{"LAND":false,"CREEK":false}}]}]';
    spyOn(arisFilterService, 'getFilterByPageName').and.callFake(()  => Promise.resolve(data));
    component.fetchFilters();
    expect(arisFilterService.getFilterByPageName).toHaveBeenCalled();
  });

  it('sample test to Check getDataFromCache Method ELSE PART getting called or not', () => {
    let arisCacheLocalService = TestBed.get(ArisCacheLocalService);
    let arisFilterService = TestBed.get(ArisFilterService);
    let data = '[{"pagename":"geopage","submiturl":"/rest/getWorkOrders","datasource":"workOrders","criterias":[{"name":"WORK_ORDER_ID","dsname":"workOrderDistinctId","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"],"val":["WKO-002"]},{"name":"WORK_ORDER_WSZ","dsname":"workOrderDistinctWsz","type":"autocompletefield","dtype":"xx","op":"in","fields":["1","2","3","4","5","6","7"]},{"name":"WORK_ORDER_PRIORITY","type":"checkbox","dtype":"xx","op":"in","fields":["1","2","3"],"val":{"1":false,"2":false,"3":false}},{"name":"WORK_ORDER_STATUS","type":"checkbox","dtype":"xx","op":"in","fields":["Open","Completed","Cancelled","Aborted"],"val":{"Open":true,"Completed":false,"Cancelled":false,"Aborted":false}},{"name":"WORK_ORDER_TYPE","type":"checkbox","dtype":"xx","op":"in","fields":["Reactive","Planned"],"val":{"Reactive":true,"Planned":true}},{"name":"WORK_ORDER_DMA","dsname":"workOrderDistinctDma","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"]},{"name":"WORK_ORDER_DESCRIPTION","dsname":"workOrderDistinctDesc","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"]},{"name":"WORK_ORDER_POSTCODE","dsname":"workOrderDistinctPostcode","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"]}]},{"pagename":"geopage","submiturl":"/rest/getSpillIncident","datasource":"spillIncident","criterias":[{"name":"INCIDENT_PUBLIC_OR_PRIVATE","type":"checkbox","dtype":"xx","op":"in","fields":["PUBLIC","PRIVATE","SSOH"],"val":{"PUBLIC":true,"PRIVATE":false,"SSOH":false}},{"name":"SPILL_SOURCE","type":"checkbox","dtype":"xx","op":"in","fields":["MAIN","LATERAL"],"val":{"MAIN":false,"LATERAL":false}},{"name":"INCIDENT_CAUSE","dsname":"spillIncidentDistinctCause","type":"autocompletefield","dtype":"xx","op":"in","fields":["DEBRIS","COLLAPSE","EQUIPMENT FAILURE","GREASE","RAIN","ROOTS","VANDALISM","OTHER","UNKNOWN"]},{"name":"INCIDENT_CAUSE","type":"checkbox","dtype":"xx","op":"like","fields":["DEBRIS","COLLAPSE","EQUIPMENT FAILURE","GREASE","RAIN","ROOTS","VANDALISM","OTHER","UNKNOWN"],"val":{"DEBRIS":true,"COLLAPSE":false,"EQUIPMENT FAILURE":false,"GREASE":false,"RAIN":false,"ROOTS":false,"VANDALISM":false,"OTHER":false,"UNKNOWN":false}},{"name":"COMMENTS","type":"textfield","dtype":"xx","op":"like","fields":["",""],"val":""},{"name":"SPILL_TO","type":"checkbox","dtype":"xx","op":"in","fields":["LAND","CREEK"],"val":{"LAND":false,"CREEK":false}}]}]';
    spyOn(arisFilterService, 'getDatasourceData').and.callFake(()  => Promise.resolve(data));
    component.getDataFromCache('val');
    expect(arisFilterService.getDatasourceData).toHaveBeenCalled();
  });

  it('sample test to Check getDataFromCache Method IF PART getting called or not', () => {
    let arisCacheLocalService = TestBed.get(ArisCacheLocalService);
    let data = '[{"pagename":"geopage","submiturl":"/rest/getWorkOrders","datasource":"workOrders","criterias":[{"name":"WORK_ORDER_ID","dsname":"workOrderDistinctId","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"],"val":["WKO-002"]},{"name":"WORK_ORDER_WSZ","dsname":"workOrderDistinctWsz","type":"autocompletefield","dtype":"xx","op":"in","fields":["1","2","3","4","5","6","7"]},{"name":"WORK_ORDER_PRIORITY","type":"checkbox","dtype":"xx","op":"in","fields":["1","2","3"],"val":{"1":false,"2":false,"3":false}},{"name":"WORK_ORDER_STATUS","type":"checkbox","dtype":"xx","op":"in","fields":["Open","Completed","Cancelled","Aborted"],"val":{"Open":true,"Completed":false,"Cancelled":false,"Aborted":false}},{"name":"WORK_ORDER_TYPE","type":"checkbox","dtype":"xx","op":"in","fields":["Reactive","Planned"],"val":{"Reactive":true,"Planned":true}},{"name":"WORK_ORDER_DMA","dsname":"workOrderDistinctDma","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"]},{"name":"WORK_ORDER_DESCRIPTION","dsname":"workOrderDistinctDesc","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"]},{"name":"WORK_ORDER_POSTCODE","dsname":"workOrderDistinctPostcode","type":"autocompletefield","dtype":"xx","op":"in","fields":["W1","W2","W3"]}]},{"pagename":"geopage","submiturl":"/rest/getSpillIncident","datasource":"spillIncident","criterias":[{"name":"INCIDENT_PUBLIC_OR_PRIVATE","type":"checkbox","dtype":"xx","op":"in","fields":["PUBLIC","PRIVATE","SSOH"],"val":{"PUBLIC":true,"PRIVATE":false,"SSOH":false}},{"name":"SPILL_SOURCE","type":"checkbox","dtype":"xx","op":"in","fields":["MAIN","LATERAL"],"val":{"MAIN":false,"LATERAL":false}},{"name":"INCIDENT_CAUSE","dsname":"spillIncidentDistinctCause","type":"autocompletefield","dtype":"xx","op":"in","fields":["DEBRIS","COLLAPSE","EQUIPMENT FAILURE","GREASE","RAIN","ROOTS","VANDALISM","OTHER","UNKNOWN"]},{"name":"INCIDENT_CAUSE","type":"checkbox","dtype":"xx","op":"like","fields":["DEBRIS","COLLAPSE","EQUIPMENT FAILURE","GREASE","RAIN","ROOTS","VANDALISM","OTHER","UNKNOWN"],"val":{"DEBRIS":true,"COLLAPSE":false,"EQUIPMENT FAILURE":false,"GREASE":false,"RAIN":false,"ROOTS":false,"VANDALISM":false,"OTHER":false,"UNKNOWN":false}},{"name":"COMMENTS","type":"textfield","dtype":"xx","op":"like","fields":["",""],"val":""},{"name":"SPILL_TO","type":"checkbox","dtype":"xx","op":"in","fields":["LAND","CREEK"],"val":{"LAND":false,"CREEK":false}}]}]';
    spyOn(arisCacheLocalService, 'keyInCache').and.returnValue(data);
    component.getDataFromCache('val');
    expect(arisCacheLocalService.keyInCache).toHaveBeenCalled();
  });

  it('sample test to Check ngOnInit ELSE SCenario', () => {
    component.pageName = undefined;
    component.showRefreshData = undefined;
    component.openFooterFilter = undefined;
    component.ngOnInit();
    expect(component.saveButtonDisable).toBeFalsy();
  });
});
