import { OnInit, Component, OnChanges,  Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Subject } from 'rxjs/Subject';
import { Language } from 'angular-l10n';
import { ISubscription } from 'rxjs/Subscription';

import { ArisFilterService } from '../../../services/aris-filter.service';
import { ArisCacheLocalService } from '../../../services/aris-cache-local.service';
import { ArisNotificationBoxService } from '../../error-module/services/aris-notification-box.service';
import { ArisPageRefreshService } from '../../../services/aris-page-refresh.service';
import { ArisConfigService } from '../../../services/aris-config.service';
declare var $: any;
@Component({
  selector: 'aris-filter',
  templateUrl: './aris-filter.component.html',
  styleUrls: ['../css/aris-filter.component.css']
})
export class ArisFiltersComponent implements OnInit, OnDestroy  {
  public displayFilter: any;
  public saveButtonDisable: any;
  public filterData: any;
  public dateRangeAfterFetch: any;
  public dateRange: any;
  public dataSources: any;
  public assets: any = {};
  public dateFrom: any;
  public dateTo: any;
  private subscription: ISubscription;
  @Language() lang: string;
  constructor(
    private arisPageRefreshService: ArisPageRefreshService,
    private arisFilterPanelService: ArisFilterService,
    private arisCacheLocalService: ArisCacheLocalService,
    private notificationService: ArisNotificationBoxService,
    private arisConfigService: ArisConfigService,
    private datePipe: DatePipe) {
  }
  @Input() pageName: string;
  @Input() pageType: string;
  @Input() showRefreshData: Subject<any> = new Subject();
  @Input() openFooterFilter: Subject<any> = new Subject();
  @Input() filterPanelCategoryTab: any;
  @Output() onPageRefresh: EventEmitter<any> = new EventEmitter<any>();
  @Output() onFilterChange: EventEmitter<any> = new EventEmitter<any>();
  @Output() onFilterLoaded: EventEmitter<any> = new EventEmitter<any>();

  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  ngOnInit() {
    this.saveButtonDisable = false; // By default disable save button
    if (this.pageName) {
      //this.fetchFilters();
    }
    this.dateRange = [];  // [from, to] filter date.
    // this function for open filter panel while click on filters text on Ui
    this.arisFilterPanelService.getOpenFilterPanelSubject().subscribe((data) => {
      this.openFilter();
    });

    if (this.showRefreshData) {
      this.subscription = this.showRefreshData.subscribe((data) => {
        this.setSubscription(data);
      });
    }

    if (this.openFooterFilter) {
      this.subscription = this.openFooterFilter.subscribe((data) => {
        this.filterPanelCategoryTab = data;
        this.openFilter();
      });
    }

    // Subscribe to refresh page
    this.arisPageRefreshService.subscribePageRefresh(
      function () {
        this.refreshPage();
      }.bind(this)
    );
  }

  setSubscription(data) {
    let filterDataToCompare = this.filterData ? Object.assign(this.filterData) : this.filterData;
    // For Show Pop up Layer Wise
    if (this.dateRangeAfterFetch && Object.keys(this.dateRangeAfterFetch)) {
      const successMessage = { status: '200', title: 'CLI_MSG_TIT_OPERATION_SUCCESS', message: 'CLI_MSG_TIT_OPERATION_USER_FILTER'  };
      this.notificationService.showNotification(successMessage, 'right', 'success');
    } else {
      this.callSuccessPopup(filterDataToCompare, data);
    }
    this.onFilterChange.emit({ filterData: this.filterData ,
      dateRange: this.dateRange[0] === undefined && this.dateRange[1] === undefined ? [] :
        this.dateRange}
    );
  }

  refreshPage() {
    // scope.$broadcast('filtering', {});
    if (this.pageType === 'geo' || this.pageType === 'schematic') {
      this.onPageRefresh.emit({
        refreshPage: true, filterData: this.filterData,
        dateRange: this.dateRange[0] === undefined && this.dateRange[1] === undefined ? null : this.dateRange
      });
    } else {
      this.onFilterChange.emit({
        refreshPage: true, filterData: this.filterData,
        dateRange: this.dateRange[0] === undefined && this.dateRange[1] === undefined ? [] : this.dateRange
      });
    }
  }

  // intialized data and clear all fields
  initFilterData() {
    this.dateRange = [];
    if (this.filterData) {
      this.filterData.forEach((tabs) => {
        tabs.criterias.forEach((subtabs) => {
          if (subtabs.type === 'checkbox') {
            subtabs.val = {};
            subtabs.fields.forEach((field) => {
              subtabs.val[field] = false;
            });
          }
          if (subtabs.type === 'autocompletefield') {
            subtabs.val = undefined;
          }
          if (subtabs.type === 'textfield') {
            subtabs.val = '';
          }
        });
      });
    }
  }

  getDataFromCache(datasource) {
    if (this.arisCacheLocalService.keyInCache(datasource)) {
      this.assets[datasource] = this.arisCacheLocalService.getItem(datasource);
    } else {
      this.arisFilterPanelService.getDatasourceData(datasource).then((response) => {
        this.assets[datasource] = response;
        this.arisCacheLocalService.setItem(datasource, this.assets[datasource]);
      }, (error) => {
        console.log(error);
        this.assets = {};
      });
    }
  }

  openFilter() {
    this.displayFilter = true;
    this.dataSources =  this.arisFilterPanelService.getDatasourcesFromConfig();
    if (this.dataSources) {
      this.dataSources.forEach((datasource) => {
        this.getDataFromCache(datasource);
      });
    }
  }

  // close filter
  changeFooterDisplay () {
    this.displayFilter = !this.displayFilter;
  }

  changeTab(tab) {
    this.filterPanelCategoryTab = tab;
  }

  // disable and enable save button
  disableSaveButton (disable) {
    this.saveButtonDisable = disable;
  }

  // function is used to manage Ngclass
  checkClass(tabs) {
    return this.filterPanelCategoryTab === tabs.datasource;
  }

  // function is used to manage [hidden] property
  showTabsinFilter() {
    return this.pageType === 'nongeo';
  }

  displayFilterTitle(subfilter) {
    let result: boolean;
    if ((this.pageType === 'geo' || this.pageType === 'schematic') &&
        subfilter.datasource !== undefined &&
        this.filterPanelCategoryTab === subfilter.datasource) {
      result = true;
    } else {
      result = false;
    }
    return result;
  }

  // update datasource for Autocomplete
  onAutocompleteChange(changedValue, subtabs, x, keys, subkey) {
    if (changedValue && changedValue.length > 0) {
      subtabs.val = changedValue;
      this.filterData[keys].criterias[subkey].val =  changedValue;
      this.disableSaveButton(true);
    } else {
      this.filterData[keys].criterias[subkey].val =  undefined;
      this.disableSaveButton(true);
    }
  }
  // on chage Date Picker
  onDateChange(changedValue, datapickerType) {
    if (changedValue && datapickerType === 'from') {
      this.dateRange[0] = this.datePipe.transform(changedValue, this.arisConfigService.getDabaseDateFormat());
      this.disableSaveButton(true);
    } else if (changedValue && datapickerType === 'to') {
      this.dateRange[1] = this.datePipe.transform(changedValue, this.arisConfigService.getDabaseDateFormat());
      this.disableSaveButton(true);
    }
  }
  // change checkbox Value while clicking on and off and update datasource for checkbox
  checkBoxChange(event, value, obj) {
    if (event.target.checked) {
      obj[value] = true;
      this.disableSaveButton(true);
    } else {
      obj[value] = false;
      this.disableSaveButton(true);
    }
  }

  inputValidator(data) {
    let dataList = [];
    let valuesOfObj;
    data.forEach((item, index) => {
      item.criterias.forEach((i) => {
        if (Array.isArray(i.val)) {
          if (i.val !== undefined && i.val.length !== 0) {
            dataList.push(i.val);
            return dataList;
          }
        } else {
          if (i.val !== undefined) {
            valuesOfObj = Object.keys(i.val).map((e) => {
              return i.val[e];
            });
          }

          if (i.val !== undefined && valuesOfObj.indexOf(true) > -1) {
            dataList.push(i.val);
            return dataList;
          }
        }
      });
    });
    return dataList;
  }

  // Handle click over Apply button in filter bar
  onFilterApply() {
    if ((this.inputValidator(this.filterData).length !== 0) ||
        ((this.dateRange[0] !== undefined && this.dateRange[1] !== undefined &&
          this.dateRange[0] !== null && this.dateRange[1] !== null))) {
      this.onFilterChange.emit({
        filterData: this.filterData,
        dateRange: this.dateRange
      });
    } else {
      this.onFilterChange.emit({
        filterData: this.filterData,
        dateRange: []
      });
    }
  }

  // Clean filter fileds information
  cleanFilterFields() {
    this.initFilterData();
    if (this.pageType === 'geo') {
      this.onPageRefresh.emit({ filterData: this.filterData, dateRange: null });
    } else {
      this.onFilterChange.emit({ filterData: this.filterData, dateRange: null });
    }
    this.arisFilterPanelService.getClearAutoCompleteSubject().next(true);
    $('#datepicker_from').val('');
    $('#datepicker_to').val('');
  }


  // Handle click over Reset button in filter bar
  onFilterReset() {
    this.cleanFilterFields();
    this.arisFilterPanelService.deleteFilterData(this.pageName).then(
      (response) => {
        if (response !== 0) {
          this.disableSaveButton(false);
        }
      }, (error) => {
      console.log(error);
      // const successMessage = { status: '200', title: 'CLI_MSG_TIT_OPERATION_NO_SUCCESS', message: ''  };
      // this.notificationService.showNotification(successMessage, 'right', 'success');
    });
  }

// function is return for save filter page wise
  saveFilter() {
    this.onFilterApply();
    let filterCriteriaToSave: any;
    if ((this.dateRange[0] === undefined && this.dateRange[1] === undefined) ||
        (this.dateRange[0] === null && this.dateRange[1] === null)) {
      filterCriteriaToSave = JSON.stringify({
        filter: this.filterData
      });
    } else {
      filterCriteriaToSave = JSON.stringify({
        filter: this.filterData,
        dateRange: this.dateRange
      });
    }

    const data = JSON.stringify({
      filterCriteria: filterCriteriaToSave,
      pageName: this.pageName
    });
    this.arisFilterPanelService.saveFilterData(this.pageName, data).then((response) => {
      const successMessage = { title: 'CLI_MSG_TIT_OPERATION_SUCCESS', message: 'CLI_MSG_DESC_OPERATION_SUCCESS', status: '200' };
      this.notificationService.showNotification(successMessage, 'right', 'success');
      // disable Save button after success
      this.disableSaveButton(false);
    }, (err) => {
      const successMessage = { title: 'CLI_MSG_TIT_OPERATION_NO_SUCCESS', message: '', status: '-1' };
      this.notificationService.showNotification(successMessage, 'right', 'success');
    });
  }

  // For Show Success Pop up Layer Wise when user click on map Layer
  callSuccessPopup(FilterData, layerName) {
    if (FilterData) {
      FilterData.forEach((data, key) => {
        if (data.datasource === layerName) {
          let keepGoing = true;
          data.criterias.forEach((checkdata, checkKey) => {
            if (checkdata.type === 'autocompletefield' && keepGoing) {
              if (checkdata.val) {
                const messagePopped = { title: 'CLI_MSG_TIT_OPERATION_SUCCESS', message: 'CLI_MSG_TIT_OPERATION_USER_FILTER', status: '200' };
                this.notificationService.showNotification(messagePopped, 'right', 'success');
                keepGoing = false;
              }
            } else if (checkdata.type === 'checkbox' && keepGoing) {
              Object.keys(checkdata.val).forEach((Newkey) => {
                if (checkdata.val[Newkey] === true) {
                  const messagePopped = { title: 'CLI_MSG_TIT_OPERATION_SUCCESS', message: 'CLI_MSG_TIT_OPERATION_USER_FILTER', status: '200' };
                  this.notificationService.showNotification(messagePopped, 'right', 'success');
                  keepGoing = false;
                }
              });
            }
          });
        }
      });
    }
  }

  // Handle to get data on page load from server
  fetchFilters() {
    this.arisFilterPanelService.getFilterByPageName(this.pageName).then(
        (response) => {
        // Try to recover the Filter Panel Information from table 'aris_pagefilter_user'
        // and update PageFilterService with the information recovered
        // If we do not recover nothing, the Filter Panel will be load with the 'standard' information
        // defined in the pageConfiguration or in the table 'aris_pagefilter'
          if (response != null && response !== "") {
            this.filterData = JSON.parse(JSON.parse(response).filterCriteria).filter;
            this.dateRangeAfterFetch = JSON.parse(JSON.parse(response).filterCriteria).dateRange;
            const allelementsNull = this.dateRangeAfterFetch ? this.dateRangeAfterFetch.join(',').replace(/,/g, '').length : this.dateRangeAfterFetch;
            if (this.dateRangeAfterFetch != null && allelementsNull !== 0) {
              this.dateFrom = new Date(this.dateRangeAfterFetch[0]);
              this.dateTo = new Date(this.dateRangeAfterFetch[1]);
            }
            this.arisFilterPanelService.setFilterConfig(this.filterData);
           // Display message "Page Loaded Using 'User Filter Preference'"
            if (this.pageName !== 'geopage') {
              const messagePopped = { title: 'CLI_MSG_TIT_OPERATION_SUCCESS', message: 'CLI_MSG_TIT_OPERATION_USER_FILTER', status: '200' };
              this.notificationService.showNotification(messagePopped, 'right', 'info');
            }
            this.displayFilters();
          } else {
            this.dateRangeAfterFetch = null;
            this.displayFilters();
            this.cleanFilterFields();
          }
          // Apply the filter with the information customized by the user
          this.onFilterLoaded.emit({ filterData: this.filterData, dateRange: this.dateRangeAfterFetch });
        }, (error) => {
      console.log(error);
    });
    // Disable Save Button
    this.disableSaveButton(false);
  }


  /**
   * this function handle to show filter and
   * Recover the Filter Panel Information from table 'pagefilter'
   */
  displayFilters() {
    const config = this.arisFilterPanelService.getFilterConfig();
    if (this.pageType === 'nongeo') {
      if (config && config.length > 0) {
        this.filterData = config;
        this.filterPanelCategoryTab = config[0].datasource;
      }
    } else if (this.filterData === undefined) {
      this.arisFilterPanelService.getFilter(this.pageName).then((response) => {
        const result = JSON.parse(response);
        this.arisFilterPanelService.setFilterConfig(result);
        if (result && result.length) {
          this.filterData = result;
          this.initFilterData();
        }
      }, (error) => {
        console.log(error);
      });
    }
  }

  changeInput(event) {
    if (event) {
      this.disableSaveButton(true);
    }
  }

}
