import { NgModule } from '@angular/core';
import { ArisFooterComponent } from './components/aris-footer.component';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { LocalizationModule } from 'angular-l10n';
import { ArisSessionService } from '../../services/aris-session.service';
import { ArisPageRefreshComponent } from '../aris-page-refresh/aris-page-refresh.component';
import { ArisFooterService } from './services/aris-footer-service';
import { ArisPageRefreshService } from '../../services/aris-page-refresh.service';
import { ArisUiComponentsModule } from '../../../common/ui-components/aris-ui-components.module';
import { ArisPopUpModule } from '../../ui-page-sections/pop-up-module/aris-popup.module';

@NgModule({
  declarations: [
    ArisFooterComponent,
    ArisPageRefreshComponent
  ],
  imports: [
    FormsModule,
    CommonModule,
    LocalizationModule,
    ArisUiComponentsModule,
    ArisPopUpModule
  ],
  providers: [ArisSessionService, ArisFooterService, ArisPageRefreshService],
  exports: [ArisFooterComponent],
})

export class ArisFooterModule { }
