import { ArisFilterService } from '../../../services/aris-filter.service';
import { ArisFooterService } from '../../footer-module/services/aris-footer-service';
import { TranslationService } from 'angular-l10n';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { ArisFooterComponent } from './aris-footer.component';
import { ArisPermissionService } from '../../../services/aris-permission.service';
import { ArisPageRefreshService } from '../../../services/aris-page-refresh.service';
import { Router } from '@angular/router';
// import { Location } from '@angular/common';
import { ArisPageSectionObservableEventService } from '../../services/aris-page-section-observable-event.service';
import { ArisSessionService } from '../../../services/aris-session.service';
import { Subject } from 'rxjs';

describe('Test Footer Component', () => {

  let handler: HttpHandler;
  let http = new HttpClient(handler);
  let arisFilterService = new ArisFilterService(http);
  let arisPersmissionService = new ArisPermissionService();
  let translation: TranslationService;
  let router: Router;
  router = new function () {
    this.navigate = function (commands: any[], extras?: any) { };
  };
  // // let location: Location;
  let arispageRefreshService: ArisPageRefreshService;
  let sharedCommunicationService = new ArisPageSectionObservableEventService();
  let sessionService = new ArisSessionService();
  let footerService = new ArisFooterService(http, sharedCommunicationService);
  let footerComp = new ArisFooterComponent(http, translation, footerService, sessionService, arisPersmissionService,
        arispageRefreshService, router, sharedCommunicationService, arisFilterService);

  it('test to isLoggedIn Method', () => {
    spyOn(sessionService, 'isLoggedIn').and.callThrough();
    footerComp.isLoggedIn();
    expect(sessionService.isLoggedIn).toHaveBeenCalled();
  });

  it('test to ngOnInit Method in Footer Comp', () => {
    spyOn(sharedCommunicationService, 'setEditLayout').and.callThrough();
    footerComp.ngOnInit();

    expect(sharedCommunicationService.setEditLayout).toHaveBeenCalled();
  });

  it('test to ngOnDestroy Method in Footer Comp', () => {
    footerComp.ngOnInit();
    spyOn(footerComp.editLayoutSubscription, 'unsubscribe').and.callThrough();
    footerComp.ngOnDestroy();
    expect(footerComp.editLayoutSubscription.unsubscribe).toHaveBeenCalled();
  });

  it('test to ngOnDestroy Method in Footer Comp with undefined values', () => {
    footerComp.editLayoutSubscription = undefined;
    footerComp.pageLayoutSubscription = undefined;
    footerComp.footerSubscription = undefined;
    footerComp.ngOnDestroy();
  });

  // it('test to openFooterFilter Method in Footer Comp', () => {
  //   spyOn(arisFilterService, 'getOpenFilterPanelSubject').and.callThrough();
  //   footerComp.openFooterFilter();

  //   expect(arisFilterService.getOpenFilterPanelSubject).toHaveBeenCalled();
  // });

  it('test to editLayout Method in Footer Comp', () => {
    spyOn(sharedCommunicationService, 'setEditLayout').and.callThrough();
    footerComp.editLayout();

    expect(sharedCommunicationService.setEditLayout).toHaveBeenCalled();
  });

  it('test to cancelEditLayout Method in Footer Comp', () => {
    spyOn(sharedCommunicationService, 'setSaveLayout').and.callThrough();
    // spyOn(footerComp, 'reloadPage').and.callThrough();
    spyOn(footerComp, 'reloadPage').and.callFake(function() {});
    footerComp.cancelEditLayout();

    expect(sharedCommunicationService.setSaveLayout).toHaveBeenCalled();
  });

  it('test to requestConfirmation Method in Footer Comp', () => {
    footerComp.saveLayoutFlag = false;
    footerComp.requestConfirmation();

    expect(footerComp.saveLayoutFlag).toBeTruthy();
  });

  it('test to requestLayout Method in Footer Comp', () => {
    spyOn(sharedCommunicationService, 'setSaveLayout').and.callThrough();
    footerComp.saveLayoutFlag = true;
    footerComp.requestLayout();

    expect(footerComp.saveLayoutFlag).toBeFalsy();
    expect(sharedCommunicationService.setSaveLayout).toHaveBeenCalled();
  });

  it('test to cancelSave Method in Footer Comp', () => {
    footerComp.saveLayoutFlag = true;
    footerComp.cancelSave();

    expect(footerComp.saveLayoutFlag).toBeFalsy();
  });

  it('test to saveLayout Method error scenario in Footer Comp', () => {
    spyOn(sharedCommunicationService, 'setSaveLayout').and.callThrough();
    spyOn(footerService, 'saveLayout').and.callThrough();
    spyOn(footerComp, 'reloadPage').and.callFake(function() {});

    let pageLayout: any = { key: "value" };
    footerComp.saveLayout(pageLayout);

    expect(sharedCommunicationService.setSaveLayout).toHaveBeenCalled();
  });

  it('test to saveLayout Method in Footer Comp', () => {
    spyOn(sharedCommunicationService, 'setSaveLayout').and.callThrough();
    spyOn(footerService, 'saveLayout').and.callFake(() => Promise.resolve());
    spyOn(footerComp, 'reloadPage').and.callFake(function() {});

    let pageLayout: any = { key: "value" };
    footerComp.saveLayout(pageLayout);

    expect(sharedCommunicationService.setSaveLayout).toHaveBeenCalled();
  });

  it('test to restoreLayout Method error scenario in Footer Comp', () => {
    spyOn(sharedCommunicationService, 'getPageName').and.returnValue('name');
    spyOn(footerService, 'restoreLayout').and.callThrough();
    spyOn(footerComp, 'reloadPage').and.callFake(function() {});

    let pageLayout: any = { key: "value" };
    footerComp.restoreLayout();

    expect(footerService.restoreLayout).toHaveBeenCalled();
  });

  it('test to restoreLayout Method in Footer Comp', () => {
    spyOn(sharedCommunicationService, 'getPageName').and.returnValue('name');
    spyOn(footerService, 'restoreLayout').and.callFake(() => Promise.resolve());
    spyOn(footerComp, 'reloadPage').and.callFake(function() {});

    let pageLayout: any = { key: "value" };
    footerComp.restoreLayout();

    expect(footerService.restoreLayout).toHaveBeenCalled();
  });

  it('test to openFooterFilter Method in Footer Comp', () => {
    spyOn(arisFilterService, 'getOpenFilterPanelSubject').and.returnValue(new Subject());
    let pageLayout: any = { key: "value" };
    footerComp.openFooterFilter();

    expect(arisFilterService.getOpenFilterPanelSubject).toHaveBeenCalled();
  });

});
