import { Component, OnInit, ViewChild, ElementRef, TemplateRef, Input, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
// import { Location } from '@angular/common';

import { filter } from 'rxjs/operator/filter';
import { TranslationService, Language } from 'angular-l10n';

import { ArisFooterService } from '../services/aris-footer-service';
import { ArisPermissionService } from '../../../services/aris-permission.service';
import { ArisPageRefreshService } from '../../../services/aris-page-refresh.service';
import { ArisPermissionPipe } from '../../../pipes/aris-permission.pipes';
import { ArisPageSectionObservableEventService } from '../../services/aris-page-section-observable-event.service';
import { ArisFilterService } from '../../../services/aris-filter.service';
import { ArisSessionService } from '../../../services/aris-session.service';


@Component({
  selector: 'aris-footer',
  templateUrl: './aris-footer.component.html',
})
export class ArisFooterComponent implements OnInit, OnDestroy {
  footer: any = {};

  @Language() lang: string;
  @Input() footerContent: TemplateRef<any>;

  editLayoutSubscription: any;
  pageLayoutSubscription: any;
  footerSubscription: any;

  editLayoutFlag = false;
  saveLayoutFlag = false;
  constructor(private http: HttpClient,
              private translation: TranslationService,
              private arisFooterService: ArisFooterService,
              private arisSessionService: ArisSessionService,
              private arisPermissionService: ArisPermissionService,
              private commonService: ArisPageRefreshService,
              private router: Router,
              private sharedCommunicationService: ArisPageSectionObservableEventService,
              private arisFilterService: ArisFilterService) {
    this.footer = window.app.config.footerTypes;
  }

  ngOnInit() {
    this.editLayoutSubscription = this.sharedCommunicationService.editLayout.subscribe(editLayoutFlag => this.editLayoutFlag = editLayoutFlag);
    this.pageLayoutSubscription = this.sharedCommunicationService.pageLayout.subscribe(pageLayout => this.saveLayout(pageLayout));
    this.footerSubscription = this.sharedCommunicationService.footer.subscribe(footer => this.footer = footer);
    this.sharedCommunicationService.setEditLayout(this.editLayoutFlag);
  }

  ngOnDestroy() {
    if (this.editLayoutSubscription) {
      this.editLayoutSubscription.unsubscribe();
    }
    if (this.pageLayoutSubscription) {
      this.pageLayoutSubscription.unsubscribe();
    }
    if (this.footerSubscription) {
      this.footerSubscription.unsubscribe();
    }
  }

  // open Filter Panel while click on filter text in footer
  openFooterFilter() {
    this.arisFilterService.getOpenFilterPanelSubject().next('openFilterPanel');
  }

  editLayout() {
    this.sharedCommunicationService.setEditLayout(! this.editLayoutFlag);
  }

  cancelEditLayout() {
    this.sharedCommunicationService.setSaveLayout(false);
    this.reloadPage();
  }

  requestConfirmation() {
    this.saveLayoutFlag = true;
  }

  requestLayout() {
    this.saveLayoutFlag = false;
    this.sharedCommunicationService.setSaveLayout(true);
  }

  cancelSave() {
    this.saveLayoutFlag = false;
  }

  saveLayout(pageLayout: any) {
    if (pageLayout) {
      const data = JSON.stringify(pageLayout);
      this.arisFooterService.saveLayout(data)
      .then(() => {
        this.sharedCommunicationService.setEditLayout(false);
      }).catch(() => {
        console.log('Save Page Layout: Problems saving the new page layout');
        this.sharedCommunicationService.setEditLayout(false);
      });

      this.sharedCommunicationService.setSaveLayout(false);
      this.reloadPage();
    }
  }

  restoreLayout() {
    this.arisFooterService.restoreLayout(this.sharedCommunicationService.getPageName())
    .then(() => {
      this.sharedCommunicationService.setEditLayout(false);
      this.reloadPage();
    }).catch(() => {
      console.log('Page Layout: Problems restoring page layout');
      this.sharedCommunicationService.setEditLayout(false);
      this.reloadPage();
    });

    this.sharedCommunicationService.setSaveLayout(false);
  }

  reloadPage() {
    window.location.reload();
  }

  isLoggedIn() {
    return this.arisSessionService.isLoggedIn();
  }

}
