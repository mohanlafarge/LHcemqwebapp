// import { HttpHandler, HttpClient } from '@angular/common/http';

// import { all } from 'q';

// import { ArisModule } from '../../../../aris.module';
// import { ArisFooterService } from './aris-footer-service';
// import { ArisPageSectionObservableEventService } from '../../services/aris-page-section-observable-event.service';

// describe('Test: Aris Footer Service', () => {
//   const footerType = 'all';
//   const footerConfig = {
//     UIElements : { All: true },
//     visibility: true,
//   };

//   let httpHandler: HttpHandler;
//   const httpClient = new HttpClient(httpHandler);
//   const sharedCommunicationService = new ArisPageSectionObservableEventService();
//   const footerService = new ArisFooterService(httpClient, sharedCommunicationService);
//   const mockFooterConfig = { refreshPage: true, editLayout: true, filter: true };

//   beforeEach(() => {
//     const arisModule = new ArisModule();
//   });

//   it('Aris Footer Service test: footerInfo can be configured with some footer Object', () => {
//     footerService.setFooterInfo(footerConfig);
//     expect(footerService.getFooterInfo()).toBeDefined(mockFooterConfig);
//   });
//   it('Aris Footer Service test: footerInfo can be configured with some footer Type', () => {
//     footerService.setFooterInfo(footerType);
//     expect(footerService.getFooterInfo()).toBeDefined(mockFooterConfig);
//   });
//   it('Aris Footer Service test: footerInfo can be configured with undefined', () => {
//     footerService.setFooterInfo(undefined);
//     expect(footerService.getFooterInfo()).toBeDefined(window.app.config.application.footerConfig);
//   });
//   it('Aris Footer Service test: get default footerConfig', () => {
//     expect(footerService.getFooter()).toBeDefined(window.app.config.application.footerConfig);
//   });
//   it('FooterService test: checking if saveLayout is called or not', () => {
//     spyOn(httpClient, 'post').and.callThrough();
//     spyOn(footerService, 'saveLayout').and.callThrough();
//     footerService.saveLayout(footerConfig);
//     expect(httpClient.post).toHaveBeenCalled();
//   });
//   it('FooterService test: checking if restoreLayout is called or not', () => {
//     spyOn(httpClient, 'get').and.callThrough();
//     spyOn(footerService, 'restoreLayout').and.callThrough();
//     footerService.restoreLayout('chartGallery');
//     expect(httpClient.get).toHaveBeenCalled();
//   });
// });
