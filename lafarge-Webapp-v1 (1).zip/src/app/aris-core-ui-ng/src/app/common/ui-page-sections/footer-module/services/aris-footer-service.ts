import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ArisPageSectionObservableEventService } from '../../services/aris-page-section-observable-event.service';


@Injectable()
export class ArisFooterService {
  footer = {config: Object.assign({}, window.app.config.application.footerConfig)};

  constructor(private http: HttpClient,
              private sharedCommunicationService: ArisPageSectionObservableEventService) {
  }

  setFooterInfo(footerType: any) {
    let footerInfo: any;
    let enable: any;
    let defaultFooterConfig = Object.assign({}, window.app.config.application.footerConfig);

    if (defaultFooterConfig.UIElements !== undefined && defaultFooterConfig.UIElements.All !== undefined) {
      enable = defaultFooterConfig.UIElements.All;
      defaultFooterConfig.UIElements = { refreshPage: enable, editLayout: enable, filter: enable };
    }
    if (!footerType || footerType === {}) {
      footerInfo = defaultFooterConfig;
    } else {
      footerInfo = {};
      if (typeof footerType === 'string') {
        Object.assign(footerInfo, defaultFooterConfig, window.app.config.footerTypes.footerConfig[footerType]);
      } else {
        Object.assign(footerInfo, defaultFooterConfig, footerType);
      }
    }

    if (footerInfo.UIElements !== undefined && footerInfo.UIElements.All !== undefined) {
      enable = footerInfo.UIElements.All;
      footerInfo.UIElements = { refreshPage: enable, editLayout: enable, filter: enable };
    }

    this.footer.config = footerInfo;

    // Adjust Footer with the new configuration Received
    this.sharedCommunicationService.setFooter(this.footer);
  }

  getFooterInfo() {
    return this.footer.config;
  }

  getFooter() {
    return this.footer;
  }

  saveLayout(data: any): Promise<any> {
    const config = {
      headers: {
        'Content-Type': 'application/json; charset=utf-8'
      },
    };

    return this.http.post('rest/pagelayout/self/save', data, config).toPromise();
  }

  restoreLayout(pageName: string): Promise<any> {
    return this.http.get('rest/pagelayout/self/restorelayout/' + pageName, { responseType: 'text' }).toPromise();
  }
}
