import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LocalizationModule } from 'angular-l10n';
import { ArisPipesModule } from '../../pipes/aris-pipes.module';
import { ArisSessionService } from '../../services/aris-session.service';
import { ArisThemeService } from '../../services/aris-theme.service';
import { ArisNotificationModule } from '../aris-notification-module/aris-notification.module';
import { ArisThemeSelectorModule } from '../aris-theme-selector-module/aris-theme-selector.module';
import { ArisLanguageSelectorModule } from '../language-selector-module/aris-language-selector.module';
import { ArisLastLoginInfoComponent } from '../last-login-info/aris-last-login-info.component';
import { ArisMenuModule } from '../menu-module/aris-menu.module';
import { ArisMenuContainerComponent } from './../menu-container-module/components/menu-container.component';
import { ArisHeaderComponent } from './components/aris-header.component';
import { ArisLogoutComponent } from '../aris-logout-module/aris-logout.component';
 




@NgModule({
  declarations: [
    ArisHeaderComponent,
    ArisLastLoginInfoComponent,
    ArisMenuContainerComponent,
    ArisLogoutComponent
  ],
  imports: [FormsModule,
    CommonModule,
    LocalizationModule,
    ReactiveFormsModule,
    ArisPipesModule,
    ArisLanguageSelectorModule,
    ArisMenuModule,
    ArisThemeSelectorModule,
    ArisNotificationModule
  ],
  providers: [ArisSessionService, ArisThemeService],
  exports: [ArisHeaderComponent],
})

export class ArisHeaderModule { }
