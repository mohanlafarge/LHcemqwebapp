import { HttpClient, HttpHandler } from '@angular/common/http';
import { Router, RouterModule, ActivatedRoute, NavigationEnd } from '@angular/router';
import { ArisHeaderComponent } from './aris-header.component';
import { ArisSessionService } from '../../../services/aris-session.service';
import { ArisLoginService } from '../../../services/aris-login.service';
import { ArisConfigService } from '../../../services/aris-config.service';
import { ArisLanguageService } from '../../language-selector-module/services/aris-language.service';
import { ArisThemeService } from '../../../services/aris-theme.service';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LocalizationModule, InjectorRef, TranslationService, LocaleService } from 'angular-l10n';
import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ArisDynamicPageModule } from '../../../ui-page-models/aris-dynamic-page-module/aris-dynamic-page.module';
import { FilterModule } from '../../filter-panel-module/aris-filter.module';
import { ArisUiComponentsModule } from '../../../ui-components/aris-ui-components.module';
import { ArisTilesTemplatesModule } from '../../../ui-tiles-templates/aris-tiles-templates.module';
import { FormsModule } from '@angular/forms';
import { ArisHeaderService } from '../services/aris-header-service';
import { ArisPageService } from '../../../services/aris-page-service';
import { ArisFilterService } from '../../../services/aris-filter.service';
import { Observable, Subject } from 'rxjs';
import { ArisNotificationBoxService } from '../../error-module/services/aris-notification-box.service';
import { ToastrService } from 'ngx-toastr';
import { ArisDataSourceService } from '../../../services/aris-datasource.service';
import { ArisPageSectionObservableEventService } from '../../services/aris-page-section-observable-event.service';
import { ArisPermissionService } from '../../../services/aris-permission.service';
import { ArisLanguageSelectorModule } from '../../language-selector-module/aris-language-selector.module';
import { ArisMenuContainerComponent } from '../../menu-container-module/components/menu-container.component';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { ArisThemeSelectorModule } from '../../aris-theme-selector-module/aris-theme-selector.module';
import { ArisLastLoginInfoComponent } from '../../last-login-info/aris-last-login-info.component';
import { ArisLogoutComponent } from '../../aris-logout-module/aris-logout.component';
import { ArisMenuModule } from '../../menu-module/aris-menu.module';
import { ArisNotificationModule } from '../../aris-notification-module/aris-notification.module';
import { ArisWebSocketService } from '../../../services/aris-websocket.service';

export class MockHttpClient extends HttpClient {
}

let mockRouter = {
  navigate: jasmine.createSpy('navigate'),
  subject: Subject,
  events: jasmine.createSpy('events').and.callFake(() => this.subject.asObservable())
};

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};

export class ArisNotificationBoxServiceMock {
  showNotification(message: any, val?: any, value?: any) {}
}

class MockServices {
  // Router
  public events = Observable.of(new NavigationEnd(0, 'http://localhost:4200/login', 'http://localhost:4200/login'));
  navigateByUrl(url: string) { return url; }
  navigate(commands: any[], extras?: any) { return commands; }
}

describe('Test Header Component', () => {

  let handler: HttpHandler;
  let http = new HttpClient(handler);
  let router: Router;

  // Fake Method to avoid navigate during our test
  router = new function () {
    this.navigate = function (commands: any[], extras?: any) { };
  };
  let langService = new ArisLanguageService();
  let arisSessionService = new ArisSessionService();
  let arisConfigService = new ArisConfigService(http, langService);
  let arisThemeService = new ArisThemeService();
  // let arisLoginService = new ArisLoginService(http, arisSessionService, arisConfigService, router );
  // let headerComp = new ArisHeaderComponent(router, arisLoginService, arisSessionService, arisThemeService);

  let component: ArisHeaderComponent;
  let fixture: ComponentFixture<ArisHeaderComponent>;
  let arisLoginService: ArisLoginService;
  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [
        ArisHeaderComponent,
        ArisMenuContainerComponent,
        ArisLastLoginInfoComponent,
        ArisLogoutComponent
      ],
      imports: [
        RouterModule,
        LocalizationModule,
        CommonModule,
        HttpClientTestingModule,
        ArisDynamicPageModule,
        FilterModule,
        ArisUiComponentsModule,
        ArisTilesTemplatesModule,
        FormsModule,
        ArisLanguageSelectorModule,
        ArisPipesModule,
        ArisThemeSelectorModule,
        ArisMenuModule,
        ArisNotificationModule
      ],
      providers: [
        ArisSessionService,
        ArisHeaderService,
        ArisPageService,
        ArisFilterService,
        InjectorRef, ArisLoginService, ArisThemeService, ArisWebSocketService,
        { provide: Router, useClass: MockServices }, { provide: HttpClient, useClass: MockHttpClient }, { provide: ActivatedRoute, useValue: {
          params: Observable.of({ geoLayerName: "destPage" })
        } }, { provide: ArisNotificationBoxService, useClass: ArisNotificationBoxServiceMock },
        ArisDataSourceService, ArisPageSectionObservableEventService, ArisPermissionService, ArisConfigService,
        ArisLanguageService, { provide: ToastrService }, { provide: LocaleService }, { provide: TranslationService, useValue: mockTranslationService }
      ]
    }).compileComponents();

    afterAll(() => {
      component = null;
        });
    // create component and test fixture
    fixture = TestBed.createComponent(ArisHeaderComponent);
    arisLoginService = fixture.debugElement.injector.get(ArisLoginService);
    // get test component from the fixture
    component = fixture.componentInstance;
  });

  let mockObject = Object({ headerConfig: Object({ Standard: Object({
    template: 'app/common/ui-page-sections/header-module/components/aris-header.component.html',
    UIElements: Object({ All: true }), visibility: true }),
    displaynone: Object({ template: 'app/common/ui-page-sections/header-module/components/aris-header.component.html',
      UIElements: Object({ All: false }), visibility: false }) }) });

  it('test to Check openPage Method', () => {
    component.openPage('Login');
    expect(component).toBeDefined();
  });

  it('test to Check isLoggedIn Method', () => {
    const value = component.isLoggedIn();
    expect(value).toBeFalsy();
  });

  it('test to Check logout Method', () => {
    spyOn(arisLoginService, 'logout').and.callFake(() => Promise.resolve());
    component.logout();
    expect(arisLoginService.logout).toHaveBeenCalled();
  });

  it('test to Check logout Method error scenario', () => {
    spyOn(arisLoginService, 'logout').and.callFake(() => Promise.reject(403));
    component.logout();
    expect(arisLoginService.logout).toHaveBeenCalled();
  });

  it('test to Check logout else scenario', () => {
    spyOn(arisLoginService, 'logout').and.returnValue(null);
    component.logout();
    expect(component.header).toBeDefined();
  });

  it('test to Check ngOnInit scenario', () => {
    component.ngOnInit();
    expect(component.locationUrl).toBeDefined();
  });
  it('test to Check ngOnInit else scenario', () => {
    // component.themeConfig.defaultColor = 'yel';
    component.ngOnInit();
    expect(component.locationUrl).toBeDefined();
  });

  it('test to Check isActive if scenario', () => {
    component.ngOnInit();
    component.isActive("http://localhost:4200/login");
    expect(component.locationUrl).toBeDefined();
  });
  it('test to Check isActive if OR scenario', () => {
    component.ngOnInit();
    component.isActive("http://localhost:4200");
    expect(component.locationUrl).toBeDefined();
  });
  it('test to Check isActive inner if else scenario', () => {
    component.ngOnInit();
    component.isActive("");
    expect(component.locationUrl).toBeDefined();
  });
  it('test to Check isActive first if else scenario', () => {
    component.isActive("");
    expect(component).toBeDefined();
  });
  it('test to Check isActive first if else scenario', () => {
    // component.themeChangeSubscription = undefined;
    component.ngOnDestroy();
    expect(component).toBeDefined();
  });

});
