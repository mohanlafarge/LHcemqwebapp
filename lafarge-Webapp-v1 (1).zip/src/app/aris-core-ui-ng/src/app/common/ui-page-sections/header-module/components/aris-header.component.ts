import { Component, Input, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Language } from 'angular-l10n';
import { ArisLoginService } from '../../../services/aris-login.service';
import { ArisSessionService } from '../../../services/aris-session.service';


@Component({
  selector: 'aris-header',
  templateUrl: './aris-header.component.html',
  providers: [ArisSessionService],
  styleUrls: ['../css/aris-header.component.css']
})

export class ArisHeaderComponent implements OnInit, OnDestroy {

  defaultHeaderConfig = window.app.config.application.headerConfig;

  username = this.arisSessionService.getConnectedUser();

  header = {};
  public locationUrl: string = "/page/overview/MON";
  public themeConfig: any = '';
  @Language() lang: string;
  @Input() logo: TemplateRef<any>;
  @Input() navbar: TemplateRef<any>;
  @Input() themeSelect: TemplateRef<any>;
  @Input() langSelect: TemplateRef<any>;
  @Input() lastLogin: TemplateRef<any>;
  @Input() notificationBell: TemplateRef<any>;
  constructor(private router: Router,
    private arisLoginService: ArisLoginService,
    private arisSessionService: ArisSessionService
  ) {   
    this.header = window.app.config.headerTypes;   
  }

  ngOnDestroy() {
  }


  public isActive(href: string): string {
    
    // this.router.events.subscribe(event => {
    //   if (event instanceof NavigationEnd) {
    //     console.log("privius============" + event.url)

    //   };
    // });
    let val = href.replace("#", "");
    if (this.locationUrl) {
      if (
        val === this.locationUrl ||
        (val.length > 1 && this.locationUrl.indexOf(val) > -1)
      ) {
        return 'selectedShadowBox';
      }
      return '';
    }
  }


  ngOnInit(): void {
    this.router.events.subscribe((val) => {
      if (val instanceof NavigationEnd) {
        if (val.url !== '/') {
          this.locationUrl = val.url;
        }
      }
    });
  }

  openPage(destPageId) {
    //this.router.navigate(['page', localStorage.plantName]);
    this.router.navigate(['/page/' + localStorage.url]);
  }

  isLoggedIn() {
    return this.arisSessionService.isLoggedIn();
  }

  logout() {
    this.arisLoginService.logout();
  }
}
