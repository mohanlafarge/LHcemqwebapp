import { ArisModule } from '../../../../aris.module';
import { all } from 'q';
import { ArisHeaderService } from './aris-header-service';

describe('Test: Aris Header Service', () => {
  beforeEach(() => {
    const arisModule = new ArisModule();
  });
  const headerType = {};
  const headerConfig = {
    UIElements : { All: true },
    visibility: true,
  };
  const arisHeaderService = new ArisHeaderService();
  const mockHeaderConfig = { All: this.enable };
  it('Aris Header Service test: testing user defined headerConfig', () => {
    arisHeaderService.setHeaderInfo(headerConfig);
    expect(arisHeaderService.getHeaderInfo()).toBeDefined(mockHeaderConfig);
  });
  it('Aris Header Service test: default headerConfig has all is true', () => {
    window.app.config.application.headerConfig = headerConfig;
    arisHeaderService.setHeaderInfo(undefined);
    expect(arisHeaderService.getHeaderInfo()).toBeDefined(mockHeaderConfig);
  });
  it('Aris Header Service test: headerType is undefined gets default headerConfig', () => {
    arisHeaderService.setHeaderInfo(undefined);
    expect(arisHeaderService.getHeaderInfo()).toBeDefined(window.app.config.application.headerConfig);
  });
  it('Aris Header Service test: get default headerConfig', () => {
    expect(arisHeaderService.getHeader()).toBeDefined(window.app.config.application.headerConfig);
  });

  it('Aris Header Service test: headerType is of type string gets default headerConfig', () => {
    const arisHeaderServiceObj = new ArisHeaderService();
    arisHeaderServiceObj.setHeaderInfo('value');
    expect(arisHeaderService.getHeaderInfo()).toBeDefined(window.app.config.application.headerConfig);
  });

  it('Aris Header Service test: setHeaderMap is executed', () => {
    arisHeaderService.setHeaderMap('value');
    expect(arisHeaderService.headerMap).toEqual('value');
  });

  it('Aris Header Service test: getHeaderMap is executed', () => {
    let result = arisHeaderService.getHeaderMap();
    expect(result).toEqual('value');
  });

});
