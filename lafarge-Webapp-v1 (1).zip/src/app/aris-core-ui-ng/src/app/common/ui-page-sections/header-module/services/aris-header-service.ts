import { Injectable } from '@angular/core';

@Injectable()
export class ArisHeaderService {
  headerMap: any;
  userLastLoginInfo: any;
  header = (window.app.config.application.headerConfig);
  headerConfig: any;
  constructor() {
    this.headerConfig = Object.assign({}, window.app.config.application.headerConfig);
  }

  setHeaderInfo(headerType: any) {
    let headerInfo: any = {};
    let enable: any;
    const defaultHeaderConfig = Object.assign({}, window.app.config.application.headerConfig);
    if (defaultHeaderConfig.All !== null && defaultHeaderConfig !== undefined) {
      enable = defaultHeaderConfig.UIElements.All;
      defaultHeaderConfig.UIElements = { All: enable };
    }
    if (!headerType || headerType === {}) {
      headerInfo = defaultHeaderConfig;
    } else {
      if (typeof headerType === 'string') {
        Object.assign(headerInfo, defaultHeaderConfig, window.app.config.headerTypes.headerConfig[headerType]);
      } else if (headerInfo === null || headerInfo === undefined) {
        headerInfo = {};
        Object.assign(headerInfo, defaultHeaderConfig, headerType);
      }
    }

    if (headerInfo.UIElements !== undefined && headerInfo.UIElements.All !== null) {
      enable = headerInfo.UIElements.All;
      headerInfo.UIElements = { All: enable };
    }
    this.headerConfig = headerInfo;
  }

  getHeaderInfo() {
    return this.header;
  }

  getHeader() {
    return this.headerConfig;
  }

  setHeaderMap(map) {
    this.headerMap = map;
  }
  getHeaderMap() {
    return this.headerMap;
  }

}
