import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LocalizationModule } from 'angular-l10n';
import { ArisLanguageSelectorComponent } from './components/aris-language-selector.component';
import { ArisLanguageService } from './services/aris-language.service';
import { ArisConfigService } from '../../services/aris-config.service';

@NgModule({
  declarations: [ArisLanguageSelectorComponent],
  imports: [
    FormsModule,
    CommonModule,
    LocalizationModule
  ],

  providers: [ArisLanguageService, ArisConfigService],
  exports: [ArisLanguageSelectorComponent]
})
export class ArisLanguageSelectorModule {

}
