import { ComponentFixture, TestBed } from "@angular/core/testing";
import { LocalizationModule, TranslationService, InjectorRef } from "angular-l10n";
import { ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { NgSelectModule } from "@ng-select/ng-select";
import { CommonModule } from "@angular/common";
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
import { ArisConfigService } from '../../../services/aris-config.service';
import { ArisLanguageService } from '../services/aris-language.service';
import { ArisSessionService } from '../../../services/aris-session.service';
import { ArisLanguageSelectorComponent } from "./aris-language-selector.component";

describe('Aris Language Selector component UnitTest:', () => {
  let component: ArisLanguageSelectorComponent;
  let fixture: ComponentFixture<ArisLanguageSelectorComponent>;
  let langObject = {
    language: 'LANGUAGE_NAME_ENGLISH',
    icon: './app/common/resources/img/flag_united_kingdom.png',
    locale: 'en-gb',
    lang: 'en'
  };
  beforeEach(async () => {
    TestBed.configureTestingModule({
      imports: [LocalizationModule, ReactiveFormsModule, HttpClientModule, NgSelectModule, CommonModule, ArisI18nModule, LocalizationModule],
      declarations: [ArisLanguageSelectorComponent],
      providers: [InjectorRef, ArisConfigService, ArisLanguageService, TranslationService],
    }).compileComponents();
  });

  it('1. check if the component exists', () => {
    fixture = TestBed.createComponent(ArisLanguageSelectorComponent);
    component = fixture.componentInstance;
    expect(component).toBeDefined();
  });

  it('2. check for the constructor functionality', () => {
    fixture = TestBed.createComponent(ArisLanguageSelectorComponent);
    component = fixture.componentInstance;
    let langContainer = window.app.config.application.languages.supported;
    expect(component.langList).toEqual(langContainer);
  });
  it('3. check for method updateLng()', () => {
    fixture = TestBed.createComponent(ArisLanguageSelectorComponent);
    component = fixture.componentInstance;
    component.updateLang(langObject);
    expect(component.selectedLang).toEqual(langObject);
  });
  it('4. check for method updateLng()-- 2nd testcase', () => {
    fixture = TestBed.createComponent(ArisLanguageSelectorComponent);
    component = fixture.componentInstance;
    component.updateLang(langObject);
    expect(component.currentLanguage).toEqual(langObject.lang);
  });
  it('4. check for method setDefault()', () => {
    fixture = TestBed.createComponent(ArisLanguageSelectorComponent);
    component = fixture.componentInstance;
    component.setDefault(langObject.locale);
    expect(component.selectedLang).toEqual(langObject);
  });
  it('5. check for method setDefault()-- 2nd testcase', () => {
    fixture = TestBed.createComponent(ArisLanguageSelectorComponent);
    component = fixture.componentInstance;
    component.setDefault(langObject.locale);
    expect(component.currentLanguage).toEqual(langObject.lang);
  });

  it('6. ngOnDestroy working', () => {
    fixture = TestBed.createComponent(ArisLanguageSelectorComponent);
    component = fixture.componentInstance;
    component.setLangSubscribe = undefined;
    component.ngOnDestroy();
    expect(component).toBeTruthy();
  });
});
