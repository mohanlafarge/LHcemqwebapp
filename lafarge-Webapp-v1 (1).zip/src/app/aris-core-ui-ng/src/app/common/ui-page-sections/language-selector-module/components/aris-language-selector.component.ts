import { Component, OnInit, OnDestroy } from '@angular/core';


import { LocaleService, TranslationService, Language } from 'angular-l10n';
import { ArisConfigService } from '../../../services/aris-config.service';
import { ArisLanguageService } from '../services/aris-language.service';


@Component({
  selector: 'aris-language-select',
  templateUrl: './aris-language-selector.component.html',
  styleUrls: ['../css/aris-language-selector.component.css']
})
export class ArisLanguageSelectorComponent implements OnInit, OnDestroy {

  selectedLang: any;
  langList: any;
  langConfigured = '';
  selectedIcon = '';
  setLangSubscribe: any;
  @Language() currentLanguage = '';
  constructor(private arisConfigService: ArisConfigService, private langService: ArisLanguageService,
    private localeService: LocaleService) {
    this.langList = window.app.config.application.languages.supported;
    this.setDefault(this.arisConfigService.getLocale());
    // this.setLangSubscribe = this.langService.setLang.subscribe(
    this.setLangSubscribe = this.langService.languageChange.subscribe(
      (value) => {
        this.setDefault(value);
      }
    );
  }
  ngOnInit() {
  }

  ngOnDestroy() {
    if (this.setLangSubscribe) {
      this.setLangSubscribe.unsubscribe();
    }
  }

  updateLang(updatedLang: any) {
    this.localeService.setCurrentLanguage(updatedLang.lang);
    this.arisConfigService.setLocale(updatedLang.locale);

    this.selectedLang = updatedLang;
    this.currentLanguage = updatedLang.lang;
    // this.langService.languageChange.next();
  }

  setDefault(defaultLang: string) {
    this.langList.forEach((element) => {
      if (element.locale === defaultLang) {
        this.selectedLang = element;
        this.localeService.setCurrentLanguage(element.lang);
        this.currentLanguage = element.lang;
      }
    });
  }
}
