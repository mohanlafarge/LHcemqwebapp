import { Subject } from 'rxjs/Subject';
export class ArisLanguageService {
  // setLang = new Subject<string>();
  // languageChange: Subject<String> = new Subject<String>();
  languageChange = new Subject<string>();
}
