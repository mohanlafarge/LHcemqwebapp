import { HttpClient, HttpHandler } from '@angular/common/http';
import { Router } from '@angular/router';
import { ArisLastLoginInfoService } from '../../services/aris-last-login-info.service';
import { ArisLastLoginInfoComponent } from './aris-last-login-info.component';
import { TestBed, ComponentFixture } from '@angular/core/testing';
import { Injector } from '@angular/core';
import { LocalizationModule, TranslationService, InjectorRef } from 'angular-l10n';
import { FormsModule } from '@angular/forms';
import { ArisLocalDateTimePipe } from '../../pipes/aris-local-datetime.pipes';
import { Observable } from 'rxjs/Observable';

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};
describe('Test ArisLastLoginInfoComponent', () => {

  let arisLastLoginInfoService = new ArisLastLoginInfoService();
  let component: ArisLastLoginInfoComponent;
  let fixture: ComponentFixture<ArisLastLoginInfoComponent>;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ArisLastLoginInfoComponent, ArisLocalDateTimePipe],
      schemas: [],
      imports: [LocalizationModule, FormsModule],
      providers: [ArisLastLoginInfoService, ArisLocalDateTimePipe, { provide: TranslationService, useValue: mockTranslationService },
        Injector, InjectorRef]
    }).compileComponents();
    fixture = TestBed.createComponent(ArisLastLoginInfoComponent);
    arisLastLoginInfoService = TestBed.get(ArisLastLoginInfoService);
    // get test component from the fixture
    component = fixture.componentInstance;
  });

  it('ArisLastLoginInfoComponent to be Truthy', () => {
    let data = { aux: ['username', 'lastLoggedIn', 'lastLoggedOutTIme'] };
    spyOn(arisLastLoginInfoService, 'getLastLoginInfo').and.returnValue(data);
    component.ngOnInit();
    expect(arisLastLoginInfoService.getLastLoginInfo).toHaveBeenCalled();
  });

  it('ngOnInit else scenario', () => {
    spyOn(arisLastLoginInfoService, 'getLastLoginInfo').and.returnValue(undefined);
    component.ngOnInit();
    expect(arisLastLoginInfoService.getLastLoginInfo).toHaveBeenCalled();
  });

});
