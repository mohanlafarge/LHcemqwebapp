import { Component, OnInit } from '@angular/core';
import { ArisLastLoginInfoService } from '../../services/aris-last-login-info.service';
import { DatePipe } from '@angular/common';
import { Language } from 'angular-l10n';

@Component({
  selector: 'aris-last-login-info',
  templateUrl: './aris-last-login-info.component.html',
  providers: [DatePipe]
})

export class ArisLastLoginInfoComponent implements OnInit {
  username: any;
  lastLoggedIn: string;
  lastLoggedOutTIme: string;
  lastLoginStatus: string;

  @Language() lang: string;

  constructor(private arisLastLoginInfoService: ArisLastLoginInfoService) {
  }

  ngOnInit(): void {
    const aux = this.arisLastLoginInfoService.getLastLoginInfo();
    if (aux !== undefined) {
      this.username = aux['username'];
      this.lastLoggedIn = aux['lastLoggedIn'];
      this.lastLoggedOutTIme = aux['lastLoggedOutTIme'];
      this.lastLoginStatus = aux['lastLoginStatus'];
    }
  }
}
