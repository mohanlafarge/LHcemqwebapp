import { Component, OnInit } from '@angular/core';
import { Language } from 'angular-l10n';

@Component({
  selector: 'aris-menu-container',
  templateUrl: './menu-container.component.html',
  styleUrls: ['../css/menu-container.component.scss']
})

export class ArisMenuContainerComponent implements OnInit{

  @Language() lang: string;

  constructor() {
  }

  ngOnInit() { }
}
