import { LocalizationModule } from 'angular-l10n';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ArisMenuComponent } from './components/aris-menu.component';
import { ArisPermissionPipe } from '../../pipes/aris-permission.pipes';
import { ArisPipesModule } from '../../pipes/aris-pipes.module';
import { ArisUiComponentsModule } from '../../ui-components/aris-ui-components.module';
import { ArisPopUpModule } from '../../ui-page-sections/pop-up-module/aris-popup.module';
import { ArisAboutModule } from '../aris-about-module/aris-about.module';

@NgModule({
  declarations: [ArisMenuComponent],
  imports: [LocalizationModule, CommonModule, ArisPipesModule, ArisUiComponentsModule, ArisAboutModule],
  providers: [ArisPermissionPipe],
  exports: [ArisMenuComponent],
})
export class ArisMenuModule {

}
