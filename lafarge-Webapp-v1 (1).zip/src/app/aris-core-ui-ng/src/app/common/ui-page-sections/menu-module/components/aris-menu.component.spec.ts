import { ArisMenuComponent } from "./aris-menu.component";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { LocalizationModule, TranslationService, InjectorRef } from "angular-l10n";
import { ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { NgSelectModule } from "@ng-select/ng-select";
import { CommonModule } from "@angular/common";
import { ArisConfigService } from '../../../services/aris-config.service';
import { ArisSessionService } from '../../../services/aris-session.service';
import { ArisLanguageService } from '../../language-selector-module/services/aris-language.service';
import { ArisLoginService } from '../../../services/aris-login.service';
import { ArisPermissionService } from '../../../services/aris-permission.service';
import { ArisPermissionPipe } from '../../../pipes/aris-permission.pipes';
import { ArisPipesModule } from '../../../pipes/aris-pipes.module';
import { ArisUiComponentsModule } from '../../../ui-components/aris-ui-components.module';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
import { ArisI18nModule } from '../../../../translation/aris-i18n.module';
import { ArisPopUpModule } from "../../pop-up-module/aris-popup.module";
import { ArisAboutModule } from "../../aris-about-module/aris-about.module";
import { ArisWebSocketService } from "../../../services/aris-websocket.service";
import { ArisNotificationBoxService } from "../../error-module/services/aris-notification-box.service";
import { ToastrService } from "ngx-toastr";
class MockActivatedRouteSnapshot {
  private _data: any;
  get data() {
    return this._data;
  }
}
let mockRouter = {
  navigate: jasmine.createSpy('navigate')
};

let mockToastrService = {
  toastrConfig: jasmine.createSpy("toastrConfig"),
  toasts: jasmine.createSpy("toasts"),
  overlayContainer: jasmine.createSpy("overlayContainer")
};

describe('Aris Menu Component UnitTest:', () => {
  let component: ArisMenuComponent;
  let fixture: ComponentFixture<ArisMenuComponent>;
  let route: ActivatedRouteSnapshot;
  let state: RouterStateSnapshot;
  let arisWebSocketService: ArisWebSocketService;
  let topMenuObject = {
    text: 'MENU_ABOUT',
    icon: 'glyphicon glyphicon-info-sign',
    link: 'arisAbout',
    enabled: true
  };
  let permissionObject = {
    text: 'MENU_UC1',
    icon: 'fa fa-caret-down',
    permission: 'PERM_VIEW_UC1',
  };
  beforeEach(async () => {
    TestBed.configureTestingModule({
      imports: [LocalizationModule, ReactiveFormsModule, HttpClientModule, NgSelectModule, CommonModule, ArisI18nModule, LocalizationModule, ArisUiComponentsModule, ArisPipesModule,
        ArisPopUpModule, ReactiveFormsModule, ArisAboutModule],
      declarations: [ArisMenuComponent],
      providers: [InjectorRef, ArisConfigService, ArisLanguageService, TranslationService, ArisLoginService, ArisSessionService, { provide: ActivatedRouteSnapshot,
        useClass: MockActivatedRouteSnapshot }, { provide: ToastrService, useValue: mockToastrService },
          { provide: Router, useValue: mockRouter }, ArisPermissionPipe, ArisPermissionService, ArisWebSocketService, ArisNotificationBoxService],
    }).compileComponents();
  });

  it('1. check if the component exists', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    expect(component).toBeDefined();
  });

  it('2. check for method closeBox()', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    component.closeBox();
    expect(component.showConfirmation).toBe(false);
  });

  it('3. check for the application version', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    expect(component.applicationVersion).toBe('3.2.0');
  });

  it('4. check for constructor functionality', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    let menuItems = window.app.config.menu.menu_config;
    expect(component.mItems).toEqual(menuItems);
  });
  it('5. check for constructor functionality -- 2nd testcase', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    expect(component.showSubMenuItems[0]).toBe(false);
  });
  it('6. check for method hasPermission()', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    expect(component.hasPermission(permissionObject.permission)).toEqual('none');
  });
  it('check for method handleTopMenu() if scenario', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    component.showSubMenuItems = [false];
    let mItem = { subMenuItems: 'val' };
    let event = { stopPropagation() {} };
    component.handleTopMenu(mItem, 0, event);
    expect(component.hasPermission(permissionObject.permission)).toEqual('none');
  });

  it('check for method handleTopMenu() first else if scenario', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    component.showSubMenuItems = [false];
    let mItem = { link: 'logout' };
    let event = { stopPropagation() {} };
    component.handleTopMenu(mItem, 0, event);
    expect(component.hasPermission(permissionObject.permission)).toEqual('none');
  });

  it('check for method handleTopMenu() second else if scenario', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    component.showSubMenuItems = [false];
    let mItem = { link: 'http' };
    let event = { stopPropagation() {} };
    component.handleTopMenu(mItem, 0, event);
    expect(component.hasPermission(permissionObject.permission)).toEqual('none');
  });

  it('check for method handleTopMenu() third else if scenario', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    component.showSubMenuItems = [false];
    let mItem = { link: 'close' };
    let event = { stopPropagation() {} };
    component.handleTopMenu(mItem, 0, event);
    expect(component.hasPermission(permissionObject.permission)).toEqual('none');
  });
  it('check for method handleTopMenu() fourth else if scenario', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    component.showSubMenuItems = [false];
    let mItem = { link: 'arisAbout' };
    let event = { stopPropagation() {} };
    component.handleTopMenu(mItem, 0, event);
    expect(component.hasPermission(permissionObject.permission)).toEqual('none');
  });

  it('check for method handleTopMenu() fifth else if scenario', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    component.showSubMenuItems = [false];
    let mItem = { link: 'dose' };
    let event = { stopPropagation() {} };
    component.handleTopMenu(mItem, 0, event);
    expect(component.hasPermission(permissionObject.permission)).toEqual('none');
  });

  it('check for method handleTopMenu() last else  scenario', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    component.showSubMenuItems = [false];
    let mItem = { link: undefined };
    let event = { stopPropagation() {} };
    component.handleTopMenu(mItem, 0, event);
    expect(component.hasPermission(permissionObject.permission)).toEqual('none');
  });

  it('check for method handleSubMenu() first if scenario', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    let mItem = { link: 'http' };
    component.handleSubMenu(mItem);
    expect(component.hasPermission(permissionObject.permission)).toEqual('none');
  });

  it('check for method handleSubMenu() first else if with rest/ scenario', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    let mItem = { link: 'rest/.html' };
    component.handleSubMenu(mItem);
    expect(component.hasPermission(permissionObject.permission)).toEqual('none');
  });

  it('check for method handleSubMenu() first else if with spring/ scenario', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    let mItem = { link: 'spring/.wal' };
    component.handleSubMenu(mItem);
    expect(component.hasPermission(permissionObject.permission)).toEqual('none');
  });

  it('check for method handleSubMenu() first else if else scenario', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    let mItem = { link: '/.html' };
    component.handleSubMenu(mItem);
    expect(component.hasPermission(permissionObject.permission)).toEqual('none');
  });

  it('check for method hasPermission() if scenario', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    let persmission = TestBed.get(ArisPermissionPipe);
    spyOn(persmission, 'transform').and.returnValue(true);
    let result = component.hasPermission('mItem');
    expect(result).toEqual('block');
  });

  it('check for method adjustHttpLink() if scenario', () => {
    fixture = TestBed.createComponent(ArisMenuComponent);
    component = fixture.componentInstance;
    let result = component.adjustHttpLink('currenthost:');
    expect(result).toEqual('currenthost:');
  });

});
