import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

import { TranslationService, Language } from 'angular-l10n';

import { ArisLoginService } from '../../../services/aris-login.service';
import { ArisPermissionPipe } from '../../../pipes/aris-permission.pipes';


const ESCAPE_KEYCODE = 27;

@Component({
  selector: 'aris-menu',
  templateUrl: './aris-menu.component.html',
  styleUrls: ['../css/aris-menu.component.css']
})
export class ArisMenuComponent implements OnInit {
  mItems = window.app.config.menu.menu_config;
  isCollapsed = [];
  showSubMenuItems = [];
  showConfirmation: boolean;
  applicationVersion: string;

  @Language() lang: string;

  @HostListener('document:keydown', ['$event']) onKeydownHandler (event: KeyboardEvent) {
    if (event.keyCode === ESCAPE_KEYCODE) {
      this.closeMenu();
      // $('#aris-menu-uncollapse>li').removeClass('open');
      // $('#aris-menu-collapse').attr('aria-expanded', 'false');
      // $('#aris-menu-collapse').css('height', '0px');
      // $('#aris-menu-collapse').removeClass('in');
      event.preventDefault();
    }
  }

  constructor(private arisLoginService: ArisLoginService,
    private router: Router,
    private translation: TranslationService,
    private permission: ArisPermissionPipe,
    private http: HttpClient)  {

    this.mItems.forEach((element, index) => {
      this.isCollapsed[index] = true;
      this.showSubMenuItems[index] = false;
    });
    this.applicationVersion = window.app.config.platform.version;
  }

  ngOnInit() { }

  hideMenu() {
    $('#aris-menu-uncollapse>li').removeClass('open');
    $('#aris-menu-uncollapse>li>a').attr('aria-expanded', 'false');
    $('#aris-menu-collapse').attr('aria-expanded', 'false');
    $('#aris-menu-collapse').css('height', '0px');
    $('#aris-menu-collapse').removeClass('in');
  }

  closeMenu() {
    this.mItems.forEach((element, index) => {
      this.isCollapsed[index] = true;
    });
    this.hideMenu();
  }

  hasPermission(permissionStatus) {
    return this.permission.transform(permissionStatus) === true ? 'block' : 'none';
  }


  handleTopMenu(mItem, mItemIndex, event) {
    this.showSubMenuItems[mItemIndex] = !this.showSubMenuItems[mItemIndex];
    if (typeof (mItem.subMenuItems) !== 'undefined') {
      this.isCollapsed[mItemIndex] = !this.isCollapsed[mItemIndex];
    } else {
      this.closeMenu();
      if (mItem.link !== undefined && mItem.link.indexOf('logout') === 0) {
        this.arisLoginService.logout();
      } else if (mItem.link !== undefined && mItem.link.indexOf('http') === 0) {
        const menuOption = mItem.link;
        window.open(this.adjustHttpLink(menuOption));
      } else if (mItem.link !== undefined && mItem.link.indexOf('close') === 0) {
        this.mItems.forEach((element, index) => {
          this.isCollapsed[index] = true;
        });
      } else if (mItem.link !== undefined && mItem.link.indexOf('arisAbout') === 0) {
        this.showConfirmation = true;
      } else if (mItem.link !== undefined && mItem.link.indexOf('close') === -1) {
        this.router.navigate(['/' + mItem.link]);
      }
    }
    event.stopPropagation();
  }

  handleSubMenu(subMenuItem) {
    this.closeMenu();
    if (subMenuItem.link.indexOf('http') === 0) {
      const menuOption = subMenuItem.link;
      window.open(this.adjustHttpLink(menuOption));
    } else if (subMenuItem.link.startsWith('rest/') || subMenuItem.link.startsWith('spring/')) {
      if (subMenuItem.link.indexOf('.html') !== -1) {
        window.open(subMenuItem.link, this.translation.translate(subMenuItem.text));
      } else {
        this.http.get(subMenuItem.link).toPromise().then(
          (result: any) => {
            // var x = ;
            var myjson = JSON.stringify(result, null, 2);
            window.open().document.write('<html><body><pre>' + myjson.replace(/\\r\\n/g, "<br />") + '</pre></body></html>');
            console.log('success' + result);
          }, (error) => {
            window.open("Error").document.write(error);
            console.log(error);
          }
        ).catch(
          (expt) => {
            console.log('error' + expt);
          }
          );
      }
    } else {
      this.router.navigate(['/' + subMenuItem.link]);
    }
    this.mItems.forEach((element, index) => {
      // if (this.isCollapsed[index] !== false) {
      this.isCollapsed[index] = true;
      this.showSubMenuItems[index] = false;
      // }
    });
  }

  adjustHttpLink(menuOption) {
    let hostAdjusted = location.host;
    if (menuOption.toUpperCase().indexOf('CURRENTHOST:') !== -1) {
      let pos = location.host.indexOf(':');

      if (pos !== -1) {
        hostAdjusted = location.host.substring(0, pos);
      }
    }
    let linkAdjusted = menuOption.replace(/CURRENTHOST/, hostAdjusted);
    return linkAdjusted;
  }

  closeBox() {
    this.showConfirmation = false;
  }
}
