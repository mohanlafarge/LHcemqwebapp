import { NgModule } from "@angular/core";
import { ArisConfirmation } from "./components/aris-confirmation.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import { NgSelectModule } from "@ng-select/ng-select";
import { LocalizationModule } from "angular-l10n";
import { ArisSvgService } from "../../services/aris-svg.service";

@NgModule({
  declarations: [
    ArisConfirmation
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    NgSelectModule,
    LocalizationModule
  ],
  providers: [
    ArisSvgService
  ],
  exports: [
    ArisConfirmation
  ]
})
export class ArisPopUpModule {

}
