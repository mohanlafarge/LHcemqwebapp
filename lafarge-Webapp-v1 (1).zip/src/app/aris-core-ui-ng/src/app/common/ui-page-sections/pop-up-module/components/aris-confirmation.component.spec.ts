import { TestBed, ComponentFixture } from '@angular/core/testing';
import { ArisConfirmation } from './aris-confirmation.component';
import { ModalModule, BsModalRef, BsModalService } from 'ngx-bootstrap';
import { LocalizationModule, InjectorRef, TranslationService, LocaleService } from 'angular-l10n';
import { ArisModule } from '../../../../aris.module';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ArisDynamicPageModule } from '../../../ui-page-models/aris-dynamic-page-module/aris-dynamic-page.module';
import { FilterModule } from '../../filter-panel-module/aris-filter.module';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Observable } from 'rxjs';

let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};
describe('Test: Aris Confirmation Component', () => {

  let component: ArisConfirmation;
  let fixture: ComponentFixture<ArisConfirmation>;

  let modalRef = new BsModalRef();

  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [],
      imports: [RouterModule,
        LocalizationModule,
        CommonModule,
        ArisDynamicPageModule,
        FilterModule,
        HttpClientModule,
        HttpClientTestingModule],
      providers: [InjectorRef, BsModalService,
         { provide: TranslationService, useValue: mockTranslationService }, { provide: LocaleService }]
    });

    // create component and test fixture
    fixture = TestBed.createComponent(ArisConfirmation);

    // get test component from the fixture
    component = fixture.componentInstance;
    component.modalRef = modalRef;

  });

  it('Component must be created succesfully', () => {

    fixture = TestBed.createComponent(ArisConfirmation);
    component = fixture.componentInstance;
    component.saveText = 'SAVE';
    component.cancelText = 'CANCEL';
    component.confirmationText = 'FOOTER_LAYOUT_SAVE_CONFIRM';
    component.ngAfterViewInit();

    fixture.detectChanges();

    expect(component).toBeTruthy();
  });

  it('Component execution for decline', () => {
    component.ngAfterViewInit();
    spyOn(component, 'decline').and.callThrough();
    component.decline();
    expect(component.decline).toHaveBeenCalled();
  });

  it('actionRequested if executed', () => {
    component.actionRequested('confirm');
    expect(component).toBeTruthy();
  });
  it('actionRequested else executed', () => {
    component.actionRequested('decline');
    expect(component).toBeTruthy();
  });
  it('actionRequested else executed', () => {
    component.actionRequested('Well');
    expect(component).toBeTruthy();
  });
  it('ngOnDestroy else executed', () => {
    component.subscription = undefined;
    component.ngOnDestroy();
    expect(component).toBeTruthy();
  });
});
