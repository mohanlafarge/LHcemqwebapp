import { Component, Input, Output, EventEmitter, OnDestroy, TemplateRef, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
// import { BsModalService } from 'ngx-bootstrap/modal';
// import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';
import { Language, TranslationService, LocaleService } from 'angular-l10n';
import { ArisSvgService } from '../../../services/aris-svg.service';
@Component({
  selector: 'aris-confirm-window',
  templateUrl: './aris-confirmation.component.html'
})
export class ArisConfirmation implements AfterViewInit, OnDestroy {
  modalRef: BsModalRef;
  message: string;

  @ViewChild('template') confirmationTemplate: ElementRef;

  @Language() lang: string;
  @Input() saveText: string;
  @Input() cancelText: string;
  @Input() confirmationText: string;
  @Input() changeTemplate: any;
  @Input() closeDialog: any;

  @Output() okSelected: EventEmitter<any> = new EventEmitter<any>();
  @Output() cancel: EventEmitter<any> = new EventEmitter();
  

  subscription: any;

  okMessage: string;
  cancelMessage: string;
  closeMessage: string;
  config = {
    animated: true,
    keyboard: true,
    backdrop: true,
    ignoreBackdropClick: true
  };
  constructor(private modalService: BsModalService, private translationService: TranslationService,
     private localeService: LocaleService, private arisSvgService: ArisSvgService) {
    this.subscription = arisSvgService.closeOpenDialog.subscribe((data) => {
      this.decline();
    });
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.okMessage = this.saveText ? this.translationService.translate(this.saveText) : this.translationService.translate('SAVE');
      this.cancelMessage = this.cancelText ? this.translationService.translate(this.cancelText) : this.translationService.translate('FOOTER_CANCEL');
      this.modalRef = this.modalService.show(this.changeTemplate ? this.changeTemplate :  this.confirmationTemplate, this.config);
    }, 0);
  }

  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  confirm(): void {
    this.modalRef.hide();
    this.okSelected.emit(null);
  }

  decline(): void {
    this.cancel.emit(null);
    this.modalRef.hide();
  }

  actionRequested(actionRequired: string) {
    if (actionRequired === 'confirm') {
      this.modalRef.hide();
      this.okSelected.emit(null);
    } else if (actionRequired === 'decline') {
      this.cancel.emit(null);
      this.modalRef.hide();
    }
  }
}
