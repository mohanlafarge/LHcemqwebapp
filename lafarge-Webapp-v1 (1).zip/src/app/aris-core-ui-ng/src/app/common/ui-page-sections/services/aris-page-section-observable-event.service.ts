import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class ArisPageSectionObservableEventService {

  private editLayoutSource = new BehaviorSubject<boolean>(false);
  private saveLayoutSource = new BehaviorSubject<boolean>(false);
  private pageLayoutSource = new BehaviorSubject<any>('');
  private footerSource = new BehaviorSubject<any>(undefined);

  editLayout = this.editLayoutSource.asObservable();
  saveLayout = this.saveLayoutSource.asObservable();
  pageLayout = this.pageLayoutSource.asObservable();
  footer = this.footerSource.asObservable();

  pageName = '';

  constructor() { }

  setEditLayout(editLayoutFlag: boolean) {
    this.editLayoutSource.next(editLayoutFlag);
  }

  setSaveLayout(save: boolean) {
    this.saveLayoutSource.next(save);
  }

  setPageLayout(pageLayout: any) {
    this.pageLayoutSource.next(pageLayout);
  }

  getPageLayout() {
    return this.pageLayout;
  }

  setPageName(pageName: string) {
    this.pageName = pageName;
  }

  getPageName(): string {
    return this.pageName;
  }

  setFooter(footer: any) {
    this.footerSource.next(footer);
  }

  getFooter() {
    return this.footer;
  }
}
