import { Component, OnInit, Input, AfterViewChecked, ViewEncapsulation } from '@angular/core';

import { UnityService } from '../unity-service/unity-service.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'unity-app-component',
  templateUrl: './unity-app.component.html',
  styleUrls: ['./unity-app.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class UnityAppComponent implements OnInit {

  @Input() id: any = "gamecontainer";
  @Input() file: any;

  loadingPerc = 0;

  constructor(private _unityService: UnityService) {

  }

  ngOnInit() {

    let unityProgressObj = {
      onProgress: this.unityProgress,
      Module: {
        onRuntimeInitialized: onRuntimeInitialized.bind(this) ,
        preInit: [() => { this.unityProgress(gameInstance, "preinit"); }]
      }
    };
    let gameInstance = this._unityService.load(this.id, this.file, unityProgressObj);

    function onRuntimeInitialized() {
      this.unityProgress(gameInstance, "complete");      
    }
  }

  unityProgress(gameInstance, progress) {
    if (!gameInstance.Module) {
      return;
    }
    let loader: any = document.querySelector("#loader");
    if (!gameInstance.progress) {
      // tslint:disable-next-line:no-shadowed-variable
      let progress: any = document.querySelector("#loader .progressBar");
      progress.style.display = "block";
      gameInstance.progress = progress.querySelector(".full");
      loader.querySelector(".spinner").style.display = "none";
    }
    gameInstance.progress.style.transform = `scaleX(${progress})`;
    if (progress === 1 && !gameInstance.removeTimeout) {
      gameInstance.removeTimeout = setTimeout(() => {
        loader.style.display = "none";
      }, 1000);
    }

    if (progress === "complete") {
      this._unityService.unityInitialized.next(progress);
      document.getElementById("loadingInfo").style.display = "none";
      document.getElementById("loader").style.display = "none";
    } else if (progress === 1 || progress === "preinit") {
      document.getElementById("loadingInfo").innerHTML = "PROCESSING...";
    } else if (progress > 0) {
      document.getElementById("loadingInfo").innerHTML = Math.round(progress * 100) + "%";
    }
    
  }

}
