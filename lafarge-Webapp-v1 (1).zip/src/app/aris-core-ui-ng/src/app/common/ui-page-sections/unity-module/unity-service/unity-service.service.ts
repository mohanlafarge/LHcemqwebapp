import { Injectable } from '@angular/core';
import { OnInit } from '@angular/core';
import { Subject } from 'rxjs/Subject';

declare let window: any;
declare var UnityLoader: any;


@Injectable()
export class UnityService implements OnInit {
  private gameInstance: any;
  public unityInitialized = new Subject<any>();

  constructor() { }

  ngOnInit() {
  }

  public load(componentId: string, jsonFile: string, unityProgress: any) {
    window.UnityLoader = UnityLoader;
    return this.gameInstance = UnityLoader.instantiate(componentId, jsonFile, unityProgress);
  }

  public sendMessage(messageHandler: string, message: any) {
    this.gameInstance.SendMessage(messageHandler, message.type, message.payload);
  }

  public setFullScreen () {
    this.gameInstance.SetFullscreen(1);
  }

}
