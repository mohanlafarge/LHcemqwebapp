import { Component, OnInit } from "@angular/core";
import { Language } from "angular-l10n";

@Component({
  selector: "aris-gdpr-template",
  templateUrl: "./aris-gdpr-description-template.html"
})
export class ArisGdprDescriptionTemplateComponent implements OnInit {

  @Language() lang: string;

  constructor() {}

  ngOnInit() {}

}
