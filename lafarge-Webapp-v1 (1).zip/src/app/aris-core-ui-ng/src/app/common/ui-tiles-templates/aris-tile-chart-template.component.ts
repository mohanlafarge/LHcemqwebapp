import { Component, Input, OnInit } from '@angular/core';
import { Language } from 'angular-l10n';

import { ArisPermissionService } from '../services/aris-permission.service';

@Component({
  selector: 'arisTileChartTemplate',
  templateUrl: './aris-tile-chart-template.component.html'
})
export class ArisTileChartTemplateComponent implements OnInit {
  @Input() permission: string;
  @Input() type: String;
  @Input() options: any;
  @Input() chartData: any;

  customStyle: any;
  @Language() lang: string;
  constructor(private arisPermissionsService: ArisPermissionService) { }

  ngOnInit() {
    if (this.options.height) {
      this.customStyle = { 'height' : this.options.height + "px" };
    } else {
      this.customStyle = { 'min-height' : "300px" };
    }
  }
}
