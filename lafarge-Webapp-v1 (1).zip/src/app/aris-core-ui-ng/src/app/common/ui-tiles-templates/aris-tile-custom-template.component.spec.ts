import { ArisTileCustomTemplateComponent } from "./aris-tile-custom-template.component";

describe('Test: ArisTileCustomTemplateComponent:', () => {
  let arisTileCustomTemplateComponent = new ArisTileCustomTemplateComponent();

  it('Component created', () => {
    arisTileCustomTemplateComponent.ngOnChanges('data');
    expect(arisTileCustomTemplateComponent).toBeTruthy();
  });
});
