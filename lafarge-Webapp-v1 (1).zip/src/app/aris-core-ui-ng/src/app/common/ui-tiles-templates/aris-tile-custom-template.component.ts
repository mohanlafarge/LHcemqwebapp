import { Component, Input, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { Language } from 'angular-l10n';

@Component({
  selector: 'arisTileCustomTemplate',
  templateUrl: './aris-tile-custom-template.component.html'
})
export class ArisTileCustomTemplateComponent implements OnChanges, OnInit {
  @Input() headerConfig: any;
  @Input() internalInput: any;
  @Input() internalComponent: any;

  @Language() lang: string;
  constructor() {
    console.log('aris-tile-template-with-true-scope onInit');
  }

  ngOnChanges(data) {
    console.log("ArisTileTemplateWithIsolatedScopeComponent has change!!!");
  }

  ngOnInit() {}
}
