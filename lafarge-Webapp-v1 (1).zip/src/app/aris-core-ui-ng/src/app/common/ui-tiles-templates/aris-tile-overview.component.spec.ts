import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Pipe, PipeTransform, Type } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpHandler, HttpClientModule } from '@angular/common/http';

import { TranslatePipe, LocaleService, LOCALE_CONFIG, LocaleStorage, TranslationService, TRANSLATION_CONFIG, TranslationProvider, TranslationHandler, InjectorRef, LocalizationModule } from 'angular-l10n';
import { ToastrService } from 'ngx-toastr';

// import { Tile } from '../../../../pages/home-module/types/Tile';
import { ArisTileOverviewComponent } from './aris-tile-overview.component';
import { ArisPageSectionObservableEventService } from '../ui-page-sections/services/aris-page-section-observable-event.service';
import { ArisNotificationBoxService } from '../ui-page-sections/error-module/services/aris-notification-box.service';
import { ArisDataSourceService } from '../services/aris-datasource.service';
import { ArisDynamicPageModule } from '../ui-page-models/aris-dynamic-page-module/aris-dynamic-page.module';
import { FilterModule } from '../ui-page-sections/filter-panel-module/aris-filter.module';
import { ArisSessionService } from '../services/aris-session.service';
import { ArisHeaderService } from '../ui-page-sections/header-module/services/aris-header-service';
import { ArisPageDashboardService } from '../ui-page-models/page-module/services/aris-page-dashboard.service';
import { ArisPageService } from '../services/aris-page-service';
import { ArisFilterService } from '../services/aris-filter.service';
import { ArisLanguageService } from '../ui-page-sections/language-selector-module/services/aris-language.service';
import { ArisPermissionService } from '../services/aris-permission.service';
import { ArisConfigService } from '../services/aris-config.service';
import { Router, ActivatedRoute, Data, Params, UrlSegment, ActivatedRouteSnapshot, ParamMap, RouterModule } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Route } from '@angular/compiler/src/core';
import { CommonModule } from '@angular/common';
import { ChartModule } from '../ui-components/chart-module/aris-chart.module';
import { ArisPipesModule } from '../pipes/aris-pipes.module';
import { ArisUiComponentsModule } from '../ui-components/aris-ui-components.module';
import { ArisTileCustomTemplateComponent } from './aris-tile-custom-template.component';
import { ArisTileTitleWithButtonsComponent } from './aris-tile-title-with-buttons.component';
import { ArisTileTitleWithDescComponent } from './aris-tile-title-with-desc.component';
import { ArisTileYammerComponent } from './aris-tile-yammer.component';
import { ArisTileChartTemplateComponent } from './aris-tile-chart-template.component';
import { ArisGdprDescriptionTemplateComponent } from './aris-gdpr-description-template.component';
import { DynamicModule } from 'ng-dynamic-component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ArisTileOverviewService } from './services/aris-tile-overview.service';
import { ArisConfirmation } from '../ui-page-sections/pop-up-module/components/aris-confirmation.component';
import { ArisPopUpModule } from '../ui-page-sections/pop-up-module/aris-popup.module';



@Pipe({
  name: 'translate'
})
export class TranslatePipeMock implements PipeTransform {
  public name = 'translate';

  public transform(query: string, ...args: any[]): any {
    return query;
  }
}

class MockArisPageSectionObservableEventService extends ArisPageSectionObservableEventService {  getPageName(): string {
  return 'SamplaePage';
}
}

class MockEvent {
  keyCode: number;
  preventDefault(): void { }
}

let mockRouter = {
  navigate: jasmine.createSpy('navigate')
};

export class MockActivatedRoute implements ActivatedRoute {
  snapshot: ActivatedRouteSnapshot;
  url: Observable<UrlSegment[]>;
  params: Observable<Params>;
  queryParams: Observable<Params>;
  fragment: Observable<string>;
  data: Observable<Data>;
  outlet: string;
  component: Type<any>|string;
  routeConfig: Route;
  root: ActivatedRoute;
  parent: ActivatedRoute;
  firstChild: ActivatedRoute;
  children: ActivatedRoute[];
  pathFromRoot: ActivatedRoute[];
  paramMap: Observable<ParamMap>;
  queryParamMap: Observable<ParamMap>;
  toString(): string {
    return "";
  }
}

export class MockHttpClient extends HttpClient {
}
let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};
describe('Test: Aris overview component:', () => {
  let trackerFormService: ArisTileOverviewService;
  let content = "three";
  let component: ArisTileOverviewComponent;
  let fixture: ComponentFixture<ArisTileOverviewComponent>;
  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [
        ArisTileCustomTemplateComponent,
        ArisTileTitleWithButtonsComponent,
        ArisTileTitleWithDescComponent,
        ArisTileYammerComponent,
        ArisTileChartTemplateComponent,
        ArisTileOverviewComponent,
        ArisGdprDescriptionTemplateComponent
      ],
      imports: [
        HttpClientModule,
        HttpClientTestingModule,
        RouterModule,
        LocalizationModule,
        CommonModule,
        FormsModule,
        ChartModule,
        ArisPipesModule,
        ArisUiComponentsModule,
        ArisPopUpModule,
        DynamicModule.withComponents([
          ArisTileCustomTemplateComponent,
          ArisTileTitleWithButtonsComponent,
          ArisTileTitleWithDescComponent,
          ArisTileYammerComponent,
          ArisTileChartTemplateComponent,
          ArisTileOverviewComponent,
          ArisGdprDescriptionTemplateComponent
        ]),
      ],
      providers: [ArisTileOverviewService,
        ArisSessionService,
        ArisHeaderService,
        ArisPageService,
        ArisPageDashboardService,
        ArisFilterService,
        InjectorRef, HttpHandler,
            { provide: Router, useValue: mockRouter }, { provide: HttpClient, useClass: MockHttpClient }, { provide: ActivatedRoute, useValue: {
              params: Observable.of({ geoLayerName: "destPage" })
            } }, { provide: ArisNotificationBoxService },
        ArisDataSourceService, ArisPageSectionObservableEventService, ArisPermissionService, ArisConfigService,
        ArisLanguageService, { provide: ToastrService }, { provide: LocaleService }, { provide: TranslationService, useValue: mockTranslationService }
      ]
    }).compileComponents();

    afterAll(() => {
      component = null;
            });
        // create component and test fixture
    fixture = TestBed.createComponent(ArisTileOverviewComponent);

        // get test component from the fixture
    component = fixture.componentInstance;
    component.maxlength = 10;
    component.content = content;

  });

  it('Function getText should call http get method.', () => {
    component.getText();
    expect(component).toBeTruthy();
  });

  it('Function ngOnInit error scenario.', () => {
    component.ngOnInit();
    expect(component.saveOverviewFlag).toBeFalsy();
  });

  it('Function ngOnInit passing scenario with null result.', () => {
    spyOn(component, 'getText').and.callFake(() => Promise.resolve(null));
    component.ngOnInit();
    expect(component.saveOverviewFlag).toBeFalsy();
  });

  it('Function ngOnInit passing scenario.', () => {
    let data = { content: 'value' };
    spyOn(component, 'getText').and.callFake(() => Promise.resolve(data));
    component.ngOnInit();
    expect(component.content).toEqual('three');
  });

  it('Function resetText should reset content to original content.', () => {
    component.content = 'Original Text';
    component.originalContent = component.content;
    component.content = 'New Text';
    component.resetText();
    component.maxlength = 20;
    expect(component.content).toEqual('Original Text');
  });

  it('Function calculateCharactersLeft should set characters left.', () => {
    component.maxlength = 20;
    component.content = 'Original Text';
    component.calculateCharactersLeft();
    expect(component.charactersLeft).toEqual(7);
  });

  it('Function saveText error scenario.', () => {
    let service = TestBed.get(ArisTileOverviewService);
    spyOn(service, 'getTextData').and.callFake(() => Promise.reject(403));
    component.saveText();
    expect(service.getTextData).toHaveBeenCalled();
  });

  it('Function saveText should call http post method.', () => {
    let data = { content: 'value' };
    let service = TestBed.get(ArisTileOverviewService);
    spyOn(service, 'getTextData').and.callFake(() => Promise.resolve(data));
    component.saveText();
    expect(service.getTextData).toHaveBeenCalled();
  });

  it('Function validateOverviewText should call preventDefault if key character is invalid.', () => {
    let invalidCharacterArray: number[] = [59, 39, 47, 60, 62, 34, 92, 43, 61, 40, 41];
    let event: MockEvent = new MockEvent();
    spyOn(event, 'preventDefault').and.callThrough();
    let counter = 1;
    invalidCharacterArray.forEach((element) => {
      event.keyCode = element;
      component.validateOverviewText(event);
      expect(event.preventDefault).toHaveBeenCalledTimes(counter);
      counter += 1;
    });
  });

  it('Function validateOverviewText  else scenario.', () => {
    let invalidCharacterArray: number[] = [59, 39, 47, 60, 62, 34, 92, 43, 61, 40, 41];
    let event: MockEvent = new MockEvent();
    spyOn(event, 'preventDefault').and.callThrough();
    invalidCharacterArray.forEach((element) => {
      event.keyCode = undefined;
      component.validateOverviewText(event);
      expect(component.saveOverviewFlag).toBeFalsy();
    });
  });

  it('Function requestConfirmation executed.', () => {
    component.requestConfirmation();
    expect(component).toBeTruthy();
  });

  it('Function requestSaveOverview executed.', () => {
    component.requestSaveOverview();
    expect(component).toBeTruthy();
  });

  it('Function cancelSave executed.', () => {
    component.content = 'Original Text';
    component.originalContent = component.content;
    component.content = 'New Text';
    component.cancelSave();
    expect(component).toBeTruthy();
  });
});
