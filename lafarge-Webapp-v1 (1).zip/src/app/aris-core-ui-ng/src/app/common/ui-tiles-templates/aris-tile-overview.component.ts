import { Component, Input, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Language } from 'angular-l10n';

import { ArisPageSectionObservableEventService } from '../ui-page-sections/services/aris-page-section-observable-event.service';
import { ArisNotificationBoxService } from '../ui-page-sections/error-module/services/aris-notification-box.service';
import { ArisTileOverviewService } from './services/aris-tile-overview.service';
import { ArisPermissionService } from '../services/aris-permission.service';

@Component({
  selector: 'aris-overview',
  templateUrl: './aris-tile-overview.component.html',
  styleUrls: ['./css/aris-tile-overview.component.css']
})

export class ArisTileOverviewComponent implements OnInit {

  content: string;
  charactersLeft: number;
  originalContent: string;
  @Input() componentid: any = 'component1';
  @Input() rows = 10;
  @Input() maxlength = 1000;
  editable: any = false;
  invalidCharacterArray: number[] = [59, 39, 47, 60, 62, 34, 92, 43, 61, 40, 41];
  resultMessage: any;
  saveOverviewFlag = false;

  @Language() lang: string;
  constructor(private http: HttpClient,
              private sharedCommunicationService: ArisPageSectionObservableEventService,
              private notificationService: ArisNotificationBoxService,
              private arisTileOverviewService: ArisTileOverviewService,
              private arisPermission: ArisPermissionService) {
  }

  ngOnInit(): void {
    this.editable = this.arisPermission.hasPermission('PERM_OVERVIEW_EDIT'); 
    this.getText().then((result) => {
      if (result !== null) {
        this.content = result.content;
        this.originalContent = this.content;
        this.calculateCharactersLeft();
      }
    }).catch((err) => {
      console.log(err);
    });
  }

  calculateCharactersLeft(): void {
    this.charactersLeft = this.maxlength - this.content.length;
  }

  resetText(): void {
    this.content = this.originalContent;
    this.calculateCharactersLeft();
  }

  saveText(): void {
    let tile: any = {}; // new Tile();
    tile.componentId = this.componentid;
    tile.componentType = 'overview';
    tile.content = this.content;
    tile.pagename = this.sharedCommunicationService.getPageName();

    this.arisTileOverviewService.getTextData('rest/pagemaster/save', tile)
    .then((result: any) => {
      this.content = result.content;
      this.originalContent = this.content;
      this.resultMessage = {
        status: '200',
        title: 'Successful',
        message: 'Overview Saved Successfully'
      };
      this.notificationService.showNotification(this.resultMessage, 'right', 'success');
      this.calculateCharactersLeft();
    }, (error) => {
      this.notificationService.showNotification(error, 'right', 'error');
    });
  }

  getText(): Promise<any> {
    return this.http.get('rest/pagemaster/getoverviewtext/' + this.sharedCommunicationService.getPageName() + '/' + this.componentid).toPromise();
  }

  validateOverviewText(event) {
    if ((<any>this.invalidCharacterArray).includes(event.keyCode)) {
      event.preventDefault();
    }
  }

  requestConfirmation() {
    this.saveOverviewFlag = true;
  }

  requestSaveOverview() {
    this.saveOverviewFlag = false;
    this.saveText();
  }

  cancelSave() {
    this.saveOverviewFlag = false;
    this.resetText();
  }
}
