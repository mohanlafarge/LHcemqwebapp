import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Pipe, PipeTransform, Type } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpHandler, HttpClientModule } from '@angular/common/http';

import { TranslatePipe, LocaleService, LOCALE_CONFIG, LocaleStorage, TranslationService, TRANSLATION_CONFIG, TranslationProvider, TranslationHandler, InjectorRef, LocalizationModule } from 'angular-l10n';
import { ToastrService } from 'ngx-toastr';

// import { Tile } from '../../../../pages/home-module/types/Tile';
import { ArisTileOverviewComponent } from './aris-tile-overview.component';
import { ArisPageSectionObservableEventService } from '../ui-page-sections/services/aris-page-section-observable-event.service';
import { ArisNotificationBoxService } from '../ui-page-sections/error-module/services/aris-notification-box.service';
import { ArisDataSourceService } from '../services/aris-datasource.service';
import { ArisDynamicPageModule } from '../ui-page-models/aris-dynamic-page-module/aris-dynamic-page.module';
import { FilterModule } from '../ui-page-sections/filter-panel-module/aris-filter.module';
import { ArisSessionService } from '../services/aris-session.service';
import { ArisHeaderService } from '../ui-page-sections/header-module/services/aris-header-service';
import { ArisPageDashboardService } from '../ui-page-models/page-module/services/aris-page-dashboard.service';
import { ArisPageService } from '../services/aris-page-service';
import { ArisFilterService } from '../services/aris-filter.service';
import { ArisLanguageService } from '../ui-page-sections/language-selector-module/services/aris-language.service';
import { ArisPermissionService } from '../services/aris-permission.service';
import { ArisConfigService } from '../services/aris-config.service';
import { Router, ActivatedRoute, Data, Params, UrlSegment, ActivatedRouteSnapshot, ParamMap, RouterModule } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Route } from '@angular/compiler/src/core';
import { CommonModule } from '@angular/common';
import { ChartModule } from '../ui-components/chart-module/aris-chart.module';
import { ArisPipesModule } from '../pipes/aris-pipes.module';
import { ArisUiComponentsModule } from '../ui-components/aris-ui-components.module';
import { DynamicModule } from 'ng-dynamic-component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ArisTileOverviewService } from './services/aris-tile-overview.service';
import { ArisTileTitleWithButtonsComponent } from './aris-tile-title-with-buttons.component';



@Pipe({
  name: 'translate'
})
export class TranslatePipeMock implements PipeTransform {
  public name = 'translate';

  public transform(query: string, ...args: any[]): any {
    return query;
  }
}

class MockArisPageSectionObservableEventService extends ArisPageSectionObservableEventService {  getPageName(): string {
  return 'SamplaePage';
}
}

class MockEvent {
  keyCode: number;
  preventDefault(): void { }
}

let mockRouter = {
  navigate: jasmine.createSpy('navigate')
};

export class MockActivatedRoute implements ActivatedRoute {
  snapshot: ActivatedRouteSnapshot;
  url: Observable<UrlSegment[]>;
  params: Observable<Params>;
  queryParams: Observable<Params>;
  fragment: Observable<string>;
  data: Observable<Data>;
  outlet: string;
  component: Type<any>|string;
  routeConfig: Route;
  root: ActivatedRoute;
  parent: ActivatedRoute;
  firstChild: ActivatedRoute;
  children: ActivatedRoute[];
  pathFromRoot: ActivatedRoute[];
  paramMap: Observable<ParamMap>;
  queryParamMap: Observable<ParamMap>;
  toString(): string {
    return "";
  }
}

export class MockHttpClient extends HttpClient {
}
let mockTranslationService = {
  translate: jasmine.createSpy('translate'),
  translationChanged: jasmine.createSpy('translationChanged').and.callFake(() => Observable.of())
};
describe('Test: ArisTileTitleWithButtonsComponent:', () => {
  let component: ArisTileTitleWithButtonsComponent;
  let fixture: ComponentFixture<ArisTileTitleWithButtonsComponent>;
  beforeEach(() => {

    TestBed.configureTestingModule({
      declarations: [
        ArisTileTitleWithButtonsComponent,
      ],
      imports: [
        HttpClientModule,
        HttpClientTestingModule,
        RouterModule,
        LocalizationModule,
        CommonModule,
        FormsModule,
        ChartModule,
        ArisPipesModule,
        ArisUiComponentsModule,
      ],
      providers: [ArisTileOverviewService,
        ArisSessionService,
        ArisHeaderService,
        ArisPageService,
        ArisPageDashboardService,
        ArisFilterService,
        InjectorRef, HttpHandler,
            { provide: Router, useValue: mockRouter }, { provide: HttpClient, useClass: MockHttpClient }, { provide: ActivatedRoute, useValue: {
              params: Observable.of({ geoLayerName: "destPage" })
            } }, { provide: ArisNotificationBoxService },
        ArisDataSourceService, ArisPageSectionObservableEventService, ArisPermissionService, ArisConfigService,
        ArisLanguageService, { provide: ToastrService }, { provide: LocaleService }, { provide: TranslationService, useValue: mockTranslationService }
      ]
    }).compileComponents();

    afterAll(() => {
      component = null;
            });
        // create component and test fixture
    fixture = TestBed.createComponent(ArisTileTitleWithButtonsComponent);

        // get test component from the fixture
    component = fixture.componentInstance;

  });

  it('onButtonClick executed', () => {
    let router = TestBed.get(Router);
    component.buttons = [{ targetPage: '' }, { targetPage: '' }];
    component.onButtonClick(1);
    expect(router.navigate).toHaveBeenCalled();
  });

});
