import { Component, Input, Pipe, Directive, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Language } from 'angular-l10n';

@Component({
  selector: 'arisTileTitleWithButtons',
  templateUrl: './aris-tile-title-with-buttons.component.html'
})
export class ArisTileTitleWithButtonsComponent implements OnInit {
  @Input() buttons: any;
  @Input() title: any;
  @Input() logo: any;

  @Language() lang: string;
  constructor(private router: Router) { }

  onButtonClick(index) {
    this.router.navigate([this.buttons[index].targetPage]);
  }

  ngOnInit() {}
}
