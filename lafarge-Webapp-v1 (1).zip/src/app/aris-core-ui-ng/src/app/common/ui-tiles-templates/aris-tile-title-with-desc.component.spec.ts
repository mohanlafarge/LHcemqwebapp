import { ArisTileTitleWithDescComponent } from "./aris-tile-title-with-desc.component";

describe('Test: ArisTileTitleWithDescComponent:', () => {
  let arisTileTitleWithDescComponent = new ArisTileTitleWithDescComponent();

  it('Component created', () => {
    expect(arisTileTitleWithDescComponent).toBeTruthy();
  });
});
