import { Component, Input, OnInit } from '@angular/core';
import { Language } from 'angular-l10n';

@Component({
  selector: 'arisTileTitleWithDesc',
  templateUrl: './aris-tile-title-with-desc.component.html'
})
export class ArisTileTitleWithDescComponent implements OnInit {
  @Language() lang: string;

  @Input() title: any;
  @Input() desc: any;

  constructor() { }

  ngOnInit() {}
}
