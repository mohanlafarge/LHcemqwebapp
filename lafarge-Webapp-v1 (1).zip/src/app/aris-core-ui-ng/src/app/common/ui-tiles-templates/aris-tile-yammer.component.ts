import { Component, Input, OnInit } from '@angular/core';
import { Language } from 'angular-l10n';

@Component({
  selector: 'arisTileYammer',
  templateUrl: './aris-tile-yammer.component.html'
})
export class ArisTileYammerComponent implements OnInit {
  @Input() title: any;

  @Language() lang: string;

  ngOnInit(): void {
    let yam: any = window['yam'];
    yam.connect.embedFeed(window.app.config.application.yammer_config);
  }
}
