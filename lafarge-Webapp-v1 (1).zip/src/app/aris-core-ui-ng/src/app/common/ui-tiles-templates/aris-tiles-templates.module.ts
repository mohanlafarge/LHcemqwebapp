import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { LocalizationModule } from 'angular-l10n';
import { DynamicModule } from 'ng-dynamic-component';

import { ArisTileCustomTemplateComponent } from './aris-tile-custom-template.component';
import { ArisTileTitleWithButtonsComponent } from './aris-tile-title-with-buttons.component';
import { ArisTileTitleWithDescComponent } from './aris-tile-title-with-desc.component';
import { ArisTileYammerComponent } from './aris-tile-yammer.component';
import { ArisTileChartTemplateComponent } from './aris-tile-chart-template.component';
import { ArisTileOverviewComponent } from './aris-tile-overview.component';
import { ArisGdprDescriptionTemplateComponent } from './aris-gdpr-description-template.component';

import { ChartModule } from '../ui-components/chart-module/aris-chart.module';
import { ArisPipesModule } from '../pipes/aris-pipes.module';
import { ArisUiComponentsModule } from '../ui-components/aris-ui-components.module';
import { ArisTileOverviewService } from './services/aris-tile-overview.service';
import { ArisPopUpModule } from '../ui-page-sections/pop-up-module/aris-popup.module';



@NgModule({
  declarations: [
    ArisTileCustomTemplateComponent,
    ArisTileTitleWithButtonsComponent,
    ArisTileTitleWithDescComponent,
    ArisTileYammerComponent,
    ArisTileChartTemplateComponent,
    ArisTileOverviewComponent,
    ArisGdprDescriptionTemplateComponent
  ],
  imports: [
    RouterModule,
    LocalizationModule,
    CommonModule,
    FormsModule,
    ChartModule,
    ArisPipesModule,
    ArisUiComponentsModule,
    ArisPopUpModule,
    DynamicModule.withComponents([
      ArisTileCustomTemplateComponent,
      ArisTileTitleWithButtonsComponent,
      ArisTileTitleWithDescComponent,
      ArisTileYammerComponent,
      ArisTileChartTemplateComponent,
      ArisTileOverviewComponent,
      ArisGdprDescriptionTemplateComponent
    ]),
  ],
  providers: [ArisTileOverviewService],
  exports: [
    ArisTileCustomTemplateComponent,
    ArisTileTitleWithButtonsComponent,
    ArisTileTitleWithDescComponent,
    ArisTileYammerComponent,
    ArisTileChartTemplateComponent,
    ArisTileOverviewComponent,
    ArisGdprDescriptionTemplateComponent
  ],
})
export class ArisTilesTemplatesModule {

}
