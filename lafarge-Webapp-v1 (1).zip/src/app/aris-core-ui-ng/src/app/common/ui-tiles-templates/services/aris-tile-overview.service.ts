import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class ArisTileOverviewService {

  constructor(private httpClient: HttpClient) {
  }

  getTextData(url, tile) {
    return this.httpClient.post('rest/pagemaster/save', tile).toPromise();
  }
}
