export function getApplicationConfig() {
  const applicationConfig = window.app.config.application || {};

  return {
    ...applicationConfig,

    mocks_path: './mocks',
    aris_core_path: '/aris', // As context path is '/aris' thats why this value should be '/aris'

    help_file_download_path: 'help/digitaltwinhelp.pdf',

    yammer_config : {
      container: '.collabyammer',
      network: 'accenture.com',
      feedType: 'group',
      _feedTypeComment: 'can be \'group\', \'topic\', or \'user\'',
      feedId: '4852836',
      _feedIdComment: 'feed ID from the instructions above',
      config: {
        defaultGroupId: 3257958,
        header: false,
        footer: false
      }
    },

    theme: {
      defaultType: 't-arisThemeStarwars',
      defaultColor: 'o-arisThemeDark',
      themeList: [
        {
          name: 'Star Wars Theme',
          class: 't-arisThemeStarwars',
          colorList: [
            { name: 'Dark', class: 'o-arisThemeDark', iconColor: 'rgb(12, 43, 47)' },
            { name: 'Light', class: 'o-arisThemeLight', iconColor: 'rgb(17, 245, 255)' }
          ]
        },
        {
          name: 'Classic Theme',
          class: 't-arisThemeClassic',
          colorList: [
            { name: 'Blue', class: 'o-arisThemeBlue', iconColor: '#43809f' },
            { name: 'Red', class: 'o-arisThemeRed', iconColor: '#802929' },
            { name: 'Green', class: 'o-arisThemeGreen', iconColor: 'green' },
            { name: 'Orange', class: 'o-arisThemeOrange', iconColor: 'orange' },
            { name: 'White', class: 'o-arisThemeWhite', iconColor: 'white' }
          ]
        },
      ]
    },

    timeout: 20000000,

    notifications: {
      timeVisible: 10000,
      closeButton: true,
      maxNumVisible: 3,
      preventDuplicates: true
    },

    autorefresh: {
      available: true,
      defaultValue: true
    },

    localCache: {
      available: true,
      expirationTime: 500 * 60 * 60
    },

    footerConfig: {
      template: '',
      UIElements: { refreshPage: true, editLayout: false, filter: false },
      visibility: true
    },

    headerConfig: {
      links: [
        { id: 'UC1_ID', text: 'UC1', path: '#/page/uc1', icon: 'app/common/resources/img/aris_nav_logo_*.png', permission: 'PERM_VIEW_UC1' },
        { id: 'UC2_ID', text: 'UC2', path: '#/page/uc2', icon: 'app/common/resources/img/aris_nav_logo_*.png', permission: 'PERM_VIEW_UC2' },
        { id: 'UC3_ID', text: 'UC3', path: '#/page/uc3', icon: 'app/common/resources/img/aris_nav_logo_*.png', permission: 'PERM_VIEW_UC3' }
      ],
      logopath: 'app/common/resources/img/acc-top-navbar_*.png',
      logoIcon: 'app/common/resources/img/aris_logo.png',
      logoText: [
        { text: 'Aris', color: 'u-color-cream' },
        { text: 'Platform', color: 'u-color-orange' }
      ],
      altText: 'ARIS CORE',
      template: '',
      UIElements: { All: true },
      visibility: true
    },

    googleAnalytics: {
      disable: false,
      accountId: 'UA-99971998-1',
      applicationId: 'ARIS'
    },

    languages: {
      supported: [
        {
          language: 'LANGUAGE_NAME_ENGLISH',
          icon: './app/common/resources/img/flag_united_kingdom.png',
          locale: 'en-gb',
          lang: 'en'
        },
        {
          language: 'LANGUAGE_NAME_SPANISH',
          icon: './app/common/resources/img/flag_spain.png',
          locale: 'es-es',
          lang: 'es'
        },
        {
          language: 'LANGUAGE_NAME_GERMAN',
          icon: './app/common/resources/img/flag_german.png',
          locale: 'de-de',
          lang: 'de'
        },
        {
          language: 'LANGUAGE_NAME_JAPANESE',
          icon: './app/common/resources/img/flag_japan.png',
          locale: 'ja-jp',
          lang: 'ja'
        }
      ]
    },

    allowedUploadFormats: ['png', 'jpg', 'jpeg', 'bmp', 'gif', 'PNG'],
    tableNames: ['aris_upload_test_table1', 'aris_upload_test_table2', 'aris_upload_test_table3'],
    passwordPattern: '^(?=.*[a-z])(?=.*[A-Z])(?=.*[#$^+=!*()@%&]).{8,}$',  // Password must contain 1 lowercase, 1 Uppercase & 1 special character & must be 8 characters or more
    urlForPasswordChange: 'page/changePassword',
    urlForPasswordReset: '/forgotpassword',
    defaultNumberOfRows: 10,
    cookieAgreementBox: {
      name: 'arisCookieLaw',
      text: 'APP_COOKIE_NOTIFY',
      position: 'bottom',
      file: './assets/cookie/cookiePolicy.pdf'
    }
  };
}
