export function getChartGridMock() {
  const chartGridMock = window.app.config.chartGridMock || {};
  return {
    ...chartGridMock,
    name: "chartGridMock",
    type: "nongeo",
    layout: [
      [{
        getTile(scope, objectScope) {
          scope.buttons = [];
          let button: any;
          button = {};
          button.text = "MENU_GEOSPATIAL_VIEW";
          button.targetPage = "page/geopage";
          scope.buttons.push(button);

          button = {};
          button.text = "MENU_SCHEMATIC_VIEW";
          button.targetPage = "page/wasteWater";
          scope.buttons.push(button);

          return objectScope.getTileTitleWithButtons("CHART_GRID_MOCK_HEAD_TITLE", scope.buttons);
        }
      }],
      [
    //     {
    //       getTile(scope, objectScope) {
    //         let data = { compid: "component1", rows: "9", maxlength: "1000" };
    //         let headerConfig = { tileCss: "o-overview-edit-box", title: "WASTEWATER_PROJECT_REPORTING_OVERVIEW_BOX_TITLE" };
    //         return objectScope.getOverviewTile("col-xs-12 col-sm-6 col-md-6", data, headerConfig);
    //       }
    //     },
         {
          getTile(scope, objectScope) {
            let headerConfig = { tileCss: "o-kpi-main", title: "CHART_GRID_KPI_TITLE" };
            return objectScope.getTemplateTile("col-xs-12 col-sm-12 col-md-4",
             "CHART_GRID_MOCK_KPI_BOX",
              headerConfig,
              undefined,
              scope);
          }
        },
        {
          getTile(scope, objectScope) {
            let options = {
              xAxisAttribute: "functionalAreaName",
              yAxisAttribute: "useCaseId",
              xAxisLabel: "Functional Area",
              yAxisLabel: "Use Case",
              chartTitle: "CHART_GRID_MOCK_BAR_TITLE",
              exportable: true,
              openWindow: true,
              scale: 'ordinal',
              calc: 'count'
            };
            return objectScope.getChartTile(scope, "col-xs-12 col-sm-6 col-md-4", "metaFunctionalArea", "DC_BAR_CHART", options);
          }
        },
        {
          getTile(scope, objectScope) {
            let options = {
              xAxisAttribute: "functionalAreaName",
              yAxisAttribute: "useCaseId",
              xAxisLabel: "Functional Area",
              yAxisLabel: "Use Case",
              chartTitle: "CHART_GRID_MOCK_LINE_TITLE",
              exportable: true,
              openWindow: true,
              scale: 'ordinal',
              calc: 'count'
            };
            return objectScope.getChartTile(scope, "col-xs-12 col-sm-6 col-md-4", "metaFunctionalArea", "DC_LINE_CHART", options);
          }
        }
    //    {
    //       getTile(scope, objectScope) {
    //         let options = {
    //           radius: "120",
    //           innerRadius: 0,
    //           nameAttribute: "contractorCompanyName",
    //           valAttribute: "projectCount",
    //           chartTitle: "WASTEWATER_REPORTING_CONTRACTOR_WORK_CHART_TITLE",
    //           calc: "sameColVal",
    //           exportable: true,
    //           openWindow: true,
    //         };

    //         return objectScope.getChartTile(scope, "col-xs-12 col-sm-6 col-md-4", "contractorworkvolume", "DC_PIE_CHART", options);
    //       }
    //     },
    //     {
    //       getTile(scope, objectScope) {
    //         let options = {
    //           calc: "sameColVal",
    //           xAxisAttribute: "projectCount",
    //           yAxisAttribute: "projectStatus",
    //           xAxisLabel: "WASTEWATER_REPORTING_PROJECT_STATUS_CHART_TITLE",
    //           chartTitle: "WASTEWATER_REPORTING_PROJECT_STATUS_CHART_TITLE",
    //           exportable: true,
    //           openWindow: true,
    //         };

    //         return objectScope.getChartTile(scope, "col-xs-12 col-sm-6 col-md-4", "projectstatus", "DC_ROW_CHART", options);
    //       }
    //     }
    //   ],
    //   [
    //     {
    //       getTile(scope, objectScope) {
    //         return objectScope.getTemplateTile('col-xs-12 col-sm-12 col-md-12', 'AWA_TILE_WASTEWATER_PROJECT_REPORTING_DASHBORD',
    //         undefined, 'projectreportingdashboardtable', scope);
    //       }
    //     }
    //   ]

    // ],

    // filterCategoriesConfig: [
    //   {
    //     datasource: "CIP_ASSET_TREND",
    //     dsList: ["projectreportingdashboardtable", "completedvsplanned", "projectstatus", "contractorworkvolume"],
    //     criterias: [
    //       {
    //         name: "ASSET_NAME",
    //         dsname: "cipAssetDistinctName",
    //         type: "autocompletefield",
    //         op: "in"
    //       },
    //       {
    //         name: "PROJECT_NAME",
    //         dsname: "cipAssetDistinctProject",
    //         type: "autocompletefield",
    //         op: "in"
    //       }
    //     ]
    //   },
    //   {
    //     datasource: "CIP_PROJECT_TREND",
    //     dsList: ["projectstatus"],
    //     criterias: [
    //       {
    //         name: "PROJECT_NAME",
    //         dsname: "cipAssetDistinctProject",
    //         type: "autocompletefield",
    //         op: "in"
    //       },
    //       {
    //         name: "PROJECT_STATUS",
    //         type: "checkbox",
    //         dtype: "xx",
    //         op: "in",
    //         fields: [
    //           "Complete",
    //           "Construction",
    //           "Design",
    //           "Planning"
    //         ]
    //       }
    //     ]
    //   }
    // ],

    // footerConfig: "all",

    // pageConfig: {
    //   permission: "PERM_VIEW_WW"
    // }
    ],
    [
      {
        getTile(scope, objectScope) {
          return objectScope.getTemplateTile('col-xs-12 col-sm-12 col-md-12', 'CHART_GRID_MOCK_DASHBORD',
          undefined, 'metaFunctionalArea', scope);
        }
      }
    ]
  ],
  footerConfig: "all",
    filterCategoriesConfig: [
      {
        datasource: "CIP_ASSET_TREND",
        dsList: ["metaFunctionalArea"],
        criterias: [
          {
            name: "FUNCTIONAL_AREA_NAME",
            dsname: "distinctFunctionalAreaName",
            type: "autocompletefield",
            op: "in"
          },
          {
            name: "USE_CASE_ID",
            dsname: "distinctUseCaseId",
            type: "autocompletefield",
            op: "in"
          }
        ]
      }
    ]
  };
}
