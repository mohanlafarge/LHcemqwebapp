import { ArisDcAreaChartService } from "../common/ui-components/chart-module/services/aris-dc-chart-area.service";
import { ArisDcChartBarService } from "../common/ui-components/chart-module/services/aris-dc-chart-bar.service";
import { ArisDcChartBarLineService } from "../common/ui-components/chart-module/services/aris-dc-chart-bar-line.service";
import { ArisDcChartErrbarService } from "../common/ui-components/chart-module/services/aris-dc-chart-errbar.service";
import { ArisDcLineChartService } from "../common/ui-components/chart-module/services/aris-dc-chart-line.service";
import { ArisDcPieChartService } from "../common/ui-components/chart-module/services/aris-dc-chart-pie.service";
import { ArisDcChartRowService } from "../common/ui-components/chart-module/services/aris-dc-chart-row.service";
import { ArisDcChartScatterService } from "../common/ui-components/chart-module/services/aris-dc-chart-scatter.service";
import { ArisNvd3LineChartService } from "../common/ui-components/chart-module/services/aris-nvd3-line-chart.service";
import { ArisC3LineChartService } from "../common/ui-components/chart-module/services/aris-c3-chart-line.service";
import { ArisDcChartCompositeMultilineService } from "../common/ui-components/chart-module/services/aris-dc-chart-composite-multiline.service";
import { ArisDChartMultilineService } from "../common/ui-components/chart-module/services/aris-dc-chart-multiline.service";
import { ArisSankeyChartService } from "../common/ui-components/chart-module/services/aris-sankey-chart.service";
import { ArisDcChartStkRowService } from "../common/ui-components/chart-module/services/aris-dc-chart-stkrow.service";
import { ArisDcChartCustomBarService } from "../common/ui-components/chart-module/services/aris-dc-chart-custombar.service";
import { ArisDcCustomRowChartService } from "../common/ui-components/chart-module/services/aris-dc-chart-customrow.service";
import { ArisDcStkBarChartService } from "../common/ui-components/chart-module/services/aris-dc-chart-stkbar.service";
import { ArisDcHorizontalErrorBarChartService } from "../common/ui-components/chart-module/services/aris-dc-chart-horizerrbar.service";
import { ArisNvd3BarChartService } from "../common/ui-components/chart-module/services/aris-nvd3-bar-chart.service";
import { ArisC3ChartUptimeService } from "../common/ui-components/chart-harvesting-module/uptime-chart/services/aris-c3-chart-uptime.service";
import { ArisC3GapLineService } from "../common/ui-components/chart-harvesting-module/aris-c3-gap-line-chart/services/aris-c3-gap-line.service";

export function getChartsConfig() {
  const chartsConfig = window.app.config.chartsConfig || {};

  return {
    ...chartsConfig,

    DC_AREA_CHART: {
      service: ArisDcAreaChartService
    },
    DC_BAR_CHART: {
      service: ArisDcChartBarService
    },
    DC_BAR_LINE_CHART: {
      service: ArisDcChartBarLineService
    },
    DC_STACK_BAR_CHART: {
      service: ArisDcStkBarChartService
    },
    DC_STACK_ROW_CHART: {
      service: ArisDcChartStkRowService
    },
    DC_CUSTOM_BAR_CHART: {
      service: ArisDcChartCustomBarService
    },
    DC_CUSTOM_ROW_CHART: {
      service: ArisDcCustomRowChartService
    },
    DC_ERROR_BAR_CHART: {
      service: ArisDcChartErrbarService
    },
    DC_HORIZONTAL_ERROR_BAR_CHART: {
      service: ArisDcHorizontalErrorBarChartService
    },
    DC_LINE_CHART: {
      service: ArisDcLineChartService
    },
    DC_PIE_CHART: {
      service: ArisDcPieChartService
    },
    DC_ROW_CHART: {
      service: ArisDcChartRowService
    },
    DC_SCATTER_CHART: {
      service: ArisDcChartScatterService
    },
    NVD3_LINE_CHART: {
      service: ArisNvd3LineChartService
    },
    C3_LINE_CHART: {
      service: ArisC3LineChartService
    },
    C3_LINE_GAP_CHART: {
      service: ArisC3GapLineService
    },
    C3_UPTIME_CHART: {
      service: ArisC3ChartUptimeService
    },
    DC_COMPOSITE_MULTILINE_CHART: {
      service: ArisDcChartCompositeMultilineService
    },
    DC_MULTILINE_CHART: {
      service: ArisDChartMultilineService
    },
    SANKEY_CHART: {
      service: ArisSankeyChartService
    },
    NVD3_BAR_CHART: {
      service: ArisNvd3BarChartService
    }
  };
}
