// TO DO : The VIS as AWA should extend this configuraiton, see sample from
// C:\02_APP_Projects\AWA\02_Repositories\99-ui-alerts-prototype\aris-core-ui-alerts\src\index.conf.js
// C:\02_APP_Projects\AWA\02_Repositories\99-ui-alerts-prototype\awa-core-ui-alerts\src\index.conf.js
import { getPlatformConfig } from './platform';
import { getEnvironmentConfig } from '../../environments/environment';
import { getApplicationConfig } from './application';
import { getFooterTypesConfig } from './footerTypes';
import { getHeaderTypesConfig } from './headerTypes';
import { getBreadCrumConfig } from './breadCrumbs';
import { getMenuConfig } from './menu';
import { getChartsConfig } from './charts';
import { getTilesConfig } from './tiles';
import { getRestrictedCharacters } from './restrictedCharacters';

import { getLoginConfig } from './login';
import { getSchematicConfig } from './schematic';
import { getGeoConfig } from './geo';

import { getHomeConfig } from './home';
import { getSimulationInProgressPage } from './simulationInProgress';
import { getSimulationResultPage } from './simulationResult';
import { getChartGridMock } from './chartGridMock';
import { getUserAccessManagementConfig } from './userAccessManagement';


/**
 * Return the Local configuration of ARIS
*/
export function getArisLocalConfiguration() {
  console.log("Executing getArisLocalConfiguration");

  window.app.config.platform = getPlatformConfig();
  window.app.config.environment = getEnvironmentConfig();
  window.app.config.application = getApplicationConfig();
  window.app.config.footerTypes = getFooterTypesConfig();
  window.app.config.headerTypes = getHeaderTypesConfig();
  window.app.config.breadCrumConfig = getBreadCrumConfig();
  window.app.config.menu = getMenuConfig();
  window.app.config.chartsConfig = getChartsConfig();
  window.app.config.tiles = getTilesConfig();
  window.app.config.restrictedCharacters = getRestrictedCharacters();

  window.app.config.login = getLoginConfig();
  window.app.config.home = getHomeConfig();
  window.app.config.schematic = getSchematicConfig();
  window.app.config.geo = getGeoConfig();

  window.app.config.simulationInProgress = getSimulationInProgressPage();
  window.app.config.simulationResult = getSimulationResultPage();
  
  window.app.config.chartGridMock = getChartGridMock();
  window.app.config.userAccessManagementConfig = getUserAccessManagementConfig();


}
