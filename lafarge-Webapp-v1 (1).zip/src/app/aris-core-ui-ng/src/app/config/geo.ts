import { ArisGeoMapLayersService } from '../common/ui-page-models/geo-module/services/aris-geo-maplayers.service';
import { WorkOrdersGeoService } from '../prototypes/geo-module/services/aris-geo-workorders.service';
import { SpillIncidentGeoService } from '../prototypes/geo-module/services/aris-geo-spillincident.service';
import { SewerPipesGeoService } from '../prototypes/geo-module/services/aris-geo-sewerpipes.service';
import { MonitoredSewerFacilitySummaryGeoService } from '../prototypes/geo-module/services/aris-geo-monitoredsewerfacilitysummary.service';

export function getGeoConfig() {
  const geo = window.app.config.geo || {};

  return {
    ...geo,

    mapLayersService: ArisGeoMapLayersService,
    geoServerWSName: 'LA',
    footerConfig: 'exceptEditLayout',
    zoom: 9,
    SewerStructures: { latitude: '34.052235', longitude: '-118.243683' },
    SewerPipes: { latitude: '34.052235', longitude: '-118.243683' },
    SewerWyeConnectors: { latitude: '34.052235', longitude: '-118.243683' },
    mapLayersInjectorServices: { workOrders: WorkOrdersGeoService,
      SewerPipes: SewerPipesGeoService,
      spillIncident: SpillIncidentGeoService,
      monitoredSewerFacilitySummary: MonitoredSewerFacilitySummaryGeoService
    },
    geoIcon: 'app/common/resources/img/SchematicIconImage_*.png',
    //mapLayerClusterIconUrl: 'https://raw.githubusercontent.com/googlemaps/js-marker-clusterer/gh-pages/images/m'
    mapLayerClusterIconUrl: 'app/common/resources/img/m'
  };
}
