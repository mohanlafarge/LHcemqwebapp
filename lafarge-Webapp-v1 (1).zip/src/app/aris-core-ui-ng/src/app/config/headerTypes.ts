export function getHeaderTypesConfig() {
  const headerTypes = window.app.config.headerTypes || {};

  return {
    ...headerTypes,

    headerConfig: {
      Standard: {
        UIElements: { All: true },
        visibility: true
      },
      displaynone: {
        UIElements: { All: false },
        visibility: false
      }
    }
  };
}
