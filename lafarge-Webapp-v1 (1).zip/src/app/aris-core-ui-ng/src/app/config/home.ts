import { HomeService } from '../pages/home-module/services/home.service';

export function getHomeConfig() {
  const home = window.app.config.home || {};

  return {
    ...home,
    name: 'home',
    type: 'nongeo',
    pageService:  HomeService,
    layout: [
      [
        {
          getTile(scope, objectScope) {
            let tile: any = {};
            tile.plugin = 'TILE_TYPE_ARIS_HOME_SECOND_ONE_BOX';
            tile.size = 'col-xs-12 col-md-6';
            return tile;
          }
        },
        {
          getTile (scope, objectScope) {
            let tile: any = {};
            tile.plugin = 'TILE_TYPE_ARIS_HOME_SECOND_TWO_BOX';
            tile.size = 'col-xs-12 col-md-6';
            return tile;
          }
        }
      ],
      [
        {
          getTile(scope, objectScope) {
            let tile: any = {};
            tile.plugin = 'TILE_TYPE_ARIS_HOME_THIRD_ONE_BOX';
            tile.size = 'col-xs-12 col-md-6';
            return tile;
          }
        },
        {
          getTile(scope, objectScope) {
            let tile: any = {};
            tile.plugin = 'TILE_TYPE_ARIS_HOME_FIRST_ONE_BOX';
            tile.size = 'col-xs-12 col-md-6';
            return tile;
          }
        }
      ],
      [
        {
          getTile(scope, objectScope) {
            let tile: any = {};
            tile.plugin = 'TILE_TYPE_ARIS_HOME_FIRST_TWO_BOX';
            tile.size = 'col-xs-12 col-md-12';
            return tile;
          }
        }
      ]
    ],
    footerConfig: 'exceptFilters'
  };
}


