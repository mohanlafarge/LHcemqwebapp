export function getLoginConfig() {
  const loginConfig = window.app.config.login || {};

  // Extend property
  return {
    ...loginConfig,
    // clientLogo: 'app/common/resources/img/client-logo.png', Client related Logos
    clientLogo: '',
    // accLogo: 'app/common/resources/img/acn-login-page_*.png',
    accLogo: '',
    appTitle: 'ARIS ANALYTICS DASHBOARD'
  };
}
