export function getMenuConfig() {
  const menuConfig = window.app.config.menu || {};
  const passwordChangeCustomUrl = window.app.config.application.urlForPasswordChange;
  const passwordChangeCustomUrlIsConfigured = ((passwordChangeCustomUrl !== undefined) && (passwordChangeCustomUrl !== ""));

  return {
    ...menuConfig,

    menu_config : [
      {
        text: 'MENU_HOME',
        link: 'page/home',
        icon: 'fa fa-home fa-lg',
        enabled: true
      },
      {
        text: 'MENU_UC1',
        icon: 'fa fa-minus',
        permission: 'PERM_VIEW_UC1',
        subMenuItems: [
          {
            text: 'MENU_DASHBOARD_UC1',
            link: 'page/uc1',
            enabled: true
          },
          {
            text: 'MENU_GEOSPATIAL_VIEW',
            link: 'page/geopage',
            enabled: true
          },
          {
            text: 'MENU_SCHEMATIC_VIEW',
            link: 'page/schematicdiag/LA:arislngschematic',
            enabled: true
          }
        ]
      },
      {
        text: 'MENU_UC2',
        icon: 'fa fa-minus',
        permission: 'PERM_VIEW_UC2',
        subMenuItems: [
          {
            text: 'MENU_DASHBOARD_UC2',
            link: 'page/uc2',
            enabled: true
          },
          {
            text: 'MENU_GEOSPATIAL_VIEW',
            link: 'page/geopage',
            enabled: true
          },
          {
            text: 'MENU_SCHEMATIC_VIEW',
            link: 'page/schematicdiag/LA:arislngschematic',
            enabled: true
          }
        ]
      },
      {
        text: 'MENU_UC3',
        icon: 'fa fa-minus',
        permission: 'PERM_VIEW_UC3',
        subMenuItems: [
          {
            text: 'MENU_DASHBOARD_UC3',
            link: 'page/uc3',
            enabled: true
          },
          {
            text: 'MENU_GEOSPATIAL_VIEW',
            link: 'page/geopage',
            enabled: true
          },
          {
            text: 'MENU_SCHEMATIC_VIEW',
            link: 'page/schematicdiag/LA:arislngschematic',
            enabled: true
          }
        ]
      },
      {
        text: 'MENU_DIGITAL_TWIN',
        icon: 'fa fa-minus',
        permission: 'ROLE_SUPERUSER',
        subMenuItems: [
          // {
          //   text: 'MENU_DIGITAL_TWIN_PREDICTIVE_MODEL_UPLOAD',
          //   link: 'page/dt/predictivemodel/upload',
          //   enabled: true
          // },
          {
            text: 'MENU_DIGITAL_TWIN_PREDICTIVE_MODEL_UPLOAD',
            link: 'page/dt/predictivemodelconfiguration',
            enabled: true
          },
          {
            text: 'MENU_DIGITAL_TWIN_CONFIGURE_SETTINGS',
            link: 'page/dt/setting/management',
            enabled: true
          },
          {
            text: 'MENU_DIGITAL_TWIN_CONFIGURE_AGENTS',
            link: 'page/dt/agent/management',
            enabled: true
          },
          {
            text: 'MENU_DIGITAL_TWIN_CONFIGURE_PROCESS_FLOW',
            link: 'page/dt/processflow/management',
            enabled: true
          },
          {
            text: 'MENU_DIGITAL_TWIN_MANAGE_SIMULATIONS',
            link: 'page/dt/simulation/management',
            enabled: true
          }
        ]
      },
      {
        text: 'MENU_ADMIN_SETTINGS',
        icon: 'fa fa-minus',
        permission: 'ROLE_SUPERUSER',
        subMenuItems: [
          {
            text: 'MENU_EMAIL_LIST',
            link: 'page/emaillist',
            enabled: true
          },
          // {
          //   text: 'MENU_DATASOURCE_MAINT',
          //   link: 'page/datasourcemaint',
          //   enabled: true
          // },
          {
            text: 'MENU_LOGGING_INFORMATION',
            link: 'page/logginginformation',
            enabled: true
          },
          {
            text: 'MENU_USER_GROUP_MANAGEMENT',
            link: 'page/usergroupmanagement',
            permission: 'ROLE_ADMIN',
            enabled: true
          },
          {
            text: 'MENU_GLOBAL_PARAMETERS',
            link: 'page/globalparameters',
            permission: 'ROLE_ADMIN',
            enabled: true
          },
          {
            text: 'MENU_AUDIT_LOG',
            link: 'page/auditlog',
            permission: 'ROLE_ADMIN',
            enabled: true
          },
          {
            text: 'MENU_ASSET_CONFIG_DATA',
            link: 'page/assetconfigdata',
            permission: 'ROLE_ADMIN',
            enabled: true
          },
          {
            text: 'MENU_FILE_UPLOAD',
            link: 'page/fileupload',
            permission: 'ROLE_ADMIN',
            enabled: true
          },
          {
            text: 'MENU_USER_ACCESS_MANGEMENT',
            link: 'page/useraccessmanagement',
            permission: 'ROLE_ADMIN',
            enabled: true
          }
        ]
      },
      {
        text: 'MENU_SUPPORT',
        icon: 'fa fa-weixin fa-lg',
        link: 'https://accentureplc.service-now.com/clientportal'
      },
      {
        text: 'MENU_TERMS_OF_USE',
        icon: 'fa fa-handshake-o',
        link: 'page/legalTerms'
      },
      {
        text: 'MENU_DEV_MENU',
        icon: 'fa fa-minus',
        permission: 'PERM_VIEW_TEST_PAGES',
        subMenuItems: [
          {
            text: 'MENU_TRANSLATE_TEST',
            link: 'page/samplei18n',
            enabled: true
          },
          // {
          //   text: 'Unity - Basic Prototype',
          //   link: 'page/unity/basicprototype',
          //   enabled: true
          // },
          // {
          //   text: 'Unity - Chemical Factory',
          //   link: 'page/unity/chemicalfactory',
          //   enabled: true
          // },
          {
            text: 'MENU_FORM_COMP_GALLERY',
            link: 'page/formcompgallery',
            enabled: true
          },
          {
            text: 'MENU_CHART_GALLERY',
            link: 'page/chartgallery',
            enabled: true
          },
          {
            text: 'MENU_UI_GRID',
            link: 'page/ng2smarttable',
            enabled: true
          },
          {
            text: 'MENU_CHART_GRID_MOCK',
            link: 'page/chartGridMock',
            enabled: true
          },
          {
            text: 'MENU_ANGULAR_GENERIC_TABLE_UI',
            link: 'page/angulargenerictable',
            enabled: true
          },
          {
            text: 'MENU_CHANGE_THEME',
            link: 'page/changeTheme',
            enabled: true
          },
          {
            text: 'MENU_MAIL_TEST',
            link: 'page/arisMailTest',
            permission: 'ROLE_ADMIN',
            enabled: true
          },
          {
            text: 'MENU_SMS_TEST',
            link: 'page/arisSmsTest',
            permission: 'ROLE_ADMIN',
            enabled: true
          },
          {
            text: 'MENU_CACHE_TEST',
            link: 'page/cacheTest',
            enabled: true
          },
          {
            text: 'MENU_GEO_CHARTS_TEST',
            link: 'page/geopage',
            enabled: true
          },
          {
            text: 'Metadata',
            link: 'page/metadatalog',
            permission: 'ACTIVE_PROFILE_LOCAL',
            enabled: true
          },
          {
            text: 'MENU_SWAGGER_UI',
            permission: 'ACTIVE_PROFILE_LOCAL',
            link: 'spring/swagger-ui.html',
            enabled: true
          },
          {
            text: 'MENU_ENDPOINTS',
            permission: 'ACTIVE_PROFILE_LOCAL',
            link: 'rest/endpoints/listurlmappings',
            enabled: false
          },
          {
            text: 'MENU_JVM_METRICS',
            permission: 'ACTIVE_PROFILE_LOCAL',
            link: 'spring/metrics',
            enabled: true
          },
          {
            text: 'MENU_SVG_TEST',
            link: 'page/svgSchematic',
            enabled: true
          },
          {
            text: 'WebSockets',
            link: 'page/websockets',
            enabled: true
          }
        ]
      },
      {
        text: 'MENU_NOTIFICATION_PREFERENCES',
        icon: 'glyphicon glyphicon-cog',
        link: 'page/notificationmanagement',
        enabled: true
      },
      {
        text: 'MENU_ABOUT',
        icon: 'glyphicon glyphicon-info-sign',
        link: 'arisAbout',
        enabled: true
      },
      {
        text: 'MENU_CHANGE_PASSWORD',
        icon: 'glyphicon glyphicon-pencil',
        link: passwordChangeCustomUrl,
        permission: passwordChangeCustomUrlIsConfigured
      },
      {
        text: 'MENU_LOG_OUT',
        icon: 'glyphicon glyphicon-log-out',
        link: 'logout',
        enabled: true
      },
      {
        text: 'MENU_CLOSE',
        icon: 'fa fa-times-circle-o fa-lg',
        link: 'close',
        enabled: true
      }]
  };
}
