export function getPlatformConfig() {
  let platform = window.app.config.platform || {};

    // Extend property
  return {
    ...platform,

    ARIS: './',
    version: '3.2.0'
  };
}
