import { SchematicInfoCardPowerUnitService } from "../prototypes/schematic-module/services/schematic-infocard-powerunit.service";
import { PlantSchematicLayerService } from "../prototypes/schematic-module/services/plant-schematic-layer.service";



export function getSchematicConfig() {
  let schematic = window.app.config.schematic || {};

  // Extend property
  return {
    ...schematic,
    schematicPageConfig: {
      'LA:powerunit': {
        pageTitle: 'ARIS Power Unit Schematic',
        layers: ['powerUnitLayer'],
        mapLayersInjectorServices: [{ powerUnitLayer: SchematicInfoCardPowerUnitService }],
      },
      'LA:arislngschematic': {
        pageTitle: 'ARIS Plant Schematic',
        layers: ['plantSchematicLayer'],
        mapLayersInjectorServices: [{ plantSchematicLayer: PlantSchematicLayerService }],
        markerHyperLinks: { 'Power Unit': '/schematicdiag/LA:powerunit' }
      }

    },
    footerConfig: 'onlyRefreshPage',
    schematicIcon: 'app/common/resources/img/SchematicIconImage_*.png',
  };
}
