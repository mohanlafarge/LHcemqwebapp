export function getSimulationInProgressPage() {
  const simulationInProgress = window.app.config.simulationInProgress || {};

  return {
    ...simulationInProgress,
    name:  "simulationInProgress",
    type:  "nongeo",
    layout: [
      [{
        getTile(scope, objectScope) {
          scope.buttons = [];
          let button = { text: "", targetPage: "" };

          button = { text: "", targetPage: "" };
          button.text = "BTN_BACK";
          button.targetPage = "page/dt/simulation/management";
          scope.buttons.push(button);

          return objectScope.getTileTitleWithButtons("SIMULATION_PROGRESS_TITLE", scope.buttons);
        }
      }],
      [
        {
          getTile(scope, objectScope) {
            return objectScope.getTemplateTile("col-xs-12 col-sm-12 col-md-12", 'TILE_TYPE_DT_SIMULATION_INFO', null);
          }
        }
      ],
      [
        {
          getTile(scope, objectScope) {
            return objectScope.getTemplateTile("col-xs-12 col-sm-12 col-md-12", 'TILE_TYPE_DT_SIMULATION_LOGS', null);
          }
        }
      ]
    ]
  };
}
