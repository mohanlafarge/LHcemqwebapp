export function getSimulationResultPage() {
    const simulationResult = window.app.config.simulationResult || {};

    return {
      ...simulationResult,
      name:  "simulationResult",
      type:  "nongeo",
      /* 'pageModel.avoidSynchTilesHeigthPerRow = true' will allow display tiles with different height in a row */
      avoidSynchTilesHeigthPerRow: true,
      layout: [
        [{
          getTile(scope, objectScope) {
            scope.buttons = [];
            let button = { text: "", targetPage: "" };

            button = { text: "", targetPage: "" };
            button.text = "BTN_BACK";
            button.targetPage = "page/dt/simulation/management";
            scope.buttons.push(button);

            return objectScope.getTileTitleWithButtons("SIMULATION_RESULTS_TITLE", scope.buttons);
          }
        }],
        [
          {
            getTile(scope, objectScope) {
              return objectScope.getTemplateTile("col-xs-12 col-sm-12 col-md-12", 'TILE_TYPE_DT_SIMULATION_INFO', null);
            }
          }
        ],
        [
          {
            getTile(scope, objectScope) {
              return objectScope.getTemplateTile("col-xs-12 col-sm-12 col-md-6", 'TILE_TYPE_DT_SIMULATION_LOGS', null);
            }
          },
          {
            getTile(scope, objectScope) {
              let options = {
                chartTitle: 'SIMULATION_CHART_ROW',
                yAxisLabel: 'Quality Parameter',
                xAxisLabel: 'Standard Deviation',
                calc: 'avg',
                xAxisAttribute: 'value',
                yAxisAttribute: 'key',
                sortable: true,
                sortOrder: "desc",
                exportable: true,
                openWindow: true,
                height: 715
              };
              let datSource = {
                id: 'simulationRowChart',
                responseDataFormat: 'json',
                restPrefix: 'digitaltwin',
                endPoint: 'simulationresult',
                filterData: {
                  criterias: [{
                    name: 'ID',
                    type: 'textfield',
                    op: 'in',
                    val: scope.pageModel.inputFilterData.id
                  }]
                },
                customDataHandler: (currentValue, data) => {
                  let tempData: any = [];
                  console.log(data);
                  let aux: any;
                  if (data !== undefined) {
                    let arrayForKeys: any = [];
                    aux = JSON.parse(data[0].executionResult)[0].standardDeviationLog;
                    aux.forEach((element) => {
                      arrayForKeys.push(element.key);
                    });
                    arrayForKeys = Array.from(new Set(arrayForKeys));
                    for (let i = 0; i < arrayForKeys.length; i += 1) {
                      let arrayForValues: any = [];
                      let tempObj = {};
                      for (let j = 0; j < aux.length; j += 1) {
                        if (arrayForKeys[i] === aux[j].key) {
                          arrayForValues.push(aux[j].value);
                        }
                      }
                      tempObj['key'] = arrayForKeys[i];
                      tempObj['value'] = stanDeviate(arrayForValues);
                      tempData.push(tempObj);
                    }
                  } else {
                    aux = null;
                  }
                  return tempData;

                  function stanDeviate(newValue) {
                    let i;
                    let j;
                    let total = 0;
                    let mean = 0;
                    let diffSqredArr = [];
                    for (i = 0; i < newValue.length; i += 1) {
                      total += newValue[i];
                    }
                    mean = total / newValue.length;
                    for (j = 0; j < newValue.length; j += 1) {
                      diffSqredArr.push(Math.pow((newValue[j] - mean), 2));
                    }
                    return (Math.sqrt(diffSqredArr.reduce((firstEl, nextEl) => {
                      return firstEl + nextEl;
                    }) / newValue.length));
                  }
                }
              };
              return objectScope.getChartTile(scope, "col-xs-12 col-sm-12 col-md-6", datSource, "DC_ROW_CHART", options);
            }
          },
          {
            getTile(scope, objectScope) {
              let options = {
                xAxisAttribute: 'executionTime',
                yAxisAttribute: 'name',
                seriesAttribute: 'resource',
                calc: 'count',
                scale: 'linear' ,
                xAxisLabel: 'SIMULATION_EXECUTION_TIME',
                yAxisLabel: 'SIMULATION_NUMBER_OF_BATCHES',
                chartTitle: 'SIMULATION_CHART_MULTILINE',
                // timeFormatType : '%b %d',
                showLegends: true,
                exportable: true,
                openWindow: true
              };
              let datSource = {
                id: 'simulationMultilineChart',
                responseDataFormat: 'json',
                restPrefix: 'digitaltwin',
                endPoint: 'simulationresult',
                filterData: {
                  criterias: [{
                    name: 'ID',
                    type: 'textfield',
                    op: 'in',
                    val: scope.pageModel.inputFilterData.id
                  }]
                },
                customDataHandler: (currentValue, data) => {
                  console.log(data);
                  let aux: any;
                  if (data !== undefined) {
                    aux = JSON.parse(data[0].executionResult)[0].basicLog;
                    aux.forEach((element) => {
                      element.executionTime = Math.floor(element.end_time / 60) * 60;
                    });
                  } else {
                    aux = null;
                  }
                  return aux;
                }
              };
              return objectScope.getChartTile(scope, "col-xs-12 col-sm-12 col-md-12", datSource, "DC_MULTILINE_CHART", options);
            }
          }
        ]
      ]
    };
}
