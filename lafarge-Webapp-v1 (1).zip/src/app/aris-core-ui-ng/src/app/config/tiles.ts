// PREDEFINED ARIS TILES
import { ArisTileTitleWithDescComponent } from '../common/ui-tiles-templates/aris-tile-title-with-desc.component';
import { ArisTileTitleWithButtonsComponent } from '../common/ui-tiles-templates/aris-tile-title-with-buttons.component';
import { ArisTileCustomTemplateComponent } from '../common/ui-tiles-templates/aris-tile-custom-template.component';
import { ArisTileYammerComponent } from '../common/ui-tiles-templates/aris-tile-yammer.component';
import { ArisTileChartTemplateComponent } from '../common/ui-tiles-templates/aris-tile-chart-template.component';
import { ArisTileOverviewComponent } from '../common/ui-tiles-templates/aris-tile-overview.component';
import { ArisGdprDescriptionTemplateComponent } from '../common/ui-tiles-templates/aris-gdpr-description-template.component';

// PREDEFINED APPLICATION TILES
// HOME
import { ArisUseCaseFirstOneBoxComponent } from '../pages/home-module/tiles/aris-use-case-first-one-box.component';
import { ArisUseCaseFirstTwoBoxComponent } from '../pages/home-module/tiles/aris-use-case-first-two-box.component';
import { ArisUseCaseSecondOneBoxComponent } from '../pages/home-module/tiles/aris-use-case-second-one-box.component';
import { ArisUseCaseSecondTwoBoxComponent } from '../pages/home-module/tiles/aris-use-case-second-two-box.component';
import { ArisUseCaseThirdFirstBoxComponent } from '../pages/home-module/tiles/aris-use-case-third-first-box.component';
import { ArisUseCaseThirdSecondBoxComponent } from '../pages/home-module/tiles/aris-use-case-third-second-box.component';

// DIGITAL TWIN
import { ArisDtSimulationInfoTileComponent } from '../pages/digital-twin-module/simulation-common/components/aris-dt-simulation-info-tile.component';
import { ArisDtSimulationLogsComponent } from '../pages/digital-twin-module/simulation-common/components/aris-dt-simulation-logs.component';

// PROTOTYPE - SAMPLE GRID/CHART WITH FILTER
import { ChartGridKpiBoxComponent } from '../prototypes/chart-grid-mock/component/chart-grid-mock-kpi-box.component';
import { ChartGridMockDashbordComponent } from '../prototypes/chart-grid-mock/component/chart-grid-mock-dashbord.component';


export function getTilesConfig() {
    const tiles = window.app.config.tiles || {};

    // Extend property
  return {
    ...tiles,
    
    // ARIS PREDEFINED TILES
    'TILE_TYPE_TITLE_WITH_DESC': ArisTileTitleWithDescComponent,
    'TILE_TYPE_TITLE_WITH_BUTTONS': ArisTileTitleWithButtonsComponent,
    'TILE_TYPE_CUSTOM_TEMPLATE': ArisTileCustomTemplateComponent, 
    'TILE_TYPE_YAMMER': ArisTileYammerComponent,
    'TILE_TYPE_CHART': ArisTileChartTemplateComponent,
    'TILE_TYPE_OVERVIEW_EDIT': ArisTileOverviewComponent,
    'TILE_TYPE_GDPR_TEMPLATE': ArisGdprDescriptionTemplateComponent,

    // HOME PAGE TILES
    'TILE_TYPE_ARIS_HOME_FIRST_ONE_BOX': ArisUseCaseFirstOneBoxComponent,
    'TILE_TYPE_ARIS_HOME_FIRST_TWO_BOX': ArisUseCaseFirstTwoBoxComponent,
    'TILE_TYPE_ARIS_HOME_SECOND_ONE_BOX': ArisUseCaseSecondOneBoxComponent,
    'TILE_TYPE_ARIS_HOME_SECOND_TWO_BOX': ArisUseCaseSecondTwoBoxComponent,
    'TILE_TYPE_ARIS_HOME_THIRD_ONE_BOX': ArisUseCaseThirdFirstBoxComponent,
    'TILE_TYPE_ARIS_HOME_THIRD_TWO_BOX': ArisUseCaseThirdSecondBoxComponent,

    // DTWIN SIMULATION TILES
    'TILE_TYPE_DT_SIMULATION_INFO': ArisDtSimulationInfoTileComponent,
    'TILE_TYPE_DT_SIMULATION_LOGS': ArisDtSimulationLogsComponent,

    // PROTOTYPE - SAMPLE GRID/CHART WITH FILTER
    'CHART_GRID_MOCK_KPI_BOX': ChartGridKpiBoxComponent,
    'CHART_GRID_MOCK_DASHBORD': ChartGridMockDashbordComponent

  };
}
