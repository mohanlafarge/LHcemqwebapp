export function getUserAccessManagementConfig(): any {
  return {
    pageTitle: "USER_ACCESS_MANAGEMENT_TITLE_PAGE_USER_ACCESS_CONTROL",
    groupTypes: {
      groupType1: "Asset",
      groupType2: "Functional Area"
    },
    prefernceParameterName: {
      landingPage: "Default Landing Page"
    },
    defaultPermission: "PERM_VIEW_UC1"
  };
}
